# Desktop: модель окон и вкладок проектов

Исследование VS-18 от 13.11.2026, checkout `D:\VoxariumStudio`, HEAD `4623cb2`. Исследование завершено после согласования пользователем правил (§10); техническая модель остаётся рекомендацией для отдельного плана реализации на утверждение, а не описанием уже реализованных вкладок. Код/spec не изменялись, сервер и Electron не запускались и не перезапускались. Доказательства исходного прохода относятся к указанной ревизии, а не к проверке установленного процесса.

## 1. Вывод и границы

Рекомендуется **один Electron main process, несколько BrowserWindow-оболочек, отдельный живой WebContentsView на вкладку проекта**. Перенос меняет владельца того же view, а не открывает проект заново. Единственный backend остаётся на `http://127.0.0.1:8765`; запуск отдельного backend для окна или вкладки исключён.

Главная предпосылка — **сквозная адресация проекта в запросах и событиях**. Backend уже держит несколько AppContext, но REST и браузерная шина всё ещё выбирают проект глобально. Поэтому одних изменений Electron недостаточно: два окна с нынешней SPA не обеспечат два независимых проекта.

Все продуктовые вопросы закрыты ответом пользователя в review VS-18. Обязательны единственная вкладка проекта во всём приложении, живой перенос без reload, drag-out/команда отделения/межоконный DnD, фоновые задачи после закрытия UI, last-window → tray, восстановление топологии/страниц после перезапуска, изолированная legacy-совместимость и проектные уведомления (§10). Сверка с завершёнными VS-17 ([[desktop-tabs/project-isolation]]) и VS-03 выполнена; сохранение фоновых задач VS-03 — готовая основа, не повторная разработка.

## 2. Доказательная база текущего состояния

Сначала выполнены запросы Graphify к `D:\VoxariumStudio\graphify-out\graph.json` (12399 узлов), затем прочитаны актуальные исходники по найденным адресам. Использованы, в частности, `query "Electron desktop BrowserWindow main.cjs preload IPC project switching frontend shell tests"`, `explain "open_project"`, запросы по workspace, WS, plugin assets и тестам. Граф служил навигацией, а не доказательством исполнения; номера строк ниже относятся к прочитанному checkout.

| Область | Что подтверждено | Источник |
| --- | --- | --- |
| Основное окно | Одна переменная window, один основной BrowserWindow и отдельный splash. Вкладок нет | `desktop/main.cjs:18,127–138` |
| Единый backend | Точный origin :8765; совместимый backend переиспользуется; запуск через штатный run.ps1 с instance/stop-file | `desktop/policy.cjs:1`; `desktop/main.cjs:46–109,195` |
| Один экземпляр приложения | Второй запуск фокусирует существующее окно, а не создаёт независимый main process | `desktop/main.cjs:200–202`; `desktop/tray.cjs:25–27` |
| Многопроектная работа backend | Контексты resident, при возврате переиспользуются, все завершаются при shutdown сервера | `backend/voxarium_studio/core/workspace.py:55–70,109–119` |
| Глобальный UI-проект | Switch меняет state.ctx, forwarding и общую replay history; публикует project.opened | `backend/voxarium_studio/core/workspace.py:120–134` |
| REST и WS | Ctx берётся из app.state.ctx; /ws использует общую browser_bus; /ws/collab выбирает ctx при подключении | `backend/voxarium_studio/api/deps.py:10–14`; `backend/voxarium_studio/ws/routes.py:23–60` |
| Reload при смене проекта | SPA перезагружает и инициатора, и другие браузерные вкладки; этим сбрасываются plugin routes и WS state | `frontend/src/stores/session.ts:179–214` |
| Frontend isolation | Один Vue/Pinia/router на renderer; API без project scope, singleton /ws | `frontend/src/main.ts:22–24`; `frontend/src/api/client.ts:146–172`; `frontend/src/ws/connection.ts:29–55,177` |
| Нынешний window.open | Внутренний URL открывается в текущем окне; новое окно запрещается | `desktop/main.cjs:177–180` |
| Закрытие | Owned-окно после подтверждения вызывает общий quit; window-all-closed также вызывает quit | `desktop/main.cjs:182–214` |

Прочитаны `AGENTS.md` и релевантные части `docs/voxarium-studio-dev-spec.md`: §2.7, §5.1–5.2, §6.1, §11.2, §16.4. Спецификация сейчас явно описывает один UI-проект и одно окно (`170–189,357–374`), а не независимые desktop-вкладки.

**Выявленное расхождение документации:** абзац AGENTS.md о runtime switch ещё говорит об удалении старого AppContext и переносе event bus. Текущий код и dev spec §5.1 уже сохраняют старые контексты; локальные шины проектов отдельные, постоянна browser_bus. В дальнейшем следует согласованно уточнить AGENTS.md и спецификацию, не возвращать старую shutdown-модель по устаревшему описанию. В VS-18 они не редактировались.

## 3. Рекомендуемая объектная модель

### 3.1 Владельцы

- **AppController, main:** один backend ownership, startup/version checks, updater, tray, сохранение/восстановление топологии и явный глобальный выход. Single-instance lock сохраняется; разные окна принадлежат этому main process. Реестр canonical root → tabId единственный на всё приложение; повторные/одновременные открытия активируют одну вкладку и её окно.
- **WindowRecord:** windowId, BrowserWindow, shell webContents, упорядоченные tabId, activeTabId, геометрия, lifecycle/revision.
- **TabRecord:** tabId, подтверждённая backend-привязка проекта, canonical root/projectKey, WebContentsView, ownerWindowId, project-relative page descriptor, loading/ready/crashed/closing, transfer generation. TabId — техническая идентичность живой вкладки, не разрешение иметь несколько вкладок проекта.
- **Shell renderer:** только заголовок, tab strip, window controls, индикаторы и UI ошибок/пустого окна. Не запускает session store проекта, его WS и плагины.
- **Project renderer:** существующая SPA со своей Pinia/router/WS/plugin cache. Проект привязывается при создании и не меняется при активации или переносе вкладки.

BrowserWindow.webContents должен с самого начала содержать shell, а проекты — дочерние WebContentsView. Не следует сначала помещать проект в основной contents окна, а при отделении пытаться «вытащить» его оттуда. Main хранит сильные ссылки и проверяет инвариант: живой tab имеет одного владельца, одно view и один contents; один view не показывается одновременно в двух окнах.

В checkout закреплён Electron **45.1.0** (`desktop/package.json:19`). [Документация этой версии](https://raw.githubusercontent.com/electron/electron/v45.1.0/docs/api/web-contents-view.md) подтверждает WebContentsView и ограничение одного представления для adopted contents. [View API](https://www.electronjs.org/docs/latest/api/view) даёт addChildView/removeChildView. Это обосновывает направление, но не доказывает безошибочный межоконный перенос в настоящем приложении.

Альтернатива — BaseWindow плюс отдельные shell-view и project-views. Она делает composition явнее, но требует больше изменений нынешних обращений к window.webContents; для постепенного перехода рекомендуется BrowserWindow-shell. Один SPA с несколькими «вкладочными компонентами» менее предпочтителен: придётся разнести module singletons, router, plugin routes, WS и локальное состояние, а межоконный перенос станет сериализацией и remount.

### 3.2 Видимость и ресурсы

Активный project-view занимает клиентскую область ниже shell; неактивные остаются живыми, но не принимают ввод и не перекрывают shell. Переключение меняет attach/visibility, bounds и focus; не выполняет loadURL, reload, смену route или remount. Конкретный способ parking скрытых view и влияние фонового throttling надо проверить на 45.1.0.

Содержимое native view нельзя считать обычным DOM внутри shell: dropdown вкладок, меню, tooltip и модальные слои не должны оказываться под ним. Геометрию и временное перекрытие контролирует main; координаты вычисляются в DIP, с учётом resize/maximize/DPI. Полоса системного перетаскивания окна и интерактивная no-drag область вкладок должны быть разделены.

## 4. Открытие проектов и маршрутизация на одном порту

### 4.1 Обязательная техническая часть

Рекомендуется отделить **ensure/open context** от **выбора legacy UI-проекта**. Создание desktop-вкладки получает/переиспользует resident AppContext, не меняя глобальный state.ctx для остальных клиентов. Новая вкладка публикуется как готовая только после успешных startup и frontend bootstrap; при ошибке существующие вкладки не меняются. Нынешнее правило «новый context стартует до смены выбранного» сохраняется (`workspace.py:82–88,111–118`).

Предлагаемый wire shape, ещё не существующий API:

- Как в VS-17 §4.2, предлагается `POST /api/projects/open` с path/create: реестр выдаёт opaque runtime `project_id` и canonical root без смены legacy selection; epoch позволяет обнаружить устаревший handle после restart. Это технический механизм, не новый пользовательский вопрос.
- `/api/projects/{project_id}/…` обслуживает проектные REST, uploads, streams и raw resources.
- `/ws/projects/{project_id}` и `/ws/projects/{project_id}/collab` привязываются к конкретной локальной шине/контексту до подписки; клиентская навигация — `/p/{project_id}/…`, как предложено в VS-17.
- Глобальные operations — health/version, application settings, recent list, управление экземпляром — не получают случайно project scope. Совместимость прежних URL должна быть явно описана в спецификации.
- SPA bootstrap и router base несут project binding; project_id нельзя незаметно заменить query-параметром после mount. Неизвестный/устаревший ID даёт явную ошибку, **не fallback на state.ctx**. Binding фиксируется на всё время HTTP/stream/background continuation или WS handshake; late responses проверяются по своей generation до применения.

Это предлагаемая форма адресации, а не требование добавить новый сервер. Не применять «перед каждым запросом глобально выбрать проект»: запросы, streams и async saves перекрываются, mutex вокруг переключения UI не обеспечивает их изоляцию.

Одного HTTP-заголовка недостаточно. Scope нужен для img/src, скачиваний, вложений, dynamic import JS/CSS/грамматик/previewers, raw-file URLs, обоих WS и plugin runtime. Сейчас plugin assets выбираются через Ctx (`backend/voxarium_studio/api/plugins.py:201–224`), компонентный кэш — по URL (`frontend/src/plugin-runtime/loader.ts:58–81`). Один pluginId в A и B может соответствовать разным ресурсам.

WS hello и resync должны подтверждать project identity/generation; replay cursor относится к своей шине. Предпочтительна отдельная подписка на ctx.bus для каждой вкладки, а не передача всех проектов всем клиентам с фильтрацией только во frontend. Legacy `/api/…`, `/ws`, `/ws/collab` и `POST /api/project/open` сохраняют прежний wire shape и browser selection как отдельный compatibility-adapter (VS-17 §4.4). Desktop использует только scoped contract: legacy `project.opened` не перезагружает и не перепривязывает его вкладки, а desktop activation/open/restore не меняет browser selection. Нынешние reload-handlers session store применяются только в legacy-режиме. Намеренно глобальные application settings остаются общими.

### 4.2 Пользовательский поток

1. Open/recent/browse вызываются в shell; папка проверяется backend, путь канонизируется до сравнения identities, включая регистр/алиасы Windows. Точное имя проекта не является его identity.
2. При пользовательском открытии существующий preflight `create:false` и ответ 409 для неинициализированной папки сохраняются; создание .voxarium_studio требует отдельного подтверждения (`api/project.py:143–162`; dev spec §5.1). При автоматическом restore недоступный/неинициализированный root остаётся явной ошибкой, без неявного create или подстановки другого проекта.
3. Пока проект открывается, shell показывает pending/error, не заменяя живой renderer другого проекта. Повторные open одного root сериализуются/coalesce на уровне реестра.
4. Новая вкладка создаёт новый project renderer; выбор другой уже открытой вкладки только активирует её.
5. Повторное открытие атомарно находит единственную вкладку проекта во всём приложении, активирует её и показывает/фокусирует окно-владелец. Гонка из нескольких окон не создаёт дубль, включая момент transfer/restore. Если вкладка закрыта, создаётся одна поверх resident context без перезапуска задач.
6. Отделение и перенос не вызывают /api/project/open и launcher. Все URL продолжают идти на :8765.

Общую Chromium session можно сохранить, но project-specific localStorage keys необходимо изолировать по стабильному projectKey, а не transient runtime handle. Общие token и пользовательские предпочтения не следует автоматически дублировать по проектам. Отдельные session partitions сами по себе не решают глобальный state.ctx и не заменяют API scope.

## 5. Drag-and-drop и отделение в новое окно

### 5.1 Перенос — транзакция main process

1. Shell начинает drag конкретного tabId. Main проверяет владение и выдаёт короткоживущий одноразовый token, связанный с source, tab и revision.
2. Payload DnD содержит только этот token и версию формата. URL, path, полномочный webContentsId, JS или файловый drop не являются командой переноса.
3. Target shell показывает insertion marker и при drop передаёт token и позицию. Main проверяет оба зарегистрированных shell, актуальность token, принадлежность вкладки, target, индекс и отсутствие close/другого transfer.
4. Main фиксирует состояние transferring и прежние owner/index/active/bounds. Пока операция идёт, конфликтующие команды для tab/window сериализуются или отклоняются.
5. Удерживая тот же view, main снимает его с source contentView и добавляет в target, проверяет attach/bounds и готовность target. До успешного attach ACK source остаётся логическим владельцем в transferring-state. Ни close, ни destroy, ни reload/loadURL не вызываются.
6. После attach ACK main атомарно меняет owner в registry, применяет активность/focus/window state/attention и завершает commit. Обе оболочки получают новое состояние с revision; token погашается, сохраняется новая согласованная топология. Только затем можно убрать опустевший source; это служебное закрытие окна не вызывает quit/shutdown и не стирает запись уже перенесённой вкладки.
7. При ошибке до commit — rollback в source с прежним порядком/активностью. Если target исчез, вкладка остаётся/возвращается в живой source; если исчез и source, main удерживает view и показывает recovery shell. Нельзя уничтожать последний живой экземпляр для «повторной загрузки».

При reorder внутри окна используется тот же registry, без reparent/navigation. Создание нового окна для detach сначала готовит shell и проверяет target; создание/загрузка shell не должна выгружать вкладку-источник. Открытые нативные модальные диалоги и незавершённое закрытие должны временно блокировать transfer с понятной причиной, а не менять parent посреди операции.

### 5.2 Согласованные жесты и отмена

Обязательны три способа: **drag-out вкладки за пределы окна → новое окно**, команда **«Отделить в новое окно»** и **DnD на полосу вкладок существующего окна Studio**. Команда — самостоятельный доступный способ, не замена обязательному drag-out. Новый target для drag-out создаётся в том же main process; операция использует ту же транзакцию §5.1.

HTML DnD может обслуживать tab strip → tab strip, но реальный межоконный drag и tear-out надо доказать на Windows/Electron 45.1.0. Нативный drag файлов не является API вкладок. Нужна main-coordinated drag session, различающая подтверждённое отпускание вне окна, drop в зарегистрированную полосу и отмену/Escape; нельзя трактовать любое dragend/dropEffect=none как создание окна. Конкретный механизм input capture/hit-testing и граница target выбираются в отдельном техническом плане и native spike, а не возвращаются пользователю как повторное согласование жеста.

Escape, отмена системой, неподдерживаемая цель и техническая ошибка оставляют вкладку в источнике без reload. Успешный drag-out создаёт ровно одно новое окно; drop на существующую полосу не создаёт дополнительное. Перенос целого окна не входит в требование. Программная команда «Перенести в окно…» может быть предложена в будущем плане как клавиатурная альтернатива, но не добавляется этим исследованием как отдельное обязательное UI-решение.

Поддельный/повторный/просроченный token, внешний файловый drop и drop в чужой экземпляр/профиль Studio отклоняются без изменения владельца. Поддерживаемое «другое окно Studio» — окно того же main process, не импорт живого renderer между независимыми процессами.

## 6. Сохранность состояния: что можно обещать

Сохранность при **живом переносе** — обязательный контракт: сохраняются интерфейс, тексты, вложения, редакторы и страница. Восстановление **после перезапуска** ограничено проектами, окнами, порядком вкладок и страницами (§6.1); несохранённые черновики/вложения после выхода или сбоя не входят. Ни URL, ни Pinia snapshot не заменяют живой редактор при переносе.

| Состояние | Основание в текущем frontend | Ожидание при живом переносе без navigation | После уничтожения renderer сейчас |
| --- | --- | --- | --- |
| Explorer selection/expanded/clipboard | `stores/explorer.ts:101–119`; `views/ExplorerView.vue:64–77` очищает URL selection | Сохранить тот же store и DOM | Не восстановить полностью из URL |
| Документ, caret, undo, collab identity | `lib/collab/session.ts:102–133,186–202`; `views/DocsView.vue:136–143,381–405` | Тот же editor/Y.Doc/session; чистый документ не записывается из-за переноса | Markdown не восстанавливает history/caret; новая room/session |
| Unsaved pipeline canvas | `views/PipelineEditorView.vue:70–85,349–367` | Сохранить component-local nodes/edges/dirty | Несохранённая часть не гарантирована |
| Chat draft и выбранные файлы | `components/chat/ChatWidget.vue:193–218,351–358` | Сохранить draft, File objects, uploads | Текст частично persisted с debounce 250 ms; attachment drafts в памяти |
| Pending HTTP/WS | `ws/connection.ts:29–55`; `api/client.ts:146–172` | Один completion, та же подписка/cursor | Новое соединение/ресинхронизация |
| Plugin-private состояние | `plugin-runtime/loader.ts:58–105`; `plugin-runtime/index.ts:91–129` | Не remount и не повторный import/bootstrap | Универсального recovery нет |

Сохранение перечисленного при живом переносе — **принятое требование**, однако возможность выполнить его предложенным primitive ещё **не подтверждена native-тестом**. Размер окна может поменять layout; focus/IME и системные меню требуют отдельной проверки даже при том же contents. Same-origin webContents не означают гарантированно разные OS renderer processes.

Обычная смена раздела тоже не равна переносу: `AppShell.vue:39–45` использует RouterView без KeepAlive, поэтому один renderer не сохраняет все когда-либо посещённые component-local страницы. Тесты документа, pipeline и чата надо выполнять отдельными проходами, а не ожидать, что несохранённый pipeline переживёт уход на Documents.

Риски persisted drafts уже есть: `stores/chat.ts:67–88` использует draft по chat ID и общий new draft; `TaskDetail.vue:117–135,150–178` — task ID без project root. Копии проектов с одинаковыми ID могут смешивать черновики. Document folds (`stores/docs.ts:415–442`) и graph layout (`DocsGraphView.vue:277–280`) уже root-scoped; их подход можно переиспользовать.

При настоящем закрытии предлагаемая prepare-close проверка dirty state/сохранения с ACK относится к безопасному завершению текущих редакторов, а не к восстановлению черновиков после выхода/сбоя. Vue onBeforeUnmount не гарантирует завершения save при закрытии contents или hard reload; debounce и конфликтный save Documents это особенно подчёркивают (`BlockEditor.vue:264–275,397–431,499–503`; `stores/docs.ts:778–830`). Нельзя обещать recovery несохранённого текста после crash. Перенос не должен запускать leave/flush/unmount ради имитации сохранности.

Dev spec §16.4 остаётся неизменяемым ограничением: Yjs room не хранится на диске, Markdown — единственный persisted формат; открытие документа ничего не пишет. Сериализовать Y.Doc как новый формат «состояния вкладки» нельзя.


### 6.1 Восстановление топологии и страниц после перезапуска

Обязательное восстановление согласовано с VS-17 §4.6: проекты, окна, порядок вкладок и открытые страницы. Предлагается один application-local manifest `user_config_dir()/desktop-session.json` и модуль `desktop/session-state.cjs`. Не создавать вторую конкурирующую базу топологии в Electron userData или managed-project config; профиль Chromium остаётся в своём нынешнем месте.

Manifest хранит version, canonical roots, группировку/порядок окон, порядок/активную вкладку и project-relative page descriptor; геометрия окон может быть техническим metadata с проверкой доступных мониторов. Не хранить секреты, auth tokens, runtime project_id, bridge secrets, старые WS cursors/epoch, Yjs или эфемерные вложения. Root — durable locator для restore, runtime id заново получается у backend; стабильный UUID в папке проекта и поиск перемещённых проектов не требуются.

Запись — атомарным snapshot после согласованных open/reorder/transfer/page changes; cancelled transfer не попадает в manifest. При явном выходе сохраняется последняя топология **до** служебного teardown, чтобы тот не затёр её пустым списком. После crash используется последний успешно записанный согласованный snapshot; восстановление каждого последнего действия и несохранённых черновиков не обещается.

Page descriptor должен отражать фактически открытую страницу/объект, а не только текущую строку URL: Explorer и Tasks могут потреблять и удалять query (VS-17 §3.3). Нужна явная сериализация project-relative route/target и его публикация main; содержимое редакторов в этот descriptor не входит.

Restore повторно разрешает roots, дедуплицирует до создания renderer, получает новые runtime handles и открывает сохранённые страницы без изменения legacy browser selection. Недоступная папка/цель даёт ошибку именно своей записи: не создавать молча новый проект, не угадывать root по имени и не подставлять активный проект. Работоспособность ссылок после перемещения папки исключена пользователем. UI restore не восстанавливает остановленные живые агентские процессы; VS-03 продолжает сохранять их лишь пока backend работает.

## 7. IPC и безопасность

Сохраняются nodeIntegration=false, contextIsolation=true, sandbox=true, webSecurity=true (`desktop/main.cjs:136–137`). Preload остаётся узким API без generic invoke/send, Node, arbitrary file/URL execution. Подписки не передают renderer объект IPC-event и имеют unsubscribe (`desktop/preload.cjs:1–33`).

**Нынешние однооконные места нельзя просто зарегистрировать второй раз:**

- `desktop/window-controls.cjs:5–31`: глобальный studio:window handler захватывает одно window, а closed удаляет handler.
- `desktop/startup.cjs:12–21`, `desktop/updates.cjs:56–67`: аналогичная привязка handler/state к одному окну.
- `desktop/policy.cjs:11–23`: handlers ставятся на session, но разрешают только один замкнутый contents; повторная регистрация на общей session заменит политику первой вкладки.
- `desktop/tray.cjs:2–33`: один window, cleanup при его закрытии.

Рекомендуемый контракт:

| Инициатор | Разрешённые операции | Проверки main |
| --- | --- | --- |
| Shell | Snapshot/subscription своего окна, open/activate/reorder/close/detach, begin/drop/cancel transfer | Зарегистрированный contents роли shell, его mainFrame, точный origin, owner, revision, типы/размеры payload |
| Project view | Получить собственный bootstrap, сообщить dirty/title/attention, ответить prepare-close | contents → tab из main registry; renderer не назначает себе tabId/project/root/owner |
| Window controls | Свернуть/развернуть/закрыть своё текущее окно | Target вычисляется по registry, не по переданному windowId |
| App services | Locale, startup, update state/install | Один handler/service на приложение, allowlist действий; global confirmation для install/quit |

Source shell не получает бессрочное право управлять переданной вкладкой. После commit target разрешён, source — нет; повторный token и устаревшая revision не работают. Project renderer не получает shell-capability только потому, что перешёл на /desktop-shell: роль принадлежит main registry. Такие проверки соответствуют [Electron IPC sender validation](https://www.electronjs.org/docs/latest/tutorial/security#17-validate-the-sender-of-all-ipc-messages).

Permissions устанавливаются один раз на session с allowlist всех живых зарегистрированных contents и main-frame/origin проверкой; closed/destroyed исключаются. Разрешено только нынешнее clipboard-sanitized-write, чтение буфера/прочие permissions остаются запрещёнными. Политику navigation/redirect/window.open надо применять ко всем project-views и shell: внешние HTTP(S)/mailto — системному браузеру, остальные схемы — запрет. Внутренние ссылки проекта не должны перепривязывать его к другому проекту или превращаться в shell.

Project scope — защита от перепутывания данных, **не RBAC и не plugin sandbox**. Все проекты доступны доверенному локальному экземпляру; принятую модель доверия dev spec §9.4 и §14 эта работа не расширяет.

## 8. Жизненный цикл, уведомления и ошибки

### 8.1 Закрытие, tray и явный выход

Принято пользователем: **close-tab и close-window не останавливают задачи; последнее окно оставляет Studio в трее**. Контексты по VS-03 живут до shutdown backend, независимо от числа вкладок; запрещены eviction/cancel/AppContext.shutdown из-за закрытия или переноса UI. Закрытие вкладки удаляет её surface, закрытие окна закрывает его вкладки, но не их работу. Перенос не является закрытием вкладки.

Нынешние `window-all-closed → app.quit()`, window-owned tray cleanup и общий quit из close одного окна необходимо изменить в будущей реализации. Tray, app-scoped IPC и backend ownership переживают ноль окон. После закрытия последнего окна команда трея/повторный запуск должны показывать доступный shell, не создавать второй процесс/backend; при нуле открытых вкладок shell может быть пустым. Не надо путать пользовательское закрытие вкладок с перезапуском: restore восстанавливает сохранённую топологию, а не специально закрытые ранее вкладки.

**Явная команда «Выход» завершает приложение, с предупреждением при активных задачах всех resident проектов**, включая не имеющие вкладок. Отмена ничего не останавливает; подтверждение использует общий защищённый shutdown. Backend ownership/stop-file/Windows Job Object остаются app-level. Независимо запущенный backend не присваивается и не завершается; app-owned backend останавливается один раз. Текст предупреждения учитывает фоновые проекты; отсутствие активных задач не требует предупреждения об их остановке.

Close/quit barrier для текущих dirty editor и ошибок сохранения — техническая защита, а не обещание восстановить черновики после выхода/сбоя. Операции закрытия сериализуются с transfer; закрытие source после commit не уничтожает перенесённый view и не останавливает backend. Updater остаётся глобальным, учитывает фоновые проекты, проходит подтверждение и не устанавливает обновление после неудачной остановки.

### 8.2 Проектные уведомления

Принято: **уведомление помечено проектом; клик открывает нужные вкладку/окно; общего центра уведомлений не добавляется** (VS-17 §4.6). Payload должен нести project identity/root locator и project-relative target, не только голые task/chat id или route. Источник события — конкретный проект, а не выбранная сейчас вкладка или legacy selection.

Клик атомарно находит единственную вкладку проекта, активирует страницу-цель, показывает/фокусирует её окно; если вкладка закрыта, создаёт её поверх resident context без перезапуска задачи. Это работает при активном B, скрытом окне A и при нуле окон/жизни в трее. Уведомление A не может открыться в B; stale runtime id сначала разрешается по своему root, недоступный root даёт явную ошибку без fallback. Повторные клики не создают дубликаты.

Нужен app-level получатель/маршрутизатор событий уведомлений и после закрытия всех project renderers; это не новый общий центр UI. Desktop subscription остаётся отделённой от legacy browser_bus. Существующие notification и Producer attention механизмы адаптируются к project source; badge агрегируется по вкладкам текущего окна и пересчитывается при transfer. Main registry не сохраняет замыкание на source-window.

### 8.3 Ошибки и технические ограничения

- Создание/конфигурация проекта не удались: новая вкладка показывает ошибку/убирает pending; старые вкладки и контексты остаются работоспособными.
- Transfer отменён или target недоступен: вкладка сохраняется без reload; повторить можно новой операцией. Никакого скрытого fallback на remount с потерей состояния: неудача native spike требует другого технического механизма, не ослабления согласованного требования.
- Project-view render-process-gone/did-fail-load/unresponsive: shell остаётся доступен, показывает ошибку и явный reload/reopen. Crash — не успешный перенос; восстановление несохранённых текстов/вложений после сбоя исключено.
- Shell crash: main registry и project-views удерживаются; пересоздание shell не должно пересоздавать проекты. Это отдельный native-тест, не уже имеющаяся гарантия.
- Потеря backend/неверная версия: не переключать проект на «какой оказался текущим». Показать disconnected/version error; восстановить только свою привязку. Существующий focus/version recovery (`App.vue:29–35`) не должен случайно перезапускать приложение во время transfer.
- При фактическом закрытии вкладки явно закрыть её contents, удалить listeners/allowlist; detached view не закрывать. [Electron отдельно предупреждает об управлении ресурсами WebContentsView](https://www.electronjs.org/docs/latest/api/base-window#resource-management).
- Stop failure при явном выходе оставляет возможность retry. Уведомления, restore, second launch и tab open не вызывают launcher или shutdown рабочего backend.

## 9. Файлы будущей реализации и проверка

### 9.1 Карта изменений

Это исследовательская карта кандидатов, **не утверждённый план реализации** и не разрешение VS-18 писать перечисленные файлы. Реализация и поправки spec будут отдельным планом на утверждение. В этом проходе изменяется только данный документ; предварительные имена модулей согласованы с VS-17, окончательные write_paths определит будущий план.

| Часть | Существующие точные файлы | Предлагаемые новые файлы |
| --- | --- | --- |
| Main registry, attach/transfer/close | `desktop/main.cjs` | `desktop/tabs.cjs` — единый controller window/tab ownership и transfer (как VS-17), без параллельного второго реестра |
| Bridge, роли, security | `desktop/preload.cjs`, `desktop/window-controls.cjs`, `desktop/policy.cjs`, `frontend/src/desktop.d.ts` | `desktop/tabs-ipc.cjs`, `frontend/src/desktop/tabs.ts` |
| Топология/restore | `desktop/main.cjs`, `desktop/tray.cjs`, `frontend/src/router/index.ts`, `frontend/src/views/ExplorerView.vue`, `frontend/src/views/TasksView.vue` | `desktop/session-state.cjs` — manifest `user_config_dir()/desktop-session.json`, как VS-17 |
| Уведомления/target routing | `frontend/src/stores/notifications.ts`, `desktop/producer-attention.cjs`, `desktop/tray.cjs`, `desktop/main.cjs`, `desktop/preload.cjs` | App-level notification router в `desktop/tabs.cjs`; без нового центра UI |
| Общие службы | `desktop/tray.cjs`, `desktop/updates.cjs`, `desktop/startup.cjs`, `desktop/producer-attention.cjs` | Нет обязательных новых |
| Shell bootstrap/заголовок | `frontend/src/main.ts`, `frontend/src/App.vue`, `frontend/src/components/layout/DesktopTitleBar.vue`, `frontend/src/components/layout/AppShell.vue` | `frontend/src/DesktopShell.vue`, `frontend/src/components/layout/ProjectTabStrip.vue` |
| Открытие/активация проектов | `frontend/src/components/project/ProjectMenuPanel.vue`, `frontend/src/components/project/ProjectSwitcher.vue`, `frontend/src/stores/session.ts`, `frontend/src/router/index.ts` | Bootstrap model можно держать в `frontend/src/desktop/tabs.ts` |
| Backend context addressing | `backend/voxarium_studio/core/workspace.py`, `backend/voxarium_studio/api/deps.py`, `backend/voxarium_studio/api/project.py`, `backend/voxarium_studio/api/__init__.py`, `backend/voxarium_studio/main.py`, `backend/voxarium_studio/ws/routes.py`, `backend/voxarium_studio/ws/bus.py` | `backend/voxarium_studio/core/project_scope.py` |
| Полная цепочка URL/WS | `frontend/src/api/client.ts`, `frontend/src/api/auth.ts`, `frontend/src/ws/connection.ts`, `frontend/src/ws/events.ts`, `frontend/src/lib/collab/session.ts`, `frontend/src/stores/sync.ts` | Централизованный builder в `frontend/src/api/project-scope.ts`; фабрика клиента `frontend/src/session/project-session.ts` из VS-17 |
| Plugins/raw assets | `frontend/src/plugin-runtime/loader.ts`, `frontend/src/plugin-runtime/index.ts`, `backend/voxarium_studio/api/plugins.py`, `backend/voxarium_studio/api/docs.py`, `backend/voxarium_studio/api/attachments.py`, `backend/voxarium_studio/api/explorer.py` | Проверить все generated resource URLs через scoped builder |
| Draft isolation/close ACK | `frontend/src/stores/chat.ts`, `frontend/src/components/chat/ChatWidget.vue`, `frontend/src/components/teams/TaskDetail.vue`, `frontend/src/views/DocsView.vue`, `frontend/src/stores/docs.ts`, `frontend/src/components/docs/BlockEditor.vue`, `frontend/src/views/PipelineEditorView.vue` | Generic close barrier — `frontend/src/desktop/close-barrier.ts` |
| Packaging/локализация/spec | `desktop/package.json` (явный files list), `frontend/src/locales/en.json`, `frontend/src/locales/ru.json`, `docs/voxarium-studio-dev-spec.md`, `AGENTS.md` | Обязательная machine-local topology schema (§6.1), не данные проекта |

Shell можно выбирать в main.ts по проверенному desktop bootstrap до создания проектной SPA/WS; это не требует второго frontend-сервера. Сгенерированный `backend/voxarium_studio/static` не редактировать руками. New desktop modules надо включить в files list упаковки, иначе dev-only успех не попадёт в NSIS.

Для отдельного плана на утверждение рекомендуемая зависимость работ: фиксация принятых правил в будущем spec → project-scope и isolation tests (VS-17) / native spike live reparent и drag-out → registry/IPC/shell → close/tray, manifest/restore и project notifications → реальный DnD → packaged verification. Это не запуск реализации: код/spec в VS-18 не меняются. Не выпускать оболочку с двумя «независимыми» проектами раньше готовности project scope. Session lookup/MCP/plugin isolation остаются в карте VS-17, не перепроектируются здесь.

### 9.2 Что проверено сейчас

В исходном исследовательском проходе выполнено без запуска Electron/backend:

`node --test desktop/test/window-controls.test.cjs desktop/test/policy.test.cjs desktop/test/tray.test.cjs desktop/test/producer-attention.test.cjs`

**13/13 passed**, без skips. `git diff --check` до записи документа не выявил ошибок; исходное git status --short было пустым. Полный frontend/backend suite, boot/shutdown/updater suites и native DnD в VS-18 не запускались. В проходе после ответа пользователя перечитаны VS-17, VS-03 и оба документа, выполнена независимая сверка и проверка согласованности текста; тесты повторно не запускались. Продуктовые вопросы закрыты; native prototype остаётся проверкой будущей реализации, не блокером завершения исследования.

Прочитанный существующий охват:

- `desktop/test/boot.test.cjs:9–108`, `shutdown.test.cjs:39–72`: VM, mock BrowserWindow/process/fetch; проверяют reuse/version/stop, не native окна.
- `desktop/test/window-controls.test.cjs:22–51`, `policy.test.cjs:4–45`, `tray.test.cjs:30–66`, `producer-attention.test.cjs:38–49`: fake EventEmitter/session, IPC и cleanup; реальный drag/focus/геометрия не доказаны.
- `desktop/test/startup.test.cjs:5–20`, `updates.test.cjs:24–69`: opt-in, sender validation, порядок stop/install и ошибки.
- `frontend/src/stores/session.spec.ts:17–25,65–131`: mock WS/version/reload. `chat.spec.ts:187–194,630–653`: drafts/popup.
- `frontend/src/stores/docs.spec.ts:100–369,482–639`: save serialization/conflicts, room/solo, root-scoped folds.
- `frontend/src/lib/collab/session.spec.ts:156–286`; `editor.spec.ts:1,145–216`: room protocol и два jsdom editor, opening without write/undo/cursors; не Electron.
- `backend/tests/test_workspace.py:192–225,253–378`: ошибки открытия, background jobs/context reuse, намеренная изоляция background от legacy browser_bus, общий shutdown.
- `desktop/test/installer-smoke.cjs` проверяет opt-in NSIS с фиктивным payload; это не e2e настоящего Studio и не запускался.

### 9.3 Новые автоматические проверки

Предлагаемые файлы: `desktop/test/tabs.test.cjs`, `desktop/test/tabs-ipc.test.cjs`, `backend/tests/test_project_scope.py`, `frontend/src/api/project-scope.spec.ts`, `frontend/src/desktop/tabs.spec.ts`. Дополнить существующие policy/window-controls/tray/startup/updates/shutdown и session/chat/docs/collab tests.

Проверить registry single-owner, one-shot tokens, revisions, rollback и cleanup; несколько senders общей session; права до/после transfer. Дополнительно нужны `desktop/test/session-state.test.cjs` и проверки notification target routing в `desktop/test/tabs.test.cjs`: snapshot/restore/atomic failure/дедупликация, project-labelled click при скрытом/закрытом UI и нуле окон. Backend-тест должен одновременно работать с A/B с одинаковыми relative paths и entity IDs, задержанными запросами, scoped WS replay/collab, plugin resources; browser legacy switch не должен менять desktop scope. Одного последовательного A→B→A недостаточно.

### 9.4 Проверка в настоящем Electron — обязательный следующий этап

В VS-18 **не выполнялась**. После отдельного разрешения использовать Electron 45.1.0 и совпадающую сборку SPA/backend; ровно один сервер :8765. Launcher не запускать из e2e для каждой вкладки. При уже работающем совместимом backend оболочка должна только подключиться; если запуск/смена версии не разрешены, остановить проверку, а не поднимать приватный порт.

Два тестовых проекта A/B должны иметь различимые данные по одинаковым путям, например document `notes.md`, image, pipeline и совпадающие task/chat IDs. Использовать существующий demo как один из проектов, второй — безопасный fixture, не рабочий игровой проект. Все disposable fixtures, harness logs/screenshots/traces для этой задачи — только `D:\VoxariumStudio\.voxarium_studio\temp\TASK-18`. Не использовать remote_test.bat как обход ограничения портов.

| Шаг | Действие | Проверяемый результат |
| --- | --- | --- |
| 1 | Открыть A и B вкладками W1; переключать, одновременно редактировать одинаковый path | Обе вкладки привязаны к своим проектам; нет глобального reload; файлы/БД/ресурсы не смешаны |
| 2 | В A оставить черновик, вложение, scroll, selection; отдельными проходами — документ с undo и dirty pipeline. В B оставить другие значения | Зафиксированы wc.id, JS sentinel, performance.timeOrigin, route, editor/session identity |
| 3 | Переставить A внутри W1; отдельными проходами отделить A командой и drag-out за пределы окна в W2, B остаётся в W1 | Оба способа обязательны; ровно одно W2, тот же contents/sentinel; не было navigation/bootstrap/destroy; B не изменился |
| 4 | Перенести A из W2 на tab strip W1 рядом с B, затем A обратно в W2 и снова в W1 | Несколько циклов туда-обратно; сохранены текст/undo/caret, File objects, selection, активность и принадлежность; нет orphan view |
| 5 | Повторить перенос во время delayed save/upload и потока WS; для collab — отдельно с доступным remote | Один completion, правильный project, тот же live sid/peer при отсутствии разрыва; перенос чистого документа не меняет файл |
| 6 | Подтверждённый drag-out, Escape/системная отмена, неподдерживаемая цель, неверный/повторный token, закрытие target, close/transfer race, отказ нового shell | Drag-out создаёт новое окно, drop на tab strip использует существующее; отмена/ошибка не создают окно и не теряют view; rollback, один владелец |
| 7 | Перенос последней/неактивной вкладки; закрыть вкладку, непоследнее и последнее окно; tray/second launch | Задачи всех проектов продолжаются без cancel/restart; при нуле окон Studio остаётся в трее; повторный запуск активирует существующее окно, при нуле окон возвращает shell без второго backend |
| 8 | Несколько мониторов, DPI, maximize/restore, resize, focus, IME, clipboard, меню/диалоги | Корректные bounds, tab hit zones и native owner; controls/attention относятся к новому окну |
| 9 | Foreign iframe/origin, подмена tab/window ID, закрытый sender, permissions после второго view и переноса | Нет управления чужим окном; clipboard только разрешённым main frames; generic IPC отсутствует |
| 10 | Project-view/shell crash, reload внутри debounce, недоступный backend, reconnect/stale handle | Явная граница recovery, нет записи A в B; соседние вкладки не закрываются |
| 11 | Owned и independent backend; явный «Выход» с активными задачами (включая без вкладок), отмена/подтверждение, update/stop failure | Предупреждение обо всех активных проектах; отмена сохраняет работу, подтверждение завершает приложение/owned backend один раз; чужой сервер не останавливается |
| 12 | Повторное/одновременное открытие A из разных окон, alias root, уведомление и restore одновременно | Одна вкладка A во всём desktop; активируются она и её окно, без дублей и перезапуска задач |
| 13 | Legacy browser/API открыть B при desktop A; повторить после transfer и restore | Старые URL/wire shape работают; desktop A не reload/rebind, desktop focus не меняет browser selection |
| 14 | Перезапуск с A/B в разных окнах, порядком вкладок и страницами (включая потреблённые query); новая epoch; недоступный root; повреждённый snapshot | Топология/страницы восстановлены из последнего валидного snapshot, runtime ids новые, нет дубликатов/чужого fallback/неявного create; drafts и перенос папки не обещаны |
| 15 | Уведомление A при активном B, скрытом окне, закрытой вкладке A и при нуле окон/жизни в трее; повторный клик | Видна метка A; открыта/сфокусирована единственная вкладка A и её target, B не затронут; без нового общего центра и повторного старта агента |
| 16 | Повторить в packaged Electron, EN/RU, серия переносов и закрытий | Модули включены, labels переведены, число views/listeners/handlers стабильно, лишних backend нет |

Для автоматизации предпочтителен opt-in Electron harness (предлагаемый `desktop/test/electron-tabs-smoke.cjs`), запускающий **реальный** бинарник и наблюдающий registry/webContents. Управление UI через Electron-capable driver требует отдельно выбранной/проверенной зависимости; сейчас она не заявлена как установленная. Физический межоконный OS drag/DPI всё равно проверить вручную. Screenshots недостаточны: нужны события navigation/destroy, IDs, renderer marker, сетевые project IDs и содержимое файлов.

## 10. Принятые решения и сверка с VS-17

Источник — ответ пользователя в review VS-18 от 13.11.2026. Все прежние Q1–Q5 закрыты. Это обязательные продуктовые правила; конкретные технические механизмы предстоит подтвердить отдельным планом/прототипом, а не повторно согласовывать уже выбранное поведение.

| Правило | Принято пользователем | Согласование с VS-17 и разделами этого документа |
| --- | --- | --- |
| D1 — уникальность | Один проект — одна вкладка во всём приложении; повторное открытие фокусирует её и окно | VS-17 §4.1, §8.1; здесь §3–4; дубликатов нет даже при гонках/restore |
| D2 — живой перенос | Без reload/remount, с сохранением интерфейса, текстов, вложений, редакторов и страницы | VS-17 §4.5, §8.2; здесь §5–6; reconstruction не является fallback |
| D3 — закрытие/выход | Закрытие вкладки/окна не останавливает задачи; последнее окно оставляет Studio в трее; явный «Выход» завершает приложение с предупреждением при активных задачах | VS-03 готова; VS-17 §4.6, §8.3; здесь §8.1; resident contexts не эвиктируются закрытием UI |
| D4 — restart | Восстановить проекты, окна, порядок вкладок и страницы | VS-17 §4.6, §8.4; здесь §6.1; один manifest по root, runtime ids разрешаются заново |
| D5 — совместимость/повторный запуск | Старые browser URL/API совместимы и не переключают desktop; повторный запуск активирует существующее окно | VS-17 §4.4, §8.5; здесь §4.1, §8.1; один backend :8765 и один main process |
| D6 — уведомления | Метка проекта; клик открывает нужные вкладку/окно; без общего центра | VS-17 §4.6, §8.6; здесь §8.2; app-level routing работает и из tray |
| D7 — жесты | Drag-out вкладки за пределы окна создаёт новое окно; команда «Отделить в новое окно»; DnD на полосу вкладок другого окна | Здесь §5.2; закрывает оставленное в VS-17 уточнение жеста, не меняя его правил live transfer |

**Явные исключения scope:** восстановление несохранённых черновиков/вложений после выхода или сбоя, работоспособность ссылок после перемещения папки, восстановление живых агентов после остановки backend, новый общий центр уведомлений, второй backend-порт. Принятое восстановление топологии/страниц не является обещанием этих функций.

**Результат сопоставления:** шесть решений VS-17 сохранены без противоречий; VS-18 добавляет подтверждённые жесты D7 и детализирует оконное владение/IPC. Рекомендуемая адресация выровнена с VS-17: runtime project_id + epoch, scoped URL/WS, legacy adapter отдельно, restart по root; machine-local manifest и controller не дублируются. Session lookup/MCP/plugin isolation остаются по карте VS-17; VS-03 не переделывается.

При документальном review выполнена независимая сверка обеих карточек/документов и матриц проверок: все замечания по согласованным правилам, жестам, восстановлению и уведомлениям интегрированы. Исследование VS-18 завершено, открытых продуктовых вопросов нет. Native live-transfer/drag-out, restore и notification routing пока не реализованы и не проверены в Electron; это критерии будущей реализации, а не незавершённая часть исследования. Следующий шаг — **отдельный план реализации на утверждение** с зависимостями, файлами/write_paths и проверками; этот документ не разрешает начинать правки кода/spec или запуск/перезапуск Studio.
