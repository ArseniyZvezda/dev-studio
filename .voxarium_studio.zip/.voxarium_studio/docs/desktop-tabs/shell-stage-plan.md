# Этап интерфейса desktop-вкладок

Основание: dev spec §5.3, [[desktop-tabs/implementation-plan]], [[desktop-tabs/window-model]], [[desktop-tabs/native-spike]]. Основа принята; этот документ описывает следующий этап, а не разрешение на выполнение и не готовую функцию. Пользователь согласился подготовить этап на утверждение. Saved Producer state и board — источник текущих статусов.

## Утверждение и границы

Первый пакет: VS-46–53, восемь Todo drafts, ожидающие отдельного утверждения кнопкой Producer. Лимит инструмента — восемь создаваемых задач за ход; оставшиеся десять ниже пока не созданы и не разрешены к выполнению. При продолжении сначала читать board и переиспользовать совпадающие карточки. Не обходить лимит через subagents и не считать этот документ согласием на остальные задачи.

Session Plan остаётся неизменным: существующие вехи покрывают этап; карточки и их IDs находятся здесь и на board, не в checklist. Приёмка первого пакета не завершает lifecycle, restore, notifications и native/packaged проверку.

Один backend :8765. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp, installed/static не заменять. При необходимости live проверки с restart сначала согласовать момент с пользователем. Ручная приёмка VS-21 завершена и не запрашивается повторно; новый production shell проверяется отдельно. Не добавлять crash-drafts, поиск перемещённых папок, общий центр уведомлений, RBAC или plugin sandbox. EN/RU обязательны. Все briefs ниже менее 1500 символов; write_paths уточняются только по правилам задач.

## VS-46 — Создать реестр живых вкладок и окон

Ключ последовательности: `registry`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-21, VS-22, VS-27.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Реализуй main-owned WindowRecord/TabRecord и canonical root→единственную вкладку поверх ensure/open VS-22; внедряемые Electron/backend adapters. Coalesced concurrent open, immutable project binding, live WebContentsView, parking/activation/bounds/focus и cleanup. Shell не владеет project stores. Приёмка: unit tests aliases/open failure/двух окон/одного view на проект, late open не подменяет owner; open/focus не вызывает backend launcher, legacy selection не меняется. Transfer, restore и quit пока отдельные задачи; подготовь явные интерфейсы, не реализуй их скрыто.

Файлы записи:

- `desktop/tabs.cjs`
- `desktop/test/tabs.test.cjs`

## VS-47 — Подключить безопасный IPC и desktop controller

Ключ последовательности: `ipc`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-46.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Подключи registry к main: shell BrowserWindow и project WebContentsView. Узкий IPC bootstrap/open/activate/state/prepare-close; права определяет registry по contents, mainFrame, origin, owner/revision, не renderer-полям. Window controls следуют текущему owner. App-level IPC/startup/updater/permissions регистрируются один раз; закрытие окна не снимает сервисы других. Сохрани auth, navigation/permissions allowlist, version/owned-backend guards. Приёмка: fake Electron tests foreign/stale/frame senders, два окна и cleanup, один launcher при boot и ни одного на open/focus. Полный close/quit — отдельная задача.

Файлы записи:

- `desktop/main.cjs`
- `desktop/tabs-ipc.cjs`
- `desktop/preload.cjs`
- `desktop/window-controls.cjs`
- `desktop/policy.cjs`
- `desktop/startup.cjs`
- `desktop/updates.cjs`
- `frontend/src/desktop.d.ts`
- `desktop/test/tabs-ipc.test.cjs`
- `desktop/test/window-controls.test.cjs`
- `desktop/test/policy.test.cjs`
- `desktop/test/startup.test.cjs`
- `desktop/test/updates.test.cjs`
- `desktop/test/boot.test.cjs`

## VS-48 — Добавить оболочку и полосу проектов

Ключ последовательности: `shell`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-47.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Раздели bootstrap shell и project SPA; shell не импортирует/создаёт project stores, sockets/plugins. Добавь полосу active/pending/error, open/recent/browse, фокус существующей вкладки/окна и пустое/error окно через IPC. Сохрани browser UX и явное подтверждение создания проекта. Неактивные views живы; tab/menu hit zones не перекрыты view, controls no-drag, keyboard/focus доступны. EN/RU через i18n. Приёмка: component/adapter tests, typecheck и temp build; A/B open/activation не rebind/reload соседей, runtime identity не назначается shell. Жесты/отделение подключит отдельная задача.

Файлы записи:

- `frontend/src/main.ts`
- `frontend/src/App.vue`
- `frontend/src/DesktopShell.vue`
- `frontend/src/DesktopShell.spec.ts`
- `frontend/src/components/layout/ProjectTabStrip.vue`
- `frontend/src/components/layout/ProjectTabStrip.spec.ts`
- `frontend/src/components/layout/DesktopTitleBar.vue`
- `frontend/src/components/layout/AppShell.vue`
- `frontend/src/components/project/ProjectMenuPanel.vue`
- `frontend/src/components/project/ProjectSwitcher.vue`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/desktop/tabs.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## VS-49 — Разделить хранилище черновиков проектов

Ключ последовательности: `drafts`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-26.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Проверь project-specific persisted UI keys и устрани коллизии черновиков по canonical root, прежде всего NEW_DRAFT_KEY и draftKey в chat store; одинаковые chat/task IDs и doc paths A/B не разделяют записи. Переиспользуй уже выполненную изоляцию, не переписывай готовые resync/editor механизмы. Глобальные настройки остаются глобальными; legacy key нельзя автоматически приписать двум проектам. Приёмка: A/B copied IDs, new chat, delayed reads/writes и restart с новым runtime id; отсутствие переноса чужих текстов/вложений. Не добавляй сохранение File/crash-drafts или новый UX миграции; неясную миграцию верни вопросом.

Файлы записи:

- `frontend/src/desktop/project-storage.ts`
- `frontend/src/desktop/project-storage.spec.ts`
- `frontend/src/stores/chat.ts`
- `frontend/src/stores/chat.spec.ts`
- `frontend/src/components/chat/ChatWidget.vue`
- `frontend/src/components/teams/TaskDetail.vue`
- `frontend/src/stores/docs.ts`
- `frontend/src/stores/docs.spec.ts`

## VS-50 — Подключить защиту редакторов при закрытии

Ключ последовательности: `barrier`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-47, VS-49, VS-48.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Подключи prepare-close/ACK к существующим dirty/save guards реально открытых редакторов и форм. Ошибка/незавершённое сохранение не выдаётся за разрешённое закрытие; повторные close коалесцируются. Сохрани существующий UX отмены, без самостоятельного нового crash-recovery. Transfer/reorder/focus не вызывает flush/leave/unmount, не сериализует editor/File. Приёмка: mounted tests dirty/cancel, delayed save/failure, clean docs open/transfer без Markdown writes; ACK относится к своей tab generation, поздний ACK не закрывает новую вкладку. Main close orchestration реализуется отдельно; новые продуктовые вопросы — в review.

Файлы записи:

- `frontend/src/desktop/close-barrier.ts`
- `frontend/src/desktop/close-barrier.spec.ts`
- `frontend/src/App.vue`
- `frontend/src/components/docs/BlockEditor.vue`
- `frontend/src/stores/docs.ts`
- `frontend/src/stores/docs.spec.ts`
- `frontend/src/views/DocsView.vue`
- `frontend/src/views/PipelineEditorView.vue`
- `frontend/src/components/chat/ChatWidget.vue`
- `frontend/src/components/teams/TaskDetail.vue`
- `frontend/src/views/SkillsView.vue`
- `frontend/src/views/MemoryView.vue`

## VS-51 — Реализовать транзакцию живого переноса

Ключ последовательности: `transfer`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-50.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. По принятому VS-21/native-spike.md реализуй перенос того же WebContentsView: source owner до attach ACK, затем atomic commit owner/revision/active/focus; rollback держит тот же contents, recovery shell при потере окна. Одноразовые короткоживущие tokens и сериализация с close/barrier; command detach и reorder пользуются тем же controller. Приёмка: replay token/stale sender, source/target destruction/failure, последний tab, A→B→A, rollback и close race; ни loadURL/reload/remount/destroy переносимого view, ни запуск prompt/jobs/backend. Жесты UI подключаются отдельно; не повторяй исследование или ручную приёмку VS-21.

Файлы записи:

- `desktop/tabs.cjs`
- `desktop/tabs-ipc.cjs`
- `desktop/test/tabs.test.cjs`
- `desktop/test/tabs-ipc.test.cjs`

## VS-52 — Подключить drag-out и перенос между полосами

Ключ последовательности: `gestures`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-51.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Подключи native механизм VS-21 к production controller: drag-out создаёт одно окно, drop на полосу существующего переносит без лишнего окна; reorder и команда «Отделить в новое окно». Escape/OS cancel/unsupported target/ошибка возвращают исходную живую вкладку. Не выводи success из dragend/dropEffect=none; token/revision/terminal проверяет main. Приёмка: unit/component integration для всех terminal outcomes, bounds/DPI conversion, focus/no-drag/menu hit zones, EN/RU; без новых серверов и повторного старта задач. Полная проверка новых production окон будет отдельной native задачей, не объявляй mock доказательством OS drag.

Файлы записи:

- `desktop/tab-drag.cjs`
- `desktop/tabs-ipc.cjs`
- `desktop/main.cjs`
- `desktop/preload.cjs`
- `desktop/test/tab-drag.test.cjs`
- `frontend/src/desktop.d.ts`
- `frontend/src/components/layout/ProjectTabStrip.vue`
- `frontend/src/components/layout/ProjectTabStrip.spec.ts`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/desktop/tabs.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## VS-53 — Выдать активную работу всех resident проектов

Ключ последовательности: `activity`. Карточка создана в Todo; требуется утверждение плана.

Зависимости: VS-22, VS-24.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Добавь минимальный app-level read-only summary активной работы всех уже resident contexts для explicit quit/updater, включая проекты без вкладок. Используй текущие реестры jobs/task/chat/subagent, не recent paths или только legacy ctx; не запускай контексты/работу ради подсчёта и не переделывай VS-03. Сохрани auth/Host/Origin safeguards. Приёмка: A/B, закрытая UI A, running pipeline/chat/subagent, завершение во время snapshot и ошибки чтения не дают ложного «работы нет»; legacy/scoped API неизменны. UI подтверждения и shutdown — отдельная задача.

Файлы записи:

- `backend/voxarium_studio/api/project.py`
- `backend/voxarium_studio/core/workspace.py`
- `backend/tests/test_desktop_activity.py`

## Будущая задача — Сохранить работу при закрытии вкладок и окон

Ключ последовательности: `close`. Черновик содержания, карточки пока нет.

Зависимости: VS-52.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Close-tab/window закрывают только UI после prepare-close, без cancel/evict/shutdown contexts. Сериализуй close с transfer/modal; закрытие опустевшего source не уничтожает перенесённый view. При нуле окон tray/IPC/backend живы; tray/second-instance возвращают shell и фокусируют уникальную вкладку без launcher. Tray принадлежит app, не одному window; общий empty-window путь. Приёмка: tests last-tab/last-window, cancel/error ACK, repeated close, transfer race, tray и второй launch при нуле окон; нет остановки фоновых jobs. Explicit quit/update guard делает следующая задача, не проверять выход на рабочем Studio.

Файлы записи:

- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/tray.cjs`
- `desktop/test/tray.test.cjs`
- `desktop/test/shutdown.test.cjs`
- `desktop/test/boot.test.cjs`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## Будущая задача — Защитить явный выход и установку обновления

Ключ последовательности: `quit`. Черновик содержания, карточки пока нет.

Зависимости: close, VS-53.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Используй app-level summary всех resident проектов для явного Выхода и updater, включая фоновые задачи проектов без вкладок. Предупреждение, cancel без остановки, close/save barrier; confirm останавливает только app-owned backend ровно один раз. Independent backend не присваивать. Ошибка summary/stop не означает успех, сохраняет retry и блокирует тихую установку. Сохрани version/restart guards §2.7/§12.1 и один launcher. Приёмка: tests owned/independent, running A при видимой B/нуле окон, cancel/confirm/повтор quit/stop failure/update failure; EN/RU. Не выполнять quit/update на рабочем Studio пользователя.

Файлы записи:

- `desktop/main.cjs`
- `desktop/updates.cjs`
- `desktop/tray.cjs`
- `desktop/test/shutdown.test.cjs`
- `desktop/test/updates.test.cjs`
- `desktop/test/tray.test.cjs`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## Будущая задача — Добавить атомарное хранилище desktop manifest

Ключ последовательности: `manifest`. Черновик содержания, карточки пока нет.

Зависимости: VS-20.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Реализуй versioned atomic storage единственного manifest user_config_dir()/desktop-session.json, включая VOXARIUM_STUDIO_HOME, и desktop adapter. Предпочти backend-owned ограниченный read/write API с текущими auth/Host/Origin guards вместо дублирования config path в Electron. Schema: canonical roots, окна/порядок/active tabs, relative page descriptors и валидируемая geometry. Запрети tokens, runtime IDs/epoch, WS cursors, Yjs/drafts/File; не храни второй snapshot в userData/project. Приёмка: roundtrip, validation, corruption/unsupported version, atomic write failure, home override, parallel saves не дают torn data. Open/restore orchestration пока не подключай, неизвестную запись не превращай молча в успех.

Файлы записи:

- `backend/voxarium_studio/api/desktop.py`
- `backend/voxarium_studio/api/__init__.py`
- `backend/tests/test_desktop_manifest.py`
- `desktop/session-state.cjs`
- `desktop/test/session-state.test.cjs`

## Будущая задача — Сохранять проектные страницы без runtime URL

Ключ последовательности: `pages`. Черновик содержания, карточки пока нет.

Зависимости: VS-52.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Добавь project-relative page descriptor и узкий обмен с main, с sender/tab generation validation. Сохраняй потреблённые query/selectors выбранной сущности (включая Explorer/Tasks) после очистки URL; восстановление той же страницы через существующий router, не runtime URL. Не записывай secrets/epoch/IDs проекта/drafts/File и не поддерживай произвольную внешнюю навигацию. Приёмка: tests consume-query→snapshot→fresh runtime, основные страницы/docs/chat/task/pipeline/plugin page, invalid/deleted target с явным результатом без fallback в другой проект; legacy router не ломается. Transfer не навигирует и не пересоздаёт editor; manifest orchestration отдельно.

Файлы записи:

- `frontend/src/desktop/page-state.ts`
- `frontend/src/desktop/page-state.spec.ts`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/desktop.d.ts`
- `frontend/src/router/index.ts`
- `frontend/src/views/ExplorerView.vue`
- `frontend/src/views/TasksView.vue`
- `desktop/tabs-ipc.cjs`
- `desktop/preload.cjs`
- `desktop/test/tabs-ipc.test.cjs`

## Будущая задача — Восстанавливать окна и вкладки из manifest

Ключ последовательности: `restore`. Черновик содержания, карточки пока нет.

Зависимости: quit, manifest, pages.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Подключи manifest к controller: snapshot только согласованных commits и page updates; перед quit фиксируй topology до служебного teardown. Restore заново ensure roots в текущей epoch, dedup с concurrent open/second-launch, порядок/active/windows/pages и доступные screen bounds. Намеренно закрытые вкладки не воскресают, cancelled transfer не сохраняется. Недоступный/uninitialised root или битая запись показывают свою ошибку без fallback/неявного create/поиска перенесённой папки. Приёмка: automated restart/new-epoch/order, missing root, corrupted manifest, open race, cancel transfer и quit teardown; no extra launcher/legacy switch. Без restart рабочего Studio, crash-drafts не добавлять.

Файлы записи:

- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/session-state.cjs`
- `desktop/test/session-state.test.cjs`
- `desktop/test/tabs.test.cjs`
- `desktop/test/boot.test.cjs`
- `frontend/src/DesktopShell.vue`
- `frontend/src/DesktopShell.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## Будущая задача — Доставлять проектные события без открытых окон

Ключ последовательности: `events`. Черновик содержания, карточки пока нет.

Зависимости: VS-53.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Сделай app-level источник notifications/Producer attention для всех resident contexts и desktop receiver, работающий без project renderers/окон. Переиспользуй scoped buses/registry; не selected browser_bus и не второй реестр проектов. Событие несёт identity/root locator и relative target; auth, allowlist, scope/epoch, reconnect/gap и dedup сохраняются. Подписка/cleanup один раз на context/app, новые resident contexts подключаются без открытия UI. Приёмка: A/B с одинаковыми seq/entity IDs, zero renderer, legacy switch, reconnect/gap и stale epoch, отказ auth/чужой target, cleanup без остановки задач. Не переделывай уже принятую scoped WS/collab доставку, не создавай общий центр уведомлений.

Файлы записи:

- `backend/voxarium_studio/ws/routes.py`
- `backend/voxarium_studio/ws/events.py`
- `backend/voxarium_studio/core/workspace.py`
- `backend/tests/test_desktop_project_events.py`
- `desktop/project-events.cjs`
- `desktop/test/project-events.test.cjs`

## Будущая задача — Направлять уведомления в окно своего проекта

Ключ последовательности: `notifications`. Черновик содержания, карточки пока нет.

Зависимости: restore, events.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Подключи app-level events к native notifications и existing Producer attention. Уведомление имеет метку проекта и scoped dedup tag; click атомарно открывает/фокусирует единственную вкладку, relative target и текущее owner window, включая tray/закрытую A при видимой B. Не повторяй запуск задачи. Badge/attention агрегируются по вкладкам окна и пересчитываются после transfer. Сохрани browser fallback/preferences и исключи двойные desktop+renderer уведомления. Приёмка: tests zero windows, duplicate clicks, restore/open race, A/B equal IDs/seq, stale handle разрешается только по своему root; missing root без fallback, EN/RU. Общий центр UI не добавлять.

Файлы записи:

- `desktop/project-notifications.cjs`
- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/producer-attention.cjs`
- `desktop/tray.cjs`
- `desktop/preload.cjs`
- `desktop/test/project-notifications.test.cjs`
- `desktop/test/producer-attention.test.cjs`
- `frontend/src/stores/notifications.ts`
- `frontend/src/stores/notifications.spec.ts`
- `frontend/src/desktop.d.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

## Будущая задача — Включить desktop модули в пакет приложения

Ключ последовательности: `packaging`. Черновик содержания, карточки пока нет.

Зависимости: notifications.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Включи новые production modules/resources shell, IPC, transfer, manifest и notifications в Electron package; не упаковывай fixtures/secrets/task temp. Сохрани existing installer/update/runtime contracts. Приёмка: automated packaging inventory/require-path tests и распаковка/проверка локального package artifact, shell/frontend assets доступны, версии совместимы. Сборка только в temp, production static/installed Studio не заменять, не публиковать релиз и не менять версию без запроса. Если упаковка требует запуска/остановки рабочего backend — верни вопрос. Full native validation отдельной задачей.

Файлы записи:

- `desktop/package.json`
- `desktop/electron-builder.cjs`
- `desktop/test/release.test.cjs`
- `desktop/test/desktop-package.test.cjs`

## Будущая задача — Проверить сквозную изоляцию двух проектов

Ключ последовательности: `isolation`. Черновик содержания, карточки пока нет.

Зависимости: notifications, VS-49.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Независимая приёмка по VS-17 §6 и spec §5.3. На fixture A/B с одинаковыми paths/plugin/entity IDs проверь данные/DB, scoped REST/streams/assets/uploads, WS/replay/collab, delayed responses, legacy switch, global/project settings, runtime controls/cleanup и close без отмены задач. Переиспользуй существующие tests, не переписывай принятые механизмы. Remote install обязателен для remote_sync: skip не успех. Приёмка: воспроизводимые команды, результаты релевантных backend/frontend suites и честные ограничения в desktop-tabs/isolation-verification.md; без cross-project записей/событий/остановок. Только тесты/отчёт; дефекты передай для отдельных corrections, не исправляй production скрыто.

Файлы записи:

- `backend/tests/test_desktop_project_isolation.py`
- `frontend/src/session/project-session.spec.ts`
- `.voxarium_studio/docs/desktop-tabs/isolation-verification.md`

## Будущая задача — Проверить готовые вкладки в настоящем Electron

Ключ последовательности: `native`. Черновик содержания, карточки пока нет.

Зависимости: packaging, isolation.

Основание: dev spec §5.3, .voxarium_studio/docs/desktop-tabs/implementation-plan.md и window-model.md. Один :8765; VS-03 и принятая основа сохраняются. Рабочий Studio не перезапускать/переключать, новых серверов не запускать; build только temp. Проверь новую production оболочку и packaged artifact по VS-18 §9.4, не повторную приёмку spike VS-21. Native evidence: drag-out/drop/команда/reorder A→B→A, cancel/rollback/races; тот же wc.id/timeOrigin/editor, drafts/File/undo/caret/delayed save. Также tray/zero windows/quit ownership, restore/pages, notifications, legacy и EN/RU, focus/IME/mixed-DPI где реально выполнено. Opt-in harness подключается только к совместимому единственному :8765, без запуска backend; безопасные demo/fixture данные. Если необходим restart/переключение проекта/остановка работы — сначала question о моменте проверки. Приёмка: durable evidence и команды в native-verification.md, выполненное отделено от невыполненного; mock/скриншот не заменяет native drag. Только тесты/отчёт, дефекты в review.

Файлы записи:

- `desktop/test/electron-tabs-smoke.cjs`
- `desktop/test/fixtures/electron-tabs/*`
- `.voxarium_studio/docs/desktop-tabs/native-verification.md`

