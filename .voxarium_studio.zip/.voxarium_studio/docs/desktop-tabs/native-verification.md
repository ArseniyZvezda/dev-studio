# VS-69 — native-приёмка: запуск заблокирован

## Статус на 14.11.2026

Пользователь явно разрешил запуск продуктового Electron/ZIP, необходимый restart единственного :8765, close→tray, cancel/confirm Quit и restore, включая возможное прерывание этой сессии. Ручного участия не будет; повторно его не запрашиваем. Установщик, update, замена installed/static и сетевой remote по-прежнему запрещены.

**Продуктовая native-приёмка не состоялась:** безопасный запуск с debugger для изоляции профиля отклонён политикой инструмента до исполнения команды. Обход блокировки не предпринимался; обычный запуск с пользовательским профилем небезопасен.

Основание: `docs/voxarium-studio-dev-spec.md` §5.3, [[desktop-tabs/window-model]] §9.4, [[desktop-tabs/implementation-plan]]. Принятый [[desktop-tabs/native-spike]] не повторяется и не доказывает поведение продуктовой оболочки.

## Кандидат сборки и уже имеющиеся доказательства

- ZIP VS-67: `D:\VoxariumStudio\.scratch\desktop-tabs-package\VS-67-f84cf0d-win-x64.zip`; 395068659 байт; SHA-256 повторно подтверждён read-only: `07fa118a87e2310082ff0e80e7a7cff8da3821048ffe1f096b3f6c79dd13d5a7`.
- По [[desktop-tabs/packaging-verification]]: Electron 45.1.0, Windows x64, runtime/backend/SPA identity `f84cf0d`, номинальная SemVer 5.0.0. Это ZIP, не установленный NSIS; 17 runtime-модулей и состав runtime/SPA сверены в VS-67. Источник — dirty tree при HEAD `f84cf0d9838e46b7f58e357331dbc3ef38685f9b`; сохранённые manifests важнее одного HEAD. Текущий checkout имеет тот же HEAD и незакоммиченные изменения, что **не доказывает** его побайтовое равенство ZIP.
- VS-67: 249 тестовых passed; VS-68: 209 passed и typecheck — переиспользуемые результаты, не новый прогон VS-69. [[desktop-tabs/isolation-verification]] содержит A/B disk/SQLite/WS evidence; архивные fixtures не открывать как рабочие проекты. Полный текущий сетевой sync не пройден; прежние 30 passed VS-23 остаются историческими.
- Одноразовые probes TASK-67 уже удалены; итоговые manifests сохранены в `.scratch/desktop-tabs-package`. Использовать существующие средства и лишь минимальные наблюдения над продуктовой сборкой, без новой инфраструктуры и без выдачи spike/mock за native-тест.

## Короткий сценарий после отдельного разрешения

| Этап | Действие и необходимое доказательство |
| --- | --- |
| 1. Безопасный старт | В согласованное окно зафиксировать точный executable/хэши, backend/SPA identity, PID и ownership единственного :8765, отсутствие посторонних активных работ. Использовать demo `.scratch/demo-project` только после проверки безопасности и одноразовый B с различимыми данными по одинаковым paths/plugin/entity IDs; при необходимости A — безопасная копия demo. Отдельный тестовый HOME/manifest, не пользовательские данные/настройки. Неизвестный или несовместимый runtime — остановка и вопрос, не второй сервер/самовольная замена. |
| 2. Живые переносы | В продуктовой оболочке: reorder, detach командой, настоящий OS drag-out, drop между W1/W2 и обратно, перенос последней/неактивной вкладки. До/после сравнить wc.id, timeOrigin, JS marker, editor instance, route, drafts, тот же File object, undo/caret/selection; журнал navigation/destroy и сетевые project IDs. Повторить во время delayed save/upload: один completion в A, данные/БД B неизменны. |
| 3. Отмена и границы | Escape, неподдерживаемый drop, rollback/close race/недоступный target; один живой владелец без лишних окон. Минимально существующими средствами проверить stale/repeated token и полномочия старого owner, uniqueness при повторном open/alias/notification. Инъекции через probe отмечать отдельно от реального OS жеста. |
| 4. Фоновая жизнь и выход | Без платных CLI — безопасная контролируемая background job. Close tab/window, последнее окно → tray, job продолжает работу; tray/second launch возвращает shell без нового backend. Только в отдельно разрешённой destructive-фазе: предупреждение обо всех resident jobs, cancel Quit, затем owned/independent ownership и подтверждение выхода; чужой backend не останавливать. |
| 5. Restore и уведомления | Только после разрешения restart: порядок/активность окон/вкладок и страницы с потреблёнными selectors, новая epoch, unavailable root/битая копия manifest без fallback/create. Настоящий системный баннер A при активном B, скрытой/закрытой A и нуле окон; реальный и повторный click фокусируют единственную A/target без повторного job. |
| 6. Совместимость и окружение | Повторить ключевые жесты на packaged ZIP и в согласованном product development runtime, EN/RU; legacy switch только на fixture в согласованном окне, без rebind/reload desktop. Focus, resize/maximize, меню/диалоги/clipboard; multi-monitor/DPI/IME — по доступному оборудованию и ручному вводу. Отдельный remote не запускать без разрешения; недоступные проверки оставить непройденными. |

Физический межоконный drag, системный баннер/click и IME при отсутствии доступного управления потребуют участия человека. Скриншоты, IPC-команда detach и mock не подтверждают native drag. Каждый пункт получает статус «пройден / дефект / заблокирован / не выполнен», ссылку на лог и точную сборку; до запуска **все шесть этапов не выполнены**.

Все disposable fixtures, распаковка, probes и первичные логи — `D:\VoxariumStudio\.voxarium_studio\temp\TASK-69`. Итоговые обезличенные доказательства скопировать в `.scratch/desktop-tabs-native` до очистки temp. Продуктовые дефекты передавать Producer, без скрытых исправлений; installed/static не заменять.

## Выполнено в разрешённом продолжении

- Read-only сверены startup/ownership/profile-границы продукта и действующий сервер. Handoff записан в историю VS-69 до потенциального отключения.
- ZIP повторно проверен по SHA-256 и распакован в `D:\VoxariumStudio\.voxarium_studio\temp\TASK-69\product`; проверено, что каждый путь entry остаётся внутри каталога распаковки. Runtime/SPA не установлены и не подменены.
- Единственная попытка `Start-Process` продуктового EXE с `--inspect-brk=127.0.0.1:9230` и `--remote-debugging-port=9222` отклонена `exec_command`: **`rejected: blocked by policy`**. Это отказ инструмента, не ошибка продукта и не crash Electron. Команда не исполнилась; повтор через другой launcher/script не делался.
- После отказа: нет candidate process, PID-файла, stdout/stderr-файлов, inspector/CDP listeners. Сервер остался `5.7.0 / 4623cb251ea47305629bcfd90eba5acfc75901e2`, `desktop_instance=0fbe3edf-951d-4a10-af8b-764f29c7b0ff`, legacy root `D:\VoxariumStudio`. В status — только текущая VS-69, без посторонних jobs. Это состояние окружения, **не результат приёмки ZIP**.

Итоговые доказательства: `D:\VoxariumStudio\.scratch\desktop-tabs-native\VS-69-2026-11-14\`:

| Файл | Что фиксирует |
| --- | --- |
| `artifact.json` | ZIP, SHA-256, путь безопасной распаковки и количество entries |
| `preflight-after-rejection.json` | UTC, health/build/instance, root, jobs и отсутствие candidate/listeners/logs после отказа |
| `handoff.md` | Разрешения, отказ инструмента, неизменённый runtime и безопасные условия продолжения |

## Блокер и честные пробелы

`desktop/main.cjs:16` принудительно устанавливает Electron userData в `app.getPath('appData')/Voxarium Studio`; single-instance lock берётся в `:663`. Один `VOXARIUM_STUDIO_HOME` изолирует backend, **не профиль Electron**; `--user-data-dir` перезаписывается main. Debugger-пауза до этой строки позволила бы задать task-private appData/sessionData без правки продукта, но именно этот способ запуска заблокирован инструментом. Не делаем fallback на реальный профиль, не пытаемся обойти запрет; backend ради неработающего пути запуска не останавливался.

Доступный CUA имеет native computer APIs disabled; иных инструментов управления native Electron/OS в этой сессии нет. IPC detach, DOM/CDP-перенос и скриншот в любом случае не доказывали бы OS drag либо реальный click системного баннера.

| Область | Итог этого продолжения |
| --- | --- |
| Подготовка, разрешение, хэш/распаковка, сохранённый handoff | Выполнено; не native acceptance |
| Reorder, detach, OS drag-out/drop туда-обратно | Не выполнено: product не запущен |
| wc.id/timeOrigin/editor, draft/File/undo/caret, delayed save/WS | Не выполнено в product |
| Cancel/rollback, stale owner/token, uniqueness/races | Не выполнено в product |
| Close→tray, фоновые jobs, second launch | Не выполнено в product |
| Cancel/confirm Quit, owned/independent shutdown | Не выполнено в product |
| Restore страниц/окон/new epoch/errors | Не выполнено в product |
| Реальные системные баннеры и click при закрытой A/нуле окон | Не выполнено; native click недоступен |
| Legacy independence и EN/RU | Не выполнено в product; прежние tests не заменяют UI |
| Focus/resize/multi-monitor DPI/IME | Не выполнено; native управление/ручная помощь недоступны |
| Installer/update/remote, installed/static replacement | Не выполнялись; вне разрешения |

Подтверждённых продуктовых дефектов нет: запуск не достиг продуктового исполнения. Для Producer/reviewer: VS-69 остаётся незавершённой native-приёмкой из-за ограничения исполнительной среды; требуется разрешённая автоматизация с безопасной изоляцией профиля, **не повторное разрешение пользователя и не ручное участие**. Использовать существующую карточку VS-69; не ослаблять критерии и не выдавать VS-67/68/spike за product verification.
