# Вкладки desktop Studio: изоляция проектов

## 1. Статус, границы и основание

VS-17 — завершённое архитектурное исследование от 13.11.2026. После первого review пользователь согласовал шесть правил; они зафиксированы в §8 и обязательны для рекомендаций этого документа. Это фиксация решений и план будущей реализации, а не изменение действующего dev spec. Сначала прочитана завершённая VS-03; её сохранение фоновых задач принимается как готовая основа и не проектируется заново. Ниже «есть» означает подтверждённое исходниками, «предлагается» — технический способ выполнить уже согласованные правила, а не новый продуктовый вопрос.

Исследован checkout `D:\VoxariumStudio`, HEAD `4623cb251ea47305629bcfd90eba5acfc75901e2`. Навигация начата через `graphify query/explain` по `graphify-out/graph.json` (12399 узлов), затем проверены актуальные файлы. Граф не нашёл символ `WorkspaceManager`: фактическая реализация — функции `initialise_workspace/open_project/shutdown_workspace` и поля ASGI state, а не класс менеджера. Ссылки ниже — пути от корня репозитория и строки этой ревизии.

Код, dev spec и конфигурация не менялись. Работающий Studio не переключался и не перезапускался; второй backend не запускался. Проверка исходников не доказывает, что установленный процесс уже исполняет ту же ревизию. Единственный сервер остаётся на `:8765`, его launcher — только `run.ps1` (через `run.cmd` либо Electron). Новая вкладка или окно не являются основанием запускать launcher.

Источник намерений — `docs/voxarium-studio-dev-spec.md` §5.1, строки 357–374: пока интерфейс показывает один проект, но все ранее открытые контексты продолжают работать. Модель нескольких одновременно видимых проектов потребует будущей явной поправки §5.1, а не скрытого изменения трактовки. Глобальные и проектные настройки сохраняют разделение §5.2, строки 409–432. Предложения не добавляют RBAC, sandbox плагинов, восстановление живых агентов после рестарта или новые серверные процессы.

## 2. Существующие гарантии — сохранить

| Гарантия | Проверенный источник |
| --- | --- |
| Повторное открытие проекта использует прежний AppContext; не вызывает shutdown текущего. Новый контекст успешно стартует до смены выбранного. При ошибке старый остаётся выбранным; частичный новый закрывается. Открытия сериализованы lock. | `backend/voxarium_studio/core/workspace.py:76–135` |
| Контексты хранятся в `state.project_contexts` по разрешённому root до остановки сервера. Только shutdown workspace закрывает все resident contexts и общий сервис окружений плагинов. | `core/workspace.py:55–73`; здесь и далее сокращённые backend-пути относятся к `backend/voxarium_studio/` |
| У каждого проекта свои DB, bus, JobEngine, registry, pipelines, explorer/watcher, docs, sync, orchestrator/chats, skills/memory и automations. PluginHost получает paths/config/bus/state своего контекста. | `core/context.py:57–119,121–133,231–241` |
| Локальные события фонового проекта продолжают доходить его плагинам/автоматизациям. В общую browser_bus пересылается только выбранный проект. Переключение очищает replay browser_bus, но не её seq и не сам объект. | `core/workspace.py:55–60,120–134`; `ws/bus.py:108–137` |
| Защита обновления смотрит jobs всех resident contexts, а не только выбранного. | `core/context.py:101–108`; `core/workspace.py:60,112` |
| Shutdown завершает producer, plugin hooks, automations, updates, sync, watcher, waits/commit jobs, JobEngine, затем DB. Это не действие навигации UI. | `core/context.py:204–222`; `main.py:55–71` |
| Глобальные настройки применяются ко всем resident contexts, а открытие проекта и global save используют один lock. Project save пишет только проектные поля, global save — пользовательский config. | `api/project.py:206–228,309–333`; dev spec §5.2 |
| Auth posture принадлежит серверу: новый AppContext получает прежний auth. Проверки Host/Origin и токена остаются отдельными от выбора проекта. | `core/workspace.py:111`; `core/security.py:109–156` |
| Встроенный MCP toolset создаётся на каждый run и замыкает конкретные orchestrator/member/task/chat/subagent/run, DB и DocStore. UI selection его не переназначает. | `teams/tools.py:95–124` |
| Codex/Qwen bridge — отдельный временный loopback listener с секретом на run и закрытием при завершении; это не второй Studio backend. `/api/mcp` управляет конфигурацией, не принимает вызовы встроенных инструментов. | `teams/backends/mcp_bridge.py:23–55,100–119`; `api/mcp.py:75–99` |

Ограничение гарантии событий: `clear_history()` очищает историю, но не уже наполненные очереди подписчиков (`ws/bus.py:49–66,135–137`). Сам существующий тест допускает кадры старого проекта перед `project.opened` (`backend/tests/test_workspace.py:174–188`). Нельзя объявлять нынешнюю browser_bus строгим проектным каналом для новых независимых вкладок.

## 3. Препятствия одновременной работе

### 3.1 HTTP, WebSocket и идентичность агентской сессии

- Обычный REST получает `request.app.state.ctx` из `api/deps.py:10–14`. `POST /api/project/open` изменяет этот общий указатель и намеренно уведомляет все браузеры (`api/project.py:143–152`). Две вкладки с разными заголовками или разными Pinia без новой адресации всё равно читают/пишут один выбранный проект.
- `/ws` подписывается на общую `browser_bus`; hello сообщает текущий root. `/ws/collab` выбирает `state.ctx` только при handshake (`ws/routes.py:23–63`). Уже подключённый collab остаётся с A, тогда как следующий непроектный HTTP-запрос после переключения может попасть в B.
- Event содержит type/data/seq/ts/channel, но не project identity (`ws/bus.py:28–46`). Seq локальной шины и seq browser_bus — разные пространства: forwarding создаёт новый event (`:115–132`). Их нельзя смешивать в одном resume cursor.
- Процессные `_LIVE_SESSIONS` и `_CONTEXT_INSPECTORS` индексируются только owner id (`teams/backends/base.py:469–523`). Task/chat/subagent IDs могут совпасть у скопированных managed projects, даже если обычно генерируются уникально. Тогда регистрация/удаление сессии A способна затронуть lookup B. Подтверждённая структурная коллизия, но сценарий с двумя реальными агентами здесь не воспроизводился.
- `AgentRunRequest.session_key` сейчас равен task/chat/subagent id и используется также для проектных сообщений/БД (`teams/backends/base.py:337–342,379–382`; `teams/chat.py:701`; `teams/subagents.py:335`; `teams/orchestrator.py:1621–1625`). Поэтому нельзя просто заменить его строкой «project:id» во всех местах: нужен отдельный составной runtime lookup key или контекстный реестр сессий. Lookup Context Viewer идёт через те же глобальные maps (`api/session_context.py:40–54,65–67`).

### 3.2 Плагины и загрузка ресурсов

- Backend registry и PluginHost.state уже проектные, но URL assets — `/api/plugins/{id}/assets/…`, версия только mtime в секундах и размер (`plugins/registry.py:132–150`). Endpoint выбирает файл из registry текущего запроса (`api/plugins.py:201–224`). Отложенный import из A после legacy switch на B может получить одноимённый модуль B.
- Runtime привязан только к pluginId, передаёт общий API/onEvent/raw helpers (`frontend/src/plugin-runtime/index.ts:91–129`). Loader кеширует по componentUrl, routes — `plugin:${page.id}`, существующее имя пропускает (`plugin-runtime/loader.ts:20,58–105`). Грамматики кешируются общим списком и по language id (`lib/highlight/grammars.ts:30–51`; `lib/highlight/highlighter.ts:78–118`). Node params writer — module singleton (`plugin-runtime/node-params.ts:15–44`).
- Python entry module получает имя только из plugin id в sys.modules (`plugins/loader.py:108–146`). Это риск lazy lookup/рефлексии при одинаковых id, не доказательство подмены уже созданных handlers: функции сохраняют свои module globals. Требуется отдельная регрессия и namespace по источнику/контексту, если тест подтвердит необходимость.
- Встроенные и сторонние плагины могут иметь прямые URL, process globals и внешние ресурсы. Полный аудит сторонних плагинов не выполнен; project routing не становится sandbox. Обновлённый контракт должен проходить через host runtime (`docs/plugins.md:345–355,424–426`).

### 3.3 Frontend: адрес, память и сохранение

- Session store загружает единственный `api.project()`, а openProject и событие `project.opened` делают полную перезагрузку. Она намеренно очищает routes/cache/WS state (`frontend/src/stores/session.ts:23–27,46–69,179–214`).
- `api/client.ts:146–172` строит общий `/api`; router не включает проект (`router/index.ts:20–57,127–130`). Один Pinia на Vue app (`main.ts:22–23`), один module-level ws без project selector (`ws/connection.ts:49–55,133–137,177–181`).
- Docs держит один open/live, Teams — activeTeamId/openTask, Chat — active chat/messages (`stores/docs.ts:259–275`; `stores/teams.ts:63–68`; `stores/chat.ts:110–142`). Подписки применяют payload по типу без project filter (`stores/teams.ts:607–657`; `stores/chat.ts:492–500`; `stores/sync.ts:40–45`). Простое объединение A/B в общий поток смешает состояние.
- Раздельные renderer дают отдельные JS realms, но не изолируют общий origin storage и backend routing. Несколько Pinia в одном JS realm не изолируют перечисленные module singletons и общий router.
- Folds документов уже имеют ключ с project root (`stores/docs.ts:415–424`), graph layout тоже (`views/DocsGraphView.vue:277–280`). Popup chat/new draft не имеют проекта (`stores/chat.ts:24–27,67–70,146–155`); task draft/attachments имеют только task id (`components/teams/TaskDetail.vue:117–118,150–151`). Нужны проектные namespaces; отдельные параллельные tab namespaces одного проекта не требуются, поскольку в desktop разрешена только одна вкладка проекта. Технический tab/session id служит владению и переносу, не разрешает дубликаты.
- Token/locale преднамеренно глобальны (`api/auth.ts:13–38`; `i18n/index.ts:52,183–194`). Общая тема и проектный accent применяются к documentElement (`stores/theme.ts:67–88,138–147`): несколько проектов в одном DOM потребуют области применения accent.
- URL недостаточно для переноса: Explorer/Tasks потребляют query и удаляют её (`views/ExplorerView.vue:60–77`; `views/TasksView.vue:79–103`); pipeline draft живёт в refs до save (`views/PipelineEditorView.vue:74–85,349–357`); chat attachments — component-local (`components/chat/ChatWidget.vue:193–199`).
- Collab join передаёт только path/client_id (`lib/collab/session.ts:87–89,345–346`). Binding DocsView основан на path; unmount делает flush/leave (`views/DocsView.vue:118–143,193–225,381–388`; `components/docs/BlockEditor.vue:497–503`). Завершение async flush при уничтожении всего renderer не гарантировано. Detach через reload/remount нельзя обещать как перенос без потери состояния.

### 3.4 Electron: окно не равно проект

- Сейчас один `window`, один BrowserWindow; window.open внутренних ссылок загружает текущее окно и запрещает новое (`desktop/main.cjs:18,134–138,177–180`). Single-instance lock можно сохранить; second launch сейчас лишь показывает одно окно (`:200`; `desktop/tray.cjs:5–9,27`).
- Attach/detach/tab IPC пока нет (`desktop/preload.cjs:3–33`; `frontend/src/desktop.d.ts:13–35`).
- Window/startup/update handlers замкнуты на конкретный webContents, проверяют mainFrame/origin и снимаются при закрытии. Нельзя просто регистрировать одинаковые ipcMain handlers для каждого окна (`desktop/window-controls.cjs:3–9,29–31`; `startup.cjs:12–21`; `updates.cjs:16–18,56–67`).
- Permission handlers установлены на session, но замкнуты на один contents (`desktop/policy.cjs:11–23`). Несколько окон общей session требуют единой диспетчеризации проверенных surfaces, а не ослабления до одного origin.
- Сейчас закрытие единственного окна связано с quit, уничтожением tray и остановкой owned backend (`desktop/main.cjs:182–214`; `tray.cjs:30–33`). Эти действия нельзя переносить на закрытие отдельной вкладки/дочернего окна.

## 4. Рекомендуемый технический контракт по согласованным правилам

### 4.1 Три независимых владельца

- Workspace/backend владеет `project_id → AppContext`; жизненный цикл resident contexts остаётся из VS-03.
- Клиентская сессия вкладки владеет `tab_id, project_id, route, drafts, selection, request generation, WS cursor`.
- Desktop main владеет `window_id → tab_ids`, единственным соответствием `canonical project root → tab_id` во всём desktop и проверенным соответствием webContents/frame/surface → tab. Перенос меняет окно-хост, не проект, клиентскую сессию или агента.

Повторное открытие проекта из любого окна атомарно находит его единственную вкладку, активирует её и показывает/фокусирует окно-владелец; гонка двух открытий не создаёт два renderer. При отсутствии вкладки создаётся одна поверх существующего resident context. Повторный запуск desktop фокусирует уже существующее окно, не создаёт второй процесс/окно/backend. Legacy browser selection не входит в этот desktop-реестр и не меняет его владение.

Не использовать tab id для lookup DB и project id как разрешение доступа. Имя проекта, task code и путь документа не являются project identity.

### 4.2 Регистрация и адресация

Рекомендуется server registry с непрозрачным runtime `project_id` для канонического root. Существующий `ProjectPaths.for_project` делает expanduser/resolve (`core/paths.py:65–67`); проверку Windows case, junction/symlink aliases и повторной регистрации нужно закрепить тестами. Id — технический дескриптор текущего backend/epoch, не пользовательская функция и не требование вечной ссылки. После перезапуска desktop восстанавливает проекты по сохранённым root и получает актуальные runtime ids; устаревшие ids/курсоры событий не переиспользуются. Стабильный UUID в managed project для этих правил не нужен. Восстановление ссылок после перемещения папки вне scope; недоступный root даёт явное состояние ошибки, без подстановки другого проекта или неявного create.

Предлагаемые новые адреса:

| Операция | Предложение |
| --- | --- |
| Зарегистрировать/открыть проект для вкладки | `POST /api/projects/open` с path/create, возвращает project_id и metadata; стартует/переиспользует контекст без смены legacy selection |
| Проектный REST и ресурсы | `/api/projects/{project_id}/…` |
| События | `/ws/projects/{project_id}` |
| Collaboration | `/ws/projects/{project_id}/collab` |
| Клиентская навигация | `/p/{project_id}/…` — технический адрес текущего runtime; при restore root заново разрешается, затем открывается сохранённая project-relative page |

Контекст разрешается один раз при начале запроса/handshake и остаётся неизменным до конца, включая streaming/background continuation. Неизвестный/закрытый id — ошибка (например 404), никакого fallback на выбранный проект, автоматической инициализации по GET или переключения всего Studio. Bootstrap подтверждает create для папки без данных, как сейчас требует §5.1.

Prefix предпочтительнее только HTTP header: img/src, download, dynamic import, grammar fetch и browser WS должны иметь тот же project selector. Все URL helpers обязаны учитывать проект: raw files, docs/assets, attachments, uploads, NDJSON rename, pipeline node UI, previewers, plugin pages/grammars. Их текущие стыки: `frontend/src/api/client.ts:197–260,283–299,346,386–389`; `plugin-runtime/loader.ts:34–42`; `lib/highlight/grammars.ts:76–81`; `api/pipelines.py:30–47`. Если добавится header-совместимость, конфликт selectors отклонять, а не выбирать один молча.

### 4.3 События, collab и MCP

- Новые WS подписывать непосредственно на bus адресованного AppContext; не переключать `forward_to` при фокусе вкладки. Legacy browser_bus оставить отдельным адаптером.
- В новом envelope/hello явно передавать project_id и идентификатор поколения потока (epoch); seq/replay cursor имеют scope `(project_id, epoch)`. Клиент проверяет scope до dispatch, gap/drop/restart требует resync только своего проекта. Новое подключение не применяет cursor другого потока.
- Collab и HTTP save получают один immutable project handle; идентичность editor binding — `(project_id, doc_path)`. Перенос окна не должен открывать комнату того же path в другом проекте. Сохранить правила §16.4: room Yjs не персистируется; открытие без правок ничего не пишет.
- Существующий MCP transport и замыкание toolset не заменять UI-dependent selector. Проект встроенного MCP — тот, который породил run. Для session control/Context Viewer нужен `(project identity, owner kind/id)`, при необходимости run generation, отдельно от DB session_key. Cleanup старого run не должен удалять новый lookup.
- Shared auth сохраняется; project routing не вводит RBAC. Проверки token/Host/Origin/path traversal/CSP остаются. Возможный будущий HTTP MCP не является частью VS-17.

### 4.4 Совместимость и глобальные операции

Согласовано сохранить прежние browser URLs/API. Технически предлагается оставить `/api/…`, `/ws`, `/ws/collab`, `POST /api/project/open` как legacy single-selection adapter с прежним wire shape и поведением только browser selection. Desktop использует scoped contract, не вызывает legacy open и не перезагружается от его `project.opened`; изменение legacy selection не переназначает desktop запросы/сокеты, страницы или вкладки. Существующие browser bookmarks продолжают работать в legacy-модели; desktop не навязывает им свой runtime id. На одном backend остаются общие resident contexts и намеренно глобальные application settings, но выбор проекта и клиентское состояние двух режимов изолированы. Повторный запуск desktop только фокусирует существующее окно; запрос открыть конкретный проект направляется к его единственной вкладке (§4.1).

Глобальны по смыслу: health/build, SPA assets, application settings, recent paths, registry установленных плагинов и lifecycle backend/updates. Enable/settings/actions/данные плагина — проектные; общие env builds не отменяются закрытием вкладки (`core/context.py:210–214`; `core/workspace.py:69–70`). В смешанных endpoints следует явно разделить операции по scope. `GET /api/status` сейчас смешивает project jobs/DB и browser-bus counters (`api/project.py:336–364`); новый ответ не должен выдавать общий счётчик за проектный.

Host runtime должен выдавать плагину уже привязанные API/URL/events/router. Namespaces модулей, routes, component/grammar caches — project/plugin/source version; долгоживущие closures не читают «активную вкладку». Старые плагины с прямыми `/api` URL нельзя объявить совместимыми автоматически: нужен аудит, адаптация или явная отметка ограниченной поддержки.

### 4.5 Detach/attach и ресурсы

Живой перенос без reload — согласованное обязательное требование, не предпочтение. Одна и та же живая клиентская сессия/renderer перемещается между окнами с сохранением страницы, интерфейса, текстов, вложений, редакторов и их несохранённого состояния. Reconstruction, remount, сериализация с повторным созданием renderer или восстановление только по URL не являются допустимой альтернативой detach/attach. Конкретный Electron primitive нужно подтвердить отдельным прототипом; техническая неудача прототипа означает необходимость другого механизма, а не разрешение ослабить правило. Жест отделения уточняется отдельно в VS-18 и не блокирует завершение исследования VS-17.

Операция переноса должна быть атомарной по владению tab id: источник остаётся владельцем живой сессии до подтверждения attach в окне-получателе, повторный IPC не создаёт дубликат, ошибка оставляет ту же живую вкладку доступной в источнике. Ack относится к переносу существующего surface, а не к восстановлению нового renderer. Нельзя запускать backend, агента, повторно отправлять prompt или вызывать AppContext.shutdown из-за attach/detach. IPC проверяет отправителя, frame, origin, текущего владельца tab и целевое окно; неизвестные/чужие surfaces отклоняются.

JobEngine уже отдельный на проект (`core/context.py:67`; `engine/jobs.py:84–95`), поэтому лимиты нескольких проектов суммируются на машине. Это существующая модель, не скрытый глобальный лимит; ограничение общего CPU/GPU/agent budget — отдельное возможное решение, не условие изоляции. Эвикция контекстов по числу открытых вкладок не предлагается: VS-03 хранит их до shutdown.

### 4.6 Закрытие, tray, восстановление и уведомления

Закрытие вкладки или отдельного окна не вызывает AppContext.shutdown, cancel задач или остановку backend; контексты продолжают работу по VS-03. Закрытие последнего окна оставляет приложение и backend работающими в трее. Tray и app-scoped IPC/services должны переживать закрытие отдельного окна; quit не должен запускаться только от `window-all-closed`. Явная команда «Выход» завершает приложение, перед этим предупреждая об активных задачах всех resident projects, включая не имеющие вкладок. Отмена выхода не останавливает работу; подтверждённый выход использует общий shutdown всех контекстов. Существующее различение owned backend и независимо запущенного backend сохраняется: оболочка не должна останавливать чужой процесс.

После перезапуска восстанавливаются проекты, окна, порядок вкладок и страницы. Рекомендуемый механизм — отдельный пользовательский desktop session manifest под `user_config_dir()` (предлагаемое имя `desktop-session.json`), содержащий root, window grouping/order, tab order/active tab и project-relative route. Это application-local topology, не managed-project config, не DB проекта и не список только recent paths. При восстановлении roots заново разрешаются в runtime ids, уникальность проекта проверяется до создания вкладок; действующий backend переиспользуется без перезапуска, а при обычном старте процесса launcher вызывается единожды. Не сохранять в manifest auth tokens, bridge secrets, WS cursors старого epoch или эфемерные вложения.

Открытая страница должна иметь восстанавливаемое project-relative представление: потреблённые query/selectors нельзя терять только потому, что текущий URL очищен (§3.3). При явном выходе сохраняется последняя топология до служебного закрытия окон. После crash используется последняя успешно записанная согласованная топология; это не обещание восстановления каждого последнего несохранённого действия. Восстановление несохранённых текстов/черновиков/вложений после выхода или сбоя и работоспособность ссылок после перемещения папки исключены пользователем. Восстановление топологии UI не означает восстановление живых агентских процессов после остановки backend.

Каждое уведомление помечено проектом. В payload нужна проектная адресация вместе с project-relative target, а не только голый route/task id. Клик находит/открывает единственную вкладку проекта, активирует её страницу-цель и показывает/фокусирует соответствующее окно; если вкладка закрыта, используется уже работающий контекст без повторного запуска агента. Нельзя открыть уведомление A в активном B. Новый общий центр уведомлений не создаётся; существующие notification/Producer attention механизмы адаптируются к проектному источнику и владельцу окна.

## 5. Карта будущих правок

Это точные существующие точки интеграции и предлагаемые новые файлы, не разрешение менять их в VS-17. Будущие задачи должны объявить собственные write_paths. Имена в фигурных скобках ниже обозначают перечисленные отдельные файлы, не файловый glob.

| Слой | Файлы и назначение |
| --- | --- |
| Спецификация | `docs/voxarium-studio-dev-spec.md` §5.1, §5.2, §11 и desktop lifecycle; `docs/plugins.md` — project-bound runtime/URL и совместимость. Согласованные правила §8 перенести в spec отдельной будущей задачей; в VS-17 spec не редактируется. |
| Backend адресация | `backend/voxarium_studio/core/workspace.py` — добавить адресный registry/resolver поверх resident contexts, сохранить VS-03; `main.py` — bootstrap state; `api/deps.py` — request-bound ctx; `api/__init__.py` — scoped/legacy routers; `api/project.py` — register/open/status/settings scope; `core/security.py` — отделить server auth lookup от legacy selection без ослабления проверок. |
| События | `backend/voxarium_studio/ws/routes.py` — scoped event/collab handshakes; `ws/bus.py`, `ws/events.py` — адаптер envelope/epoch при сохранении local consumers и legacy wire shape. |
| Agent lookup | `backend/voxarium_studio/teams/backends/base.py`, `claude_code.py`, `qwen.py`; `teams/orchestrator.py`, `chat.py`, `subagents.py`; `api/session_context.py`, `teams.py`, `chats.py` — передать отдельный project-bound runtime key при регистрации/поиске/cleanup. Текущие вызовы: Claude `:433,582,662`, Qwen `:290`, orchestrator `:2163,2203`, API chats `:156,172`, teams `:955,977`. `teams/tools.py` и `teams/backends/mcp_bridge.py` — регрессионные ориентиры, transport менять не требуется. |
| Backend plugins/URLs | `backend/voxarium_studio/plugins/registry.py`, `api/plugins.py`, `api/pipelines.py` — scoped assets/node UI; `plugins/loader.py` — module namespace после проверки. `api/explorer.py`, `docs.py`, `attachments.py` — аудит URL-ответов и file boundary, а не массовое переписывание проектных сервисов. |
| Frontend session | `frontend/src/main.ts`, `App.vue`, `router/index.ts`, `api/client.ts`, `api/types.ts`, `ws/connection.ts`, `ws/events.ts`; `stores/session.ts`, `docs.ts`, `teams.ts`, `chat.ts`, `sync.ts`, `notifications.ts`, `theme.ts` — project-bound session, подписки, stale-response guard, storage. Остальные stores проверить по тому же правилу, окончательный список расширить до начала реализации. |
| Frontend ресурсы/редакторы | `frontend/src/plugin-runtime/index.ts`, `loader.ts`, `node-params.ts`; `types/voxarium_studio-plugin.d.ts`; `lib/highlight/grammars.ts`, `highlighter.ts`; `lib/collab/session.ts`; `views/DocsView.vue`, `DocsGraphView.vue`, `ExplorerView.vue`, `TasksView.vue`, `PipelineEditorView.vue`; `components/docs/BlockEditor.vue`, `components/chat/ChatWidget.vue`, `components/teams/TaskDetail.vue`. |
| Frontend shell/deep links | `frontend/src/components/layout/AppShell.vue`, `DesktopTitleBar.vue`, `SideNav.vue`, `SearchPalette.vue`; `components/project/ProjectSwitcher.vue`; `desktop.d.ts`; `locales/en.json`, `ru.json`. |
| Desktop ownership/IPC | `desktop/main.cjs`, `preload.cjs`, `window-controls.cjs`, `policy.cjs`, `tray.cjs`, `startup.cjs`, `updates.cjs`, `producer-attention.cjs` — уникальный project→tab registry, реестр окон/surfaces, живой перенос, last-window→tray и explicit quit с предупреждением. `run.ps1` менять для открытия вкладок не требуется. |
| Предлагаемые новые модули | `frontend/src/session/project-session.ts` — фабрика project-bound клиента; `desktop/tabs.cjs` — main-process unique project→tab ownership/live transfer controller; `desktop/session-state.cjs` — запись/восстановление topology manifest без drafts/секретов. Имена предварительные: после прототипа могут быть заменены с явным обновлением будущих write_paths. |

## 6. Матрица проверок реализации

Все будущие сценарии выполняются на временных управляемых проектах A/B, с одинаковыми относительными путями документов, pipeline/team/plugin ids; отдельный набор — копии БД с одинаковыми task/chat/subagent ids. Для каждого write проверять и содержимое/БД A, и неизменность B, а не только ответ HTTP.

| Проверка | Ожидаемый результат |
| --- | --- |
| Одновременные REST A/B: docs, tasks/chats, pipelines/runs, VCS, skills/memory, automations, search и settings; активировать B между стартом и ответом запроса A | Назначение запроса не меняется; late response не мутирует store B. Отмена операции A не отменяет B. |
| Scoped unknown id, конфликт selectors, неинициализированный root/create=false | Явная ошибка; нет fallback, записи, миграции или смены текущего проекта. |
| Files: raw/preview/images/attachments, multipart upload, streaming rename, downloads | Читают/пишут только адресованный root; traversal/auth/CSP защита сохранена. |
| Два scoped WS и legacy WS; A/B reconnect/replay/gap/overflow, смена epoch/restart | Нет чужих events; курсоры не смешиваются; resync только своего scope. Legacy open не перезагружает новые вкладки. |
| Plugin одинакового id/version stamp, но разных исходников/config; задержанный import A после активации B | Actions/settings/assets/node UI/routes/grammars принадлежат A; caches не возвращают B; reload/disable одного проекта не ломает второй. |
| Агент A работает при открытии B, detach/attach A, закрытии её окна; возвращение A | Тот же job/native session, один запуск, нет cancel/restart/prompt replay; результат и transcript только в DB A. Отдельно проверить chat, producer, subagents, pipeline, waits, plugin hooks/automations и sync. |
| Copied ids: live session A/B, remote control, Context Viewer, cleanup завершившегося run | Lookup и cleanup не затрагивают чужую сессию. Нельзя включить remote control B запросом A. |
| MCP A после открытия B и переноса окна; bridge secret другого run | Toolset остаётся с A, неверный secret отвергается; нет повторной выдачи tools из выбранного UI. Реальные внешние CLI проверить отдельно от fake backends. |
| Collab одинакового path в A/B, join/save debounce/scribe transition во время detach | Комнаты и saves разделены; нет двойного scribe/потери текста; open/transfer без правок не меняет Markdown и не персистирует Yjs. |
| Несохранённый pipeline, document selection, chat/task text+attachments; in-flight save/upload; повторный/сорванный перенос A→новое окно→другое окно→обратно | Тот же живой renderer и клиентская сессия без reload/remount; страница, редакторы, тексты и вложения сохранены. До attach ack источник владеет сессией; rollback сохраняет её живой, побочные действия не повторяются. |
| IPC чужого tab/window, iframe, неизвестный contents, внешний origin; закрытие соседнего окна | Отказ без изменения ownership; trusted handlers/permissions остальных окон продолжают работать. |
| Глобальные настройки/обновления при открытии нового контекста | Поля проекта не попадают в application config и наоборот; globals доходят всем; restart guard видит фоновые jobs; env build не отменяется закрытием вкладки. |
| Закрытие вкладки, отдельного и последнего окна; отмена/подтверждение явного «Выход» при фоновых задачах | Задачи продолжаются после закрытия вкладок/окон, последнее окно оставляет Studio в трее; tray и IPC других surfaces живы. Выход предупреждает обо всех активных проектах, отмена сохраняет работу, подтверждение завершает приложение и все owned resident contexts; owned backend останавливается один раз, чужой backend не останавливается. |
| Legacy API/browser links и desktop scoped клиенты одновременно | Старые URLs/API/wire shape и browser selection сохранены, legacy open не переназначает desktop, а desktop focus/restore не переключает browser selection. |
| Повторное/одновременное открытие проекта из разных окон, aliases root, повторный запуск desktop | Ровно одна desktop-вкладка проекта; активируется она и её окно; второй запуск фокусирует существующее окно, не создаёт backend или дубль вкладки. |
| Перезапуск с несколькими проектами/окнами/порядком вкладок/страницами, новая runtime epoch, недоступный root | Восстанавливается топология и project-relative страницы, id разрешаются заново, нет дубликатов и чужого fallback; нет требования восстановить несохранённые drafts/вложения либо ссылки после перемещения папки. |
| Уведомление A при активном B, скрытом окне и закрытой вкладке A | Уведомление явно помечено A; клик открывает/фокусирует единственную вкладку и окно A без рестарта задач и без нового общего центра уведомлений. |

Основы существующих тестов: `backend/tests/test_workspace.py`, `test_codex_mcp_bridge.py`, `test_plugins.py`, `test_plugin_hooks.py`, `test_browser_security.py`; `frontend/src/stores/session.spec.ts`, `lib/collab/session.spec.ts`, `editor.spec.ts`; `desktop/test/boot.test.cjs`, `window-controls.test.cjs`, `policy.test.cjs`, `tray.test.cjs`, `startup.test.cjs`, `updates.test.cjs`, `producer-attention.test.cjs`. Предлагается добавить `backend/tests/test_project_scopes.py`, `frontend/src/ws/connection.spec.ts` и `desktop/test/tabs.test.cjs`: они проверяют новый контракт, не заменяют регрессии VS-03.

## 7. Фактически выполненная проверка и неизвестное

При правке после review перечитаны документ и карточки VS-17/VS-18, выполнена независимая проверка согласованности с шестью решениями пользователя и расширена матрица §6. Новые тесты и Electron-прототип в этом документальном проходе не запускались; код/spec не менялись, рабочий сервер не перезапускался. Результат тестов ниже относится к исходному исследовательскому проходу.

В исходном исследовательском проходе запущен существующий `backend/tests/test_workspace.py`: **44 passed in 9.39s**. Команда из backend: `D:\VoxariumStudio\backend\.venv\Scripts\python.exe -m pytest tests/test_workspace.py -q --basetemp=D:\VoxariumStudio\.voxarium_studio\temp\TASK-17\pytest -p no:cacheprovider`, с TEMP/TMP внутри TASK-17 и PYTHONDONTWRITEBYTECODE=1. Это pytest fixtures/in-process contexts, не запуск сетевого backend и не обращение к рабочим данным. Предупреждение pytest-asyncio о неуказанном default fixture loop scope не исправлялось.

В частности проверены существующие сценарии: background agent/context reuse и DB isolation (`test_workspace.py:253–313`), local events/legacy replay (`:316–353`), shutdown всех проектов (`:356–378`), atomic failure/concurrent opens/auth. Эти тесты не доказывают работу ещё не реализованных вкладок.

Не проверены GUI detach/attach, реальные агенты/их нативные журналы между копиями проектов, неизвестные сторонние плагины, memory/CPU при большом числе resident contexts, межоконная гонка storage/drafts и конкретный reparent primitive Electron 45.1.0 (`desktop/package.json:19`). Нужен отдельный прототип с проверками отсутствия reload/remount при переносе, crash/focus/IME/devtools/collab и сохранности живого renderer. Перенос без reload обязателен по решению пользователя, но его техническая реализация ещё не подтверждена; завершение исследования не означает приёмку будущего прототипа. Shared launch_root или вложенные managed projects физически могут адресовать пересекающиеся файлы: project routing не обещает файловую sandbox-изоляцию; такой случай требует явной проверки/предупреждения, не молчаливой гарантии.

## 8. Согласованные решения пользователя

Источник — ответ пользователя, переданный в review VS-17 от 13.11.2026. Ранее открытые шесть продуктовых вопросов закрыты следующими правилами:

1. **Один проект — одна вкладка во всём desktop-приложении.** Повторное открытие фокусирует её окно и активирует существующую вкладку; дубликаты одного проекта в разных окнах не создаются.
2. **Живой перенос без reload.** Сохраняются интерфейс, тексты, вложения, редакторы и открытая страница. Remount/reconstruction не являются запасным вариантом согласованной функции.
3. **Закрытие не останавливает задачи.** Закрытие вкладки/отдельного окна оставляет задачи работать. После закрытия последнего окна Studio остаётся в трее. Явный «Выход» завершает приложение с предупреждением при активных задачах.
4. **Восстановление после перезапуска:** проекты, окна, порядок вкладок и страницы. Несохранённые черновики/вложения после выхода или сбоя и ссылки после перемещения папки не входят. Это не восстановление живых агентов после остановки backend.
5. **Legacy browser URLs/API сохраняются изолированно от desktop.** Повторный запуск фокусирует существующее окно, повторное открытие проекта — его вкладку. Адресация и устойчивость runtime id — технический механизм этих правил, не отдельная пользовательская функция или дополнительный открытый вопрос.
6. **Уведомления помечены проектом.** Клик открывает соответствующую вкладку/окно; новый общий центр уведомлений не создаётся.

Жест отделения уточняется отдельно в VS-18 ([[desktop-tabs/window-model]]); VS-17 не выбирает его и не считает вопрос блокером своей приёмки. Неизвестные технические детали перечислены в §7 и проверяются будущим прототипом/реализацией, а не возвращаются пользователю как повторное согласование уже принятых правил.

На этом исследование VS-17 завершено. Следующие шаги — отдельная поправка dev spec по этим решениям, минимальный Electron live-transfer прототип, затем scoped routing/lookup, project-bound frontend/plugins и window ownership с матрицей §6. Код и spec в данном проходе не меняются; сохранение фоновых задач VS-03 остаётся готовой основой.
