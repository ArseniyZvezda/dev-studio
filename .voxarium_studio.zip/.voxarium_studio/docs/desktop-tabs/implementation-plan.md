# Проект плана реализации вкладок Studio

Основание: принятые исследования VS-17 [[desktop-tabs/project-isolation]] и VS-18 [[desktop-tabs/window-model]]. Документ описывает предлагаемый порядок работы, не является разрешением на выполнение. Утверждение этапов выполняется отдельной кнопкой Producer. Поведение уже согласовано; повторное согласование семи правил не требуется.

## Границы и контрольные точки

- Один backend :8765; никаких серверов на вкладку/окно. Рабочий Studio не перезапускать без отдельного согласования момента проверки.
- VS-03 сохраняется. Живой перенос означает тот же renderer/view без reload/remount; реконструкция из snapshot не принимается.
- Начало: спецификация и отдельный native Electron harness без backend. После успешного native spike — проектная адресация и изоляция.
- Завершение первого этапа ещё не означает готовые пользовательские вкладки. Оболочка, lifecycle, восстановление, уведомления и полная приёмка — следующий отдельно утверждаемый этап.
- Исключены crash-drafts, поиск перемещённых проектов, восстановление остановленных агентов, общий центр уведомлений, RBAC и sandbox плагинов.
- Новые UX-вопросы передаются пользователю. Исправления результатов done оформляются отдельными задачами после review.

## Этап 1 — к утверждению, VS-20–27

### VS-20 — Закрепить контракт вкладок в спецификации

Зависимости: VS-17, VS-18, VS-19.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Зафиксируй семь принятых правил, scoped REST/WS/ресурсы и отдельный legacy adapter, роли shell/project/main, уникальность проекта, live transfer, last-window→tray/explicit quit, manifest и проектные уведомления. Сохрани разделение global/project settings и исключения scope. Уточни устаревший абзац AGENTS.md про shutdown при переключении. docs/plugins.md описывает project-bound runtime и пределы совместимости прямых /api URL. Приёмка: один непротиворечивый контракт для последующих задач; без новой UX-функциональности, RBAC, sandbox, crash-drafts или новых портов. Только документация, итог на русском.

Файлы записи:

- `docs/voxarium-studio-dev-spec.md`
- `docs/plugins.md`
- `AGENTS.md`

### VS-21 — Доказать живой перенос и drag-out в Electron

Зависимости: VS-17, VS-18.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Создай изолированный opt-in harness на установленном Electron: shell BrowserWindow + живой WebContentsView. Без backend и без запуска основного Studio. Проверь reparent туда-обратно, detach командой, настоящий drag-out и drop на полосу другого окна, Escape/отмену/ошибку target; не выводи tear-out из любого dragend. Зафиксируй wc.id, sentinel/timeOrigin, отсутствие navigation/destroy/bootstrap, сохранение DOM/File/selection, focus и bounds. Приёмка: подтверждён механизм live transfer и жестов, воспроизводимая команда, результаты и ограничения в desktop-tabs/native-spike.md. Mock не заменяет native; если GUI/OS drag не проверяем или механизм не работает, верни question, не ослабляй требование и не выдавай гипотезу за успех.

Файлы записи:

- `desktop/test/native-transfer-spike.cjs`
- `desktop/test/fixtures/native-transfer/*`
- `.voxarium_studio/docs/desktop-tabs/native-spike.md`

### VS-22 — Добавить адресные контексты и проектный REST

Зависимости: VS-20, VS-21.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Добавь registry canonical root→runtime project_id/epoch поверх resident contexts, POST /api/projects/open без смены legacy selection и /api/projects/{project_id}/… с immutable request ctx. Раздели global/project операции; legacy /api/project/open и /api остаются прежними. Неизвестный id/alias/open failure не ведут к fallback или неявному create. Auth/Host/Origin/path safeguards сохранить. Приёмка: concurrent A/B reads/writes и delayed/stream запросы не смешивают контексты; aliases/coalescing, failure rollback, глобальные настройки и VS-03 покрыты тестами. Не менять пользовательский lifecycle и не трогать IPC/frontend.

Файлы записи:

- `backend/voxarium_studio/core/project_scope.py`
- `backend/voxarium_studio/core/workspace.py`
- `backend/voxarium_studio/main.py`
- `backend/voxarium_studio/api/deps.py`
- `backend/voxarium_studio/api/__init__.py`
- `backend/voxarium_studio/api/project.py`
- `backend/voxarium_studio/core/security.py`
- `backend/tests/test_project_scopes.py`
- `backend/tests/test_workspace.py`

### VS-23 — Изолировать WS и collab по проектам

Зависимости: VS-22.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Реализуй /ws/projects/{project_id} и /ws/projects/{project_id}/collab с привязкой при handshake к local bus/context, scope+epoch в hello/envelope и корректным replay/gap. Legacy WS/wire shape отдельно, без его переключения от desktop. Приёмка: одновременно A/B/legacy; чужие ids/cursors, reconnect/overflow/restart не доставляют чужих событий; одинаковые doc paths имеют разные комнаты. Сохрани block-editor spec и §16.4: open ничего не пишет, Yjs не персистируется. При затрагивании sync установи remote в backend env и реально выполни test_remote_sync, не считай skip успехом. Внешний remote protocol без необходимости не меняй.

Файлы записи:

- `backend/voxarium_studio/ws/routes.py`
- `backend/voxarium_studio/ws/bus.py`
- `backend/voxarium_studio/ws/events.py`
- `backend/tests/test_project_events.py`
- `backend/tests/test_remote_sync.py`

### VS-24 — Разделить runtime-реестры агентских сессий

Зависимости: VS-22, VS-19.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Устрани коллизии process-global live sessions/context inspectors при скопированных task/chat/subagent IDs. Отдельный runtime lookup key включает проект/тип owner/поколение; DB session_key не переписывать. Проведи ключ через регистрацию, control/context lookup и cleanup; старый run не удаляет новый. MCP run-bound toolset/bridge не переназначать и не перепроектировать. Приёмка: два проекта с одинаковыми IDs одновременно, control/Context Viewer/cleanup только своего проекта, завершение A не затрагивает B; регрессии backend adapters и MCP. Сохрани параллельные изменения VS-19.

Файлы записи:

- `backend/voxarium_studio/teams/backends/base.py`
- `backend/voxarium_studio/teams/backends/claude_code.py`
- `backend/voxarium_studio/teams/backends/qwen.py`
- `backend/voxarium_studio/teams/backends/codex.py`
- `backend/voxarium_studio/teams/orchestrator.py`
- `backend/voxarium_studio/teams/chat.py`
- `backend/voxarium_studio/teams/subagents.py`
- `backend/voxarium_studio/api/session_context.py`
- `backend/voxarium_studio/api/teams.py`
- `backend/voxarium_studio/api/chats.py`
- `backend/tests/test_project_session_isolation.py`

### VS-25 — Привязать backend-ресурсы плагинов к проекту

Зависимости: VS-22.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Проверь и исправь generated URLs и выбор источников assets/node UI/raw/preview/images/attachments/download/upload для scoped REST; все ссылки должны сохранять project scope. Одинаковые plugin id/version stamp в A/B не подменяют исходники. Проверкой установи риск sys.modules namespace; изолируй module names там, где необходимо для корректного параллельного load/lazy lookup. Приёмка: разные файлы по одинаковым путям и plugins A/B читаются/пишутся только в своём root, delayed imports и disable/reload одного не ломают второй, traversal/auth прежние; legacy URLs проходят регрессии. Не обещать sandbox сторонним плагинам.

Файлы записи:

- `backend/voxarium_studio/plugins/registry.py`
- `backend/voxarium_studio/plugins/loader.py`
- `backend/voxarium_studio/api/plugins.py`
- `backend/voxarium_studio/api/pipelines.py`
- `backend/voxarium_studio/api/explorer.py`
- `backend/voxarium_studio/api/docs.py`
- `backend/voxarium_studio/api/attachments.py`
- `backend/tests/test_project_resources.py`
- `backend/tests/test_plugins.py`

### VS-26 — Привязать SPA, API и сокеты к проекту вкладки

Зависимости: VS-22, VS-23.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Добавь immutable project binding для /p/{project_id}/… и единый scoped URL builder/API client, включая multipart, raw, download и streams. WS/collab закрепить за своим scope+epoch; stale responses/cursors игнорировать и resync только свой проект. Legacy bootstrap/open/reload остаются legacy-only; desktop не reload от чужого project.opened. Global auth/preferences не превращать в проектные. Приёмка: две renderer-сессии A/B и legacy switch, чужие delayed ответы/WS, invalid handles, reconnect и одинаковые collab paths; typecheck и целевые тесты. Оболочку окон здесь не реализовывать.

Файлы записи:

- `frontend/src/session/project-session.ts`
- `frontend/src/api/project-scope.ts`
- `frontend/src/api/project-scope.spec.ts`
- `frontend/src/api/client.ts`
- `frontend/src/api/types.ts`
- `frontend/src/api/auth.ts`
- `frontend/src/router/index.ts`
- `frontend/src/ws/connection.ts`
- `frontend/src/ws/connection.spec.ts`
- `frontend/src/ws/events.ts`
- `frontend/src/lib/collab/session.ts`
- `frontend/src/lib/collab/session.spec.ts`
- `frontend/src/stores/session.ts`
- `frontend/src/stores/session.spec.ts`
- `frontend/src/stores/sync.ts`

### VS-27 — Изолировать frontend runtime плагинов и кэши

Зависимости: VS-26, VS-25.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Передавай плагинам project-bound API/URL/events/router; assets, import, CSS, previewers, node UI и grammars используют свой scoped URL. Раздели cache keys/route registration по project/plugin/source identity где требуется; closures не читают текущий legacy проект. Сохрани plugin API насколько возможно и явно покажи неподдержанные прямые legacy URL, не добавляя sandbox. Приёмка: plugins с одинаковым id/stamp, но разным кодом/грамматикой в A/B; задержанный import A после открытия B; перезагрузка/отключение A не меняет B. Тесты, typecheck и проверка согласно docs/plugins.md.

Файлы записи:

- `frontend/src/plugin-runtime/index.ts`
- `frontend/src/plugin-runtime/loader.ts`
- `frontend/src/plugin-runtime/node-params.ts`
- `frontend/src/types/voxarium_studio-plugin.d.ts`
- `frontend/src/lib/highlight/grammars.ts`
- `frontend/src/lib/highlight/highlighter.ts`
- `frontend/src/plugin-runtime/project-scope.spec.ts`

## Следующий этап — ещё не создан и не утверждён

Ниже предварительные независимые результаты и файлы. Перед созданием карточек повторно проверить board и фактические интерфейсы первого этапа, переиспользовать подходящие задачи, объявить write_paths и представить новый план. Номера задач здесь не назначены. Указания не запускают работу.

### Изолировать черновики и сохранить close-поведение

Зависимости по результатам: VS-26.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Изолируй project-specific persisted drafts/storage по стабильному canonical project key, включая new chat и совпадающие task/chat IDs; глобальные предпочтения не дублировать. Подготовь минимальный close ACK, сохраняющий существующие гарантии редакторов/ошибок save при реальном закрытии view. Живой transfer не вызывает flush/leave/unmount и не сериализует editor/File ради remount. Не добавлять новый самостоятельный UX закрытия или crash recovery; новые продуктовые вопросы возвращать question. Приёмка: A/B с одинаковыми IDs, delayed save, draft/attachment isolation, закрытие не выдаёт потерянный save за успех; чистый collab документ не записывается при open/transfer.

Предварительные файлы записи:

- `frontend/src/stores/chat.ts`
- `frontend/src/stores/chat.spec.ts`
- `frontend/src/components/chat/ChatWidget.vue`
- `frontend/src/components/teams/TaskDetail.vue`
- `frontend/src/stores/docs.ts`
- `frontend/src/stores/docs.spec.ts`
- `frontend/src/views/DocsView.vue`
- `frontend/src/components/docs/BlockEditor.vue`
- `frontend/src/views/PipelineEditorView.vue`
- `frontend/src/desktop/close-barrier.ts`
- `frontend/src/desktop/close-barrier.spec.ts`

### Создать реестр окон и безопасный IPC вкладок

Зависимости по результатам: VS-21; VS-20; VS-22.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. По принятому native spike создай один app controller: WindowRecord/TabRecord, canonical root→одна вкладка, shell BrowserWindow + живые project WebContentsView. Контролируй parking/bounds/focus, coalesced open и immutable bootstrap. IPC handlers/services регистрируются один раз, sender role/mainFrame/origin/owner берутся из main registry; project view не получает shell права. Window controls следуют текущему владельцу; permissions allowlist общая, без ослабления политики. Приёмка: fake/targeted tests на два окна, unique opens, stale/foreign sender, cleanup одного окна не ломает другое, launcher не вызывается на open/transfer. Здесь базовая инфраструктура; DnD, restore и полный close lifecycle отдельными задачами.

Предварительные файлы записи:

- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/tabs-ipc.cjs`
- `desktop/preload.cjs`
- `desktop/window-controls.cjs`
- `desktop/policy.cjs`
- `desktop/startup.cjs`
- `desktop/updates.cjs`
- `frontend/src/desktop.d.ts`
- `desktop/test/tabs.test.cjs`
- `desktop/test/tabs-ipc.test.cjs`
- `desktop/test/window-controls.test.cjs`
- `desktop/test/policy.test.cjs`
- `desktop/test/startup.test.cjs`
- `desktop/test/updates.test.cjs`

### Добавить полосу вкладок и открытие проектов

Зависимости по результатам: Создать реестр окон и безопасный IPC вкладок; VS-26; VS-27; VS-24.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Раздели shell bootstrap и project SPA: shell не создаёт project stores/WS/plugins. Полоса вкладок, active/pending/error, open/recent/browse, activation/reorder и команда отделения через узкий IPC. Повторное открытие фокусирует существующую вкладку и её окно; новый проект не меняет живые соседние. Сохрани подтверждение создания .voxarium_studio и browser UX. Native view не перекрывает меню/tab hit zones; no-drag controls отделены от drag region. Приёмка: EN/RU, keyboard/focus и component tests, typecheck/build; открытие A/B без reload/rebind. DnD реализует отдельная задача поверх этой полосы.

Предварительные файлы записи:

- `frontend/src/main.ts`
- `frontend/src/App.vue`
- `frontend/src/DesktopShell.vue`
- `frontend/src/components/layout/ProjectTabStrip.vue`
- `frontend/src/components/layout/ProjectTabStrip.spec.ts`
- `frontend/src/components/layout/DesktopTitleBar.vue`
- `frontend/src/components/layout/AppShell.vue`
- `frontend/src/components/project/ProjectMenuPanel.vue`
- `frontend/src/components/project/ProjectSwitcher.vue`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/desktop/tabs.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

### Реализовать живой drag-out и перенос между окнами

Зависимости по результатам: Добавить полосу вкладок и открытие проектов; VS-21; Изолировать черновики и сохранить close-поведение.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Реализуй все три согласованных пути: drag-out→новое окно, команду отделения и DnD на полосу существующего окна, включая reorder. Используй подтверждённый native механизм, одноразовые tokens/revisions и транзакцию attach ACK→commit/rollback; тот же view/contents без reload/remount. Escape/невалидный target/сбой/close race не создают лишних окон и не уничтожают view; source теряет права после commit. Приёмка: unit/integration tests на повтор token, stale owner, последний tab, target/source failure, rollback и повтор A→B→A; сохраняются JS identity, drafts/File/editor/страница. Не считать только HTML dragend доказательством native drag-out.

Предварительные файлы записи:

- `desktop/tabs.cjs`
- `desktop/tabs-ipc.cjs`
- `desktop/test/tabs.test.cjs`
- `desktop/test/tabs-ipc.test.cjs`
- `frontend/src/components/layout/ProjectTabStrip.vue`
- `frontend/src/components/layout/ProjectTabStrip.spec.ts`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/desktop/tabs.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

### Сохранить фоновые задачи при закрытии окон

Зависимости по результатам: Создать реестр окон и безопасный IPC вкладок; Добавить полосу вкладок и открытие проектов; Изолировать черновики и сохранить close-поведение; Реализовать живой drag-out и перенос между окнами.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Close-tab/window закрывают только UI, не contexts/jobs. Последнее окно оставляет tray/IPC/backend живыми; tray и second launch возвращают shell без нового backend. Явный Выход учитывает активные задачи всех resident проектов (даже без вкладок), предупреждает; cancel ничего не останавливает, confirm останавливает только owned backend один раз. Сохрани update/stop failure safeguards и существующий close/save barrier; transfer сериализован с close. Приёмка: автоматические сценарии zero windows, background projects, independent/owned backend, отмена/подтверждение quit, повторный запуск и stop failure; VS-03 регрессии. Не испытывать выход на работающем Studio пользователя.

Предварительные файлы записи:

- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/tray.cjs`
- `desktop/updates.cjs`
- `desktop/test/tray.test.cjs`
- `desktop/test/shutdown.test.cjs`
- `desktop/test/boot.test.cjs`
- `desktop/test/updates.test.cjs`
- `backend/voxarium_studio/api/project.py`
- `backend/tests/test_project_scopes.py`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

### Восстанавливать топологию окон и страницы

Зависимости по результатам: Сохранить фоновые задачи при закрытии окон; VS-26.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Один atomic/versioned manifest user_config_dir()/desktop-session.json: canonical roots, окна/порядок/active tabs и project-relative страницы, в том числе потреблённые query/selected target. Restore заново разрешает runtime ids, дедуплицирует roots и не меняет legacy selection. Не сохраняй tokens, Yjs, drafts/File или WS cursors; не ищи перемещённые папки. Служебный teardown после quit не затирает snapshot; cancelled transfer не попадает в него. Приёмка: restart/new epoch, повреждённая запись, unavailable root без fallback/create, concurrent reopen/restore, валидные bounds и порядок; unit tests manifest и page descriptors. Не перезапускать Studio ради проверки на этом этапе.

Предварительные файлы записи:

- `desktop/session-state.cjs`
- `desktop/main.cjs`
- `desktop/tabs.cjs`
- `desktop/test/session-state.test.cjs`
- `frontend/src/desktop/tabs.ts`
- `frontend/src/router/index.ts`
- `frontend/src/views/ExplorerView.vue`
- `frontend/src/views/TasksView.vue`
- `frontend/src/desktop/page-state.ts`
- `frontend/src/desktop/page-state.spec.ts`

### Направлять уведомления в окно нужного проекта

Зависимости по результатам: Сохранить фоновые задачи при закрытии окон; Восстанавливать топологию окон и страницы; VS-23.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Адаптируй existing notifications/Producer attention: метка проекта и project-relative target; click открывает/фокусирует единственную вкладку и её окно. Нужен app-level источник событий resident проектов и при нуле project renderers; не использовать выбранную legacy browser_bus и не создавать общий центр UI. Binding/allowlist сервиса сохраняют auth/scope; badge/attention пересчитываются после transfer, без source-window closures. Приёмка: уведомление A при активном B, скрытой/закрытой A, нуле окон; двойной click и гонка restore не дублируют tabs/jobs; stale handle/root error без fallback. EN/RU и backend/desktop/frontend tests.

Предварительные файлы записи:

- `desktop/project-notifications.cjs`
- `desktop/tabs.cjs`
- `desktop/main.cjs`
- `desktop/producer-attention.cjs`
- `desktop/tray.cjs`
- `desktop/preload.cjs`
- `desktop/test/project-notifications.test.cjs`
- `desktop/test/producer-attention.test.cjs`
- `backend/voxarium_studio/ws/routes.py`
- `backend/voxarium_studio/ws/events.py`
- `backend/tests/test_project_events.py`
- `frontend/src/stores/notifications.ts`
- `frontend/src/stores/notifications.spec.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

### Проверить сквозную изоляцию двух проектов

Зависимости по результатам: VS-24; VS-25; VS-27; Изолировать черновики и сохранить close-поведение; Направлять уведомления в окно нужного проекта.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Независимая проверка матрицы VS-17 §6 на fixtures A/B с одинаковыми paths/plugin IDs и скопированными task/chat/subagent IDs. Добавь недостающие сквозные тесты REST/streams/assets/uploads, WS/replay/collab, MCP/runtime lookup, global settings и legacy switching; проверяй данные/DB обоих проектов, а не только HTTP. Запусти релевантные backend/frontend suites; remote_sync не пропускать при проверке collab. Сохрани команды, результаты и ограничения в desktop-tabs/isolation-verification.md. Только тесты/отчёт, без скрытых продуктовых исправлений; дефекты передай в review для отдельных корректирующих задач. Приёмка: воспроизводимое доказательство отсутствия cross-project записи/событий/остановки сессий.

Предварительные файлы записи:

- `backend/tests/test_desktop_project_isolation.py`
- `frontend/src/session/project-session.spec.ts`
- `.voxarium_studio/docs/desktop-tabs/isolation-verification.md`

### Проверить вкладки в настоящем и packaged Electron

Зависимости по результатам: Проверить сквозную изоляцию двух проектов; Реализовать живой drag-out и перенос между окнами; Восстанавливать топологию окон и страницы; Направлять уведомления в окно нужного проекта.

Основание: .voxarium_studio/docs/desktop-tabs/{project-isolation,window-model}.md (VS-17/18), AGENTS.md и dev spec. Один backend :8765; VS-03 не переделывать. Рабочий Studio не перезапускать. Добавь новые runtime modules в packaging files и opt-in native smoke harness. Выполни VS-18 §9.4 на demo + безопасном fixture A/B: все жесты туда-обратно, тот же wc.id/sentinel/timeOrigin без navigation, draft/File/undo/caret и delayed save; ошибки/IME/DPI/focus; фоновые задачи, tray/quit ownership, restore, notifications, legacy mode, EN/RU и packaged сборка. Один :8765, тесты не запускают backend на вкладку. Подключайся только к совместимому runtime; если нужны restart/переключение рабочего проекта/остановка задач — сначала question о времени проверки, не выполняй самовольно. Fixtures/logs в .scratch; не используйте реальные пользовательские данные. Приёмка: отчёт desktop-tabs/native-verification.md с точными выполненными/невыполненными проверками и доказательствами; mock/скриншоты не заменяют native drag. Дефекты — в review, без незаявленных исправлений.

Предварительные файлы записи:

- `desktop/package.json`
- `desktop/test/electron-tabs-smoke.cjs`
- `desktop/test/fixtures/electron-tabs/*`
- `.voxarium_studio/docs/desktop-tabs/native-verification.md`

