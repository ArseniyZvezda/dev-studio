# Проверка упаковки вкладок Studio — VS-67

Дата: 14.11.2026. Основание: dev spec §5.3, [[desktop-tabs/implementation-plan]], [[desktop-tabs/window-model]] §9. Результат: собран Windows x64 ZIP с packaged Electron; содержимое действительно распаковано и сверено. **Это проверка состава и происхождения сборки, не native-приёмка.**

## Артефакт

- Путь: `D:\VoxariumStudio\.scratch\desktop-tabs-package\VS-67-f84cf0d-win-x64.zip`.
- SHA-256: `07fa118a87e2310082ff0e80e7a7cff8da3821048ffe1f096b3f6c79dd13d5a7`.
- Размер: **395068659 байт**. В распакованном ZIP: **11733 файла**.
- Формат: ZIP приложения Windows x64, **не NSIS-установщик**, без установки/публикации. Electron 45.1.0, electron-builder 26.18.0; подпись отключена существующей настройкой `signExecutable: false`.

Рядом сохранены долговременные свидетельства:

- `VS-67-artifact-verification.json` — хэш ZIP и SHA-256 каждого распакованного файла;
- `VS-67-asar-verification.json` — inventory ASAR, metadata и хэши runtime-модулей;
- `VS-67-runtime-verification.json` — сверка backend/SPA/plugins и файловые хэши backend;
- `VS-67-snapshot-inputs.json` — хэши исходников staging, использованных для сборки;
- `VS-67-source-stamp.json` — идентичность исходного рабочего дерева.

## Состав и настройки

Необходимое расширение `files` / `extraResources` **уже присутствовало** в незакоммиченном `desktop/electron-builder.cjs` до VS-67. Оно сохранено; дополнительных продуктовых правок не потребовалось. `package.json` не изменялся: штатные `pack`/`dist` явно используют этот конфиг, дублировать списки не нужно.

В ASAR найдены и побайтно сверены со staging все **17 runtime-модулей**:

`main.cjs`, `preload.cjs`, `backend-version.cjs`, `policy.cjs`, `window-controls.cjs`, `producer-attention.cjs`, `tray.cjs`, `startup.cjs`, `updates.cjs`, `update-feed.cjs`, `tabs.cjs`, `tabs-ipc.cjs`, `tab-drag.cjs`, `native-terminal.cjs`, `session-state.cjs`, `project-events.cjs`, `project-notifications.cjs`.

Транзитивные локальные runtime-require не имеют пропусков. `scripts/release.cjs` нужен только dev-ветке main. Native helper правильно лежит **вне ASAR**, `resources/native-terminal.ps1`; его хэш совпал с исходником staging. Наличие пути не доказывает работу native hooks. Проверены `resources/stop-backend.ps1`, runtime Python/Node и EN/RU-каталоги: каталоги в ASAR совпадают с исходными frontend locales staging. Тесты в ASAR не попали.

## Версии и происхождение

- HEAD исходного checkout: `f84cf0d9838e46b7f58e357331dbc3ef38685f9b`, branch `main`, без exact tag; дерево **dirty**. Это не чистый релиз и не утверждение, что одного commit hash достаточно для воспроизведения: точный состав фиксируют manifest-хэши.
- Runtime backend `_build_stamp.json.version`, свежий SPA `static/studio-version.json.version` и ASAR `package.json.studioVersion`: одинаковое значение **`f84cf0d`**.
- Номинальная версия Python package / frontend package / Electron SemVer: **5.0.0**. Это штатный fallback SemVer для untagged commit, не замена runtime identity.
- Backend wheel заново собран из временной копии текущих исходников, не взят из установленного Studio. Побайтно сверены **151 Python-файл**, **246 файлов SPA** и **59 файлов встроенных плагинов** со staging. Встроенные плагины принёс существующий wheel force-include.
- Базовый Python/Node и зависимости взяты из копии `desktop/build/runtime`; сам старый backend там заменён только внутри staging свежим wheel через штатный `prepare-runtime.ps1`. `uv export --frozen` и constraints использовали скопированный текущий `backend/uv.lock`; resolve: 53 пакета. Изолированная проверка CLI/import, static/plugins и равенства версий внутри штатного скрипта прошла.

## Безопасная staging-сборка и команды

Все временные файлы, копии, caches, логи и распаковка: `D:\VoxariumStudio\.voxarium_studio\temp\TASK-67` (`$T` ниже). Только готовый ZIP и итоговые manifests скопированы в согласованный каталог `.scratch/desktop-tabs-package`.

Скопированы `frontend`, `backend`, `desktop`, `CHANGELOG.md`, `run.cmd`, `run.ps1`; исключены исходные static/build/dist, venv и caches. `node_modules` обоих JS-проектов и базовый runtime скопированы **физически, без junction**: сборщик не может записать через ссылку в исходные зависимости. SPA построен заново в `stage/backend/voxarium_studio/static`.

Экспортированная копия не содержит `.git`. Поэтому **только в staging** `sourceReleaseInfo` возвращает заранее считанный release исходного checkout, а wheel hook получает заранее считанный `stamp_payload` с `dirty: true`. Продуктовые `release.cjs`/`hatch_build.py` не менялись; это фиксация одной исходной идентичности для SPA и wheel, а не присвоение старому runtime новой версии.

Основные выполненные команды (PowerShell; cwd указан явно):

```powershell
$T = 'D:\VoxariumStudio\.voxarium_studio\temp\TASK-67'
# Подготовка физической копии и source manifests:
backend/.venv/Scripts/python.exe -B "$T/stage.py"
# TEMP/TMP, UV_CACHE_DIR, ELECTRON_CACHE, ELECTRON_BUILDER_CACHE направлены в $T.
Set-Location "$T/stage"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File desktop/scripts/prepare-runtime.ps1
# Скрипт выполняет vue-tsc + Vite, uv export/install wheel, strip-build-paths и isolated imports.
Set-Location "$T/stage/desktop"
# Сначала сформирован win-unpacked штатным builder (см. ограничение NSIS ниже).
node node_modules/electron-builder/cli.js --config electron-builder.cjs --win nsis --x64 --publish never "--config.directories.output=$T/output"
# Финальный безопасный артефакт без installer-generation:
node node_modules/electron-builder/cli.js --config electron-builder.cjs --win zip --x64 --publish never "--prepackaged=$T/output/win-unpacked" "--config.directories.output=$T/zip-output" --config.artifactName=VS-67-f84cf0d-win-x64.zip
Set-Location D:/VoxariumStudio
node "$T/verify-asar.cjs"
backend/.venv/Scripts/python.exe -B "$T/verify-runtime.py"
backend/.venv/Scripts/python.exe -B "$T/verify-zip.py"
Get-FileHash .scratch/desktop-tabs-package/VS-67-f84cf0d-win-x64.zip -Algorithm SHA256
```

ZIP распакован в `$T/zip-extracted`, после проверки безопасных entry paths. SHA-256 и набор **всех 11733 файлов** совпали с `output/win-unpacked`, на котором выполнены ASAR/runtime-проверки; хэш скопированного итогового ZIP также повторно совпал. Проверки реализованы одноразовыми task-private probes, не новой тестовой инфраструктурой проекта.

## Проверки и ограничения

- Существующие Node suites: `boot`, `shutdown`, `tabs-ipc`, `tab-drag-ipc`, `tab-drag`, `session-state`, `project-events`, `project-notifications`, `policy`, `window-controls`, `tray`, `producer-attention`, `startup`, `updates`, `update-feed` — команда `node --test desktop/test/<имя>.test.cjs` с перечисленными 15 файлами: **249 passed, 0 failed, 0 skipped**. Native/launcher/update вызовы в них подменены; реальные действия не выполнялись.
- `vue-tsc --build && vite build` staging: успешно. Vite предупреждает о будущем native config loader и крупных chunks; это не ошибка сборки. Полные frontend/backend suites не требовались и не запускались. Graphify использован перед поиском, затем вывод проверен по текущим исходникам; независимый read-only subagent подтвердил покрытие packaging lists.
- NSIS-команда была **остановлена на компрессии payload**, когда инспекция установленного `NsisTarget.js` выявила, что следующий штатный шаг запускает промежуточный installer для генерации uninstaller. На момент остановки был только промежуточный `.nsis.zip`, Setup EXE ещё отсутствовал. Этот шаг не выполнялся; обхода запрета и изменения builder internals нет. Для завершения в разрешённых рамках выбран ZIP target. **NSIS-сборка и установочный сценарий не проверены**; при их необходимости потребуется отдельное разрешение на этот build-time запуск.
- Исходный `backend/voxarium_studio/static` остался побайтно неизменным относительно предсборочного manifest. Исходный `desktop/build/runtime`, installed runtime и работающий Studio не заменялись; сборка/strip/install wheel были направлены только в копию. Посторонние изменения сохранены.
- Серверы, Electron/приложение, installer, update, Quit не запускались. Ничего не установлено и не опубликовано.
- Drag-out/live transfer, native helper, tray/close/explicit Quit, restore, уведомления, DPI/IME и поведение packaged UI остаются отдельной native-приёмкой по [[desktop-tabs/window-model]] §9.4. Наличие этого ZIP **не означает** прохождения этой приёмки.
