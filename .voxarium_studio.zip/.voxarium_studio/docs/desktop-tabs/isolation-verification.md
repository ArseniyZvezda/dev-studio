# VS-68 — адресная проверка изоляции проектов

## Итог и границы

Проверено 14.11.2026 в checkout `D:\VoxariumStudio`, HEAD `f84cf0d9838e46b7f58e357331dbc3ef38685f9b` **с незакоммиченными интеграционными изменениями**. Нормативное основание: dev spec §5.3, [[desktop-tabs/project-isolation]], [[desktop-tabs/implementation-plan]]; следующий native этап — [[desktop-tabs/shell-stage-plan]], VS-69.

**Текущие адресные проверки: 65 backend + 144 frontend = 209 passed**, три TypeScript-конфигурации — exit 0. Подтверждённых продуктовых дефектов в проверенном охвате не обнаружено. Добавлен только один regression test: `backend/tests/test_desktop_project_isolation.py`; продуктовые файлы не исправлялись, новый frontend spec не понадобился. Это приёмка изоляции в тестовых fixtures, **не приёмка installed/packaged Electron или работающего Studio**.

Ни серверы, ни Electron, ни реальные CLI-агенты не запускались. Рабочий Studio не переключался/не перезапускался; installed/static не заменялись, build не выполнялся. ASGI requests, WebSocket ASGI harness и AppContext lifespan исполнялись внутри тестового процесса. Legacy switches и имитация новой backend epoch ниже относятся только к fixtures.

## Переиспользованные принятые доказательства

Карточки перечисленных задач перечитаны через Studio; их прежние totals не прибавлены к 209 текущим тестам.

| Принятая работа | Что переиспользовано |
| --- | --- |
| VS-17, [[desktop-tabs/project-isolation]] §7 | VS-03/resident contexts; исторический workspace прогон 44 passed. Исследование само по себе не доказывает новые вкладки. |
| VS-22 — done | 136 целевых passed: canonical identity/alias/open rollback, scoped REST, safeguards и global/project split. Широкая foundation-матрица повторно не выполнялась. |
| VS-23 — done | 175 passed, **в том числе все 30 test_remote_sync с настоящим remote, без skip**: scoped/legacy комнаты, отсутствие записи при open, неперсистентность Yjs. Это историческое принятое доказательство, не новый запуск VS-68. |
| VS-24 и корректирующая VS-28 — done | Runtime project/owner/generation, MCP и безопасный native-journal fallback. Принятые totals: VS-24 727 passed + 1 Windows skip; VS-28 303 целевых passed. Текущая выборка ниже проверяет интеграционные швы, не повторяет все форматы CLI. |
| VS-25 — done | 371 passed: resource URLs, namespace плагинов, auth/traversal/legacy. Текущие A/B resource-сценарии повторены, полная защитная матрица — нет. |
| VS-26 / VS-27 — done | 1296 / 1516 frontend passed, immutable renderer binding, plugins/caches; контракт прямых URL — `docs/plugins.md`. Текущая выборка проверена заново. |
| VS-62 — done | 212 desktop и 16 frontend passed, routing уведомлений/attention. В VS-68 перепроверен renderer notification scope; системный баннер и native click не объявляются проверенными. |

Graphify использован до поиска; текущие исходники сверены непосредственно. Граф не разрешил точное имя `TeamOrchestrator.update_task`, поэтому для этой части использован актуальный файл. Для воспроизводимости при dirty HEAD сохранены SHA-256 выбранных исходников в архиве доказательств.

## Текущие доказательства A/B

Используются разные managed roots при намеренно одинаковых относительных путях, plugin id `resource_probe`, version `1.0.0`, stamps, task/chat/subagent IDs и upload references. Ни один результат не выводится только из HTTP 200.

| Риск | Проверенное наблюдение |
| --- | --- |
| Отложенная DB mutation после legacy switch | Новый `test_delayed_copied_task_patch_commits_and_emits_only_in_its_project`: тело scoped PATCH A приостановлено gate; legacy выбран B и тем же task ID изменён B; затем A продолжен. Отдельные read-only SQLite connections видят ровно собственный title/status и audit `agent_message`; чужих title/audit нет. Local event histories содержат только свой `team.task.updated`, legacy — только B; sentinels `same.txt` обоих roots неизменны. |
| REST/body/upload | `test_concurrent_docs_and_settings_are_project_local` проверяет Markdown/config.yaml обоих проектов. `test_delayed_request_body_survives_legacy_switch` проверяет disk A и отсутствие чужого файла/PNG в B, для JSON и multipart. |
| Stream/continuation | `test_real_rename_stream_and_background_mending_stay_in_project`, включая abandoned stream: rename/mending A завершается в A после legacy switch; B сохраняет старый путь и ссылку, новый путь в B отсутствует. |
| Raw/images/download/review uploads | Реальные ASGI resource handlers читают разные bytes по одинаковым путям. Проверяются bytes на диске обоих roots, colliding upload references, copied task IDs; удаление attachment A не удаляет B. Awaited upload read после switch пишет только в A. |
| Plugins/backend | Generated page/previewer/grammar/node-UI URLs и relative late imports сохраняют project prefix. Disable/reload A не меняет Python module/source/action B, несмотря на одинаковый id/stamp. |
| WS/replay | Одновременные A/B/legacy sockets получают только соответствующие local events; switch меняет forwarding только legacy. Проверены scoped reconnect, восемь existing bad-cursor cases, bounded overflow только медленного consumer и отказ старому id/epoch после fixture restart. Frontend проверяет scope до dispatch и игнорирует callbacks старого socket/generation. |
| Collab/editor | Текущие frontend tests разделяют одинаковый doc path, handshake/update/awareness и stale responses A/B; docs save queues не переносят delayed save A в B. Два реальных тестовых editor не пишут при open, сохраняют независимый undo/cursors. Backend+реальный remote/open-no-write/Yjs доказаны принятой VS-23, не сетевым прогоном этой задачи. |
| Runtime/control/cleanup | Шесть независимых адресов task/chat/subagent A/B; raw-ID fallback запрещён. Scoped/legacy Context Viewer и remote-control изменяют собственную DB. Stale response/finally/cleanup не удаляет replacement generation. Реальные request builders с gated test backend сохраняют DB session_key; после завершения A B остаётся live/inspectable. |
| MCP | Existing run-bound toolsets с одинаковым run_id после legacy switch читают только DB создавшего проекта. Это проверка handlers/toolset, не нового transport/bridge процесса. |
| Общий workdir/native SID | Три выбранных negative journal cases используют Studio fallback вместо единственного чужого файла; шесть positive Claude/Codex/Qwen × task/chat cases читают свой доказанный journal и fragments. Это файловые fixtures, не запуск реальных CLI. |
| Global/project saves | Global save обновляет effective globals A/B, не меняя bytes их project config. Последующий project save не сериализует global fields. Project save/reload не принимает внешнее изменение application file; явный global PUT принимает его и сохраняет project files. |
| Нет чужих остановок | Existing workspace gated agent продолжает работу при переключениях, возвращается тот же job/context, в DB A приходит needs_review, в DB B этой задачи нет, request всего один. Activity fixture с copied IDs: завершение task/chat/subagent/pipeline A оставляет jobs B незавершёнными. Read-only activity не меняет registry/selection/mtime файлов A/B. Реальный native close/transfer проверяется отдельно в VS-69. |
| Legacy независим | Ensure/open A/B не меняет selected ctx/browser_bus. Legacy switch не переадресует scoped requests/sockets; frontend project renderer игнорирует legacy project.opened и не вызывает legacy open. После PATCH A legacy остаётся B. |

### Сохранённая проверка файлов и БД

Архив: `D:\VoxariumStudio\.scratch\desktop-tabs-isolation\VS-68-2026-11-14\`.

В `fixtures/game` (A) и `fixtures/other` (B) сохранены итоговые одноразовые проекты нового regression test. В `disk-observations.json` записаны результаты независимого чтения после теста:

| Snapshot | team_task | agent_message audit | Чужой title в team_task | same.txt |
| --- | --- | --- | --- | --- |
| A/game | task_copied, Alpha after, todo | только Alpha before → Alpha after | 0 | Alpha |
| B/other | task_copied, Bravo after, todo | только Bravo before → Bravo after | 0 | Bravo |

SQLite snapshots экспортированы через backup API из **тестовых** DB с учётом committed WAL, затем только архивные копии переведены в DELETE journal mode. Простое равенство/неравенство bytes основного app.db без WAL не использовано как доказательство. Оригинальные fixture DB и реальные project DB не редактировались. Snapshot SHA-256 записаны в JSON; архив предназначен для read-only анализа, не для открытия в рабочем Studio.

Все disposable scripts, первичные fixtures/логи и build metadata создавались в `.voxarium_studio/temp/TASK-68` по обязательному правилу task temp. В запрошенный `.scratch/desktop-tabs-isolation` скопированы **итоговые доказательства**, чтобы они пережили очистку temp при Done. `source-sha256.json` фиксирует исследованные исходники. Другие generated fixtures не архивировались: их disk/DB assertions находятся в тестах и passed-логах.

## Команды текущего прогона

Из `D:\VoxariumStudio\backend`; TEMP/TMP и basetemp всегда task-private, bytecode/cacheprovider отключены. Exit code каждого прогона — 0.

```powershell
$t='D:\VoxariumStudio\.voxarium_studio\temp\TASK-68\backend'
$env:TEMP=$t; $env:TMP=$t; $env:PYTHONDONTWRITEBYTECODE='1'

.\.venv\Scripts\python.exe -m pytest -n0 -q -p no:cacheprovider --basetemp="$t\final-seam-fixtures" tests/test_desktop_project_isolation.py
# 1 passed in 1.24s; backend/seam-final.log
```

Существующий адресный набор — **32 passed in 16.57s**, `backend/targeted.log`:

```powershell
$nodes=@(
 'tests/test_project_scopes.py::test_ensure_does_not_select_and_legacy_reuses_same_resident'
 'tests/test_project_scopes.py::test_concurrent_docs_and_settings_are_project_local'
 'tests/test_project_scopes.py::test_delayed_request_body_survives_legacy_switch'
 'tests/test_project_scopes.py::test_real_rename_stream_and_background_mending_stay_in_project'
 'tests/test_project_scopes.py::test_application_settings_propagate_without_writing_any_project_config'
 'tests/test_project_scopes.py::test_project_save_and_reload_do_not_adopt_external_application_changes'
 'tests/test_project_resources.py::test_raw_preview_images_and_file_operations_use_their_own_root'
 'tests/test_project_resources.py::test_docs_image_uploads_and_relative_references_are_project_local'
 'tests/test_project_resources.py::test_colliding_upload_references_download_from_only_their_project'
 'tests/test_project_resources.py::test_review_attachments_with_copied_task_ids_keep_their_project'
 'tests/test_project_resources.py::test_awaited_upload_read_retains_context_after_legacy_switch'
 'tests/test_project_resources.py::test_generated_plugin_urls_and_relative_late_import_keep_project_scope'
 'tests/test_project_resources.py::test_scoped_plugin_disable_and_reload_do_not_rebind_other_project'
 'tests/test_project_events.py::test_simultaneous_projects_local_subscribers_and_legacy_selection'
 'tests/test_project_events.py::test_reconnect_replays_only_local_cursor_then_continues_live'
 'tests/test_project_events.py::test_bad_reconnect_cursor_resyncs_without_partial_replay'
 'tests/test_project_events.py::test_bounded_overflow_notifies_only_slow_scoped_consumer'
 'tests/test_project_events.py::test_backend_restart_rejects_old_runtime_id_and_old_epoch'
 'tests/test_workspace.py::test_agent_finishes_in_background_and_return_reuses_its_context'
 'tests/test_desktop_activity.py::test_real_running_and_slot_queued_jobs_include_hidden_resident_with_copied_ids'
 'tests/test_desktop_activity.py::test_activity_is_read_only_and_legacy_and_scoped_bindings_are_unchanged'
)
.\.venv\Scripts\python.exe -m pytest -n0 -q -p no:cacheprovider --basetemp="$t\targeted-fixtures" @nodes
```

Runtime — **23 passed, 4 deselected in 8.84s**; journal выборка — **9 passed in 5.99s**:

```powershell
$r='D:\VoxariumStudio\.voxarium_studio\temp\TASK-68\runtime'
$env:TEMP=$r; $env:TMP=$r
.\.venv\Scripts\python.exe -m pytest -n0 -v -p no:cacheprovider --basetemp="$r\pytest-sequential" tests/test_project_session_isolation.py tests/test_runtime_session_adapters.py -k 'not qwen'
$journals=@(
 'tests/test_project_session_journals.py::test_shared_external_workdir_and_copied_sid_do_not_authorize_other_project_journal[foreign-dispatch-inventory-project-task-claude_code]'
 'tests/test_project_session_journals.py::test_shared_external_workdir_and_copied_sid_do_not_authorize_other_project_journal[foreign-dispatch-fragment-project-chat-codex]'
 'tests/test_project_session_journals.py::test_shared_external_workdir_and_copied_sid_do_not_authorize_other_project_journal[cwd-only-legacy-snapshot-inventory-legacy-chat-qwen]'
 'tests/test_project_session_journals.py::test_dispatch_proof_selects_own_journal_with_copied_sid_and_shared_workdir'
)
.\.venv\Scripts\python.exe -m pytest -n0 -v -p no:cacheprovider --basetemp="$r\pytest-journals" @journals
```

Логи: `runtime/isolation-adapters-sequential.log`, `runtime/journals.log`. Четыре Qwen lifecycle tests намеренно исключены: они используют subprocess fake launcher, а текущая проверка ограничена in-process. Qwen journal fixtures входят в текущие девять passed. Первый черновой seam/runtime запуск унаследовал configured xdist; финальные результаты выше последовательно повторены с -n0, дубликаты в totals не считаются.

Из `D:\VoxariumStudio\frontend`:

```powershell
$f='D:\VoxariumStudio\.voxarium_studio\temp\TASK-68\frontend'
$env:TEMP=$f; $env:TMP=$f
npm test -- --reporter=verbose src/api/project-scope.spec.ts src/ws/connection.spec.ts src/lib/collab/session.spec.ts src/plugin-runtime/project-scope.spec.ts src/stores/session.spec.ts src/stores/notifications.spec.ts
# 126 passed, 6 files
npm test -- --reporter=verbose src/stores/docs.spec.ts -t 'copied document paths in separate renderers|scoped gap recovery'
# 13 passed; 83 unrelated tests filtered (vitest labels them skipped)
npm test -- --reporter=verbose src/lib/collab/editor.spec.ts
# 5 passed
foreach ($part in 'app','node','vitest') {
 npm exec vue-tsc -- --project "tsconfig.$part.json" --noEmit --tsBuildInfoFile "$f/tsconfig.$part.tsbuildinfo"
}
# all three exit 0; no SPA build/static output
```

Логи: `frontend/{targeted-vitest,docs-targeted-vitest,editor-vitest,typecheck}.log`. Frontend transports/fetch/WS/import подменены; editors/tokenizer работают в тестовом окружении. Это не самостоятельное доказательство записи в backend DB — его дают отдельные ASGI/SQLite проверки выше. В логах есть pytest-asyncio deprecation, Vite/Vue Router предупреждения и ожидаемые ошибки негативных grammar fixtures; падений нет. `git diff --check -- backend/tests/test_desktop_project_isolation.py` — exit 0.

## Честные пробелы и передача дальше

- **Полный текущий `test_remote_sync.py` не запускался.** Его `start_server` поднимает настоящий TCP uvicorn remote на ephemeral port; fixture `studio` зависит от него. Это противоречит запрету запускать серверы в VS-68. Не подменяли remote mock, не считали import/collection/skip успехом и не строили новую transport-инфраструктуру. Основание для sync/collab server-side — принятый VS-23: 30 реальных passed без skip. Модули Studio/remote сейчас доступны из checkout, но это не заменяет прогон. Если потребуется именно повторный полный sync на текущей ревизии, сначала отдельно согласовать окно и разрешение на тестовый remote; до этого текущая сетевая sync-приёмка остаётся исторической.
- Новый production/native/packaged lifecycle, OS drag, настоящий banner/click, tray/Quit/update и single-backend launch не проверялись здесь. Они принадлежат **VS-69**; её карточка требует сначала question о моменте запуска. Принятый [[desktop-tabs/native-spike]] не повторяли и не выдаём за приёмку production оболочки.
- MCP transport/bridge и реальные CLI/native journals не запускались. Run-bound handlers, builders, generation cleanup и доказательства принадлежности journal проверены in-process; остальные прежние adapter/security проверки переиспользованы из VS-22/24/25/28.
- Сторонний plugin с прямым legacy /api, общий физический внешний workdir, вложенные/пересекающиеся managed roots не становятся sandbox из-за project routing. Не утверждаем изоляцию произвольных файловых побочных эффектов таких plugins; глобальные preference вроде smoothing по контракту остаются глобальными.
- Продуктовых дефектов для отдельной коррекции Producer не найдено; скрытых исправлений нет. Результат VS-68 завершён в разрешённом in-process scope, оставшаяся native приёмка — VS-69, а не утверждение готовности всей функции.
