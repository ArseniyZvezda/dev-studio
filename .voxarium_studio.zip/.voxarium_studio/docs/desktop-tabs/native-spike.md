# Native spike: живой перенос и terminal-event target

## 1. Статус VS-21

Закрывающий аудит 13.11.2026. **Исходная приёмка VS-21 выполнена: `done`.** После ручного прохода пользователь сообщил: **«Всё отработало корректно»** — это принято как подтверждение результата, не готовности. Найден соответствующий interactive-журнал; native-hook transfer/cancel/rollback и сохранность живого view независимо проверены по нему (§8). Пользовательское подтверждение и разрешение телеметрии разделены; непредложенные mixed-DPI/IME/Alt-Tab не объявлены пройденными.

Основание: [[desktop-tabs/project-isolation]], [[desktop-tabs/window-model]] §5, dev spec §5.1/§5.3. VS-03 не переделывается. Production-код/spec/настройки не менялись, основной Studio/backend не запускался и не перезапускался. Harness не использует сервер вообще: ни :8765, ни другой backend-порт ему не нужен. После автоматических прогонов закрыты все его окна и helper; interactive-окна ждать человека не оставлены.

## 2. Точные команды и журналы

Из PowerShell в `D:\VoxariumStudio`:

```powershell
# Только справка, без запуска Electron:
node desktop/test/native-transfer-spike.cjs

# Native transfer + race regression; сам завершится:
node desktop/test/native-transfer-spike.cjs --run-native

# Тот же полный прогон EN:
node desktop/test/native-transfer-spike.cjs --run-native --en

# Запускает САМ ПОЛЬЗОВАТЕЛЬ, когда готов к физическому проходу:
node desktop/test/native-transfer-spike.cjs --run-native --interactive
```

Консоль сразу печатает точный каталог evidence:

```text
D:\VoxariumStudio\.voxarium_studio\temp\TASK-21\run-<UTC timestamp>-<launcher PID>\
  events.jsonl
  result.json          # только завершённый auto-run; НЕ сертификат физического теста
  runtime-source.json
  runtime\
  os-temp\
```

В interactive результат пользователя определяется по `events.jsonl` и фактически выполненным шагам, а не по существованию `result.json`. Исходные журналы в TASK-21 disposable: Studio удалит их при окончательном Done. До закрытия сохранён постоянный архив исходных байтов, итогов и проверяющего скрипта — §8; результаты ниже не зависят от сохранности temp. По завершении ручного прохода передать **полный путь к `events.jsonl`**, какие шаги реально выполнены и наблюдавшиеся отклонения. Не редактировать журнал для получения PASS.

Установка runtime по умолчанию: `%LOCALAPPDATA%\Programs\Voxarium Studio`. Для другой установки задать `NATIVE_SPIKE_INSTALLED_DIR` с каталогом, содержащим `Voxarium Studio.exe`. Новых зависимостей, скачиваний Electron и npm install нет. В `desktop/node_modules/electron` здесь есть typings 45.1.0, но нет бинарника; он не используется для запуска.

## 3. Изоляция и файлы

- `desktop/test/native-transfer-spike.cjs`: opt-in launcher, main registry/transfer, native regression.
- `desktop/test/fixtures/native-transfer/{shell,project}.{html,js}`, `preload.cjs`: локальные renderer fixtures, sandbox/contextIsolation, без Node в renderer.
- `terminal-input.ps1`: persistent C# Win32 input/target helper, скомпилированный **до готовности интерфейса**, hooks установлены до `ready`.
- `terminal-client.cjs`: NDJSON-транспорт к уже работающему helper.
- `terminal-policy.cjs`: классификация неизменяемой terminal-записи и local lease checks.
- `terminal-regression.cjs`: воспроизводимые интеграционные проверки target races.
- Старый одноразовый `hit-test.ps1` **удалён**: поздний запуск PowerShell для определения цели больше не существует.

Launcher побайтно копирует установленный runtime (exe/DLL/pak/locales), **исключая resources основного приложения**, в TASK-21 и создаёт собственные `resources/app/{package.json,entry.cjs}`. Это настоящий установленный Electron, но не запуск Studio main. `resources/app.asar`, `desktop/main.cjs`, `run.cmd/run.ps1` и backend не загружаются. SHA оригинала/копии сохраняется. Профили appData/userData/sessionData/crashDumps/logs, дочерние TEMP/TMP и compiler artifacts направлены в TASK-21. Network/permissions/navigation/window.open fixtures запрещены. Обычный `npm test` этот opt-in harness не запускает.

Watchdog: 120 секунд auto, 30 минут interactive. Он завершает только запущенный PID и descendants, не Studio по имени. При штатном выходе helper получает quit, снимает hooks и завершается; project contents явно закрывается после окончания измерений.

## 4. Что исправлено в гонке

### 4.1 Terminal snapshot, а не поздний hit-test

До исправления release запускал новый PowerShell; HWND определялся спустя время, и исчезнувшая цель могла превратиться в desktop. Теперь **WH_MOUSE_LL** в заранее работающем helper фиксирует `WM_LBUTTONUP` непосредственно в callback **до `CallNextHookEx`**:

- `MSLLHOOKSTRUCT.pt` — координата самого terminal event, physical/per-monitor-aware;
- `MSLLHOOKSTRUCT.time` — native tick события;
- root HWND, PID, class и physical rect из `WindowFromPhysicalPoint/GetAncestor`;
- token, provenance `native-hook`, injected flag и topology generation.

Это immutable запись. Main не определяет terminal target из renderer IPC, `getCursorScreenPoint`, `GetCursorPos`, `dragend` или `dropEffect`. Renderer pointerup теперь только диагностический notice. Последующее перемещение курсора не меняет записанную точку. Если helper не успел arm до отпускания, нет подходящего token, helper недоступен или native snapshot невалиден — **отмена**, а не поздний fallback.

Shell по-прежнему использует custom primary-pointer capture, а не файловый OS DnD. Main arm связан с source/revision/token; `GetAsyncKeyState` проверяет лишь удержание LButton при arm, **не выбирает цель release**. Порог движения — 12 DIP от исходного pointerdown до native terminal point. Native keyboard hook фиксирует Escape как cancel без координат. Pointercancel/capture loss, native blur и timeout 30 секунд также отменяют session. Hooks только наблюдают активный жест и всегда вызывают `CallNextHookEx`; ввода они не генерируют и не подавляют.

### 4.2 Поздние наблюдения могут только отменять

Классификация выполняется один раз по captured HWND/point и сохранённой геометрии/поколению shell:

- зарегистрированная полоса shell → перенос в это окно;
- зарегистрированный body/controls/titlebar → unsupported/cancel;
- обычная внешняя поверхность → новое окно через тот же live transfer;
- taskbar/system menu/modal surface и невалидная цель → cancel.

**Ограничения «только свободный desktop» больше нет.** Обычное внешнее окно может быть фоном custom tear-out: ему не передаются token/файл/renderer и оно не становится владельцем вкладки. Это не импорт между независимыми процессами. Полоса другого shell того же main остаётся самостоятельным обязательным жестом. Реальная удобность этой политики ещё требует физического прохода.

Persistent helper `validate` сравнивает saved signature с текущей **в той же сохранённой точке**, не с текущим курсором. Это veto, не новая классификация: исчезновение/смещение/перекрытие не превращает strip в detach или старую внешнюю цель в новый desktop. Main проверяет owner/revision, target generation/геометрию и живость target.

SetWinEventHook сохраняет историю WINDOW destroy/show/hide/location после terminal tick. Show→hide/destroy не отбрасывается только потому, что к доставке callback окно уже скрыто/удалено. Даже возврат target в прежнюю позицию отменяет запись. Неизвестные уничтоженные HWND трактуются консервативно; живые дочерние controls исключены. Поэтому возможна безопасная лишняя отмена при посторонних оконных изменениях — её частоту надо оценить вручную, но она не создаёт ложный detach.

Новый tear-out shell подготавливается **скрытым**. `prepare(token,hwnd,pid)` допускает исключение только конкретного проверенного hidden HWND своего процесса, который после terminal никогда не показывался; прошлый либо будущий SHOW необратимо снимает исключение. Обычные скрывшиеся внешние окна таким исключением не обладают.

### 4.3 Линеаризация и rollback

Перед registry commit main **ожидает** helper `finish`: validate-and-consume выполняются вместе на одном native message-loop thread. Это точка линеаризации принятого terminal; fire-and-forget consume больше нет. После ответа повторно проверяется local lease, затем тот же view фиксируется в target, восстанавливаются focus/bounds. Изменение/исчезновение target до finish отменяет перенос; ошибка после native attach до commit возвращает view источнику. События после принятой точки линеаризации относятся уже к последующему жизненному циклу окна, не переопределяют старую terminal-классификацию.

Это не обещание атомарной блокировки всех окон Windows: primitive — immutable terminal decision + проверяемая точка принятия и fail-closed история событий. Ни одно наблюдение позже release не может выбрать *другую* цель вместо captured target.

## 5. Доказанные автоматические результаты

Финальные **exit 0** на текущем коде 13.11.2026:

- EN: `TASK-21/run-2026-11-13T09-30-29-831Z-11200`.
- RU: `TASK-21/run-2026-11-13T09-30-48-720Z-2016`.
- `node --check` main и всех JS/CJS fixtures, whitespace check — PASS.
- Desktop regression `npm test`: **73 passed, 0 failed**, `TASK-21/desktop-tests-continuation.log`.
- После перечисленных auto-прогонов процессов harness/native helper не осталось. Они не являются физическим тестом; последующий interactive-проход пользователя и его аудит приведены в §8.

Runtime: Windows x64, Electron **45.1.0**, Chromium 156.0.8078.49, Node 24.22.1, установленный Studio executable file version 5.7.0. SHA-256 оригинала и runtime-копии: `0bd2cb4ca32c5721f18dafd2dacb918995e5213e8730e2e1a4827a37b703820f`.

### Native transfer regression

**32 commits, 2 rollback, 112 snapshot** в финальном RU run. Включены 10 полных W1→W2→W1 циклов, detach/return через sandbox preload + ipcMain, resize/maximize/restore, перенос на второй монитор с отрицательным X и обратно, закрытие пустого source, ошибка после addChildView, реальный target.destroy после attach до ACK и отказ уже закрытого target. Дополнительные commits — native перенос по стабильному synthetic terminal на полосу и tear-out поверх обычного unregistered BrowserWindow-backdrop, затем возвраты.

Сохраняется **тот же объект WebContentsView**: removeChildView/addChildView, без reload/loadURL/remount/destroy проекта во время transfer. Сверяются DOM node/File identity (`===`), File contents/name/size, draft, caret, scroll, selection, sentinel/timeOrigin/bootstrap, native owner/children и focus/bounds. File seeded в renderer один раз через File/DataTransfer — настоящий File, но не тест системного picker. Selection в финальной fixture — textarea 8–25; отдельный независимый DOM Range одновременно с ним не обещан.

Постоянные значения финального RU run:

```json
{
  "wcId": 3,
  "sentinel": "149da4d0-62b7-4312-a192-b1ea089184da",
  "timeOrigin": 1794562250293,
  "nodeSame": true,
  "fileSame": true,
  "fileName": "unsaved-fixture.txt",
  "fileSize": 47,
  "caret": [8, 25],
  "scrollTop": 48,
  "activeElement": "draft",
  "focus": { "owner": true, "contents": true, "document": true },
  "baseline_and_final_bounds": { "x": 0, "y": 116, "width": 644, "height": 375 },
  "counters_before_cleanup": { "navigation": 1, "destroyed": 0, "bootstrap": 1, "load": 1, "gone": 0 },
  "physicalGestures": "NOT_TESTED"
}
```

Navigation/load/bootstrap по одному — **начальная загрузка**, их delta от baseline до конца переносов нулевая. Единственный project:destroyed появляется только после test-end при cleanup. wc.id локален изолированному процессу. Native focus assert прошёл после commit/rollback; это не доказательство IME/clipboard. Два монитора были с scaleFactor=1; mixed-DPI не проверялся.

### Воспроизводимые terminal/race проверки

Полная команда auto из §2 запускает `terminal-regression.cjs`: **13 результатов**, из них 12 integration-сценариев с реальными Win32 HWND/окнами и один pure-policy. Terminal в них создаётся явным helper `sample`, provenance `synthetic-sample`: **ни один не является физическим mouse-up**. Проверяется тот же capture/validation/commit маршрут, но hook-доставка отпускания остаётся ручным критерием.

| Сценарий | Результат |
| --- | --- |
| Стабильная полоса + replay token | Native transfer PASS; повторный terminal отклонён |
| Target сдвинут между capture и обработкой | Cancel, тот же source/view, лишнего окна нет |
| Target ушёл и вернулся в прежние bounds | Cancel по истории, не PASS только из-за совпавшей signature |
| Resize target | Cancel |
| Destroy target после capture | Cancel, без переосмысления точки как desktop |
| Новое окно реально перекрыло captured HWND | Cancel; native current HWND действительно другой |
| Occluder SHOW→HIDE до обработки | Cancel по сохранённому SHOW, не delivery-time visibility |
| Occluder SHOW→DESTROY до обработки | Cancel по истории |
| Validate PASS → target move → finish | Atomic finish повторно проверяет и отвергает; consumed=true, commit отсутствует |
| Prepare hidden shell → SHOW→HIDE → finish | Исключение отозвано, cancel |
| Обычное внешнее BrowserWindow как фон | Создан один tear-out shell, live view сохранён, return PASS |
| Внешний фон уничтожен после capture | Cancel, ни нового shell, ни fallback на desktop |
| Pure-policy: desktop/обычное окно/taskbar | Первые два detach, taskbar cancel; не native gesture evidence |

Для детерминированного topmost в race fixtures временно используются always-on-top окна **самого harness**, затем они убираются. Это настройка автоматической оснастки, не продуктовый режим и не управление чужим приложением. Независимый read-only review обнаружил и помог закрыть history/finish/prepared-SHOW дефекты; соответствующие негативные регрессии включены.

## 6. Физический проход: выполненный набор и воспроизведение

Пользователь уже выполнил предложенный набор и подтвердил результат; повторный проход для закрытия VS-21 **не запрашивается**. Ниже оставлена короткая команда/последовательность для будущего воспроизведения, а не новая просьба повторить тест.

```powershell
node desktop/test/native-transfer-spike.cjs --run-native --interactive
```

Отдельные окна spike, не основной Studio; подчёркнутая верхняя строка — drop strip. Снимки доступны кнопкой «Снимок».

1. «Отделить» / «Вернуть» в окне-владельце chip.
2. Drag-out chip на desktop и поверх обычного окна; drop обратно на полосу другого shell, несколько циклов.
3. Escape во время удержания внутри/снаружи source, затем отпустить: нет переноса/лишнего окна, следующий drag работает.
4. Отпустить над body spike; включить «Ошибка цели» и повторить перенос: отказ/rollback без потери view. Сделать снимки. Завершить «Выход» в любом shell.

Именно этот набор отнесён к подтверждению пользователя. Mixed-DPI, IME и Alt-Tab им не подтверждались. Обычный close окна с проектом harness блокирует ради сохранности измерения — это не production tray/close.

Проверять в `events.jsonl`:

- `native-helper.record` с `event:terminal`, `provenance:native-hook`, kind/tick/point/target/injected;
- `renderer-release-notice` — только диагностика, не источник решения;
- `terminal-decision` → `terminal-linearized` → `transfer-commit`, либо `gesture-cancel`/`terminal-rejected`/`transfer-rollback`;
- `snapshot` до/после: wcId/sentinel/timeOrigin/File/selection, counters, один owner, focus и expected bounds.

Для просмотра короткой трассы после выхода:

```powershell
# Подставить каталог, напечатанный именно ВАШИМ запуском:
$run = 'D:\VoxariumStudio\.voxarium_studio\temp\TASK-21\run-<timestamp>-<pid>'
Get-Content "$run\events.jsonl" | ConvertFrom-Json |
  Where-Object { $_.event -in @('native-helper','terminal-decision','terminal-linearized',
    'terminal-rejected','gesture-cancel','transfer-commit','transfer-rollback','snapshot') } |
  ConvertTo-Json -Depth 15
```

`isTrusted`, provenance и injected flag сами по себе не подтверждают физического человека. Здесь они сопоставлены с сообщением пользователя о реально выполненном проходе и с единственным найденным interactive-запуском. Агент физический ввод не генерировал; synthetic auto-результаты не переименованы в native-hook. Ограничения различимости desktop и положений Escape в журнале явно сохранены в §8.

## 7. Итог и границы приёмки

Живой перенос одного WebContentsView без reload/remount подтверждён native auto-regression и реальным пользовательским GUI-проходом. Команда detach/return, drag-out и межоконный strip drop, отмена и ошибка target проверены в исходном scope VS-21; существенных противоречий или потерь состояния при сверке не обнаружено. Поздний cursor polling/переклассификация удалены; race-регрессии §5 сохранены.

Результат относится к spike, не к уже выпущенным вкладкам Studio. Rich-editor undo/Yjs/WS/upload, два настоящих проекта, restore/tray/notifications, production IPC/permissions, mixed-DPI/IME/Alt-Tab не объявляются проверенными и не являются незавершённой частью исходной приёмки этого primitive. VS-03 не менялась. Production-реализация остаётся отдельной работой.

## 8. Закрывающий аудит физического теста и постоянный архив

### 8.1 Два независимых уровня подтверждения

**Пользователь:** после предложенного набора (§6) ответил «Всё отработало корректно». Ответ принят как результат физического теста. Повторное подтверждение не запрашивалось.

**Журнал:** среди всех runtime-source.json в TASK-21 найден ровно один запуск с `--run-native --interactive`:

- исходный каталог: `D:\VoxariumStudio\.voxarium_studio\temp\TASK-21\run-2026-11-13T09-36-41-904Z-28316`;
- runtime interactive=true, Electron 45.1.0, main PID 16680; manual-ready `09:36:43.709Z`;
- 199 строк, 96 675 байт; время `09:36:43.245–09:39:10.727 UTC`, 13.11.2026;
- SHA-256 исходного/архивного JSONL: `dc5b40b8c803680e5e670e77cd234072b723104f02b3bdd3ccadd123c3284ab7`;
- test-end code=0: строка 195, `09:39:10.684Z`; project destroyed только в teardown, строка 196, `09:39:10.687Z`.

### 8.2 Трасса жестов, команд и отмен

| Проверено непосредственно по журналу | Строки и результат |
| --- | --- |
| Native input | 15 gesture-begin → 15 terminal из helper: 14 up + 1 cancel, все provenance=native-hook и injected=false; synthetic-sample нет |
| Команда | 3 command-detach commits (17, 86, 132), 1 command-return (89) |
| Реальный drag-out | Native terminal→detach→finish→commit дважды: 21–32 и 35–46; owner 3→4 и 4→5, wcId=3 |
| Drop на полосу | 7 native strip commits: 58, 70, 82, 144, 156, 168, 194; включая циклы W7→W1→W7→W1 |
| Проверенное принятие terminal | 9 terminal-linearized; перед каждым helper ответил valid=true, consumed=true; затем ровно соответствующий commit |
| Escape | Native kind=cancel, token `bd682d93-bf71-46fc-865e-8fdd11f730cb`, строки 93–97, `09:38:05.655Z`; без linearization/commit |
| Unsupported surface | Четыре terminal-decision=cancel и gesture-cancel: 100–103, 107–110, 171–174, 178–181; дополнительных commits нет |
| Ошибка цели / rollback | Token `35dcb016-1a36-4f80-b4f9-15216a57dc77`: terminal 114 (`09:38:26.454Z`), rollback 119 (`.656Z`), rejected/cancel 121–122 (`.657Z`); owner=1 и revision=8 сохранены, commit отсутствует |
| Снимки | 32 snapshots всего, в том числе 3 явных manual-snapshot (10, 13, 128); 13 пар before→commit и 1 before→rollback |
| Отказы не-владельцу | 5 command-error (11, 12, 18, 90, 91): `cancel gesture / command from non-owner`. Это ожидаемая проверка полномочий, не потеря view; последующие правильные команды успешны |

Всего 13 commits = 4 команды + 9 физических native transfers; 6 отмен = 1 native cancel + 4 unsupported + 1 injected rollback. Ни один token отмены не был линеаризован/зафиксирован.

**Что нельзя выдать за дополнительные записи журнала:** оба outside-detach зафиксировали один внешний `Chrome_WidgetWin_1`, PID 26172, HWND 132968; отдельного terminal над WorkerW/Progman нет. Desktop-проход подтверждён пользователем, а внешний фон — ещё и двумя hook-записями. Единственный Escape record имеет point/target=null; он доказывает native отмену, но не различает две позиции inside/outside. Обе позиции относятся к пользовательскому подтверждению набора, не к двум независимо различимым cancel-записям. Это ограничение детализации evidence, а не основание игнорировать уже полученный результат пользователя или повторно спрашивать его.

### 8.3 Состояние, владение, focus/bounds, отсутствие reload

Во **всех 32 snapshots** неизменны:

```json
{
  "wcId": 3,
  "sentinel": "ee60d2a9-4bae-4775-8d6d-c527734ce7d1",
  "timeOrigin": 1794562603460.9,
  "bootstrap": 1,
  "nodeSame": true,
  "fileSame": true,
  "fileName": "unsaved-fixture.txt",
  "fileSize": 47,
  "caret": [8, 25],
  "scrollTop": 48,
  "counters": { "navigation": 1, "destroyed": 0, "bootstrap": 1, "load": 1, "gone": 0 }
}
```

Draft и File text сравнивались полностью, не только по длине: расхождений с baseline нет. Их SHA-256 соответственно `54a1289d82884a924a29a0d2128c63aaa9b238b0f676974aaefe54e22cf28a30` и `a2f0deaf9186bbdfa26c04e9e53e19892baf9a67ab5cd19d307f5c81a380e0d8`. DOM textarea identity сохраняется; domSelection text/offsets также стабильны. Его anchorNodeSame/focusNodeSame уже в baseline равны false, поэтому identity независимых DOM Selection anchors не заявляется.

Ровно один parent/owner и actual bounds=expected bounds — во всех snapshots. Native owner/content/document focus восстановлен во всех 13 commit-snapshots и rollback; activeElement не изменился в парных transfer-снимках. Baseline bounds `{x:0,y:116,width:644,height:375}`; при оконных resize последующие bounds сверены с текущим owner.

Navigation/load/bootstrap присутствуют только при начальной загрузке (строки 5–7), до baseline 8. Между baseline и test-end их delta=0; destroyed/gone=0, нет fatal/render-process-gone/helper error. Закрытие пустых shell не уничтожило project contents. Проверяющий скрипт не нашёл нарушений; независимый read-only аудит подтвердил те же числа и границы.

### 8.4 Evidence переживёт очистку TASK-21

Постоянное расположение, в пределах объявленного write scope:

`desktop/test/fixtures/native-transfer/evidence/2026-11-13/`

- `interactive.events.jsonl` — **неизменённая побайтная копия** всех 199 строк;
- `interactive.runtime-source.json` — аргументы запуска и совпавшие SHA runtime;
- `interactive-audit.json` — счётчики, baseline, все 14 пар snapshot, токены/строки трассы, issues=[];
- `user-confirmation.md` — точная фраза пользователя, предложенный набор и границы, отдельно от telemetry;
- `auto-regression.events.jsonl`, `auto-regression.result.json`, `auto-regression.runtime-source.json` — полный последний RU auto-run с 32 commits/2 rollback/13 terminal-проверками;
- `desktop-tests.log` — 73 passed;
- `verify-interactive.cjs` — read-only разбор сохранённого журнала с assertions, без Electron/backend;
- `manifest.json` — bytes/SHA-256 архивных файлов и fingerprints исходников при закрывающем аудите. Source fingerprints не выдаются за подпись исходников, снятую launcher в момент теста.

Перепроверка архива без запуска GUI и без зависимости от исходного temp-журнала:

```powershell
New-Item -ItemType Directory -Force .voxarium_studio/temp/TASK-21 | Out-Null
node desktop/test/fixtures/native-transfer/evidence/2026-11-13/verify-interactive.cjs `
  desktop/test/fixtures/native-transfer/evidence/2026-11-13/interactive.events.jsonl `
  .voxarium_studio/temp/TASK-21/rechecked-audit.json
```

При закрывающем аудите эта команда завершилась exit 0, issues=[]; hashes копий совпали с оригиналами. Никакой повторный interactive/Studio/backend не запускался. Новых выводов о mixed-DPI, IME или Alt-Tab не делалось.

API-основание (не замена runtime evidence): [Electron WebContentsView](https://www.electronjs.org/docs/latest/api/web-contents-view), [View](https://www.electronjs.org/docs/latest/api/view), [BaseWindow resource management](https://www.electronjs.org/docs/latest/api/base-window#resource-management), [Microsoft LowLevelMouseProc](https://learn.microsoft.com/en-us/windows/win32/winmsg/lowlevelmouseproc), [MSLLHOOKSTRUCT](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-msllhookstruct), [SetWinEventHook](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setwineventhook), [W3C Pointer Events](https://www.w3.org/TR/pointerevents3/).
