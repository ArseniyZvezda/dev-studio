# Android ↔ Voxarium Studio Remote: контракт v1 и план реализации (VS-70)

## 1. Решение и границы

Срез исходников и read-only проверки: **14.11.2026**, репозиторий Studio `D:\VoxariumStudio`, HEAD `f84cf0d9838e46b7f58e357331dbc3ef38685f9b`. Рабочее дерево содержит многочисленные чужие незакоммиченные изменения: ссылки ниже относятся к прочитанным файлам, а не только к HEAD. Сначала выполнены запросы graphify, затем проверены реальные исходники; граф не заменяет проверку актуального кода.

**Рекомендуемый минимум:** нативная оболочка Kotlin / Jetpack Compose Material 3 в `D:\VoxariumRemoteAndroid`; native HTTP/WS-клиент напрямую к Remote; локально упакованный WebView-редактор с той же схемой Tiptap/Yjs и Markdown codec, что у Studio. Native-код заменяет роль локального Studio relay/mirror, но не запускает Studio на телефоне. Сервер и Studio менять не требуется.

**Не подходит:** textarea → полный безусловный PUT; произвольный `Y.Text("body")`; стандартный y-websocket/Hocuspocus provider, направленный на существующий endpoint; выдуманные REST `/projects`, `/spaces`, `/documents`. Remote имеет собственный JSON-протокол. File-level CAS сам по себе не защищает чужие ещё несохранённые CRDT-правки — существенное ограничение, подробно в §8.

Документ задаёт контракт и задачи реализации, **не утверждает, что Android-клиент уже реализован или протестирован**. VS-71 параллельно создаёт только Material 3 shell. В VS-70 не менялись сервер, Studio, Android-проект или глобальная среда; сборки и тесты не запускались.

### 1.1 Первоисточники и приоритет

Пути этой таблицы — от `D:\VoxariumStudio`; номера строк — текущий срез.

| ID | Источник | Что определяет |
| --- | --- | --- |
| S1 | `docs/voxarium-studio-dev-spec.md:4098–4258`, особенно §16.1–16.4 | Remote, зеркало Markdown, конфликты, комнаты, scribe, инварианты |
| S2 | `docs/voxarium-studio-dev-spec.md:4260–4288`, §16.5–16.6 | Настройки, reconnect, сознательные ограничения |
| S3 | `docs/block-editor-spec.md:25–37,121–137,366–393,427–440,465–467` | Файл — источник правды; envelope; неизвестные конструкции; открытие не пишет |
| S4 | `remote/voxarium_studio_remote/app.py:61–108,141–160`; `auth.py:22–105` | Три endpoint, Bearer, отказ, отзыв |
| S5 | `remote/voxarium_studio_remote/protocol.py:20–102` | Версия, коды, пути, размеры, hash/base64 |
| S6 | `remote/voxarium_studio_remote/hub.py:134–280,446–475`; `store.py:200–279` | hello/sync/change, CAS, ack/nack, seq/tombstones |
| S7 | `remote/voxarium_studio_remote/hub.py:75–106,284–443,452–482` | Комнаты, epoch, seed, updates, scribe/reset/presence |
| S8 | `backend/voxarium_studio/sync/protocol.py:14–83`; `service.py:68–86,282–408` | Половина протокола Studio, URL, backoff/handshake |
| S9 | `backend/voxarium_studio/sync/service.py:410–512,546–638,667–821`; `state.py:31–105` | Reconciliation, pending, база, live-write, relay и flush-before-leave |
| S10 | `frontend/src/lib/collab/session.ts:93–95,120–143,217–305,312–443`; `seed.ts:30–54`; `carried.ts:32–47,83–135,153–184` | Y.Doc, provider, seed CAS, awareness, carried |
| S11 | `frontend/src/lib/editor/extensions.ts:47–73,170–254`; `nodes.ts:19–27`; `lib/md/document.ts:34–48,102–145`; `lib/md/prosemirror.ts:70–75,255–259,549–550` | Точная схема и Markdown round-trip |
| S12 | `frontend/src/components/docs/BlockEditor.vue:89–114,236–284,362–465`; `views/DocsView.vue:185–225,243–339` | Первый рендер, dirty, autosave, scribe, offline/reset |

В S11 пути `lib/...` и в S12 `views/...` сокращены относительно `frontend/src/`. В дальнейшем ссылки S1–S12 отсылают к этим точным файлам/строкам.

Block-editor spec §2 первоначально исключал collaboration; позднейший dev spec §16 **добавляет** комнаты, не отменяя сохранность Markdown и «открытие не пишет». Для действующего wire источником является код обеих сторон. Например, сырой Remote `joined` не содержит `content/user`: их добавляет локальный relay Studio (S9); нельзя переносить браузерный контракт на Remote без адаптера.

## 2. Подключение, авторизация, выбор проекта

### 2.1 Endpoint и версия

Относительно настроенного base URL; если reverse proxy публикует Remote под префиксом, префикс сохраняется.

| Endpoint | Запрос / ответ |
| --- | --- |
| `GET /healthz` | Без auth. `{"status":"ok","service":"voxarium_studio_remote","version":"0.1.0","protocol":1}`; 0.1.0 — наблюдаемая версия пакета (`remote/voxarium_studio_remote/__init__.py:8`), не версия схемы редактора |
| `GET /api/v1/me` | Header `Authorization: Bearer <personal-key>`. Ответ `{"user":{"id":"…","name":"…","color":"…"},"protocol":1}` |
| `WS /api/v1/sync?space=<name>` | Тот же Authorization header в handshake. После accept сервер проверяет ключ/space и присылает `hello` либо application close |

Неверный/отсутствующий ключ в `me`: HTTP **401**, `{"detail":"Missing or invalid key."}`, `WWW-Authenticate: Bearer`. OpenAPI/Swagger и browser-facing статика отключены; Documents/admin REST здесь отсутствует (S4).

`PROTOCOL_VERSION = 1` на обеих сторонах (S5, S8). Клиент обязан сравнить `hello.protocol` **до** sync/join/write; mismatch → остановка, объяснение о несовместимости. Сервер не получает отдельную client-version и сам эту проверку за клиента не делает. `healthz.version` не заменяет `protocol`; совпадение protocol **не гарантирует** совпадение editor schema.

### 2.2 Ключ и транспорт

- Ключ выдаёт администратор существующим CLI; сервер хранит SHA-256, не исходный ключ. Выдаваемый формат `vxs_…`; не придумывать login/password, регистрацию или refresh token.
- Принимается **только заголовок**, не `?token=`, cookie или subprotocol. Bearer scheme case-insensitive (S4).
- Native transport владеет ключом и HTTP/WS. Обычный браузерный `new WebSocket(url)` не является заменой native-клиенту с требуемым header; Studio браузер ходит к своему relay, а не к Remote (S1, S10).
- Рекомендация Android: ciphertext в app-private storage, ключ шифрования в Android Keystore; токен не попадет в JS, URL, Markdown, git, backup и логи. Keystore хранит криптографический ключ, а не произвольный Bearer-текст. См. [официальную модель Keystore](https://developer.android.com/privacy-and-security/keystore).
- Production — HTTPS/WSS с обычной проверкой сертификата/hostname, без trust-all. TLS завершает reverse proxy. Plain HTTP к другой машине раскрывает ключ; для MVP не разрешать его в release. Никакие изменения сервера для этого не нужны.
- `revoke` отключает активного пользователя, проверка раз в 30 с. Не обещать то же для `rotate`: watcher проверяет active user ID, не token hash (`app.py:155–160`, `store.py:167–195`).

### 2.3 Проект — локальный профиль, space — серверный набор Documents

Remote не знает `D:\...`, local project ID Studio, desktop tab или checkout. На телефоне «проект» — сохранённый профиль `{label, canonicalServerUrl, spaceName}`; ключ — отдельно для сервера/учётной записи. Пользователь вводит имя пространства, согласованное с `sync.space` desktop-проекта.

Нет API перечисления проектов/пространств, поэтому UI показывает **локальный список профилей**, не выдаёт его за серверный каталог. Перед первым connect подтвердить имя: space автоматически создаётся при подключении, опечатка тоже создаёт пустой space. Действующий ключ имеет доступ ко всем space, ACL/приглашений нет (S1 §16.2; S6).

Валидация space: trim + lowercase, **1–64 ASCII**, первый символ буква/цифра, остальные буквы/цифры/`._-`. URL canonicalization как S8: bare host → HTTPS; `ws/wss` → `http/https`; hostname lowercase; убрать завершающий slash; запрет userinfo/query/fragment. Токен никогда не часть адреса.

Ключ состояния cache: как минимум `(canonicalServerUrl, accountId, space.id)`, путь документа — внутри этого namespace. Новый `hello.space.id` при том же имени означает другую базу сервера: сбросить cursor/base и выполнить полный sync, **сохранив drafts/recovery**, а не отправляя старые revision в новую базу. Переключение профиля не должно переадресовать ни один pending callback старого документа.

## 3. Формат сообщений и зеркало Documents

JSON **text** frames, каждый объект с `t`. Yjs updates и awareness — стандартный base64 внутри JSON, не отдельные binary WS frames. Все сообщения обрабатываются последовательно, с проверкой connection generation. Это не wire y-websocket и не Hocuspocus (S5–S7).

### 3.1 Поля и направления

C — Android/Studio backend, S — Remote. В таблицах указаны поля **помимо `t`**; строки с `null` допускают именно JSON null.

| Направление / t | Поля |
| --- | --- |
| S→C `hello` | `protocol:1, user:{id,name,color}, space:{id,name}, seq:int` |
| C→S `sync` | `since:int` |
| S→C `change` | `path:string, rev:int, hash:string\|null, deleted:bool, content:string\|null, by:user\|null` |
| S→C `synced` | `seq:int` |
| C→S `put` | `id, path, content:string, base_rev:int`; опционально `live:sid` |
| C→S `delete` | `id, path, base_rev:int` |
| S→C `ack` | `id, path, rev, hash, deleted` |
| S→C `nack` | `id, path, current:null\|{rev,hash,deleted,content}` |
| S→C `presence` | `peers:[{user:{id,name,color},connections:int,docs:[path,...]},...]` |

Источники: S6; presence — S7 `hub.py:426–443`. `id` только возвращается как correlation echo: сервер не дедуплицирует повторные request IDs. Android использует свои монотонные integer IDs и хранит snapshot/hash каждого запроса до завершения.

Пример начала разговора (значения в угловых скобках пояснительные):

~~~json
{"t":"hello","protocol":1,"user":{"id":"<user-id>","name":"Alice","color":"#3e63dd"},"space":{"id":"<space-id>","name":"game"},"seq":12}
{"t":"sync","since":0}
{"t":"change","path":"design/dash.md","rev":12,"hash":"<sha256>","deleted":false,"content":"# Dash\n","by":null}
{"t":"synced","seq":12}
~~~

### 3.2 Перечень и чтение — через sync, не REST

`sync since:0` отдаёт последнюю запись **каждого** пути, включая tombstones, затем `synced`. `content` уже в `change`: отдельного GET документа нет. UI строит дерево и заголовок из cache неудалённых записей; папки выводит из сегментов пути. Поиск MVP — локальный, timestamps сервер не передаёт.

`rev` документа — значение **общего space sequence** на момент его последней записи. `changes_since`: `rev > since ORDER BY rev`, не история всех промежуточных правок. `by` у online change — пользователь, у replay — null (`store.py:244–279`, `hub.py:186–210`).

После sync соединение уже получает новые change/presence, отдельной subscribe-команды нет. На старте без полного надёжного cache всегда `since:0`. Нельзя сохранять `hello.seq` как уже применённый cursor: так можно пропустить весь начальный набор. Cache/base/cursor обновлять атомарно после применения кадров, а не после их получения из сети; `synced` не означает, что все локальные drafts записаны.

### 3.3 Создание, запись, удаление

~~~json
{"t":"put","id":1,"path":"design/dash.md","base_rev":12,"content":"# Dash\n\nUpdated.\n"}
{"t":"ack","id":1,"path":"design/dash.md","rev":13,"hash":"<sha256>","deleted":false}
~~~

Обычная запись — CAS по `base_rev`; неизвестный путь использует 0. После tombstone восстановление использует ревизию tombstone, не 0. Устаревшая база даёт `nack.current`, без изменения файла. Совпадающий с текущим текст — `ack` текущей ревизии даже со старой базой; повтор delete уже отсутствующего/удалённого — тоже `ack` (rev 0 или tombstone). Только реальные изменения повышают seq.

Отправитель получает `ack`, **не собственный change**. Остальные соединения получают change. На ack база становится **snapshot отправленного текста**, не более новым текстом, который пользователь успел напечатать в ожидании. Новый draft сохраняется отдельно и отправляется следующим. Один in-flight write на путь; не считать `WebSocket.send` подтверждением сохранения. S6, S9 `service.py:546–627`.

`delete` условный по текущей ревизии. Rename — отдельные delete+put, **не атомарная** операция; в минимальном UI переименование/удаление можно отложить. Копии конфликта создавать через обычный put нового уникального пути; сервер их сам не создаёт.

### 3.4 Валидация и ограничения

S5 `protocol.py:24–98`:

- Суффиксы `.md/.markdown/.txt` (проверка case-insensitive); content — строка, максимум **1 000 000 UTF-8 bytes**, не символов.
- Путь trim, непустой, ≤512 символов, POSIX относительно Documents, без ведущего `/`, backslash, управляющих символов <32 и пустых/`.`/`..` сегментов. Не передавать `.voxarium_studio/docs/` перед путём.
- `hash` — SHA-256 lowercase hex от **точного UTF-8 текста**, без нормализации CRLF/frontmatter.
- Update/awareness — строгий base64; decoded payload ≤**8 MiB**. CLI Remote задаёт WS max size **32 MiB** (`remote/voxarium_studio_remote/cli.py:63–74`); proxy/другой launcher могут ограничивать иначе. Studio-клиент принимает frames до 64 MiB (S8).
- Серверные числовые поля идут через `_integer`: non-int/bool → 0, отрицательные int не запрещены. Android не должен полагаться на такую поблажку: отправлять неотрицательные значения, проверять диапазон и не терять точность на JS bridge.

Пути case-sensitive на Remote, Windows может свести `Notes.md` и `notes.md` в один файл. MVP запрещает новые case-only коллизии и предупреждает о пришедших; существующие записи не «чинит» переименованием (S2 §16.6).

## 4. Живая комната: точный контракт

Один socket пространства мультиплексирует sessions. `sid` задаёт клиент: непустая строка ≤64 символов, уникальная в пределах соединения. `client_id` — ID рабочего Y.Doc для awareness, не user ID. Все room-ответы содержат **sid адресата**, не отправителя. S7.

| Направление / t | Поля |
| --- | --- |
| C→S `join` | `sid,path,client_id,base_rev` |
| S→C `join_failed` | `sid,path,reason:"missing"\|"stale"` |
| S→C `joined` | `sid,path,epoch,seeded:bool,state:base64\|null,scribe:bool,dirty:bool,rev` |
| C→S `seed` | `sid,update:base64` |
| S→C `seeded` | `sid,ok:bool,state:base64\|null` |
| C→S / S→C `update` | `sid,update:base64` |
| C→S / S→C `awareness` | `sid,update:base64` |
| S→C `peer_joined` | `sid` |
| S→C `peer_left` | `sid,client_id` |
| S→C `scribe` | `sid` |
| C→S `leave` | `sid`, ответа нет |
| S→C `reset` | `sid,path,reason:"replaced"\|"deleted"` |

### 4.1 Join и seed без дублей

1. Дождаться sync/reconciliation и отсутствия pending write для пути. Документ должен существовать; cache Markdown/hash должны соответствовать согласованной rev.
2. Создать новый рабочий Y.Doc, новый sid; отправить `join` с этой base_rev. `missing` → не создавать документ неявно; `stale` → сначала catch-up, затем ограниченный retry с новой базой.
3. При `joined.seeded:true` применить полный `state` к **пустому** рабочему Y.Doc, затем монтировать Collaboration-редактор **без initial content**. Отдельно сохранить Markdown envelope согласованного файла.
4. При `seeded:false` получить Markdown из собственного cache этой rev: сырой Remote его в joined не присылает. Построить seed в **отдельном throwaway Y.Doc** тем же codec/schema, отправить `seed`.
5. `seeded ok:true,state:null` → применить собственный seed к рабочему doc. `ok:false,state:<winner>` → отбросить свой seed и применить победителя к пустому рабочему doc. Никогда не merge два независимо засеянных текста.
6. Только теперь разрешать ввод/исходящие updates. До seeded server updates/awareness от этой session игнорирует. Полученный `epoch` идентифицирует incarnation комнаты; на новый epoch нужен новый doc.

Инициализация WebView асинхронна, но сервер её не ждёт: после joined/seeded сразу могут прийти updates, а `scribe` — ещё до seeded. Native coordinator сохраняет роль немедленно, буферизует и применяет frames строго по порядку при готовности JS; ни один frame не пропадает из-за mount. Clean baseline фиксируется из начального seed/state **до** последующих updates. Реальные правки, пришедшие до первого render, остаются отдельным dirty generation и долгом scribe, а не принимаются за «чистое открытие» (`hub.py:312–361,409–413`, `session.ts:434–436`).

В raw joined **нет user/content**. User берётся из hello; content — из document-layer cache. Studio добавляет их в relay `service.py:808–812`, убирает sid из большинства browser frames, а браузер отправляет только `join {path,client_id}` и seed/update/awareness. Не копировать этот упрощённый обмен напрямую на Remote (S9–S10).

### 4.2 Updates, awareness и scribe

`update` применяется к room Y.Doc и рассылается остальным synced sessions; sender ACK не получает. Origin-marker на принимаемой транзакции предотвращает эхо. Awareness — эфемерный курсор/пользователь, не документ: сервер только пересылает, не хранит. На `peer_joined` повторить своё awareness; на `peer_left` убрать указанный client_id. User `id/name/color` брать из hello (S7, S10).

Первый вошедший — scribe. При уходе scribe следующий synced участник получает `{"t":"scribe","sid":"…"}`. **Только scribe по дисциплине клиента** материализует общий документ в Markdown после любых комнатных изменений, включая чужие:

~~~json
{"t":"put","id":2,"path":"design/dash.md","base_rev":13,"content":"<merged Markdown>","live":"<own-sid>"}
~~~

Native сериализует очередь: сначала относящиеся к snapshot Yjs update frames, затем этот put; один snapshot in-flight на путь. Если за время записи пришли новые изменения — dirty generation остаётся, после ack нужен следующий snapshot. Хранить неподтверждённый draft до ack; при ошибке не показывать «сохранено».

`live` обходит base_rev и не reset-ит room. **Сервер проверяет только, что sid принадлежит этому connection и этой room**, а не роль scribe, соответствие Markdown Y.Doc, epoch или synced. Это доверительная обязанность клиента, не серверная защита (`hub.py:218–232,459–464`). Не ставить live на offline draft или на текст старого редактора.

`joined.dirty:true` означает, что комната впереди materialized Markdown. Новый редактор должен помнить долг записи, даже если сам не набирал: став scribe, записать **текущее общее** состояние. Чистое наследование роли не причина записи. Референс: debounce 700 мс, при продолжающемся вводе максимум 3 с; проверка отсутствия изменения перед put обязательна (S12).

Закрытие **scribe** при штатной связи: завершить IME → flush редактора → дождаться ack последнего snapshot и отсутствия более новых pending правок → `leave` → уничтожить editor/Y.Doc. **Non-scribe не отправляет put и не получает ACK своих updates**: он ждёт, пока document-layer change материализует его текущий merged Markdown, либо сохраняет recovery и явно сообщает, что durability ещё не подтверждена. Соответствие тексту файла проверяет и Studio (`BlockEditor.vue:456–465`); state-vector persistence ACK в протоколе нет. Не закрывать Y.Doc под живым binding. Не успели подтвердить запись — recovery и видимый статус, а не молчаливый уход. Studio делает flush до leave (S9 `741–751`, S12).

При последнем leave room Y.Doc исчезает: сервер **не сериализует его**. Перезапуск Remote также восстанавливает только Markdown, не старую CRDT-комнату.

## 5. Markdown ↔ CRDT ↔ Markdown: обязательная совместимость

Remote непрозрачно применяет Yjs updates через pycrdt; он не определяет структуру editor document и не знает serializer. Тестовый `Text("body")` в `remote/tests/test_remote.py:86–97` — test fixture, **не** контракт редактора Studio.

Совместимый цикл (S10–S11):

~~~text
точный исходный Markdown
  → parseDocument: mdast + envelope
  → mdastToProseMirror
  → carry + roomSchema
  → prosemirrorJSONToYDoc(..., fragment "default")
  ↔ Collaboration / Yjs updates
  → editor.getJSON()
  → proseMirrorToMdast
  → serializeDocument(mdast, исходный envelope)
~~~

Минимально переносится **модель**, не весь desktop UI:

- Тот же fragment **default**, типы узлов, attrs/defaults и marks: heading 1–6, task/plain items, table alignment, inline image/width, wikiLink, directiveTitle/callout/toggle, textColor, unsupportedBlock/unsupportedInline.
- `carried`: marks для `wikiLink,image,unsupportedInline,hardBreak`; `taskItem.checked:null`. Плагин держит carried и реальные узлы согласованными; служебный attrs не попадает в Markdown.
- Envelope `frontmatter,eol,finalNewline` хранится рядом с деревом, **не в Y.Doc**. Frontmatter не парсить/пересобирать YAML; сохранять исходный текст и переводы строк. Envelope берётся от согласованного Markdown, не от промежуточного ack, перетирающего новый editor state.
- Неизвестные Markdown-конструкции проходят через unsupported nodes с исходным mdast payload, не выбрасываются и не превращаются молча в обычный текст. В UI — безопасный нередактируемый placeholder.
- В комнате `StarterKit.undoRedo:false`, history принадлежит Collaboration; undo отменяет свои изменения, не чужие. **trailingNode:false**: финальная таблица/список не должны автоматически дополняться абзацем.
- Vue node views можно заменить простыми DOM node views внутри WebView, но не менять schema. Image reference хранится без изменений; Remote не отдаёт assets. Для MVP — placeholder; никакой загрузки внешнего URL или попытки обратиться к Studio `/api` с телефона.
- Однократная нормализация при **реальной правке** допустима; повторное сохранение стабильно. Известное отличие комнаты: вложенный цвет той же mark-семьи расплющивается в соседние spans (S1 `4255–4258`). Не выдавать это за byte-identical round-trip любого неканонического input.

Закрепить в отдельном Android web package те же проверенные версии из Studio lockfile, не caret/latest: Tiptap core/Collaboration **3.32.2**, y-tiptap **3.2.0**, Yjs **13.6.33**, y-protocols **1.0.7** (`frontend/package-lock.json`; прямые диапазоны — `frontend/package.json:15–54`). Codec и fixture corpus переносить с provenance и проверкой лицензий; Studio не рефакторить для переиспользования.

**Schema-риск:** протокол v1 не согласует editor schema. Официальная [Tiptap Collaboration documentation](https://tiptap.dev/docs/editor/extensions/functionality/collaboration) предупреждает о синхронном удалении нераспознаваемого content и описывает защиту `enableContentCheck` для Collaboration **3.33.0+**. В срезе Studio 3.32.2: нельзя приписывать ей эту защиту. MVP допускает запись только с проверенной одинаковой schema; до монтирования binding выполнить валидацию полного входящего дерева; последующие remote updates тоже предварительно проверять на отделённой копии Y.Doc **до** передачи live binding. При неизвестном type/attr/mark или невозможности lossless conversion — остановить исходящие изменения и сохранения, сохранить recovery и raw входящий state, не выполнять автоматический repair. Отсутствие серверного schema negotiation остаётся явным ограничением.

Официальный [Yjs Update API](https://docs.yjs.dev/api/document-updates) описывает applyUpdate/encodeStateAsUpdate и идемпотентность updates. Это свойство одного CRDT-документа, **не разрешение** merge разных независимо засеянных room epochs.

## 6. Reconciliation, конфликты и reconnect

### 6.1 Локальная база Android

Предлагаемые app-private данные: согласованные `{path,baseRev,baseHash,baseContent/deleted}`, server cache, отдельные drafts/recovery, cursor; pending `{id,path,snapshotHash,snapshotContent,generation}`. Персистить атомарно. Состояние зеркала — локальная служебная БД, не новый формат Documents на сервере. Старые recovery не удалять из-за смены профиля/space.id.

Алгоритм как Studio S9, а не last-writer-wins:

| Локально относительно base | Remote относительно base | Действие |
| --- | --- | --- |
| Не менялся | Изменён/удалён | Принять Remote |
| Изменён/удалён | Не менялся | Обычный CAS put/delete, но учитывать §8: для редактирования существующего online-документа сначала войти в room |
| Точный одинаковый текст/hash | Любая более новая rev с тем же текстом | Обновить базу, без повторной записи |
| Изменён | Удалён | Сохранить draft; по политике Studio восстановить через put от tombstone rev |
| Удалён | Изменён | Восстановить Remote |
| Изменён | Изменён иначе | Сначала надёжно сохранить локальную копию; исходному пути — Remote, локальному варианту — conflict-copy |

Имя копии по Studio: `name (conflict <user> YYYY-MM-DD HHMMSS).md`, при коллизии — числовой suffix. Android сохраняет оба варианта локально **до** принятия Remote; публикация копии — CAS create с base 0, при nack не перезаписывает чужую копию. При исчерпании имени/ошибке диска draft остаётся, ошибка видима. При nack **нельзя** просто подставить новую base_rev и повторить старый content в исходный путь.

Первое подключение — та же reconciliation с пустой base. `change` на путь с in-flight write не должен преждевременно уничтожать draft: ответ ack/nack завершает эту попытку; более новый локальный generation остаётся к отправке (референс S9 `410–429,588–627`).

Офлайн draft уже существующего документа безопаснее публиковать отдельной conflict-copy после reconnect, если нельзя доказать отсутствие расхождения. Автоматически заменять оригинал целым offline-текстом в новой room запрещено: это не CRDT merge и может стереть свежие правки.

### 6.2 State machine

~~~text
Unconfigured → Connecting → Hello/version-check → Syncing
    → Reconcile drafts/pending → Connected → Joining → Seed/State → Editing
disconnect → Offline + local recovery → backoff → new connection → full handshake
reset → checkpoint old editor → retire old sid/doc → reload new Markdown → new join
4401 / 4400 / protocol mismatch → stopped, требуется действие пользователя
~~~

Сетевые retry как Studio: 1→2→4…→30 с + jitter 0…delay/2; open timeout 10 с, hello timeout 15 с (S8). Это настройки клиента, не поля протокола. JSON heartbeat/resume-room команды нет; transport ping допустим как WS-механизм, не выдуманный frame.

После disconnect sid/pending transport bindings невалидны; неопределённый результат отправки разрешается sync/hash/reconciliation, а не слепым повтором live. Вновь войти с новым sid/doc, **не** воспроизводить старые Yjs updates в новую incarnation. Во время offline разрешён локальный draft, честно обозначенный как «на устройстве, не синхронизирован», не обещать offline CRDT merge (S1 §16.4).

`reset` вызывается успешной **изменяющей** ordinary put/delete извне. Другим connections сначала приходит новый change, затем reset; connection-автор получает ack вместо своего change (S6–S7). Не монтировать старый doc в новую room даже на один кадр. Перед заменой UI сохранить recovery текущего materialized текста; при локальных/неподтверждённых изменениях показать конфликт. Same-content no-op put не reset-ит room.

### 6.3 Ошибки

| Событие | Реакция Android |
| --- | --- |
| WS **4401** `Missing or invalid key` / `Key revoked` | Остановить retry, сохранить drafts, запросить новый ключ |
| WS **4400** | Ошибка space/config, исправить настройки; reason — текст validation, сервер обрезает до 120 символов |
| WS **4408** `Too far behind` | Очередь Remote достигла 5000 кадров; backoff + sync с надёжного cursor |
| Сетевой обрыв / обычное закрытие | Recovery + reconnect; не считать запись подтверждённой |
| `error` frame | Разобрать correlation, показать причину; сохранить draft, прекратить повтор идентичного невалидного payload |
| `join_failed stale` | Catch-up + ограниченный rejoin, не seed из старой базы |
| `join_failed missing` | Закрыть room intent; предложить локальную копию/явное создание, не воскрешать молча |

`error`: invalid JSON → `{t:"error",message:"Frames must be JSON"}`; неизвестный t/не-объект → `Unknown message …`; ProtocolError → `{t:"error",message,of:<t>}` плюс исходные id/sid/path, если значения str/int. Например `No such session`, `A session id is required`, `An update must be base64`, `Update is too large`, `Update could not be applied: …`. Обработанные ошибки не закрывают socket; это не гарантия обработки всех произвольных исключений/binary frames (S4–S7).

**4000/4001 не являются raw Remote close codes**: это Studio→browser unavailable/reset (S8 `protocol.py:20–24`). На Android direct reset — JSON frame, а не ожидание close 4001.

## 7. «Открытие не пишет»: проверяемый инвариант клиента

Гарантия относится к содержимому Documents: открыть/показать/закрыть неизменённый документ не отправляет put/delete, не меняет rev/hash и файлы Studio. Создание нового space при connect — отдельная metadata-запись, не нарушение этой гарантии.

Обязательные правила:

1. Join/seed/awareness не являются изменением пользователя и сами не вызывают put. На Remote seed не ставит dirty (S7).
2. До первого полностью нарисованного room state не сериализовать пустой редактор. Не давать initial content поверх Collaboration.
3. Dirty возникает от настоящих редактирований, не от `serialize(source) != source`. Для room сравнивать с нормализованным **первым нарисованным** состоянием и учитывать dirty-at-join; иначе первое открытие неканонического Markdown само перепишет файл (S11–S12).
4. Нет TrailingNode в room; курсор, selection, фокус, UI раскрытие toggle и настройки отображения не часть документа.
5. Только scribe пишет долг комнаты; clean role inheritance/Back/blur/поворот экрана не делают чистый документ dirty.
6. Если вошли в уже dirty room и унаследовали scribe, запись чужих **существующих правок** нужна. Это не запись от простого открытия: долг возник до нового участника.

## 8. Сохранность чужих правок: честные гарантии и пределы

**В штатной online-room** совместимый Y.Doc с одной схемой сливает правки; только scribe пишет materialized Markdown, очередь не теряет новые generations, перед leave подтверждается запись. **В file-level конфликте** CAS + recovery/conflict-copy предотвращают молчаливую перезапись уже сохранённой чужой версии. Это требования приёмки Android, не новая возможность сервера.

Однако абсолютное «ни один чужой символ не потеряется при любом сбое» существующий протокол **не обеспечивает**:

- CAS видит только последнюю Markdown rev. Пока room dirty, ordinary put с правильной base_rev может заменить файл и reset-нуть комнату, уничтожив её ещё не materialized edits. Даже просмотр presence перед put не решает гонку: это не lock (`hub.py:212–245,415–421`).
- `live` — доверенный обход CAS, не проверка соответствия snapshot текущему Y.Doc и не серверная валидация scribe. Старый/ошибочный live snapshot способен стереть материализованные правки (`218–232,459–464`).
- Room updates не durable и не имеют ACK сохранения; room исчезает с последним участником. При crash последнего scribe/Remote до put могут пропасть изменения с последнего подтверждённого Markdown. `dirty` сбрасывается при live put без watermark/state-vector сохранения (`220–224,350–361,395–421`).
- Разные editor schemas могут привести к destructive repairs; protocol v1 не согласует версии схемы (S2, §5).

Поэтому **минимальный совместимый редактор — room-first, не CAS textarea**. При недоступной комнате/неизвестной схеме Android хранит draft локально или публикует отдельную conflict-copy, но **не** full overwrite оригинала. Recovery сохраняет и чужие правки, которые уже попали в видимый merged snapshot; на reset нельзя молча выбрасывать такой snapshot.

На Android требуются локальные checkpoints, bounded autosave, flush/ack-before-leave, явное разделение статусов «передано в room», «сохранено Remote», «только на устройстве». Это снижает риск, но не превращает эфемерный room в журнал. В этом scope не предлагаются новые server locks, REST или хранение Yjs; неизбежные crash/external-writer окна должны быть указаны пользователю и отражены в тестах.

## 9. Минимальная Android-архитектура

- Один открытый документ, один активный profile/socket; локальный список profiles и cache Documents. Compose Material 3: Connection → Documents → Editor, видимые настоящие статусы; EN/RU, dark/light, IME/insets, TalkBack.
- Native repository владеет auth/HTTP/WS, sequence/revisions, scribe-очередью, reconciliation и persistent recovery. Activity/theme не содержат сетевой логики. HTTP/WS библиотеку с custom Authorization выбрать и закрепить на этапе transport, не использовать JS socket.
- WebView владеет Y.Doc/awareness, точной PM schema, Markdown codec и undo. Native не переписывает codec на Kotlin. Упрощённый toolbar допустим при полной schema; неподдерживаемые desktop-команды можно не показывать.
- HTML/JS/CSS только из APK через [WebViewAssetLoader](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content), origin `https://appassets.androidplatform.net`. Не загружать удалённый editor/CDN и не исполнять HTML из Markdown.
- Bridge — **внутренний API приложения, не wire Remote**: versioned JSON, `documentGeneration,connectionGeneration,sid,requestId`, ограниченные команды `init/applyState/applyUpdate/serialize/format/dispose` и события `ready/localUpdate/awareness/snapshot/error`. Ключей, произвольного JS/native execution и файловых путей в нём нет.
- [WebViewCompat.addWebMessageListener](https://developer.android.com/reference/androidx/webkit/WebViewCompat): точный allowlisted origin, main-frame check, feature check. Нельзя wildcard origin или универсальный addJavascriptInterface для недоверенной страницы. Блокировать navigation/iframe/произвольную сеть; внешние ссылки — отдельно после действия человека; fallback при отсутствии функции — понятный read-only/unsupported, не небезопасный bridge.
- Сохранение snapshot — по запросу с generation; ответ от предыдущего документа игнорируется. Поворот/Back/background/render-process death сохраняют recovery; нельзя надеяться только на onDestroy.
- Новые библиотеки не выбирать по слову latest. [WebKit releases](https://developer.android.com/jetpack/androidx/releases/webkit) указывают повышение minSdk до 24 в 1.16.0, тогда как текущий shell minSdk=23. Для сохранения API 23 кандидат — закреплённая 1.15.0 (release notes: minSdk 23), после проверки необходимых bridge features на устройстве; иначе отдельное согласованное повышение minSdk. Compose BOM не выбирает compiler plugin: версия plugin следует Kotlin ([официальная настройка](https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler)).

## 10. Декомпозиция реализации с файлами

Все пути ниже — **внутри `D:\VoxariumRemoteAndroid`**, не изменения Studio. Относительные Kotlin-пути в таблице начинаются с `app/src/main/java/com/voxarium/remote/`. Новые этапы — предложения последующих задач, не обещание уже созданных карточек.

| Этап / зависимости | Файлы и ответственность | Критерий готовности |
| --- | --- | --- |
| 0. Shell — VS-71, независимо | Уже есть `MainActivity.kt`, `VoxariumRemoteApp.kt`, `ui/theme/Theme.kt`, `app/src/main/res/values{,-ru}/strings.xml`, wrapper/build scripts, smoke tests | Сборка shell и тема проверены отдельно; никаких фиктивных сетевых состояний |
| 1. Codec/schema parity — можно параллельно этапу 2 | `editor-web/package.json`, lockfile, `index.html`, `vite.config.ts`; `src/md/{document,conventions,prosemirror,color,image-width,table,wikilink}.ts`; `src/schema/{extensions,nodes,text-color}.ts`; `src/collab/{carried,seed}.ts`; простые DOM node views | Полный набор attrs/marks как S11; fixture и two-editor tests; seed/round-trip не теряет содержимое; unknown schema блокируется |
| 2. Transport + native data — параллельно этапу 1 | `data/{RemoteProtocol,RemoteTransport,ConnectionStore,TokenStore,DocumentsRepository,SyncStateStore,RecoveryStore}.kt`; manifest INTERNET, при необходимости `res/xml/network_security_config.xml`; `app/build.gradle.kts` для pinned зависимостей | hello/version/auth, raw frames, sync/cache, один writer на путь, atomic base/cursor/drafts; токен не логируется/не передаётся JS |
| 3. Read-only vertical slice — после 2 | `ui/{ConnectionScreen,DocumentsScreen}.kt`, `RemoteViewModel.kt`, обновление `VoxariumRemoteApp.kt` и EN/RU strings | Реальный server+space, список/чтение из sync, offline status; пока без write |
| 4. Room/editor integration — после 1 и 2 | `editor/{EditorWebView,EditorBridge,EditorMessages}.kt`; `data/{RoomCoordinator,ScribeQueue,ConflictResolver}.kt`; `editor-web/src/{main,bridge,room}.ts`; `ui/EditorScreen.kt`; build task → generated editor assets | seed CAS, raw Remote sid routing, scribe/save/handoff, no-write-on-open, recovery/rejoin; toolbar в живой room |
| 5. Интеграция и приёмка — после 3–4 | `app/src/test/.../{RemoteProtocol,DocumentsRepository,ConflictResolver,ScribeQueue,Recovery}Test.kt`; `app/src/androidTest/.../{EditorBridge,EditorLifecycle}Test.kt`; `editor-web/src/{md,collab}/*.spec.ts`; `README.md`, `VERIFICATION.md` | Тесты §11, реальные Studio+Android, воспроизводимый APK и честный список непроверенного |

В этапе 1 `createExtensions` нельзя копировать с неразрешёнными импортами Vue/i18n/Studio API: перенести schema overrides, заменить presentation adapters, убедиться тестами в полном равенстве schema. Тестовые fixtures из `frontend/src/lib/md/__fixtures__/` и `seed/editor.spec.ts` — read-only эталон; копия и provenance находятся в Android-репозитории. Сгенерированный web bundle — build output в generated assets, не вручную редактируемый dist. Package-lock не заменять текущими интернет-версиями без нового parity-теста.

Чтобы writers работали параллельно без коллизий, этап 1 владеет `editor-web/*`, этап 2 — `data/*`; интегратор один меняет Gradle/manifest/root app. Write paths каждой будущей задачи объявляются отдельно.

## 11. Тестовые сценарии и критерии

Ниже — **план приёмки**, не результаты запуска VS-70.

| Сценарий | Проверяемый результат |
| --- | --- |
| Auth: нет ключа, неправильный, revoked, protocol mismatch | 401/4401 различаются с сетевой ошибкой; retry прекращён, draft сохранён; mismatch не отправляет sync/write |
| Profiles/spaces | Ручной выбор; предупреждение об автосоздании; ни один callback/cache/ключ не протекает в другой profile; изменён space.id → полный sync с сохранением drafts |
| Начальный sync + tombstones + incremental | Список совпал с Remote; content прочитан из change; собственный ack обновил cache; рестарт не пропускает изменения; crash между cache и cursor не теряет запись |
| CAS/races/ack потерян | Старый base → nack; обе версии сохранены; повтор same text идемпотентен; набранное во время in-flight save не стирается старым ack |
| Два одновременных seed | Один winner, проигравший не merge-ит свой seed; ни одного дублированного блока |
| Android + настоящий Studio editor | Оба набирают в разных местах и на одной позиции; в итоге одинаковый merged Markdown; undo Android не удаляет чужой ввод |
| 10 открытий без ввода | **0 put/delete**, rev/hash/файлы/SCM без изменений; финальные table/list, пустой файл, нестандартный Markdown, clean scribe handoff |
| Round-trip corpus | Frontmatter/EOL/final newline, GFM/table alignment, вложенные directives/lists, h4–h6, wikiLink marks, image widths/links, unsupported blocks/inline, checked:null; повторное сохранение стабильно; известный nested-color normalization учтён |
| Awareness/selection/toggle view | Курсоры приходят/уходят, повторяются новичку; **не меняют Markdown** и не вызывают put |
| Scribe/handoff/dirty-at-join | Non-scribe не пишет; новый scribe сохраняет чужой долг; ранний scribe до seeded и updates до WebView ready не теряются; первый render не обнуляет долг; перед leave scribe ждёт ack, non-scribe — materialized текст или сохраняет recovery |
| Ввод во время serialize/put | generation защищает от отката; следующий snapshot включает новые local/remote updates; ошибка записи не убирает dirty |
| Disconnect/reconnect, смена epoch | Старые updates не применяются к новой room; offline draft остаётся; conflict-copy не затирает исходный документ; 4408 восстанавливается sync |
| External put/delete при dirty room | Подтвердить **текущее ограничение** сервера: CAS не защищает нематериализованный Y.Doc; Android до reset replacement сохраняет полученный merged snapshot в recovery и показывает конфликт |
| Last-scribe/Remote crash до materialization | Не выдавать update delivery за durable save; восстановить локальный checkpoint где он есть; задокументировать неизбежное окно потери на стороне протокола |
| Malformed/oversized/security | Path traversal, >1 MB UTF-8, >8 MiB decoded update, invalid base64; чужой origin/iframe/stale generation; HTML/ссылки не получают native bridge/токен |
| Android lifecycle/реальное устройство | RU IME composition, emoji/selection, Back, rotation, background/process death, WebView renderer death; TalkBack, large font, обе темы/ориентации; recovery не исчезает |

Существующие регрессии, которые нужно переиспользовать/сопоставить:

- `remote/tests/test_remote.py:103–147,153–235,246–288,291–336,339–420`: auth, CAS/tombstones, limits, seed race, dirty/relay, live/scribe/reset/presence.
- `backend/tests/test_remote_sync.py:193–340,403–539`: mirror, initial/offline conflicts, отказ ключа/reconnect, live browsers, flush-before-leave/reset/offline; `770–810`: scoped no-write-on-open/no Yjs persistence.
- `frontend/src/lib/collab/editor.spec.ts:145–232`: два настоящих Tiptap editors, 0 updates на open, совместный ввод/marks/undo/awareness.
- `frontend/src/lib/collab/seed.spec.ts`, `frontend/src/lib/md/round-trip.spec.ts:1–85` и fixtures: codec corpus, стабильность и no-loss.
- Перед запуском backend integration убедиться, что пакет Remote установлен в **том же** Python environment: skipped `test_remote_sync.py` не считается pass (AGENTS.md). Не устанавливать его неявно в исследовательской задаче.

Полноценную проверку прямого Android transport делать против существующего Remote в изолированных test data, затем против Studio-участника той же schema; pure `Y.Text` relay test недостаточен. Сервер Studio не запускать на произвольном втором порту; при использовании предусмотренного `remote_test.bat` остановить его после проверки. VS-70 ничего из этого не запускал.

## 12. Read-only toolchain audit и риски проверки

Аудит был действительно read-only: `Get-Command`, `java/javac/node/npm --version`, чтение env/release/source.properties/build scripts/lockfile, просмотр SDK/AVD/cache. Без Gradle task, установки пакетов, sdkmanager, ADB, эмулятора и запуска/перезапуска серверов. Во время аудита каталог Android из пустого стал shell-проектом в рамках **VS-71**; изменения и APK ниже не произведены VS-70.

Снимок дополнен в **22:02 МСК 14.11.2026**:

| Проверка | Наблюдение / риск |
| --- | --- |
| Java по PATH | Oracle **1.8.0_501**; `javac` — Adoptium **25.0.3**, `JAVA_HOME` и Android Studio JBR — JDK **25.0.3**. PATH и JAVA_HOME расходятся |
| Найденная совместимая JVM | `C:\Program Files\Android\openjdk\jdk-21.0.8\bin\java.exe -version` → Microsoft OpenJDK **21.0.8+9-LTS**. Не утверждать, что подходящего JDK нет: первоначальный поиск его не показал |
| Wrapper / plugins | Gradle **8.14.3-all** уже есть, wrapper с distribution SHA-256; AGP **8.13.2**, Kotlin/Compose compiler **2.3.21**. Проверены Android `build.gradle.kts:1–5`, `gradle/wrapper/gradle-wrapper.properties` |
| Android SDK | `%LOCALAPPDATA%\Android\Sdk`: platforms **android-36**, **android-37.0**; Build Tools **35.0.0**, **36.0.0**; Platform Tools **37.0.1**, Emulator **37.1.11** |
| CLI/env | gradle/adb/sdkmanager не в PATH; ANDROID_HOME/ANDROID_SDK_ROOT не заданы; `local.properties` у shell указывает SDK. `cmdline-tools` не найден |
| Device tests | 0 AVD, `system-images` отсутствуют. Наличие Emulator binary не означает возможность connected tests; физическое устройство не проверялось |
| Shell build config | `app/build.gradle.kts:7–45`: compile/target **36**, min **23**, bytecode target **17**, Compose BOM **2025.10.01**, Activity Compose **1.11.0**, Robolectric **4.16.1** |
| Наличие функций | `app/src/main/AndroidManifest.xml:1–20` без INTERNET; только MainActivity/root/theme/resources/smoke tests. Нет transport/editor. Shell README прямо указывает эти границы |
| Артефакт другой задачи | Замечен `app/build/outputs/apk/debug/app-debug.apk`, 11 234 315 байт, mtime 22:01:43. Это **не доказательство pass тестов или работоспособности Remote-клиента**; результаты shell принадлежат VS-71 |
| Web toolchain | Node **24.18.1**, npm **11.16.0** из runtime Studio; Studio lockfile: Vite **8.3.5**, engine `^20.19.0 \|\| >=22.12.0`. Node подходит этому engine, editor-web проекта пока нет |

**JVM запуска Gradle ≠ bytecode target приложения.** Для Gradle 8.14.3 нельзя полагаться на обнаруженный default JDK 25: официальная [Gradle compatibility matrix](https://docs.gradle.org/current/userguide/compatibility.html) поддерживает Java 25 для запуска с 9.1.0, Java 21 — с 8.5. Выбирать найденный JDK 21 явно для текущего процесса/IDE, без правки глобальной среды. Механически поднимать wrapper до 9.x ради JDK 25 не нужно.

[AGP 8.13 release notes](https://developer.android.com/build/releases/agp-8-13-0-release-notes): минимум Gradle 8.13/JDK 17, API до 36.1, в 8.13.2 есть поддержка Kotlin 2.3. Существующий SDK 36 подходит этой связке. Само наличие кешей не доказывает сборку; dependency cache менялся параллельно.

Документ прочитан обратно через Studio и прошёл независимое read-only review wire/гарантий; учтены ранние frames при mount и отдельный close-barrier non-scribe. Проверены целостность текста, таблицы и отсутствие conflict markers; это не прогон runtime-тестов.

Следующие **не выполненные здесь** проверки в Android-задачах: `assembleDebug`, `testDebugUnitTest`, `lintDebug`; editor-web typecheck/build/unit tests; instrumentation на устройстве с подходящим WebView; interop Studio+Android. Перед ними повторно прочитать текущие README/VERIFICATION и toolchain: VS-71 ещё работает. Gradle/npm могут писать cache/downloads и требовать сеть; первые ошибки могут быть environment, а не протокол. Временные пробы VS-70 допустимы только в `D:\VoxariumStudio\.voxarium_studio\temp\TASK-70`; общие scratch/проектные файлы под них не использовались.

## 13. Итоговый gate перед включением записи

Запись в оригинальные Documents включается только после codec/schema parity, успешного room interop, no-write-on-open, scribe/ack ordering и recovery/conflict тестов. До этого допустим настоящий read-only sync и локальные drafts. Контракт не требует новых серверных функций; абсолютная durability эфемерных CRDT-правок и совместимость неизвестных схем остаются ограничениями существующего протокола, а не обещаниями Android MVP.
