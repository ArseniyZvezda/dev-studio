# VS-128 — план активации глобального Remote API

16.11.2026. **План реализации, не выполненная интеграция.** Единственный результат VS-128 — этот документ. Основание: [[remote-identity/delivery-authorization]], [[remote-identity/studio-design]] §5–9/S3–S9, [[remote-identity/server-design]], [[remote-identity/catalog-offline-gaps]] и [[remote-identity/catalog-metadata-contract]].

Разрешение пользователя снимает прежние offline-запреты **этапа**. Ограничение VS-128 — только документ, без code/config/data edits, тестовых запусков, сборок или серверов — не переносится в будущие реализационные карточки. Исторические «ещё нет REST/providers» и «запреты не сняты» в VS-116 не описывают сегодняшний остаток. Не нужна новая приёмка VS-93–127.

## 1. Что подключаем, а не переписываем

Graphify query выполнены по `D:/VoxariumStudio/graphify-out/graph.json`, затем прочитаны текущие owners. Граф — навигация; широкие ответы усекались, поэтому выводы основаны на исходниках. Ниже ссылки на checkout на дату документа; при сдвиге строк ориентироваться на названный symbol.

| Готовый owner | Точная граница использования |
| --- | --- |
| [RemoteProfiles / ProfileConsumers / ConsumerGuard](../../../backend/voxarium_studio/sync/profiles.py#L32), `create:96`, `rename:112`, `_consumers:130`, `_credential:193`, `change_url:210`, `delete:233`, `recover:277` | S2 CRUD, CAS, cross-file nonsecret journal и консервативное recovery существуют. Без authoritative lifecycle guard чувствительные mutations намеренно отказывают. Это не production guard и не async drain. |
| [S2CatalogReaders.check / PendingCatalogProviders](../../../backend/voxarium_studio/sync/catalog_providers.py#L34), `get:124`, `load_token:147` | Pending-aware exact profile/URL/revision providers готовы. Только bounded observations; journal может появиться после последней проверки. Не обещают multiprocess lease/send-boundary atomicity. Не использовать lock-writing `RemoteProfiles.load_token:175` в read-only S3. |
| [CatalogMetadataObserver](../../../backend/voxarium_studio/sync/catalog_metadata.py#L69) и [CatalogMetadataAdapter.list](../../../backend/voxarium_studio/api/remote_metadata.py#L73) | Реальная цепочка list/source → immutable rows → ServerProfile уже готова (VS-122/125). Не читать token ради bool; не создавать новый status cache. |
| [UnavailableVerification / ServerProfile](../../../backend/voxarium_studio/api/remote.py#L79), [create_remote_router](../../../backend/voxarium_studio/api/remote.py#L247) | VS-119/124: готова немонтируемая оболочка GET servers, POST verify, GET projects; strict DTO, typed errors, no-store. GET projects сам captures revision; не добавлять ему browser CAS задним числом. Нет CRUD/Create/mounting. |
| [CatalogService._snapshot / _check / _read](../../../backend/voxarium_studio/sync/catalog_service.py#L159), `list_projects:233`; [CatalogVerificationService](../../../backend/voxarium_studio/sync/catalog_verification.py#L74); [CatalogReadService](../../../backend/voxarium_studio/sync/catalog_read_service.py#L25) | Read guards, v2 read facade, HTTP-only v1 Verify, snapshot/legacy adapters готовы с injected decoded transport. Не повторять их реализацию; реальный HTTP ещё не доказан. |
| [CatalogCreateService](../../../backend/voxarium_studio/sync/catalog_create_service.py#L113), `create_project:254`, `recover_create:339`; [CatalogIntentJournal](../../../backend/voxarium_studio/sync/catalog_intents.py#L121) | Durable reservation **уже интегрирована** в Create (VS-114/115), process-exit evidence — VS-120. Нужен owner/path/public handler, не «подключить журнал заново». Instance default не годится для production. |
| [isGlobalApiPath / scopedApiUrl](../../../frontend/src/api/project-scope.ts#L6) | VS-127 done: exact allowlist трёх существующих Remote paths. Не blanket `/remote*`, не повторная задача на этот classifier. |
| [create_app.lifespan](../../../backend/voxarium_studio/main.py#L59), [api_router / project_router](../../../backend/voxarium_studio/api/__init__.py#L27) | Глобального catalog owner/mount пока нет. Import-level api_router общий; нельзя поместить туда singleton с выбранным home/активным Ctx. Существующий Remote router уже имеет полный prefix `/api/remote/servers`. |

Карточки VS-125/127 прочитаны: done не объявляются новым результатом. **VS-129 уже принят**: `frontend/src/api/remote.ts`, `remote.spec.ts`, только typed client трёх существующих методов; не дублировать. **VS-130 ожидает review**: отдельный opt-in AI-контракт, см. §8.

## 2. Правила композиции и точки отказа

- Один application-owned `RemoteCatalogRuntime` на lifespan backend, не на вкладку, project root или `app.state.ctx`. Персональный home берётся из существующего user-config scope; production composition единожды выбирает home и связывает **действительные** locators S2 readers. При drift/неопределённом home — отказ, не fallback на новый home.
- Цепочка metadata: S2 `RemoteProfiles.list/get` + `profile_token_source` + actual path observers → `CatalogMetadataObserver` → `CatalogMetadataAdapter` → существующий router. GET ничего не создаёт, не recover-ит, не вызывает transport/Verify/clock. Каждый корректный profile возвращает **ровно** `verification:{state:"unavailable"}`; не unchecked/error/результат предыдущего Verify. ENV-unbound, pending, corruption или race — отказ **всего** ответа, не empty/partial/default unavailable.
- Для каждого outbound read fresh `PendingCatalogProviders` с captured exact profile_id/URL/revision; фасад выбирает их до awaits, затем reuse существующих S3 guards. Не один mutable «последний профиль» для параллельных запросов. Key A→B при одинаковом source/has_token не доказывает continuity.
- Verify — отдельная явная команда HTTP health/me; v1 diagnostic не даёт доступа к v2 каталогу. GET списка серверов (metadata) никогда не выполняет Verify; valid POST result не становится сохранённым разрешением. Каждый v2 catalog operation проходит собственные version/capability/binding guards.
- [require_auth / browser_access_allowed](../../../backend/voxarium_studio/core/security.py#L109) используют server-wide `app.state.auth`, Host/Origin и явный dev-origin allowlist, не auth выбранного проекта. Локальный Studio token и Remote Bearer — разные секреты. Studio auth остаётся существующей; Remote принимает Bearer только из backend, без query/cookie/body credential fallback.
- Синхронный `ConsumerGuard` не может ждать сетевые ACK. Async quiesce/drain делается **до** входа в него; внутри короткой критической секции frozen inventory/lease остаётся стабильным до S2 publication. Порядок: lifecycle → application-config transaction → credential store. Не держать synchronous/thread lock через await и не блокировать read-loop, принимающий ACK.
- Lifecycle учитывает все resident contexts, private bindings (в том числе неоткрытых roots), legacy URL consumers и in-flight catalog/Create operations. Unknown inventory = `consumer_lifecycle_unavailable`, не `ProfileConsumers()`. Пока private bindings/S5 drain не реализованы, только доказанно unbound/idle профили допускают чувствительные mutations; используемые — 409, не forced stop.
- [workspace._register_project](../../../backend/voxarium_studio/core/workspace.py#L81) ключуется canonical root и выдаёт runtime descriptor. persistent ID, profile_id и storage_epoch **не** заменяют runtime project_id/backend epoch/root. Никаких rebind/remount/restart вкладки, переноса draft/base или остановки jobs/агентов B при действии в A.

## 3. Минимальный первый безопасный вертикальный срез V0

**C1 → C3**, без зависимости от готовности сервера и без HTTP-клиента: production global home → существующий observer/adapter → authenticated GET `/api/remote/servers` через настоящее приложение. Это первая полезная API-интеграция сохранённых серверов со статусом unavailable, а не новый offline adapter.

C3 монтирует существующий router один раз на app. Два outbound метода присутствуют, но их обязательные injected facades до C4 детерминированно возвращают `service_unavailable`/502 **до credential lookup/сети**. Это не успешный Verify и не «сервер offline». Не добавлять фиктивные valid/status/capabilities ради mounting. CRUD/Create отсутствуют/405; Select/Enable/WS новой модели не включаются.

Доказательство V0: два real app lifespans с разными synthetic homes не делят owner; A/B project selection не меняет глобальный ответ; missing home не создаётся; pending/ENV-unbound/corrupt fixtures дают typed no-store failure; запрещённые transport/clock/token-loader counters = 0; auth/Host/Origin до любой S2 операции. VS-129 может потреблять этот GET после собственной приёмки; UI ещё отдельный S8.

**V1 = C2 + C4** добавляет реальный HTTP Verify; каталог открывается только после серверного gate R3. **V2 = C5–C9** добавляет local profile management и явный Create, не project sync. Ни один из этих срезов сам по себе не завершает S4–S9 или milestone Remote AI.

## 4. Конечный backlog подключения Studio

Идентификаторы C0–C9 — **ярлыки готовых briefs, не выдуманные номера карточек**. Все пути ниже exact, относительно `D:/VoxariumStudio`; «новый» означает предложенный файл. В будущей карточке объявить весь список до записи. Read-only ссылки не входят в write_paths. Если понадобится иной owner — расширить scope до записи, не править молча.

### C0 — Закрепить узкие локальные API-дополнения в canonical specs

**Зависимости:** решения этого плана; независима от code owners. **Документный C0 выполнен в VS-134 до приёмки VS-128, без зависимости от approve.** Это перенос конкретного решения, не новый общий аудит или перепроектирование wire; runtime C7/C9 не объявлены реализованными.

**write_paths:**
- `docs/voxarium-studio-dev-spec.md`.
- `.voxarium_studio/docs/remote-identity/studio-design.md`.

Нормативные копии локального уточнения: [[remote-identity/studio-design]] §5.1 и [dev spec §5.2.1](../../../docs/voxarium-studio-dev-spec.md). Полная route/input/status таблица ниже — критерий реализации C6/C7/C9, не разрешение менять wire/credential continuity; Remote POST и cold fail-closed прежние.

**Локальное уточнение VS-134 (C0; нормативно для будущих C6/C7/C9).** Только глобальный API Studio; это не изменение Remote wire и не утверждение о mounting. `B=/api/remote/servers`, `S=B/{profile_id}`; profile_id — canonical UUID, expected_revision — strict integer ≥1 (не bool), неизвестные поля/лишний body/query отклоняются до dispatch. Все ответы, включая auth/validation/errors, — `Cache-Control:no-store`; credential/URL из browser payload не подменяют сохранённый exact binding.

| Метод / локальный путь | Строгий вход | Успешный HTTP / ответ и эффект |
| --- | --- | --- |
| GET `B` | Без body/query | 200 `{items:ServerProfile[]}`; metadata-only, verification ровно `{state:"unavailable"}` при отсутствии применимого результата, без Verify/clock/сети/записей. |
| POST `B` | `{name,url}` | 201 secret-free ServerProfile; keyless, уникальный normalized URL, без подключения проекта. |
| PATCH `S` | **Один вид**: `{expected_revision,name}` **либо** `{expected_revision,url,clear_credential:true}` | 200 secret-free ServerProfile с новой revision. Name-only без reconnect; URL-only только при допустимых consumers, с revoke binding/journal/очисткой stored key. Name+URL, пустой patch и clear_credential вне URL-варианта — 422 до любых writes. UI не делает hidden split одного Apply; два изменения — отдельные явные действия/подтверждения со свежим CAS. Composite atomic PATCH вне increment. |
| PUT `S/credential` | `{expected_revision,token}`, непустой secret | 200 metadata результата S2 (has_token/revision), без token; drain/CAS обязательны. |
| DELETE `S/credential` | `{expected_revision}` | 200 secret-free metadata; удаляет только stored key, не ENV/Remote user/project. ENV остаётся effective source либо environment_unbound даёт typed отказ, не ложный source none. |
| POST `S/recover` | `{expected_revision,confirmation:{profile_id,action:"discard_uncertain_credential"}}` | 200 `{profile:ServerProfile\|null}`; подтверждённое удаление uncertain stored credential через S2 recover, не восстановление/повтор старого key. null только при доказанном отсутствии metadata. |
| POST `S/verify` | `{expected_revision}` | 200 VerificationResult `{state,checked_at,user,wire_protocol,catalog_version?,error_code?}` при возврате facade; только HTTP health/me, не Create/WS. Typed exceptions не становятся успешной verification. |
| DELETE `S` | `{expected_revision}` | 204 без body, только без bindings/active consumers; не изменяет project configs. |
| GET `S/projects` | Только query `cursor?` (canonical after ID), без body | 200 `{items:CatalogProject[],next_cursor:ID\|null}`; revision захватывает backend, не browser CAS. Не вызывает явную команду Verify/Select/Create; собственный health/me/version/binding preflight каталога сохраняется. |
| POST `S/projects` | `{id,display_name,operation_id,expected_revision}` | 201/200 **только** result envelope по таблице ниже; C8 owner и durable reservation. Remote body только `{id,display_name}`. |
| POST `S/projects/operations/{operation_id}/observe` | `{expected_revision}`; без id/url/key | 200 result envelope found/absent при успешном observation; отдельная явная команда `CatalogCreateService.recover_create`, не GET handler и не повтор Create. Remote traffic только health/me + GET **исходного** ID из reservation, без POST/WS/writes проекта. |

Operation_id — локальный exact `[A-Za-z0-9._-]{1,128}`, не Remote field. ID/display_name валидируются по Studio design §6 / dev spec §16.7; name/url — существующими S2 validators. Невалидная форма confirmation — 422; структурно валидные, но несовпавшие profile_id/action — typed 409 до S2 recovery. Recovery требует предупреждения и отдельного подтверждения очистки uncertain key, того же CAS/drain/authoritative guard. Startup/GET не recover-ят, malformed journal сохраняется с отказом; ENV не меняется. Это **не** cold Create recovery.

**Result envelope фиксирован:** всегда ровно `{state,project,error_code}`, все три поля обязательны, включая null; без selection/ownership/retry booleans, raw message/body/request_id. Строка code — только fixed sanitized vocabulary, не произвольная серверная строка. Это mapping **возвращённого CreateResult**, не перехват исключений.

| CreateResult.state | Локальный HTTP | project | error_code / смысл |
| --- | --- | --- | --- |
| `created` | 201 | Exact validated CatalogProject исходного ID | null; даже 201 не Select/Enable. |
| `conflict` | 200 | null | `project_exists`; никакого auto GET/POST/Select победителя гонки. |
| `unknown` | 200 | null | Fixed sanitized code: `create_unknown`, `transport_unavailable`, `invalid_response`, `version_mismatch`, `redirect_refused`, `temporarily_unavailable` либо `remote_error`; неоднозначность не разрешает повтор. |
| `rejected` | 200 | **null** | Только `invalid_id`, `invalid_display_name`, `invalid_request`, `unauthorised`, `project_not_found`, `metadata_conflict`, `snapshot_changed`, `payload_too_large` либо fallback `remote_error`; без retry, Select или освобождения operation. |
| `found` | 200 | Exact validated CatalogProject исходного ID | null; только observation, не авторство/привязка; Select — отдельное будущее действие. |
| `absent` | 200 | null | `project_not_found`; не освобождает operation, не разрешает auto POST. |

Первичный Create возвращает первые четыре исхода; found/absent возникают после отдельного явного observe. Повтор того же Create с тем же exact input и живым неизменившимся binding возвращает последний сохранённый result (включая rejected и found/absent после явного observe), без нового transport send; другой profile/revision/body под тем же operation_id — typed 409 operation_conflict, не новый intent. Guards/journal failures могут вместо result дать typed exception. Ни rejected, ни остальные outcomes не освобождают reservation; исправленный Create требует нового явного действия и нового operation_id, не автоматического retry. Observe никогда не запускается автоматически после rejected/conflict/unknown; явно вызванный observe заново проверяет **живой** binding и читает исходный ID, может вернуть found/absent, но не делает Select. После restart/loss live proof любая durable запись, включая created/rejected/found, даёт `credential_binding_unproven` до credential/transport calls; revision/source/has_token не доказывают continuity.

**Boundary exceptions отдельно:** локальный envelope `{code,details}` (fixed codes, sanitized details), не `{state,project,error_code}`. Вход/валидация — 422; profile/operation not found — 404; CAS/collision/in-use/not-drained/recovery-required/conflicting confirmation/operation_conflict/operation_in_progress/credential_binding_unproven — typed 409; unavailable lifecycle/store/journal/admission capacity — typed 503. Malformed recovery journal — typed 503 profile_recovery_unavailable, без удаления/repair. Remote/transport/version/capability/response exceptions — существующий typed 502 mapping (unauthorised → remote_unauthorised); auth Studio — 401/403, unsupported method — 405. Не превращать эти исключения в rejected/unknown/absent, не заворачивать ошибки в HTTP200. Cancellation сохраняет cancellation и reservation, не синтетический success.

**Server status matrix — только обработанный ответ целевого Remote POST, после успешных guards/health/me:** не переопределяет Remote errors/wire. Если facade бросил исключение до возврата CreateResult (включая post-await guard/secret/journal failure), применяется boundary mapping выше, а не эта таблица.

| Ответ Remote POST / отдельного observation GET | Возвращённый локальный result |
| --- | --- |
| POST 201 + валидный project исходного ID | created →201. Невалидный 201 →unknown/200 с fixed invalid_response (protocol mismatch →version_mismatch), если facade вернул result, а не exception. |
| POST 400 invalid_id/invalid_display_name/invalid_request | rejected →200, project=null, только соответствующий fixed code. |
| POST 401 unauthorised | rejected →200 с unauthorised; не локальная Studio 401 и не отказ health/me. |
| POST 404 project_not_found | rejected →200; **не absent**. |
| POST 409 project_exists | conflict →200. |
| POST 409 metadata_conflict/snapshot_changed | rejected →200, не conflict и не Select. |
| POST 413 payload_too_large | rejected →200. |
| POST 503 temporarily_unavailable | unknown →200, не доказанный отказ/разрешение retry. |
| POST неожиданный status (включая 200/204/500) | unknown →200 с remote_error; redirects/transport failure — fixed code только если возвращён CreateResult, иначе typed boundary exception. |
| POST 400/401/404/409/413 с malformed envelope/неизвестным или несовпавшим code | rejected →200 с **remote_error**, не raw code; malformed 409 не project_exists/conflict. |
| Observe GET исходного ID 200 + валидный project / 404 project_not_found | found/absent →200; только exact project GET 404 означает absent. |
| Health/me error (включая 401/404/503), observation GET иной error/невалидный ответ | Typed boundary failure, не rejected/absent/unknown outcome; никакого implicit POST. |

**Targeted acceptance будущей реализации (не выполненные проверки VS-134):**
- Table-driven C9: все шесть states, обязательные три поля/null, 201 только created; перечисленные POST 400/401/404/409 (все три codes)/413/503, unexpected 200/204/500, malformed error envelopes и invalid 201. Проверить phase distinction: health/me 401/404/503 и GET error — typed failures; GET exact 404 — absent, POST 404 — rejected.
- Rejected и повтор: одинаковый operation/input → тот же rejected/200, project=null, fixed code, POST counter=1, новые GET/Verify/Select/retry/release counters=0; другой body/profile/revision →409 до credential lookup. Проверить durable reservation осталась и после rejected, response failure/cancel/restart; cold repeat/observe →409 credential_binding_unproven, credential/transport counters=0.
- Отдельный explicit observe — только health/me + GET reservation ID; found/absent не bind/enable/release. Raw canary в server message/code/request_id/exception не выходит в DTO/logs/repr/chains; unknown code →remote_error. Все boundary 404/409/422/502/503 и Studio 401/403/405 остаются typed no-store, не HTTP200 outcome.
- C7: missing/mismatched confirmation, stale CAS, in-use/not-drained/unknown consumers, partial writes, corrupt journal, absent metadata, ENV-bound/unbound; recovery не возвращает key и не делает network. C6/C7: name+URL/лишние поля/empty patch/неверный clear_credential →422 с **нулём writes**; UI не подменяет Apply двумя hidden requests.

**Проверка C0:** cross-links и статическая сверка трёх документов; targeted runtime acceptance выше выполняют будущие C6/C7/C9. Старые done-приёмки не пересчитываются, offline-запрет этапа не продлевается.

### C1 — Создать application-owned композицию, без сети и mounting

**Зависимости:** принятые VS-118/119/122/124/125; новых blockers нет. **Готова к назначению сейчас.**

**write_paths:**
- `backend/voxarium_studio/sync/catalog_runtime.py` — новый.
- `backend/tests/test_remote_catalog_runtime.py` — новый.

Результат: explicit factory/ready holder с lifecycle start/close, один home, реальные S2 readers/locators, metadata chain и request-bound read facade factories. Никаких глобальных monkeypatch home или implicit import-time I/O. Outbound facades закрыты до явной интеграции C4. Не открывать CatalogIntentJournal при startup/GET; он создаёт файл. Не подставлять `RemoteProfiles.load_token`; закрытие owner идемпотентно, admission после shutdown запрещён, failed startup не оставляет usable owner.

**Tests:** `pytest backend/tests/test_remote_catalog_runtime.py`: real S2 synthetic homes → metadata chain; historical labels/два профиля/known empty; pending до и после source/locator drift; ENV-unbound/corruption без partial; overlapping profile factories не смешивают expected_url/revision; startup failure/close twice/new lifespan; 0 writes/clock/Verify/token-load/network для GET. Это composition tests, не повторная полная приёмка observer.

### C2 — Реализовать bounded HTTP transport

**Зависимости:** существующий `CatalogTransport`; независима от C1/C3 и серверного coding gate. **Готова к назначению сейчас.**

**write_paths:**
- `backend/voxarium_studio/sync/catalog_http.py` — новый.
- `backend/tests/test_remote_catalog_http.py` — новый.

Reuse уже объявленный backend dependency `httpx`, без нового пакета. Implement `CatalogTransport.request` + owned async close. Exact normalized endpoint/prefix; TLS verification включена, redirects запрещены всех видов (включая same-origin), нет retries POST/альтернативного URL/key. Dedicated HTTP client без ambient cookies, netrc/auth hooks, proxy-env forwarding и header/frame debug logs; `trust_env=False`. Health без Bearer. Не принимать URL от browser payload.

Фиксируем проверяемые production bounds: connect/pool 5s, read/write 15s, total request deadline 30s; raw response ≤4 MiB, включая chunked/no Content-Length; лимит и на декодированные bytes, не доверять compression expansion (предпочтительно identity encoding и отказ compressed response). Strict UTF-8/JSON object, reject duplicate keys/NaN/nonfinite/invalid type; body/error/headers не выводить. Клиентские `Cache-Control:no-store`, отсутствие cache, close response в success/error/cancel. Byte-limit до JSON decode, не после построения огромного объекта. Content-Type JSON обязателен для JSON-ответов. Все raw transport/parser exceptions, URL/headers/request repr/chains санитизировать до фиксированных CatalogError. Сохранить неоднозначность Create при timeout/cancel; transport не решает, что POST не дошёл.

**Tests:** `pytest backend/tests/test_remote_catalog_http.py`: mock low-level httpx transport/stream, no sockets; exact prefix/query/method, health/Bearer separation; 301/302/303/307/308 и second host — второй send=0; TLS verify/trust_env/client options; oversized declared/chunked/compressed/invalid JSON, timeout по каждой фазе, total deadline, cancel+close, pool exhaustion; canary secret в exceptions/headers/body/logs/repr/chains отсутствует; POST send counter ≤1. Реальный TLS/Remote interop — release gate §7, не доказательство mock-тестами.

### C3 — Смонтировать V0 и проверить full-app security

**Зависимости:** C1. Можно параллельно C2; один writer `main.py`.

**write_paths:**
- `backend/voxarium_studio/main.py`.
- `backend/tests/test_remote_catalog_mount.py` — новый.

Отдельный app-owned holder создаётся factory, ready в lifespan, закрывается при startup failure и shutdown. Mount напрямую в `create_app`, **не** в project_router и не через mutable `get_ctx`; router содержит полный `/api/remote/servers`, не добавить второй `/api`. Не менять shared import-level `api_router` ради instance services. AuthSettings доступен до readiness/первого запроса. После прекращения admission catalog tasks завершаются/отменяются с ожиданием до закрытия HTTP resources; jobs/контексты живут своим прежним lifecycle.

**Tests:** `pytest backend/tests/test_remote_catalog_mount.py`: реальная ASGI app/lifespan на synthetic project/home без listener; security для всех трёх existing routes — configured token missing/wrong 401+WWW-Authenticate, valid token+foreign/null/malformed/duplicate Origin и invalid/duplicate Host 403, loopback DNS rebinding, разрешённый dev origin и nonbrowser без Origin; hostile Forwarded не обходят policy. На 401/403/422/405 и typed 5xx no-store, services вызваны 0 при auth refusal. Только exact global URL, нет scoped mirror/`/api/api`; A/B/root копии не меняют owner/auth; selection/open/close-tab не закрывает его; unavailable GET без I/O, outbound deny facades без key lookup. Старые project/scoped маршруты неизменны.

### C4 — Активировать outbound Verify и v2 reads через готовые facades

**Зависимости:** C1, C2, C3; v2 catalog activation дополнительно R3. V1 Verify разрешён после C2/C3 и не требует v2 сервера.

**write_paths:**
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/tests/test_remote_catalog_activation.py` — новый.

Заменить deny facades настоящими request-bound `CatalogVerificationService/CatalogService/CatalogReadService`; захватить profile locator/revision до построения pending providers, не использовать состояние active tab. Shared transport owned runtime; каждый request own providers/client, fresh verification; checked Verify response не кэшируется для GET. S3 guards продолжают проверять binding до/после failed/cancelled awaits/pages. Наличие accepted R3 — release gate, а runtime всё равно каждый раз проверяет protocol/capabilities; не вводить persistent feature flag как обход. Нет v1 WS fallback и нет смены production `PROTOCOL_VERSION` ради HTTP reads.

**Tests:** `pytest backend/tests/test_remote_catalog_activation.py`: full chain synthetic S2→real services→HTTP mock→mounted route; v1 health/me только diagnostic, unknown protocol/missing strict_connect/catalog cap — zero catalog/Create calls; changed profile/key/ENV/pending на health/me/page boundary — no continuation/partial; two concurrent profiles/roots не смешивают Bearer, deployment prefix сохранён; GET servers после valid Verify всё равно unavailable. Проверить 502 network и sanitized error без fallback. Timeout-код 504 не обещать существующему facade без отдельного typed mapping: до явного расширения сохраняется нынешний 502.

### C5 — Подключить authoritative consumer/admission lifecycle

**Зависимости:** C1; для включения в приложение — C3. Не зависит от C2 или R3. Авторитетное положительное знание private binding inventory требует незавершённого S4, а positive drain используемого профиля — незавершённого S5; до них принимается только fail-closed seam, не объявляется production-ready разрешение sensitive mutations.

**write_paths:**
- `backend/voxarium_studio/sync/profile_lifecycle.py` — новый.
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/voxarium_studio/core/workspace.py`.
- `backend/voxarium_studio/core/context.py`.
- `backend/tests/test_remote_profile_lifecycle.py` — новый.

Задача — guard/admission и точная граница с будущим S5, **не импровизированный drain на основе cancel**. Register/unregister resident sync consumers при startup/failure/shutdown; legacy sync URL match консервативно считается использованием профиля, даже без нового profile_id. Registry учитывает in-flight outbound/CatalogCreate leases и known private bindings; отсутствие пока S4 storage не превращается в утверждение «нет bindings». Проверка bound_roots для URL/delete строже active_roots для credential. Unknown/recovering inventory держит guard закрытым.

Публичная mutation не вызывает forced drain. До реализованного S5 caller должен отдельно остановить/подтверждённо drained consumers; если доказательства нет — 409 с локальными roots, без side effect. В будущем S5 выдаёт готовый drain ticket после editor+pending ACK, C5 только проверяет/удерживает его и блокирует новые attach/reconnect/read/create до publication. Pure rename не reconnect-ит. Short synchronous `ConsumerGuard` соответствует существующему S2 API; serialize concurrent attach/delete/key changes, lock ordering §2. Не брать project_lock через длительные awaits.

**Tests:** `pytest backend/tests/test_remote_profile_lifecycle.py`: attach racing credential/url/delete, failed startup, hidden resident/legacy consumer, same URL/two roots и unknown private-binding inventory; active/non-drained → refusal, drained ticket не означает unbound; new consumer/read/Create не проскальзывает до publication; no deadlock ACK loop/lock ordering; A mutation не cancel-ит jobs B, selected project irrelevant. При отсутствии S5 реальный used profile остаётся blocked — это acceptance, не незавершённый «успешный drain».

### C6 — Открыть безопасные metadata mutations профилей

**Зависимости:** C3; C5 не нужен для create/rename, так как S2 уже разрешает их без consumer guard.

**write_paths:**
- `backend/voxarium_studio/api/remote.py`.
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/tests/test_remote_profile_api.py` — новый.

POST servers `{name,url}` →201 secret-free ServerProfile с unavailable; name-only PATCH `{expected_revision,name}` → новая revision без reconnect. Strict extra forbid, canonical profile UUID, integer CAS (не bool), existing URL/name validators, URL collision typed 409. Сохранить global settings/project split и opaque поля existing S2 writer. Не выполнять GET metadata всего списка **после** mutation как условие её «успеха»: отказ observer другого профиля не должен маскировать committed write/провоцировать повтор создания. Ответ строить из exact committed row + pending-safe presence только этого профиля, unknown presence — честный typed failure без rollback/авторетрая. В ошибках явно не утверждать «изменения не применены» после commit. Для нового keyless профиля не выдумывать credential history unchecked.

**Tests:** `pytest backend/tests/test_remote_profile_api.py`: real S2 store и mounted HTTP handlers, create один normalized URL/два одинаковых имени, stale rename 409, name-only не меняет URL/key/runtime generation; payload URL/key/unknown extras не логируется; no network, opaque/global fields сохранены; commit-success/response failure различим без repeat. Auth/no-store берётся из C3 и проверяется для новых методов targeted, не полная повторная suite S2.

### C7 — Открыть credential/URL/delete и explicit S2 recovery

**Зависимости:** C0, C5, C6. Реальный positive in-use drain — внешний S5 gate; до него used consumers получают 409.

**write_paths:**
- `backend/voxarium_studio/api/remote.py`.
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/tests/test_remote_profile_mutation_api.py` — новый.

PUT/DELETE credential, URL-only PATCH с `clear_credential:true`, DELETE profile по §5.1 → существующие S2 методы, **не** ручные save/config/reconfigure. PATCH name+URL в одном запросе отклонять до записи: текущий S2 не имеет composite atomic method; не делать два commits с одним CAS. Ограничение single-kind PATCH закрепляет C0; UI не должен скрыто превращать одно Apply в два запроса. Composite atomic PATCH не входит в этот increment, а не остаётся неучтённой дырой плана.

Локальное дополнение для доступного recovery: POST `/api/remote/servers/{profile_id}/recover`, body `{expected_revision,confirmation:{profile_id,action:"discard_uncertain_credential"}}`, ответ `{profile:ServerProfile|null}`; null только если S2 recover доказал отсутствие metadata. Это proposed **local** endpoint, не Remote wire и не cold Create recovery. Явно предупреждает об очистке uncertain key; malformed journal не удаляется. S2 guard/CAS сохраняются, startup/GET не recover-ят. Stored credential DELETE при ENV не означает «ENV удалён»: response остаётся source environment либо отказ при environment_unbound, окружение не менять. Нет positive old-token recovery, import/replay, remote user/project delete, auto enable.

Fixed typed local mapping до dispatch: validation 422; CAS/collision/in-use/not-drained/recovery-required/conflicting confirmation 409; store unavailable 503; sanitized network errors как C4. Roots могут попасть только в локальный typed conflict, никогда в outbound requests. Новые mutation responses и validation/errors no-store, token через strict SecretStr/repr-safe boundary, очищается после передачи владельцу насколько допускает Python.

**Tests:** `pytest backend/tests/test_remote_profile_mutation_api.py`: CAS plus concurrent consumer admission; in-use URL/delete, active key change denied; nonsecret journal между credential/config publication, disk faults на обеих стадиях → следующий read unusable; явный recover требует confirmation, не возвращает старый key; corrupt journal остаётся, deleted metadata recovery null; ENV override не стирается кнопкой; canary в validation/logs/repr/chains отсутствует. Без общего переаудита foundations.

### C8 — Дать durable Create стабильного application owner

**Зависимости:** C4, C5; fake transport tests не ждут R3, реальный POST — только после R3.

**write_paths:**
- `backend/voxarium_studio/sync/catalog_create_runtime.py` — новый.
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/tests/test_remote_catalog_create_runtime.py` — новый.

Owner выбирает один absolute local `user_config_dir()/remote-catalog-intents.sqlite3`, сохраняет DB/sidecars с owner-only policy; home выбран C1. Создавать journal только при первой явной Create/recovery command, не list/startup. Не repair/reset/GC reserved intents и не fallback instance mode. Failed open оставляет Create unavailable без повреждения других API.

Keep live service/providers per captured profile+URL+revision; application-global operation_id routing перед направлением в service, чтобы одинаковый operation_id под другим binding/body не потерял исходную запись. Нельзя новый `CatalogCreateService` на каждый HTTP request: это превратит живой recovery в cold. In-memory invalid-command reservations тоже не терять; registry и original binding живут до shutdown. Для upper bound admission новых операций можно отказать, **не** evict/release старые operation IDs; позитивное восстановление после restart не добавляется. Зафиксировать finite bound, например 1024 live operations/owner, с typed 503 до нового reservation.

Shutdown запрещает admission, ожидает/отменяет request tasks, ambiguous POST остаётся unknown/reserved. После нового lifespan любая durable запись без live proof → `credential_binding_unproven` **до credential/transport calls**, даже created/found/совпавшая revision/current valid Verify. Не сохранять token/hash как «решение».

**Tests:** `pytest backend/tests/test_remote_catalog_create_runtime.py`: два HTTP callers/repeated operation → максимум один POST; another profile/body → conflict до key lookup; lazy path/ACL/error ownership, stable service и live GET-only recovery; cancellation/shutdown/reopen → cold refusal и нулевые cold credential/network counters; capacity отказ не освобождает старый ID; journal loss/corruption не пустой success. Reuse VS-115/120 cases как регрессию, не повторять их массовую приёмку.

### C9 — Открыть явный Create и GET-only observation исходного ID

**Зависимости:** C0, C6, C7, C8 и R3 для выпуска реального POST; один writer api/remote.py после C7.

**write_paths:**
- `backend/voxarium_studio/api/remote.py`.
- `backend/voxarium_studio/sync/catalog_runtime.py`.
- `backend/tests/test_remote_catalog_create_api.py` — новый.

POST `…/{profile_id}/projects` строго `{id,display_name,operation_id,expected_revision}` → C8. Strict result envelope для **всех шести** `created/conflict/unknown/rejected/found/absent`: `{state,project:CatalogProject|null,error_code:string|null}` (все три поля обязательны; без selection/ownership/retry booleans). `created` →201; `conflict/unknown/rejected/found/absent` →200 по точным таблицам C0 и canonical specs. `rejected` всегда project=null, только fixed sanitized code; никаких retry/Select/освобождения operation. Отказ binding/CAS/operation_conflict — typed409, unavailable journal —503; остальные boundary exceptions сохраняют собственный typed HTTP, не становятся outcome. Это **локальное дополнение** к прежней таблице 201, не изменение Remote POST.

Для отдельного явного GET-only recovery command: POST `…/{profile_id}/projects/operations/{operation_id}/observe` с `{expected_revision}`, без ID/URL/key в body, вызывает только `recover_create`. ID берётся из исходной reservation; метод POST локально, но remote traffic только health/me + GET original ID. Не менять его на arbitrary GET другого ID и не делать implicit observation на любой list/timeout/retry. `found` и `conflict` от Remote 409 project_exists требуют отдельного Select позже, не bind; не любой 409: metadata_conflict/snapshot_changed дают rejected; `absent` не освобождает operation, новая Create — новая явная команда/operation_id.

Существующие typed ошибки дополнить точными Create codes без raw Remote message. Catalog project `storage_epoch` не runtime epoch; никаких project config/Markdown/bases/WS/selection writes ни на одном из шести outcomes или boundary failure.

**Tests:** `pytest backend/tests/test_remote_catalog_create_api.py`: strict body/operation UUID-like alphabet/extras/type, canonical ID, wire body **только id/display_name**, operation_id остаётся локально; 201 без changes project state; 409/timeout → no auto GET/POST/Select, observe отдельно exact original ID, 404 → no release; cold observe no I/O; same operation parallel request one POST, auth/no-store/canary failure, v1/capability denied no POST. Обязателен весь targeted acceptance C0: rejected/повтор/no-release и phase-sensitive server statuses 400/401/404/409/413/503 плюс invalid/unexpected responses; не ограничиваться happy path/timeout.

## 5. Серверные блокеры: открытые предпосылки, не объявление PASS

Текущие owners: [Remote create_app](../../../remote/voxarium_studio_remote/app.py#L38), [Hub.connect](../../../remote/voxarium_studio_remote/hub.py#L134), [Store.space](../../../remote/voxarium_studio_remote/store.py#L200) обслуживают v1/name/autocreate; [Remote protocol](../../../remote/voxarium_studio_remote/protocol.py#L1) и [Studio protocol](../../../backend/voxarium_studio/sync/protocol.py#L1) по-прежнему v1. Наличие client adapters и нового Admin EXE не создаёт v2 на сервере.

Это минимальные серверные deliverables из server-design S1–S3 для catalog activation; **все ещё требуют реализации/проверки**, реальные БД/deploy не выполнены VS-128.

| Gate / dependencies | Exact write_paths будущей серверной карточки | Конкретные tests / что разблокирует |
| --- | --- | --- |
| **R1 — versioned schema + explicit fixture migration**, согласованный server-design | `remote/voxarium_studio_remote/store.py`; `remote/voxarium_studio_remote/migrations.py` (новый); `remote/tests/test_store_migrations.py` (новый) | v1 fixture→v2, old UUID ID=epoch байт-в-байт, FK/content/hash/revs/seq/tombstones/empty spaces/users сохранены; rollback/integrity/repeat no-op; unknown schema fail, no implicit startup migration. Не production migration. |
| **R2 — exact catalog store**, после R1 | `remote/voxarium_studio_remote/store.py`; `remote/voxarium_studio_remote/protocol.py`; `remote/tests/test_project_catalog_store.py` (новый) | strict canonical IDs, equal labels distinct IDs, concurrent create ровно 201+409, read lookup never creates, independent new epoch, exact legacy mapping; snapshot read transaction bounded pages. |
| **R3 — v2 HTTP + strict-connect как единая release boundary**, после R2 | `remote/voxarium_studio_remote/app.py`; `remote/voxarium_studio_remote/hub.py`; `remote/voxarium_studio_remote/protocol.py`; `remote/tests/test_remote.py`; `remote/tests/test_catalog_api.py` (новый) | Bearer before existence, health/v2 me exact caps, list/get/create/snapshot/resolve/errors; unknown WS/v1 rejection/reconnect/sync/join/put/delete не создают; hello ID/epoch, unknown version terminal; snapshot continuation seq/epoch race409 без mixed page, ≤4 MiB; POST only two fields and 2KiB bound. |

Команды будущих targeted проверок — `pytest remote/tests/test_store_migrations.py`, затем `test_project_catalog_store.py`, затем `test_catalog_api.py test_remote.py` из `remote/` с путями `tests/…`. R1–R3 последовательны по shared store/protocol/app/hub; не раздавать их одновременно. При наличии созданной владельцем серверной карточки привязать C4/C9 к её **реальному** ID, не создавать дубликат по этому плану.

C1/C2/C3/C5/C6/C7 не ждут сервера. HTTP-only Verify старого сервера тоже полезен. **C4 v2 catalog/C9 реальный POST блокирует R3**, не одна новая health capability. Snapshot/legacy resolution нужны дальнейшим Preview/миграции S4–S9; проверка strict-connect обязательна до включения новой identity sync, не после первого сохранения.

Server user credential-generation enforcement из server-design §6/S4 остаётся отдельным gate для полноценного sync/security rollout: текущее rotate не гарантирует отзыв уже открытых WS. Его не объявлять готовым через catalog work и не переделывать здесь Admin/SSH/bootstrap/EXE. HTTP catalog не заменяет этот gate.

## 6. Параллельный старт и распределение файлов

**Немедленно готовы к назначению: C1 и C2 параллельно; документный C0 выполнен в VS-134.** После C1: C3 параллельно продолжающемуся C2. R1 можно отдельно начать одновременно со Studio-задачами; R2/R3 — по цепочке. VS-129 уже принят: typed frontend client готов и не ждёт C1/C2 coding, но потребление работающего backend требует C3/C4. VS-130 — независимый документ, не зависимость каталога.

После C3 можно C6, пока серверный владелец делает R1–R3. C4/C5/C6/C7/C8/C9 меняют общий `catalog_runtime.py`: выполнять **последовательно** либо заранее разделить будущие write_paths отдельной координированной карточкой; нельзя считать их независимыми только потому, что tests разные. Практический порядок: C1 → C3 → C4 (если C2 готов) → C5 → C6 → C7 → C8 → C9; при задержке R3 C4 принимает diagnostic/disabled-catalog branch, а C8/C9 готовят fake-based wiring, production POST не выпускают. По `api/remote.py` C6→C7→C9 строго последовательно.

Никаких новых задач «ещё один audit foundations/providers/status/classifier/Create journal». S4 bindings/reservation, S5 save fencing/drain, S6 client/store, S7 editor ACK, S8 UI EN/RU, S9 migration — **последующие конкретные deliverables исходного studio-design**, а не незаметные callbacks C1–C9. VS-129 покрывает только часть S6. Этот backlog конечен для global catalog API; полный проектный Create→Select→Preview→Enable остаётся зависимым от S4–S9.

## 7. Проверка будущей интеграции и выпуск

Каждая карточка из §4 сдаёт только новый targeted test module, команду/count/skips, secret/no-write/no-network counters где применимо и независимое scoped review diff. Существующие suite подключать как адресную регрессию затронутых owners, не снова принимать VS-93–127. Указанные tests/команды — **будущие**, в VS-128 не запускались.

После R3+C4+C9 отдельная integration/release карточка должна объявить exact outputs и выполнить настоящий in-process Remote interop: установленный Remote в backend env, `backend/tests/test_remote_sync.py` не skipped; v2 identity wire constants Studio меняются согласованно только вместе с S4/S5 runner/hello/cursor changes, а не C2. Проверить real HTTP byte/TLS/redirect behaviour, v1 отказ без auto-create, root A/B isolation и Create без sync effects. До S4/S5 нельзя выдавать успешный catalog test за проверку safe Enable.

Интерактивный smoke/перезапуск — отдельная реализационная проверка, только штатные `run.cmd/run.ps1`, один backend :8765, явный `.scratch/demo-project`, без остановки пользовательских jobs; парный sync — только штатный `remote_test.bat` с остановкой его процессов. Это не требование запустить их в VS-128. Production migration/deploy требует целевого окружения, проверяемого backup/rollback; общего повторного разрешения пользователь уже не должен давать.

## 8. Будущий opt-in AI не расширяет каталог скрыто

[[remote-identity/delivery-authorization]] требует запуска AI на явно открывшем доступ ПК и работы других ПК/Android с задачами/чатами. **VS-130** владеет отдельным client identity/grants/relay/idempotency контрактом; этот документ не проектирует его wire.

C1 owner и C5 admission не должны автоматически открывать доступ к Tasks/Chats, транскриптам, shell/FS, AI keys или всем roots по Remote key/catalog profile. AI default off; никакого piggyback команды в Documents/Yjs/HTTP catalog. Стабильный AI client ID и grants — не profile_id/persistent_id/runtime project_id. Наличие valid Verify/каталога не считается grant. Интеграция AI после отдельной приёмки VS-130 и соответствующих Studio/Remote/Android задач; каталог не ждёт wire-дизайна AI.

## 9. Проверка VS-128

Статически сверены актуальные владельцы после Graphify и прочитаны текущие документы/карточки; старые ограничения отделены от delivery authorization. Независимые read-only проверки composition/security и mutations/Create используются только как scoped evidence плана, не runtime readiness. Независимое scoped review основного плана и финальной delta C0/S4–S5 dependencies — PASS, блокеров нет; неблокирующие координаты source links исправлены. Все три результата subagents прочитаны через get_subagent. Статическая проверка: 21 source link, отсутствующих source paths 0, U+FFFD/conflict markers 0; diff-check заявленного документа без ошибок. Runtime/API readiness из этих проверок не следует.

В исходном VS-128 изменялся только этот документ через Studio. Реальные config/keys/data не читались, runtime imports/тесты/сеть/listeners/build/restart не выполнялись; существующий большой чужой diff не включается в результат. Ни один runtime C/R gate не объявлен реализованным.

### Коррекция VS-134 до приёмки VS-128

После Graphify повторно сверены owners: `CreateResult` [catalog.py:101](../../../backend/voxarium_studio/sync/catalog.py#L101), ветка rejected [catalog.py:418–419](../../../backend/voxarium_studio/sync/catalog.py#L418), возвращающий её [CatalogCreateService.create_project](../../../backend/voxarium_studio/sync/catalog_create_service.py#L254) и отдельный [recover_create](../../../backend/voxarium_studio/sync/catalog_create_service.py#L339); [RemoteProfiles.recover](../../../backend/voxarium_studio/sync/profiles.py#L277) и [typed local mapping](../../../backend/voxarium_studio/api/remote.py#L146). Подтверждён пропуск rejected в прежнем C9, а не дефект принятого Create owner. Исправлены C0/C9 и перенесены узкие C0 additions в [[remote-identity/studio-design]] §5.1 / dev spec §5.2.1; Remote/server wire/statuses не изменены. Статическая проверка VS-134: идентичные нормативные блоки трёх документов, 11 global routes и все шесть outcomes в каждом, 13 добавленных локальных cross-links разрешаются; fences парны, конфликтных маркеров/U+FFFD и новых trailing whitespace нет. `git diff --check` dev spec и `git diff --no-index --check` shared docs относительно task baseline — без ошибок (exit 1 no-index означает наличие diff, не ошибку whitespace); все прежние строки dev spec, включая чужой diff, сохранены в исходном порядке. Независимое scoped review исправленного VS-128/C0/spec consistency — **PASS**; отдельная финальная delta-проверка ссылок §6 и metadata GET/catalog preflight — **PASS**, оба результата прочитаны через get_subagent. Менялись только три объявленных документа; runtime/tests/build/listeners, code/config/data edits не выполнялись. Это не пересмотр прошлых PASS и не API/runtime readiness; C1–C9 runtime и R1–R3 остаются будущими работами.
