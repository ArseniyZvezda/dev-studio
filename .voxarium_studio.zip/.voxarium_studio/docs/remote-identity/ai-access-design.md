# Opt-in AI-доступ к ПК через Remote

## 1. Решение и статус

VS-130, 16.11.2026. **Контракт будущей реализации, не работающая функция.** Основание — [[remote-identity/delivery-authorization]], [[remote-identity/studio-design]], [[remote-identity/server-design]], [[remote-identity/android-design]]. ПК явно публикует выбранные задачи/чаты выбранным пользователям и устройствам; другой ПК или Android читает состояние, пишет сообщения и запускает новую работу **на выбранном ПК**. Remote аутентифицирует, проверяет grants и ретранслирует; AI SDK/CLI, инструменты, файлы, расходы и ключи остаются на исполнителе.

Выбран отдельный **AI Control Protocol 1 (ACP/1)**: outbound WSS executor → Remote и requester → Remote; браузер requester общается только со своим Studio backend. Никакого проброса HTTP URL, shell, FS, MCP или всего локального API. Documents sync/Yjs не транспорт команд, task/chat DB не реплицируется. Принято безопасное ограничение первого выпуска: обычные агентские чаты, task draft/start/note/cancel и чтение; Producer, ревью, VCS, attachments, context inspection — вне ACP/1. Это не отказ от цели, а явная первая поверхность с дальнейшим расширением по версии.

**До интеграции обязательна поправка dev spec (§12).** Documents-only граница/отсутствие task sync не считаются молча отменёнными разрешением пользователя. В VS-130 изменён только этот документ; code/config/data edits, AI вызовов, запуска приложений, сборок или deploy нет.

## 2. Проверенные существующие владельцы

Graphify query выполнен перед поиском, затем прочитаны актуальные исходники; индекс даёт навигацию, не доказательство установленного runtime. Shared checkout уже содержит сторонние staged/unstaged изменения и новые identity/catalog компоненты: их наличие не доказывает подключение к API. Номера строк ниже — ориентиры снимка 16.11.2026, символы важнее номеров.

| Область | Наблюдаемое поведение и следствие |
| --- | --- |
| Task API | `backend/voxarium_studio/api/teams.py:63–188,826–929,982–1194,1261–1307`: create/list/detail/edit/start/note/review/cancel; detail возвращает весь transcript и model_dump. `actor_id/created_by=None` означает локального пользователя, не сетевую identity. Некоторые lifecycle handlers передают только task_id: ACP обязан сам проверять team/export/resource, не доверять URL или этим wrappers. |
| Task execution | `teams/orchestrator.py:553–628,637–839,841–925,1299–1549`: null actor обходит иерархию; team autostart может выпустить созданную карточку через `_autostart_todo`, PATCH status может запустить её. Start — только pending, dependencies/Solo/slots/holds проверяются локально. Следовательно нельзя ретранслировать существующие POST/PATCH как есть или считать draft create заведомо небиллингующим. |
| Chat API/runtime | `api/chats.py:26–62,99–208`, `teams/chat.py:298–322,383–454,480–575`: create не запускает ход, send запускает либо ставит сообщение в inbox работающего чата. ACP/1 запрещает очередь сообщений в busy chat и не принимает attachments/context.file; нужен отдельный service admission, не wrapper над send. |
| Identity sessions | `core/workspace.py:58–90`, `core/project_scope.py:18–53`, `api/deps.py:11–29`, `teams/backends/base.py:183–205,504–535`: root → resident Ctx/runtime project_id+epoch; сессия — canonical managed root+kind+owner ID+generation. Provider agent_session_id — не субъект и не адрес назначения. |
| Данные и события | `models/teams.py:230–548`: task/chat/message в локальном app.db, нет Remote-user ownership. `ws/bus.py:24–97,101–204`: ограниченная RAM история, overflow/gap требуют resync. Сырые события/AgentMessage.data не годятся для сетевого экспорта. |
| Local security | `core/security.py:39–69,109–156`, `api/__init__.py:34–80`: shared local token + Host/Origin, scoped routes рядом с legacy selection; это не multi-user ACL. ACP не выдаёт этот token и не использует None actor как сетевой superuser. |
| Existing Remote Control | `api/teams.py:1267–1307`, `teams/backends/base.py:453–474`: provider-specific handoff/link (Claude), **не** Studio Remote relay. session/connect URLs и environment ID не экспортируются. |
| Persistence | `core/db.py:146–173`: SQLite WAL+synchronous NORMAL сегодня, не power-loss durability обещание. Нужны транзакционный command ledger и отдельная проверка durability для запуска (§7), а не только RAM JobEngine. |
| Identity/catalog заготовки | `core/project_identity.py:1–38` уже описывает portable identity, `sync/protocol.py:17` ещё PROTOCOL_VERSION=1. `api/remote.py:create_remote_router` — factory; чтение `api/__init__.py`/`main.py` не подтверждает mount этого factory. ACP capability не выводится из файлов/версии пакета. |

### 2.1 Remote и Android — независимая сверка

Remote сейчас v1: `remote/voxarium_studio_remote/protocol.py:20`, `app.py:74–110` (health/me/sync), `hub.py:134–147`/`store.py:200–211` (sync connect создаёт space по имени). Нельзя проверять control capability открытием sync. `auth.py:34–73,94–105` даёт UUID principal, hash-only ключи и header-only Bearer; это reuse authentication interface, не готовые grants. `app.py:141–159` не проверяет credential перед каждым read/write; watcher смотрит active user раз в 30 s, `store.py:167–196` при rotate меняет hash, но active остаётся true. Следовательно текущий socket может пережить rotation: ACP обязан проверять актуальный credential fingerprint/generation, не только is_active. `hub.py:45–72` ограничивает очередь числом кадров, не байтами; эти лимиты нельзя переиспользовать как ACP bounds.

Android исследован read-only (в Studio graph его нет): `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/security/ProfileStore.kt:9–30` пока объединяет URL+spaceName+credentialId; `data/transport/RemoteEndpoint.kt:9–39` — v1 me/sync и нормализация space; `RemoteConnection.kt:159–200` после me подключает Document WS. Это не server-only ACP transport. Reuse паттерны generation fencing и no redirects (`RemoteConnection.kt:90–132,357–360`), `data/security/CredentialStore.kt:33–55` (AES/GCM Android Keystore, без hardware guarantee), native UI. `ui/editor/bridge/SecureEditorView.kt:78–101,125–135` оставляет WebView local-assets-only, никакого AI bridge.

Новые Android main/test/resources меняют acceptance fingerprint `app/build.gradle.kts:12–37`, даже если editor не редактируется. Нужна новая независимая final-source editor/APK acceptance перед enabled artifact; исторический report и Gradle gate не обходятся. Server-only profiles/catalog из identity designs — явные prerequisites, не уже подключённая возможность.

## 3. Идентичности и хранение

| Поле | Точный смысл |
| --- | --- |
| `server_instance_id` | Новый несекретный UUID серверной control registry; меняется при её reset/замене. Вместе с exact normalized URL (включая prefix) разделяет registrations/grants. Не подменяет Documents storage_epoch. |
| `user_id` | Неизменяемый ID Remote principal из authenticator; display name/color — только подписи. Rename/rotation ключа не меняет user_id, delete+recreate не наследует grants. |
| `client_id` | Случайный UUIDv4 установки Studio **или** Android, локально создаваемый только явным Register. Стабилен через reconnect/backend restart, не hostname, IP, profile ID, task ID или ID проекта. Не секрет и сам ничего не разрешает. |
| `registration_id` | Выданный Remote UUID регистрации (server_instance_id,user_id,client_id). PC/Android доказывает её отдельным device secret. Один client_id допустим на разных серверах, регистрации/секреты независимы. |
| `persistent_id` | Portable project identity = Remote catalog space; canonical ASCII правило из identity designs. Не исполнителя выбирает, не runtime binding. |
| `export_id` | Локальный UUID опубликованной **рабочей копии**: private mapping exact root → target registration+URL+persistent_id+catalog storage_epoch+identity revision. Не переносится вместе с папкой. |
| `export_revision` | Fence mapping/export policy; изменения отдельного grant используют grant.revision и не меняют export_revision. При rebind, смене ID/URL/account/epoch/root или restore несогласованного состояния экспорт выключается; новая публикация/consent, старые команды не переадресуются. |
| `executor_epoch` | Случайное поколение работающего control service на ПК, меняется после restart/takeover. Не client_id и не project identity. Все новые mutations привязаны к текущему значению. |
| `runtime project_id/epoch` | Только локальный descriptor Ctx; не wire target ACP. Выбирается один раз из private export mapping без legacy selection fallback/auto-open. |
| `resource_id/run_id` | Opaque task/chat ID + локально созданный ACP run token, namespaced exporter/export. Display ID вроде VS-130 и provider session ID не используются для routing. |

Полный сетевой target: `(server_instance_id, executor_registration_id, export_id, persistent_id, storage_epoch, export_revision)`; mutation дополнительно требует `executor_epoch`. Requester хранит target при открытии экрана, не перечитывает active selection перед отправкой. Два ПК с одним persistent_id — два исполнителя; копия папки на том же ПК без явной публикации недоступна. В ACP/1 одна active публикация на (executor registration, persistent_id) для разных roots: второй root получает duplicate_export, не merge. Root, hostname, IP, пользователь ОС и provider handles не нужны Remote.

На ПК private `user_config_dir()/ai-access.db`: client registration metadata, export mappings, grants, локальный consent/revisions, audit metadata; device secret отдельно в личном secret store с exact URL+server_instance_id+user_id+registration_id. Никакого enabled/grants/secret в переносимом project config. Таблицы command ledger и provenance task/chat/message — в project app.db (§7), но без credentials; копирование app.db не активирует экспорт, ключ ledger включает регистрацию+export_id.

Remote хранит отдельные control registrations, SHA-256 случайных 256-bit device secrets, grant mirrors и audit metadata, **не** transcripts/prompts/команды для offline исполнения. Это новые таблицы/миграция, не Documents docs/events/rooms. Android сохраняет client metadata/device secret средствами существующего native Keystore-backed storage, не WebView/JS. На Studio личный файл secret store owner-only ACL + atomic replacement — **не шифрование диска**. Потеря/повреждение credentials/grants не чинится defaults: disabled, явная новая регистрация.

Копирование целиком private Studio home/Android backup с секретом клонирует authority — от этого один client_id не защищает. Backup должен исключать device secret/активный consent; при известном клонировании revoke registration, новый client_id и явные grants. ACP/1 не обещает hardware attestation. Remote допускает один live executor socket на регистрацию: второй получает conflict, не вытесняет первый; takeover требует закрытия/expiry lease.

## 4. Opt-in, grants, ownership

По умолчанию выключены и глобальная публикация ПК, и каждый export; отсутствие capability/grant = deny. Document sync enabled, valid Remote key, один аккаунт или общий space **не дают AI-доступа**. AI publication может работать при Documents sync disabled, но только после explicit подтверждения каталожного ID/epoch и local export; ничего не создаёт через sync/connect.

Локальный пользователь на executor в Settings → Remote AI:
1. Register device на выбранном server profile, показывает full client_id/user_id/URL; отдельное включение publication.
2. В Project Settings выбирает resident рабочую копию и подтверждённый catalog ID/epoch, нажимает Publish. Никакого открытия произвольного пути удалённым клиентом.
3. Выбирает конкретные Remote `user_id + requester_registration_id` из authenticated directory; никаких wildcard/all-users/автопереноса на будущие устройства.
4. Выбирает teams и agent member allowlist, operations, resource scope, срок (максимум 30 дней, default 24 часа) и риски/лимиты исполнения. UI явно показывает фактический backend/permission mode/MCP: обычный агент может иметь shell и bypassPermissions; ACP не делает его песочницей.
5. Save grant: атомарный локальный consent/revision → publish mirror → ACK Remote → effective. Любая ошибка оставляет доступ disabled/pending, не расширенный fallback.

Grant: `grant_id, revision, target tuple, grantee_user_id, grantee_registration_id, operations[], team_ids[], member_ids[], resource_scope, execution_policy_digest, issued_at, expires_at, revoked_at`. execution_policy_digest фиксирует выбранные backend/model, permission mode, tools/MCP policy, max_turns и local limits; перед каждым dispatch сравнивается с текущей policy. Изменение policy не расширяет grant автоматически: run permissions suspended до локального нового consent. Grant update увеличивает только grant.revision; изменение mapping/export policy увеличивает export_revision, выключает export и делает все старые grants неэффективными до явной перепубликации с новым target. Scope по умолчанию `created_by_this_grantee` (provenance пары user+registration); отдельный explicit `selected_resources` с exact task/chat IDs либо предупреждённый `all_resources_in_selected_teams` включает локально созданные/исторические объекты. Viewer ПК/Android видит деятельность исполнителя только по такому согласию; это не копирование карточек в свою локальную доску.

Чтение status/list и чтение transcript — разные permissions; mutation требует также status visibility. `operate_existing` нужно **дополнительно** к каждой mutation для объекта, не созданного этим grantee. Право создать объект не даёт прав на существующие или на другие устройства того же пользователя. У grant нет наследования по имени/цвету/проектному ID.

Remote identity не является TeamMember. Новая типизированная `RemoteActor(user_id,registration_id,grant_id,revision,command_id)` проходит service admission, без клиентских actor_id/created_by и без подстановки None. Capability означает явно делегированную локальным владельцем operator-операцию **только** в выбранном team/member/resource scope, не роль директора всей команды. RemoteActor разрешается как новый service principal, не сериализуется в старое поле actor_id; внутренний адаптер не вправе превращать его в неограниченный локальный вызов. Существующие MCP org-chart rules агентов остаются: удалённый запрос не получает право менять roster, роли, grants или permission_mode. Авторство, assignee, manager, создатель карточки и физический executor — разные поля; task/chat не становятся собственностью Remote.

Для новых объектов/введённых сообщений сохраняется immutable remote_origin, а каждая mutation — last_actor/audit receipt: principal, device, grant revision, command/run IDs, время и исход. Нельзя представиться локальным человеком/агентом. PC UI помечает запуск/сообщение как remote и показывает requester; локальный владелец всегда может остановить свою работу/отозвать grants. Ownership метаданные не расширяют видимость.

## 5. Разрешённые операции ACP/1

Все body schemas strict, unknown поля запрещены. UUID/IDs проверяются до lookup; каждый resource проверяется в pinned Ctx, team_id и grant scope. Ответы — отдельные allowlisted DTO, **не** model_dump/проксирование REST.

| Operation | Permission и семантика |
| --- | --- |
| `catalog.list`, `resource.list/get` | `view_status`: только разрешённые exporters/exports/teams/resources, title, assignee safe label, status, is_running/waiting/error-code, run_id, timestamps, result_type, usage (cost_estimated/unavailable явно). Без brief/summary/prompt/error text/roster config: brief и summary доступны только как content через view_transcript; title тоже проходит redaction и consent на status-видимость. Неавторизованный объект — generic not_available без existence oracle. |
| `transcript.page`, `stream.subscribe/unsubscribe` с topic=transcript | `view_transcript` (+view_status); projected messages/status только выбранного resource. Пагинация и cursor/gaps §8. topic=status требует только view_status, не содержит content. |
| `task.create` | `create_task`: team, allowed assignee, title, brief, relative write_paths, locale. Результат **todo + auto_start=false + no remote release**, даже при team Autostart. Без Producer/Effort Solver, dependency graph, attachments, model/backend overrides. Нужна новая suppression admission path; недостаточно передать auto_start=false старому create_task. task.created/status events remote draft не запускают AutomationEngine pipeline/plugin actions: до explicit local adoption/разрешённого Start такие события только для UI/audit, без отложенного replay automation. Это отдельная нормативная разница от локального Create. |
| `task.edit_draft` | `edit_task`: только title/brief/write_paths в idle todo с expected_resource_revision; не status/assignee/model/dependencies. После старта — note, не переписывание исполняемого брифа. |
| `task.start` | `run_task`: expected revision, существующий idle todo или pending без ожидания зависимостей/Solo; todo → pending через явное разрешённое release → start. Один run token, без auto_start/resume_on_limit/remote persistent queue. До acceptance атомарно try-reserve доступный job/agent slot и write locks; если job/slot/lock не готовы — busy/conflict без message/run mutation, не автоматический запуск позже. Все local dependencies/write locks/limits сохраняются. |
| `task.note` | `write_task`: текст в transcript; idle — прочтётся только при отдельном Start, running — как локальная note на следующей границе инструмента. Запись note не запускает отдельный ход. Поступившая и принятая running-note становится частью текущего уже разрешённого выполнения; revoke не вынимает уже доставленный текст. |
| `task.cancel` | `cancel_task`: только expected_run_id, best effort локальная cancellation; ответ requesting_cancel не равен terminated. Не переводит вручную в done и не удаляет результаты. |
| `chat.create` | `create_chat`: allowed agent member, title, locale; обычный idle chat, producer_mode=false, AI не вызывается. |
| `chat.send` | `run_chat`: text + expected revision, только idle обычный chat; одна запись и один turn token. Busy → conflict **до** сохранения/очереди. Context только серверно сформированная пометка Remote origin; user-supplied route/file/document/selection/attachments запрещены. |
| `chat.cancel` | `cancel_chat`: expected_run_id, best effort, не удалить чат. |
| `command.get` | Read receipt своего command_id при ещё действующем scope; не повторная команда, не выдача чужих запросов. |

Производные права не подразумеваются: run_task не даёт create_task, transcript или cancel; UI прячет/disable действия по capability, но backend всё перепроверяет. Terminal/needs_review task не запускается повторно через ACP/1. Для новой работы создаётся новый draft; если локальный владелец явно вернул существующую задачу в pending, последующий remote Start требует новый command_id и current revision. Это не reconnect replay и не разрешение удалённого reset/review. Новая карточка и запуск — две команды: если create succeeded, start failed, показывается draft, не второй create.

**Запрещено:** произвольный method/URL/body routing, /fs, shell/PTY, raw файлы/patch/download/preview, uploads, tools/MCP calls, provider Remote Control URLs, context journals/fragments/inspect, секреты/config/env, roster/profile/permission edits, reset/delete/compress, произвольный PATCH status, start-all, approve/request-changes/claim/complete и Producer automation. Нельзя исполнять на Remote или мигрировать туда provider session. Расширение операций — отдельный контракт и review.

write_paths — декларация координации, не FS API/песочница: ACP принимает только safe relative paths под выбранным managed root, без drive/UNC/../symlink escape; пустой список явно предупреждён. Локальный grant подтверждает доверие prompt-driven AI с реальными правами выбранного агента. Пользовательский текст может просить shell — это агентское исполнение в рамках локальной policy, а не техническая гарантия отсутствия shell; грант запуска нельзя выдавать недоверенным людям как безопасный read-only доступ.

## 6. Конкретный транспорт, authentication и routing

Новый namespace `/api/ai/v1`, wire `acp=1`. **Единственный источник discovery ACP — отдельный GET `/api/ai/v1/capabilities`**, не health и не me. `/healthz`, `/api/v1/me` и `/api/v2/me` сохраняют существующие DTO без AI-полей; Documents PROTOCOL_VERSION не меняется. Не отправлять ACP кадры в /api/v1|v2/sync, room ID или Markdown.

Причина разделения проверена по owning source: `sync/catalog.py:274–309` (`CatalogClient.verify`) отвергает health extra fields и требует exact v2 me envelope через `_object:138–141`; `sync/catalog_verification.py:163–168` требует exact v1 health, `_legacy_user:124–143` — exact v1 me. Добавление `ai_control` в эти ответы сломает Verify/catalog ещё до работы с AI. Их validators не ослабляются ради ACP.

Discovery выполняется native Studio backend/Android **до explicit Register**, только с personal `Authorization: Bearer <Remote key>`, без `X-VXS-Client-ID`/`X-VXS-Device-Token` и без создания client_id, registration, export, grants или подключения socket. Это read-only проверка отдельной AI-доступности, не замена и не prerequisite Documents Verify/catalog/Create. Запрос и ответ используют `Cache-Control: no-store`; результат не хранится в persistent cache и не считается consent или разрешением операции. Точные normalized profile URL + prefix, проверка TLS cert/hostname и запрет redirects действуют и здесь: нельзя пробовать другой origin/prefix, cleartext endpoint или guessed version.

При реально mounted ACP routes/auth/relay Remote отвечает HTTP 200 со strict JSON `{acp:1,server_instance_id:UUID,ai_control:{versions:[1]}}`: ровно указанные поля на обоих уровнях, acp и элемент versions — integer (не boolean), server_instance_id — UUID; никаких extra/duplicate keys. Наличие файлов, package version или будущего factory не является mount. Если ACP выключен/не mounted, endpoint даёт 404, не положительный capability DTO. Полученный server_instance_id привязывается к выбранному profile; последующие registration/control должны совпасть с ним, mismatch требует новой проверки/consent по существующим identity fences.

Typed outcomes discovery: 404 → `unsupported`; корректный version envelope без совместимого ACP/1 → `unsupported`; 401 → `auth_failure`, не «старый сервер». Network/timeout/TLS → `unavailable` с safe typed code; malformed JSON/UUID/fields/types (включая extra поля) → `error:invalid_response`; redirect → `error:redirect_refused`, прочий HTTP → `error:remote_error`. Для несовместимой версии сначала валидируется структура envelope (acp integer, versions непустой массив уникальных integers), а для совместимого ACP/1 требуется exact DTO выше. Ни один отрицательный исход не вызывает fallback, auto Register, sync/connect, control socket или исполнение; существующий Documents verification/catalog state не переопределяется результатом AI discovery.

Все ACP remote endpoints (включая capabilities): HTTPS/WSS с проверкой cert/hostname (или явно настроенный loopback TLS/SSH tunnel). Только exact normalized profile URL+prefix, redirects запрещены, no CORS/browser direct, no query/body/cookie token. Секреты не попадают в URL. Ответ с device_token Remote получает только native Studio backend/Android credential handler; локальный browser API возвращает has_device_token и metadata, никогда этот token. Native backend/Android ставит заголовки:
- `Authorization: Bearer <personal Remote key>`;
- для device-authenticated endpoints зарегистрированного устройства (не capabilities/Register) `X-VXS-Client-ID`, `X-VXS-Device-Token: <random device secret>`.
На device-authenticated endpoints Remote сопоставляет оба credentials с одним active user/registration; клиентские actor/source user в JSON запрещены.

| Endpoint | Контракт |
| --- | --- |
| GET `/api/ai/v1/capabilities` | Read-only до Register, personal Bearer без device auth; request/response no-store, strict DTO и typed outcomes выше. HTTP 200 только при реально mounted ACP, иначе 404; без health/me extras и побочных эффектов. |
| POST `/api/ai/v1/registrations` | Только personal key + strict {client_id, display_name, kind:studio/android}; explicit Register. Ответ 201 {server_instance_id,registration_id,client_id,user_id,device_token}. Секрет один раз, только сюда. Повтор возвращает 409 registration_exists и только registration_id записи **того же authenticated user+client_id**, не возвращает/не заменяет старый token. Lost response → explicit cleanup собственной orphan registration через DELETE и новая регистрация с новым registration_id/token, без наследования grants; стабильный client_id установки сохраняется. Ни автоматической ротации credential, ни восстановления чужого секрета по ID. |
| GET `/api/ai/v1/registrations` | Device-authenticated directory: user_id/registration_id/client_id/display_name/kind, без roots/exports/credentials; выбираемые exact устройства для локального consent. Active key уже командно доверенный по модели Remote; directory не даёт прав на AI. |
| DELETE `/api/ai/v1/registrations/{id}` | Только сам пользователь для собственной регистрации (+ personal key); немедленный deny/close и revoke всех её grant mirrors. Админские операции остаются SSH. |
| WS `/api/ai/v1/control` | Dual-auth, strict empty query. Один duplex control socket на executor registration, requester mode может совмещаться в нём; Android только requester. hello {acp,server_instance_id,connection_id,lease_seconds:15,heartbeat_seconds:5}. |
| Socket `executor.attach` | Studio предъявляет executor_epoch и manifest {export_id,revision,hash} (≤16), не полный snapshot grants. Remote подтверждает epoch/lease и mirror_status; reconnect attach ничего не воскрешает и не расширяет. Отсутствующие/mismatched mirrors остаются unavailable до explicit publish/CAS. |
| Socket `directory.list` | Возвращает только targets, видимые requester по live grant; states online/offline/unavailable. Нет browsing all PCs/exported projects по одному key. |
| Socket `request` | request_id, target, expected_executor_epoch, grant_id/revision, op, command_id (mutation), issued_at (mutation), expected_resource_revision/run_id, payload. Server выводит actor из authenticated socket, проверяет current DB grants/expiry/user/device/op/scope/online lease, маршрутизирует только exact target connection. |
| Socket `forward` | Server добавляет authenticated actor+source registration, connection_id, current grant revision/deadline. PC повторно сверяет private consent, exact mapping/catalog epoch, current epoch/revisions/expiry, resource ownership, operation schema, limits, expected revisions/run, затем допускает эффект. Server claims доверяются только на аутентифицированном WSS данного server profile. |
| Socket `response/event` | Только с pinned executor connection, match request_id/command_id/target; server снова фильтрует current grantee/scope при доставке. Requester не может отправить executor response/event для чужого ID. |

**Lifecycle export/grant mirror wire.** Из authenticated executor socket, роль studio, server выводит executor_registration_id сам и проверяет владельца каждого export; другой Studio credential не может писать в чужой namespace даже с известным export_id.
- `export.publish {export_id,persistent_id,storage_epoch,revision,expected_revision,policy_digest,display_name,hash}`: новый export только expected_revision=0/revision=1; update только next revision=current+1 с exact CAS. Server binding включает server_instance_id и authenticated executor. ACK: {export_id,revision,hash,state}.
- `grant.put {export_id,export_revision,grant_id,expected_revision,revision,grant,hash}`, `grant.revoke {export_id,export_revision,grant_id,expected_revision,revision,hash}`: полный strict grant из §4 либо revoke tombstone без content, next revision=current+1; ACK повторяет IDs/revisions/hash/state.
- `export.unpublish {export_id,expected_revision,revision,hash}` сохраняет disabled tombstone и гасит grants/subscriptions; повторная публикация этого же mapping только с большей revision и новым explicit consent. Удалённый export_id с terminal deleted tombstone не переиспользуется.
- Хеш — SHA-256 canonical JSON semantic record без hash/transport fields. Equal revision+equal hash → тот же ACK; equal revision+different hash → conflict; lower revision → stale, без изменения. При lost ACK локальный grant/export остаётся pending, отправляет идентичный record или получает `mirror.get {export_id,grant_id?}` с revision/hash/state и сверяет matching ACK. Не включает по одному connect success.
- Revoke/unpublish tombstones не удаляются на reconnect/full attach; stale snapshot не возвращает доступ. Удаление регистрации tombstones только вместе с terminal registry reset, после которого новый server_instance_id требует нового consent.
- Расширение применимо на ПК только после matching ACK. Сужение/revoke сначала атомарно локально (deny), затем mirror; CAS conflict/timeout не возвращает прежние права. Grant revision независима от других grants; export revision change гасит все их старые target bindings.
- `heartbeat.ping {nonce,executor_epoch}` каждые 5 s, `heartbeat.pong {nonce,executor_epoch,lease_seconds:15}` только после актуальной auth/attachment проверки. На ПК lease deadline = monotonic **времени отправки** ping +15 s, не получения pong; pending nonce один, устаревший/повторный pong не продлевает lease. На Remote deadline по monotonic последнего валидного ping. Disconnect/expiry блокируют dispatch/stream независимо от wall clock.

ПК передаёт отдельный `resource.index` (bounded pages ≤50) только с resource_id/kind/team_id/member_id/remote_origin/revision, без title/brief/text; server проверяет resource→grant scope по этому минимальному индексу. Новый resource сначала фиксируется на ПК, затем index ACK, и лишь затем становится доступен read/control; при missing/stale index server fail closed, ПК тоже проверяет DB. Index не task sync: не история/состояние карточки для offline работы, только metadata авторизации; после reconnect rebuild от ПК. `resource.index.begin {export_id,export_revision,index_revision,row_count,hash}` → `resource.index.page {index_revision,page_no,rows}` → `resource.index.commit {index_revision,hash}`; staging bounded, сервер атомарно заменяет index только после exact count/hash/ACK, до этого mutations/read на несогласованный resource denied. Удаление resource — новый index без него; события только после ACK текущего resource revision. List фильтруется по index+grant на сервере и заново по DB на ПК, unsolicited events без текущей подписки запрещены. Origin для created_by_this_grantee берётся только из PC-provenance, не из requester JSON.

**Внешняя форма кадра:** `{acp:1,type,request_id,body}`, type из allowlist выше, request_id UUID; response: `{acp:1,type:"response",request_id,body:{target,command_id?,state,code?,retry_after?,result?}}`. event содержит subscription_id, target, resource_id, stream_epoch, seq, resource_revision и projected payload. Все перечисленные metadata — строгие типы, resource revision целое ≥1; run_id UUID. Минимальные command states: rejected/accepted/dispatching/running/completed/failed/cancelled/denied_before_dispatch/outcome_unknown. Receipt завершения команды create не равен завершению её AI resource.

Application close codes: 4400 protocol_error, 4401 unauthorised (key/device), 4403 permission_revoked, 4409 executor_conflict, 4429 overloaded; per-request enum: not_available, denied, stale_target, revision_conflict, idempotency_conflict, busy, expired, rate_limited, outcome_unknown, resync_required, snapshot_changed, unsupported. Ошибка одной валидной команды не закрывает остальные подписки, кроме потери auth/lease. Никаких retries mutation по close code.

Сервер проверяет актуальность personal key/device/grant **на каждом request, response и выдаче stream batch**, не только при upgrade, периодически закрывает idle/revoked sockets (5 s); existing Documents 30 s check не достаточен для ACP. Peer messages не broadcast всем в space. Revoke/expiry сбрасывает buffers/subscriptions, поздние ответы не выдаются. JSON duplicate keys, unknown enum/field, duplicate headers/query, binary frames и неправильная role — protocol_error/close; UTF-8 only. Ошибки safe enum + correlation ID, без исключения/пути/токена.

PC повторная проверка не является защитой от злонамеренного/взломанного Remote, который может подделать user assertions внутри уже разрешённого grant. **Remote и его TLS termination — доверенный auth/relay**, нет E2E encryption/signatures. Для неподконтрольного сервера такой запуск не включать; полноценное end-to-end device signing/pairing — отдельная версия, не скрытое обещание ACP/1.

## 7. Idempotency и crash/reconnect

Requester создаёт UUID command_id **до первой отправки** и сохраняет pending intent+hash в private локальном store (Studio/Android). Сетевой timeout/disconnect означает outcome_unknown; UI не генерирует новый ID и не повторяет Start/Send автоматически. Reconnect сначала command.get, затем resend **того же** ID/побайтно того же canonical semantic payload только по recovery UI. Source reconnect не создаёт execution. `issued_at`, `expires_at`, `revoked_at` и wire timestamps — целые Unix UTC milliseconds (signed int64, не float/ISO locale). Grant истёк при now >= expires_at на любой стороне; допустимый skew не продлевает grant ни на миллисекунду.

PC — авторитетный durable ledger с unique key `(server_instance_id, executor_registration_id, export_id, source_registration_id, command_id)`, principal, grant revision, SHA-256 canonical payload/target/op/preconditions, resource/message/run IDs, state/outcome/timestamps. JSON canonicalization: sorted object keys, integer-only numeric metadata, UTF-8, no whitespace, no normalization текстов; transport request_id/connection_id не входят в hash. Hash включает op, target, source identity, grant_id+revision, issued_at, executor_epoch и все resource/run preconditions, но не transport request_id/connection_id. Другой body/target/precondition с тем же key → idempotency_conflict. Дубликат после revoke сначала получает denied, не старый sensitive response.

Срок подачи новой mutation — не более 60 s от issued_at при допустимом clock skew 30 s (issued_at > now+30 s отклоняется; для возраста команды upper bound 60 s без добавления skew); PC проверяет wall-clock и монотонный deadline в текущем процессе. Повтор уже зарегистрированного command_id может читать receipt после этого срока, но не менять payload. Новые IDs со старым timestamp не запускаются. При недостоверном времени/скачке назад — execution disabled до локальной проверки времени, не продление grant. Сжатые dedupe tombstones с hash+IDs сохраняются всё время существования export; safe results до 30 дней, text payload не хранить вторично после commit. При disk-full нельзя удалить tombstones и продолжить приём: deny, локальная maintenance с новым export/consent. Export ID никогда не переиспользуется после удаления.

Порядок:
0. **Порядок duplicate/epoch:** authenticate и current grant/scope/exact immutable export target проверяются всегда. Затем lookup command ledger: известный ID+тот же hash возвращает receipt даже после смены executor_epoch, без запуска; command.get использует текущую сессию/действующий grant и ID исходной операции, не требует старой executor_epoch. Только для ещё неизвестного ID проверяются current executor_epoch, 60 s deadline и CAS до admission. Это позволяет восстановить lost ACK после restart, не признать stale command новым. Изменение payload/старого expected_epoch у повтора ради «обновления» даёт hash conflict; надо command.get, не новый Start.
1. До acceptance: server + PC auth, target generation, grant, schema, local policy и CAS. Сериализация по resource + admission lock export; revoke использует тот же lock. Все await чтения/подготовки заканчиваются **повторной** проверкой непосредственно перед commit/submit.
Resource revision — durable integer sidecar на ПК, увеличивается при **каждом локальном и remote** edit/note/send/start/cancel/status/assignee change и Producer conversion, не только ACP запросах. Перед effect и dispatch под resource lock перепроверяется фактический team/member, обычный idle chat (не Producer), grants/policy_digest, revision/run token; source данных — DB/Ctx, не mirror. Внешний/неподдержанный writer, нарушающий revision tracking, переводит projection/export в resync/disabled, не выдаёт stale CAS.
2. Для create/edit/note: ledger outcome, provenance и object/message mutation коммитятся **одной транзакцией project app.db**, события публикуются после commit. Отдельные ledger write → старый HTTP handler запрещены: crash в таком зазоре дублирует действие. Draft suppression действует и для автоматических watchers.
3. Для task.start/chat.send: атомарно резервируются ledger+run token, состояние/входное сообщение, затем durable `dispatching` marker **до** запуска CLI/SDK. Один token допускает максимум один dispatch; JobEngine/runner получает этот token и уже зарезервированный nonblocking slot; проверяет fence прямо перед внешним исполнением. Подготовка после reservation ограничена 10 s; timeout/cancel освобождает reservation и завершает команду без возможности позднего dispatch. Ожидания очереди slot в ACP/1 нет. Не запускаем новый процесс под тем же token после crash.
4. ACK `accepted` значит локальный commit, не успех AI. `running`, `completed/failed/cancelled` отдельны от delivery state. Зарезервированный job в короткой подготовке, ещё не дошедший до dispatch, при lease/grant loss отменяется с denied_before_dispatch; remote-origin auto-start/usage-limit resumes после restart/пропажи доступа запрещены. Уже начатый job продолжает локальную lifecycle/внутренние шаги до terminal или явного cancel.
5. Если процесс упал после dispatching, но до внешнего start/receipt, восстановление даёт `outcome_unknown` + существующие resource/run IDs; **никогда** автоматически не запускает повторно. Локальный владелец сверяет session/job/transcript и вручную завершает recovery; новый remote command не обходит lock unresolved run. Возможна потеря запуска, не повторный запуск.
6. Duplicate delivery с тем же ID возвращает тот же receipt/state, не вызывает service повторно. Утраченный response после commit восстанавливается по ledger. No exactly-once внешний side effect: обещается dedupe/at-most-once dispatch, unknown исход сохраняется честно.

Current SQLite synchronous NORMAL не достаточен для power loss. Для ACP mutation transactions будущая реализация обязана использовать проверенный FULL durability до dispatch (включая соединение, которое пишет message/ledger), atomic commit и fixture fault injection. Если durable commit не подтверждён — никакого dispatch. Ledger corruption/restore/обнаруженное расхождение с private registry закрывает export до recovery; резервная копия app.db+ai-access.db восстанавливается только с export disabled, новым executor_epoch и локальным reconcile. Не обещается распознавание всех скрытых rollback файлов/сбойного диска или защита от администратора ОС, стирающего ledger.

Remote не держит offline command queue и не является источником истины по result. Сбой Remote теряет in-flight delivery/stream; восстановление requester идёт к ПК за receipt/snapshot. PC offline → offline/unavailable, запуск на другом ПК не выбирается автоматически. Тексты drafts могут оставаться локально у requester с предупреждением; их отправка после reconnect — отдельная явная команда в актуальный target, не background replay.

## 8. Status, transcripts и flow limits

Availability отделена от execution: `disabled/unpublished/online/offline/revoked/unsupported` — доступность export; task сохраняет свои todo/pending/in_progress/needs_review/blocked/done/cancelled; chat — idle/running/cancelling/error. Offline не означает stopped. Последний snapshot помечается stale + observed_at, кнопки mutation заблокированы.

DTO transcript: resource/message ID, role/kind, projected text, created_at, origin safe label, delivery state, safe usage. Не пересылаются raw `data`, tool arguments/results, system prompts/context, provider session IDs, terminal logs, URLs handoff, absolute FS paths и attachment URLs. System/tool события только allowlisted краткие статусы без raw payload; kind=remote_control и сообщения с handoff исключены целиком. Известные provider Remote Control/session/connect URL и environment identifiers редактируются **во всех текстовых DTO** (включая title/brief/summary/error/user/assistant и historical text), не только в полях или system kind; redaction выполняется **до** chunking/streaming, включая historical text после disable, тест содержит URL, скопированный в пользовательское сообщение. User/assistant/summary тексты всё ещё могут содержать код, пути и секреты: локальный фильтр редактирует известные credentials/canary перед export, но не гарантирует нахождение произвольного секрета, уже написанного моделью. UI предупреждает об этом **до** view_transcript grant. Markdown отображается как untrusted text, HTML/scripts не исполняются; link navigation explicit, никаких автозагрузок remote images/attachments.

Stream не копирует EventBus целиком. На ПК projection adapter подписывается только на pinned Ctx/resource и выдаёт `stream_epoch+seq` (новое поколение при restart, compaction/reset projection). Каждое событие несёт полный target/export revision/resource revision и message ID для дедупликации. Snapshot pagination cursor — opaque привязка к target+resource+projection revision; compaction/изменение набора → snapshot_changed/resync_required, не смешанный transcript.

Subscribe содержит last stream cursor; bounded replay на ПК 500 кадров/60 s. Gap, overflow, неизвестная epoch/курсор впереди → resync_required, доставка прежних delta прекращается; client делает paginated snapshot и новый subscribe. Snapshot выдаёт watermark; subscribe-after-watermark атомарен относительно projection или отдаёт gap и требует повторить snapshot. Remote хранит только bounded RAM buffers, не event history; requester не считает stream доказательством сохранения. Компактация локального transcript может удалить старые записи — ACP не обещает архив/восстановление полной истории.

Обязательные максимумы ACP/1, проверяемые **сервером и ПК** до allocation/dispatch (возможны только более низкие локальные limits):
- Один UTF-8 JSON frame ≤64 KiB; decoded depth ≤12, ≤128 object fields суммарно; text prompt/note ≤16 KiB, title ≤480 bytes, write_paths ≤64 по ≤256 bytes. Никакого chunked upload обхода лимита.
- List/transcript page ≤50 items и ≤32 KiB payload; большие projected texts выдаются ≤16 KiB chunk с message_id+offset/total, только по bounded transcript.page, без потери хвоста/молчаливого усечения. Максимальная видимая запись 1 MiB; выше — content_omitted + локальный просмотр, не автоматическая загрузка всего.
- До 16 in-flight requests/socket, 4 reads/s burst8 и 1 mutation/s burst4 на source→target export, дополнительно 20 requests/s burst40 на principal/server; 429/rate_limited + retry_after без смены command_id. До 8 subscriptions/source, 32/target export.
- Stream ≤20 frames/s и ≤256 KiB/s/subscription; coalesce status, но не переупорядочить message content. Buffer ≤1 MiB или 128 frames/subscription, overflow → gap/resync, memory bounded. Local JobEngine никогда не ждёт медленного наблюдателя.
- Heartbeat 5 s, executor lease 15 s (по monotonic server time), request receipt timeout 10 s; accepted job не ограничен этим timeout. Подключение/все replay не продлевают expired grant автоматически.
- Metadata capacities: ≤32 active registrations/user, ≤16 exports/executor, ≤128 grants/export, ≤1024 resource-index rows/export по ≤1 KiB/row, metadata staging ≤2 MiB/export, только один staging index. Attach manifest ≤16 записей, grants передаются отдельными кадрами. Превышение — capacity_exceeded, не silent truncate/частичный all_resources scope; владелец сужает export scope. Все page/snapshot кадры также ≤64 KiB.
- Concurrent remote-origin AI jobs на export: default 1, локально explicit максимум ≤ существующих team/agent concurrency; per-grant ≤1. Не автоматический кредитный бюджет: max_turns/permission/backend limits остаются локальными, spend approval понятен владельцу. Повтор note/read не обходит запускной budget/slots.

## 9. Revoke/offline и безопасность секретов

Локальный Revoke/Disable под admission lock атомарно увеличивает revision/отмечает revoked **до** ACK/сети, останавливает экспорт/подписки, вычищает buffers и запрещает новые/ещё не dispatch remote jobs. Затем отправляет mirror revoke; при недоступном Remote deny на ПК уже действует. Remote может показывать stale metadata до lease expiry ≤15 s, но executor не примет старый grant. Server-side key/device revoke помечает связанные grant mirrors revoked необратимо для прежней revision, а не только user.active=false; reactivation/rotate не воскрешают отозванный grant. Ключ rotation закрывает socket старого credential fingerprint, новая auth того же user не переиспользует открытый socket. Server-side key/device revoke немедленно запрещает новую маршрутизацию/доставку и закрывает сокеты; PC узнаёт через уведомление/disconnect/lease ≤15 s. При сетевом разделении нельзя гарантировать мгновенный глобальный revoke: ранее forwarded/admitted команда может дойти до dispatch в остатке действующего lease, если локальный consent не отозван. Локальный revoke fence действует сразу; удалённый отзыв в UI показывается pending executor acknowledgement до уведомления/expiry. После этого ни подготовка, ни reconnect не возобновляют dispatch.

Revoke означает **нет новых удалённых действий/выдачи**, не обещание откатить уже принятую работу, стереть прочитанное с устройств или мгновенно убить AI. Уже dispatch job по умолчанию продолжает локально, включая принятую running-note; владелец видит это и отдельную кнопку Stop affected runs. Cancel best effort, результат/файлы не удаляются. Потеря requester сети тоже не отменяет разрешённый run. Работа, заблокированная до dispatch, не стартует при восстановлении связи без новой явной команды.

Registration/grant renewal/epoch mismatch/persistent identity edit/URL or account change требуют explicit consent, нет автонаследования. Ограниченный reconnect к тому же registration/epoch возобновляет только чтение после auth, не offline mutations. Статус revoked очищает in-memory transcript на requester; локальное сохранение уже прочитанного контролируется requester OS, гарантии удалённого удаления нет.

AI provider keys, локальный Studio token, SSH/private keys, .mcp.json secrets, ENV и provider auth/session URLs никогда не являются wire полями. Credential headers только exact URL transport, не в debug logs/error repr/crash report; server access logs без Authorization/device headers/body. Server audit — command hash/IDs/op/outcome/time, без prompts/transcript. На requesters pending intent с пользовательским текстом — private локальное хранилище с TTL 24 h/explicit discard и предупреждением, не analytics.

TLS защищает только transit; Remote TLS terminator видит prompts/ответы и способен их сохранить. «Не сохраняем content» — реализуемое правило приложения (без body logs/DB/queue), не E2E/privacy гарантия против администратора, backup или reverse proxy. Диск Studio plaintext не становится encrypted от ACP; не обещаны lossless delivery/полная история/power-loss сохранность без §7.

## 10. Минимальная проверяемая приёмка

Fixtures/fake backend с счётчиком dispatch, без реальных AI/ключей. При интеграционной проверке документы/БД/hash до и после, не только HTTP 200.

| Case | Проверяемый результат |
| --- | --- |
| Discovery/strict DTO | До Register и без device headers GET exact normalized URL+prefix `/api/ai/v1/capabilities`; request/response no-store. Mounted ACP → exact 200 DTO из §6; выключенный/unmounted/старый peer → 404 unsupported. Valid incompatible version → unsupported; 401 → auth_failure; timeout/TLS/network → typed unavailable; malformed/extra/duplicate keys/UUID/types → invalid_response; redirect → redirect_refused, Authorization на redirect target не уходит. Никакого fallback/probe execution. |
| Discovery/read-only | На каждый исход выше повторить discovery без client_id/device secret: ноль Register/DELETE/sync/control/AI вызовов, dispatch=0; registrations/exports/grants/ledger/task/chat/Documents и profile verification/catalog state до/после неизменны. Старый peer не получает WS или guessed endpoints; ни space, ни draft, ни credential не создаются. |
| Documents compatibility ACP on/off | Для v1 peer с ACP on и off existing strict Verify успешно читает прежние exact health/me (valid identity, catalog_unavailable), без AI-полей. Для v2 peer с ACP on и off existing strict Verify + catalog list/detail + explicit fixture Create проходят с прежними DTO, capabilities и auth; Create вызывается отдельно тестом, никогда discovery. Сравнить ответы/эффекты on/off и неизменный Documents PROTOCOL_VERSION; отрицательное AI discovery не сбрасывает Documents Verify и не блокирует catalog/Create. |
| Default/old peer | Свежая установка, sync enabled, тот же user/space, но нет explicit publication+grant/capability: ни target/transcript, ни запуск не доступны; ни legacy REST proxy, ни sync fallback. |
| Identity/clone | Два ПК, один persistent ID и одинаковые task IDs: команда только выбранному registration/export. Copy root/private binding отсутствует; duplicate export отказ. ID/URL/storage_epoch/revision/runtime restart stale request → conflict, не fallback на активный проект. |
| Two-level auth | Invalid key/device/user, подмена source actor, другой requester device того же user, grant для другого team/task/op: server deny. Forward со старым/подменённым grant при fake доверенном relay: PC deny; null actor, mismatched team/task не обходят. Key revoke при живом socket отсекает следующий response/batch. |
| Scope/operations | view_status не читает transcript; read не запускает. operate_existing выключен — чужой/local объект не меняется. Shell/FS/raw URLs/config/attachments/provider handoff/Producer/actor overrides отклонены до service calls; известных canary keys нет в DTO/logs. |
| Intended workflow | На exporter уже есть local tasks/chats: explicit all_resources scope показывает их и projected состояния/тексты на другом ПК и Android. create_task даёт draft, Start создаёт один run; обычный chat create+send — один turn, видны итог и cancel status. Исполнителя в Remote AI process нет. |
| Autostart/busy | Team Autostart=true и automation listeners: remote draft ни solver, ни agent не вызывает; PATCH status/start-all недоступны. Busy chat send не пишет message/inbox; dependency/Solo/slot conflict не создаёт отложенный remote start. |
| Dedupe/crash | N copies Start/Send и lost ACK → один message/run/dispatch; другой payload same ID → conflict. Fault injection до/после transaction/dispatch marker/external start/receipt/restart: максимум один dispatch, unknown честен, нет auto resume. Disk-full/commit error → ноль dispatch; FULL mode проверяется на соединении mutation. |
| Race/revoke/offline | Локальный Revoke в await/после try-reserve перед dispatch → ноль запуска; server-side revoke режет traffic сразу, PC fence не позднее lease expiry (проверяется partition-case); при уже running локальный job продолжается и это видно. Нет offline queue/replay/подмены executor, grant expiry и lease истечение fail closed. Late response после revoke не раскрывается. |
| Streams/limits | seq gap, compaction, reconnect, snapshot-watermark race и slow Android → resync или корректная последовательность, без дубликатов/смешения targets. Каждый max/unknown field/depth/binary/rate cap проверен; память bounded, основной job не блокируется. |
| Regression/security | Switching/закрытие вкладок не меняет pinned target/сессии; Documents Markdown/Yjs/no-write-on-open неизменны и task/chat rows не появились в Remote Docs. Transcript Markdown не исполняет JS, не качает URL. Tests секретов, URL prefix/no redirects, old versions проходят; skipped remote integration не считается passed. |

## 11. Следующие небольшие задания и exact write_paths

Это **план, не созданные карточки и не разрешение писать перечисленные файлы в VS-130**. Пути Studio/Remote относительно D:/VoxariumStudio; Android — абсолютные в отдельном репозитории. Новые файлы помечены «новый». При выдаче исполнитель обязан сверить актуальных владельцев, сохранить чужой dirty checkout и объявить полный список через Studio; пересечения выполнять последовательно. Последовательность: Studio contracts/admission → Remote relay → Android; public enable только после interop всех частей.

### S-A0 — Нормативная поправка перед кодом
`write_paths`: `docs/voxarium-studio-dev-spec.md`.
Приёмка: §12 этого документа перенесён как future ACP/1; запрет репликации task/chat DB и границы текущего v1 не сняты задним числом.

### S-A1 — Identity, private consent и strict ACP schemas (не mount)
`write_paths`:
- `backend/voxarium_studio/ai_access/__init__.py` — новый
- `backend/voxarium_studio/ai_access/protocol.py` — новый
- `backend/voxarium_studio/ai_access/identity.py` — новый
- `backend/voxarium_studio/ai_access/grants.py` — новый
- `backend/tests/test_ai_access_identity.py` — новый
- `backend/tests/test_ai_access_grants.py` — новый
- `backend/tests/test_ai_access_protocol.py` — новый

Приёмка: §3–6 identity/grants schemas, default off, exact profiles/URL, private durable ACL/CAS, malformed no overwrite; pure tests без сети. Reuse существующий credential provider, отдельный device secret namespace без project save.

### S-A2 — Транзакционный ledger/provenance и projection
`write_paths`:
- `backend/voxarium_studio/models/ai_access.py` — новый
- `backend/voxarium_studio/models/__init__.py`
- `backend/voxarium_studio/core/db.py`
- `backend/voxarium_studio/ai_access/ledger.py` — новый
- `backend/voxarium_studio/ai_access/projection.py` — новый
- `backend/tests/test_ai_access_ledger.py` — новый
- `backend/tests/test_ai_access_projection.py` — новый

Приёмка: atomic ledger+fixture mutation, FULL transaction, tombstones/recovery, safe paginated DTO/secret canaries/gap snapshots; schema migration код проверен только fixture DB; применение к production данным/transport не входит в задание.

### S-A3 — Executor admission и at-most-once dispatch
`write_paths`:
- `backend/voxarium_studio/ai_access/executor.py` — новый
- `backend/voxarium_studio/teams/orchestrator.py`
- `backend/voxarium_studio/teams/chat.py`
- `backend/voxarium_studio/engine/jobs.py`
- `backend/voxarium_studio/teams/slots.py`
- `backend/tests/test_ai_access_executor.py` — новый
- `backend/tests/test_ai_access_crash_recovery.py` — новый
- `backend/tests/test_teams.py`
- `backend/tests/test_chats.py`

Приёмка: RemoteActor не None, strict scope перед каждым effect; draft suppression, no busy inbox/no delayed execution, revision/run fencing, try-reserve и revoke-before-dispatch race; fault-injected fake backend запускается максимум раз. Если старые service transactions не позволяют atomicity — refactor внутри этих файлов, не shim HTTP.

### S-A4 — Studio transport/lifecycle и requester local API
`write_paths`:
- `backend/voxarium_studio/ai_access/transport.py` — новый
- `backend/voxarium_studio/ai_access/service.py` — новый
- `backend/voxarium_studio/ai_access/intents.py` — новый
- `backend/voxarium_studio/api/ai_access.py` — новый
- `backend/voxarium_studio/api/__init__.py`
- `backend/voxarium_studio/core/workspace.py`
- `backend/tests/test_ai_access_api.py` — новый
- `backend/tests/test_ai_access_transport.py` — новый

Приёмка: локальные routes под require_auth/Origin/Host; global `/api/ai-access` registration/publication/grants/directory, requester `/api/ai-access/requests` и receipts, поток к browser `GET /api/ai-access/events` через authenticated fetch/SSE, не WS token в URL. Explicit target body, не legacy Ctx selector, no arbitrary proxy. Один process service, no start until explicit enable; fake relay contract tests; отдельный GET capabilities по §6 до Register, personal Bearer без device auth, no-store, strict DTO/typed outcomes и exact URL/prefix/TLS/no redirects. Отрицательный discovery не делает Register/sync/control и не меняет Documents verification/catalog state; wire disabled при отсутствии ACP. Intent store pre-send + recovery UI DTO; global restart/shutdown без второго backend.

### S-A5 — Studio UI opt-in и remote target workspace
`write_paths`:
- `frontend/src/api/ai-access.ts` — новый
- `frontend/src/stores/ai-access.ts` — новый
- `frontend/src/stores/ai-access.spec.ts` — новый
- `frontend/src/components/settings/RemoteAiAccessSettings.vue` — новый
- `frontend/src/components/settings/RemoteAiAccessSettings.spec.ts` — новый
- `frontend/src/views/RemoteAiView.vue` — новый
- `frontend/src/views/RemoteAiView.spec.ts` — новый
- `frontend/src/views/SettingsView.vue`
- `frontend/src/views/ProjectSettingsView.vue`
- `frontend/src/router/index.ts`
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

Приёмка: full target/user/device, least privilege, stale/offline/unknown/revoke, create then start, EN/RU parity; no secrets in Pinia/storage. Remote workspace не подменяет локальные task/chat stores и ProjectSession, target frozen; authenticated fetch stream. Не обещать generic reuse local components с local API builders без нового typed adapter.

### R-A0 — Credential lifecycle без resurrection (security prerequisite)

`write_paths`:
- `remote/voxarium_studio_remote/store.py`
- `remote/voxarium_studio_remote/auth.py`
- `remote/voxarium_studio_remote/app.py`
- `remote/voxarium_studio_remote/hub.py`
- `remote/tests/test_user_lifecycle.py` — новый

Приёмка: credential fingerprint/generation меняется при rotate/revoke/reactivate, старый socket закрывается; mutation hook инвалидирует AI grant mirrors до выдачи нового token. Нет resurrection после revoke+rotate между watcher ticks. Согласовать с существующей security-задачей server-design, не переделывать принятый результат. Это prerequisite R-A1/R-A2; ACP ai_auth делает per-frame guard независимо от legacy watcher.

### R-A1 — Remote registrations/grants/auth policy (после S-A1 schemas)
`write_paths`:
- `remote/voxarium_studio_remote/ai_protocol.py` — новый
- `remote/voxarium_studio_remote/ai_store.py` — новый
- `remote/voxarium_studio_remote/ai_auth.py` — новый
- `remote/tests/test_ai_auth.py` — новый
- `remote/tests/test_ai_store.py` — новый

Приёмка: отдельные versioned control tables/registry identity/hash-only secrets, двойная auth, exact user/device/grants/revocation/expiry; не импортирует Studio. Authenticator interface переиспользуется, общий Documents ACL не расширяется.

### R-A2 — Remote bounded relay и capabilities (после R-A1/S-A4)
`write_paths`:
- `remote/voxarium_studio_remote/ai_relay.py` — новый
- `remote/voxarium_studio_remote/ai_routes.py` — новый
- `remote/voxarium_studio_remote/app.py`
- `remote/tests/test_ai_relay.py` — новый
- `remote/tests/test_ai_routes.py` — новый
- `remote/README.md`

Приёмка: §6 wire/close/errors, per-frame auth, lease/role/limits/no offline queue/body logs; simultaneous revoke/late response, one executor, zero AI imports/processes. GET `/api/ai/v1/capabilities` по §6: personal Bearer без device auth до Register, no-store, strict 200 DTO только после actual mount ACP; off/unmounted → 404. Health и v1/v2 me остаются без AI-полей, Documents PROTOCOL_VERSION прежний; existing strict v1 Verify и v2 catalog/Create tests проходят с ACP on/off. Discovery read-only, включая auth/error пути, без регистрации/space/grants/AI effects.

### X-A1 — Studio↔Remote fixture interop (после R-A2)
`write_paths`:
- `backend/tests/test_remote_ai_access.py` — новый
- `remote/tests/test_ai_interop.py` — новый

Приёмка: два fake Studios + настоящий Remote в одном test loop, cases §10, включая отдельный capabilities discovery и регрессию ACP on/off: strict v1 Verify, v2 Verify/catalog/Create, no AI extras в health/me, read-only/no side effects на старом peer и всех negative outcomes; никаких реальных AI. Remote установлен в test env, skip — не pass; serialization fixtures общий wire без production package imports друг в друга. После этого разрешается expose UI capability, не до.

### A-A1 — Android native ACP/identity и intents (после X-A1 и server-only profiles/catalog/immutable sessions из android-design A1–A5)
`write_paths`:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/ai/AiProtocol.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/ai/AiConnection.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/ai/AiRepository.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/ai/AiIntentStore.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/ai/AiDeviceStore.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/data/ai/AiProtocolTest.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/data/ai/AiRepositoryTest.kt` — новый

Приёмка: native GET capabilities до Register по §6 (personal Bearer, без device headers, no-store, exact URL/prefix/TLS/no redirects, strict DTO/typed outcomes); unsupported/auth_failure/unavailable/error не вызывают Register/sync/control/AI и не меняют Documents verification/catalog. Затем отдельный native socket, exact profile/account/server partition, secret не в editor bridge, pending command_id survives process death, reconnect без replay запуска, limits/gaps/revoke. Переиспользовать безопасный secret-store механизм, не менять editor bridge ради AI.

### A-A2 — Android выбор исполнителя, задачи/чаты и interop
`write_paths`:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/ai/AiWorkspaceScreen.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/ai/AiWorkspaceViewModel.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/MainActivity.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/VoxariumRemoteApp.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/res/values/strings.xml`
- `D:/VoxariumRemoteAndroid/app/src/main/res/values-ru/strings.xml`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ui/ai/AiWorkspaceViewModelTest.kt` — новый
- `D:/VoxariumRemoteAndroid/app/src/androidTest/java/com/voxarium/remote/AiAccessInteropTest.kt` — новый

Приёмка: native список конкретных ПК/projects/resources, projected transcript/status, draft/start/send/cancel и unknown recovery; EN/RU, отдельные состояния discovery unsupported/auth failure/unavailable/error без auto Register или Documents fallback, stale target/auth/grants, unsafe Markdown, process death и limit tests. Documents draft/Room/Keystore/gates и original-document write gate не ослаблять. Новый source делает исторический gate report stale; до A-A3 нельзя выпускать enabled APK. APK/deploy/production smoke — следующая отдельная задача с точными целями/backup; эта карта не утверждает поставку функции.

### A-A3 — Независимая final-source AI/editor/APK acceptance
`write_paths`:
- `D:/VoxariumRemoteAndroid/verification/ai-access-v1/*`
- `D:/VoxariumRemoteAndroid/verification/editor-write-gate.json`
- `D:/VoxariumRemoteAndroid/VERIFICATION.md`

Приёмка: closed-source build без active report, полный native/web/editor regression и реальный owned fixture interop с fake AI/Remote/Studio; gate fingerprint конечного source, no-write-on-open/room/scribe/recovery checks, upgrade без uninstall/data loss. Gate report — только после независимых доказательств; старые evidence не переписывать и app/build.gradle.kts не ослаблять. Если исправлен source — повтор приёмки. Version metadata/artifact signing/smoke отдельно объявляются до final fingerprint по android-design A6v/A8.

## 12. Необходимые изменения dev spec

В этом задании spec не редактируется. S-A0 обязан:
- §16 вводный Documents-only текст и §16.1 «поверх того же соединения» уточнить: **отдельный ACP socket/namespace/version**, новые данные — AI prompts/status/projection, только explicit grants. Не обещать task/chat sync: task/chat DB/agent session никогда не зеркалятся, ownership/исполнение остаются на ПК. Явно сохранить запрет task sync как репликации и задокументировать узкое исключение remote control/view.
- §16.2/§16.6/§14: текущая командная модель без per-space ACL остаётся для Documents; ACP требует user+device+project+operation grants. Это scoped security extension, не общее RBAC/multi-user local REST. Не использовать «все active keys видят всё» для AI.
- §5.2.1/§5.3.2: стабильный client ID/registration/export отдельно от persistent_id/runtime handles, private consent вне проекта, copy/move/ID change fences, текущие frozen bindings/tray/context lifecycle сохраняются.
- §10.3/§10.4/§10.8/§10.9/§10.11 и §11: RemoteActor/provenance, draft suppression, явный start, no busy queue в ACP/1, operation allowlist, projected DTO/status/cursor, отличие от provider Remote Control; Producer/review остаются вне первой версии.
- §12/§16: auth обеих сторон, per-frame revocation, transport TLS/trusted relay/no E2E, command ledger/FULL durability/unknown crash outcomes/no offline queue, limits и секреты. В §5 storage split добавить private registry и несинхронизируемый project ledger.
- §16 discovery: отдельный read-only GET `/api/ai/v1/capabilities` по §6, personal Bearer до Register без device auth, no-store, exact normalized URL/prefix/TLS/no redirects, strict mounted-only DTO и typed negative outcomes без fallback/side effects. Не добавлять AI-поля в `/healthz` или v1/v2 me, не ослаблять их strict validators и не менять Documents PROTOCOL_VERSION; сохранить независимость Documents Verify/catalog/Create при ACP on/off и закрепить регрессию §10.
- Разделить normative future ACP/1 и наблюдаемый shipped v1/v2. Docs/Yjs Markdown-only/no-write-on-open и независимость remote package не меняются.

## 13. Проверка VS-130 и коррекция VS-136

Исследование: Graphify → owning source Studio; отдельный read-only разбор Remote/Android; независимый read-only review документа. Функциональные тесты/AI/server/build не выполнялись: здесь принимается согласованный проверяемый контракт, а не доставленная интеграция. Два read-only направления выполнены и результаты прочитаны: Remote/Android source research и независимый security review Studio/документа. Исторический полный review VS-130 не обнаружил конфликт health capability со strict DTO; его прежний вывод о готовности утверждения больше не действует. **VS-130 остаётся unapproved до повторной проверки исправленного контракта**; выполнение VS-136 не зависит от approve VS-130 и само не утверждает её. Закрыты grant mirror CAS/ACK/tombstones, resource index/auth, duplicate-before-epoch, nonblocking admission, redaction/content scope, Remote credential lifecycle и Android final-source gate. Readback совпал с сохранённым текстом; заголовки/таблицы/отсутствие trailing whitespace проверены напрямую. git diff --check для deliverable без ошибок, но shared docs могут быть gitignored, поэтому git-проверка не выдаётся за проверку содержимого.

VS-136: scoped коррекция только discovery (§6), её приёмки (§10), будущих S-A4/R-A2/X-A1/Android заданий (§11) и spec additions (§12). Grants/ledger/revoke/операции и остальной дизайн не меняются. Owning source strict health/me проверен после Graphify; это документная проверка, не выполнение будущих regression tests. Независимое scoped review всей delta и readback/diff-check обязательны перед завершением VS-136; серверы/AI/code/config/data не затрагиваются.
