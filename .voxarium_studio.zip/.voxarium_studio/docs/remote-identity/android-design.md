# Android: серверные профили и проекты по ID — контракт перехода (VS-90)

## 1. Статус, границы и основания

**15.11.2026. Исследование и контракт, не реализация и не разрешение мигрировать production.** Единственный результат VS-90 — этот общий документ. Android, Studio, Remote, конфигурация, active report, старые APK/evidence не изменялись; сборки, тесты, серверы, AVD/adb не запускались.

Сначала запрошен graphify Studio (`D:/VoxariumStudio/graphify-out/graph.json`); он дал исходники Remote/Studio, но не Android-specific связи. После этого проверены реальные файлы отдельного Android-проекта. Прочитаны карточки **VS-70, VS-79, VS-87**, общий [[remote-android/protocol]], Android `README.md`, `VERIFICATION.md`, `EDITOR.md`, `RELEASE.md`, дополнительно `DATA.md` и отчёт VS-87 `.scratch/build-fix-verification/RESULT.md`. **Локального `D:/VoxariumRemoteAndroid/AGENTS.md` нет**, рекурсивный поиск не нашёл и вложенных AGENTS.md; `D:/AGENTS.md` также отсутствует. Это отсутствие входного файла, не предположение о его содержимом.

Приоритет: фактический wire — текущий Remote; действующая Android-приёмка — VERIFICATION/VS-84, состояние опубликованного APK — RELEASE/VS-79, текущая shell-сборка — VS-87. Ранние фразы EDITOR «gate закрыт» и DATA «UI не подключён» исторические. VS-70 задаёт прежний протокол, **не описывает уже реализованный будущий каталог**.

Связанные исследования: **VS-88** / [[remote-identity/studio-design]] и **VS-89** / [[remote-identity/server-design]]. Их появившиеся документы прочитаны при согласовании: ниже принят **предложенный VS-89 v2** (canonical ID = прежний UUID, отдельный storage_epoch, без legacy sync fallback). Это ещё не утверждённый/реализованный API. Перед реализацией стороны принимают общий контракт и обновляют dev spec; ожидание будущих реализаций не блокирует завершённое Android-исследование VS-90.

## 2. Текущий срез: точные места и существенные различия

Все Android-пути далее относительно **`D:/VoxariumRemoteAndroid/`**. Сокращение **K** означает `app/src/main/java/com/voxarium/remote/`, **T** — `app/src/test/java/com/voxarium/remote/`. Номера строк — навигация по прочитанному срезу, перед изменением повторно проверить файл.

| Текущий файл | Факт / место адаптации |
| --- | --- |
| `K/data/security/ProfileStore.kt:10–30,52–58,69–117` | SavedProfile = id, label, canonicalServerUrl, **spaceName**, credentialId. Это совмещённый локальный server+project профиль, не каталог. Atomic checksummed `noBackupFilesDir/profiles.v1`. Backend API upsert/remove есть, нынешний UI предоставляет только добавление. |
| `K/data/security/CredentialStore.kt:15–24,33–55,58–78,90–101,117–152` | Отдельные credential IDs, AES-256/GCM encrypted `credentials.v1`; Keystore alias **`com.voxarium.remote.credentials.v1`**. Несколько профилей могут разделять credentialId. При существующем ciphertext потерянный alias не пересоздаётся. |
| `K/data/transport/RemoteEndpoint.kt:7–39` | URL и space сцеплены в одном value object. HTTPS-only; bare host → HTTPS, WSS → HTTPS; canonical OkHttp URL, без userinfo/query/fragment, trailing slash удаляется. Proxy prefix входит в адрес. Space trim+lowercase, regex `[a-z0-9][a-z0-9._-]{0,63}`. |
| `K/data/transport/RemoteConnection.kt:159–215,357–358` | Connect выполняет `GET /api/v1/me`, проверяет protocol, **затем открывает WS**. User из me сейчас не сохраняется/не сравнивается с hello. Redirects запрещены. Этот connect нельзя переиспользовать как безопасную отдельную кнопку «Проверить сервер». |
| `K/data/transport/Frames.kt` | Реальные типы Remote frames и bounded FrameCodec; это wire, не формат нового каталога. |
| `K/data/documents/DocumentModels.kt:10–12,15–62,68–80` | Namespace = **canonical URL + authenticated user.id + hello.space.id**, не profile label и не запрошенное spaceName. Length-prefixed encoding. Отдельные drafts, immutable pending, recovery, scope и send owner. |
| `K/data/documents/DocumentsRepository.kt:98–129,166–210` | Journal на URL+account с разделами по space.id и историей name→space.id. Offline binding дополнительно включает profile.id, URL, spaceName, credentialId. Hello.name должен совпасть с запрошенным space; неожиданный account блокируется. |
| тот же файл `:229–245,285–316,369–394,465–514` | Unknown pending разрешается sync/hash, не replay; ACK относится к immutable snapshot, newer draft сохраняется. Draft сам не даёт original-write. Проверки owner/scope/generation/token перед send. Recovery прежних space.id текущего account выдаётся отдельно. |
| `K/data/documents/DocumentStorage.kt:18–23,43–76,113–181`; `DocumentStateCodec.kt:22–60` | `noBackupFilesDir/documents.v1`, opaque hashed dirs, cache.bin и drafts.bin — **разные транзакции**, не единая БД. Magic/version/length/hash, AtomicFile/fsync/readback. Cache можно перечитать, corrupt durable journal нельзя считать пустым. JSON codec v1 внутри внешнего envelope. |
| `K/data/room/RoomRecoveryStore.kt:34–38,76–89` | Отдельный room journal по полному namespace, включая raw/rejected данные; payload проверяется на точный namespace. Перенести только Markdown недостаточно. |
| `K/data/room/RoomCoordinator.kt:7–10,71–79,109–120,258–265,434–454`; `ScribeQueue.kt` | Immutable owner/scope/incarnation; storage/schema failure отзывает запись; checkpoint/recovery до disposal; send queue не даёт durability ACK. |
| `K/ui/connection/RemoteSession.kt:93–181,186–192,259–280,475–487,535` | Сохранение профиля — local-only; select/connect и switch проходят барьер, новый documentEpoch/immutable binding. Список room recovery сейчас только текущего namespace. BuildConfig — источник write policy. |
| `K/RemoteViewModel.kt:21–48,100–116`; `K/VoxariumRemoteApp.kt:56–62,108–225,239–275` | UI state/intents, local profiles, подтверждение по profileId, локализованные статусы. Потребуются отдельные server/project/verification/catalog selection generations. |
| `K/ui/connection/ProfileForm.kt:27–120` | Форма label/server/**space**/key. Защищённый native password input, без saveable token, autofill/save/personalized learning; очистка до submission/disposal. Сохранить защиты при разделении формы. |
| `K/ui/editor/RecoveryHub.kt:20–28` | Repository recovery сводится к id/path/markdown: исходный spaceId не показан. Новый UI обязан восстановить provenance, иначе одинаковые пути разных проектов неоднозначны. |
| `K/ui/editor/EditorScreen.kt`; `bridge/RoomEditorCodec.kt`; `bridge/SecureEditorView.kt:78–136` | Runtime gates/typed bridge; только local appassets origin + main-frame/current URL и feature check. Не добавлять в WebView каталог, HTTP, Bearer или URL с ключом. |
| `app/src/main/res/values/strings.xml`, `values-ru/strings.xml`; `K/ui/theme/Theme.kt:10–51`; `K/MainActivity.kt:10–16` | EN/RU, Material3 light/dark уже есть, edge-to-edge/insets. Новая UI-библиотека не нужна. |
| `app/build.gradle.kts:10–40,96–138` | Fingerprint включает main/** и test/**, в том числе UI/resources; все web gates и полный native suite обязательны при packaging (§8). |
| `app/src/main/AndroidManifest.xml:5–7`, `res/xml/backup_rules.xml`, `res/xml/data_extraction_rules.xml` | Backup запрещён/исключён. Uninstall/clear data уничтожают local state, не являются способом миграции. |

### 2.1 Что означает ID сегодня

Текущий Remote в **Studio root**:

- `remote/voxarium_studio_remote/app.py:78–127`: `GET /healthz`, `GET /api/v1/me`, `WS /api/v1/sync?space=...`.
- `remote/voxarium_studio_remote/store.py:202–217`: space ищется **по name**, на первом обращении создаётся; отдельный `id = uuid.uuid4().hex`.
- `remote/voxarium_studio_remote/hub.py:134–153`: hello содержит **space:{id,name}**, seq; query space попадает в lookup name.
- `store.py:219–224`: list_spaces существует **как внутренний Python API**, не как доступный Android HTTP endpoint.
- `remote/voxarium_studio_remote/protocol.py` и `backend/voxarium_studio/sync/protocol.py`: wire protocol v1, room/file sync; подробные frames — [[remote-android/protocol]] §§2–8.

Следовательно, нынешний **`spaceName` (routing token)** и нынешний **`hello.space.id` (серверная identity/incarnation)** — разные значения. Нельзя переименовать поле, отправить старый hello UUID в query вместо имени и объявить миграцию завершённой: старый сервер создаст другой пустой space.

## 3. Целевая модель и правила identity

Ниже — предлагаемый Android-контракт, **ещё не реализованный формат**.

| Сущность | Поля / ответственность |
| --- | --- |
| ServerAddress | Versioned canonical HTTPS base URL. Это логический адрес сервера; DNS, display name и произвольная папка не identity. В текущем wire нет отдельного подтверждённого server-instance ID. |
| ServerProfile | `localProfileId` (стабильный локальный ID), `name` (только display), `canonicalUrl`, `credentialId`, `credentialRevision`, `verification`. **Без space/project ID.** Один профиль позволяет выбирать разные проекты. Разные профили одного URL допустимы. |
| ServerVerification | Привязка к exact URL + credentialId/revision + request generation; confirmed user.id/displayName/color (v1 name, v2 display_name через adapter), protocol, время последней проверки, состояние и поддержанный catalog-contract version. Никакого plaintext/token hash в UI state. Persisted «проверен раньше» — история, не доказательство текущей доступности. |
| RemoteProjectSummary | `projectId`, `displayName`; источник server catalog либо явно помеченный legacy record. Wire Project уже согласован в §4.2.1: storage_epoch, metadata_revision, created_at; это ещё не реализованный API. Name не уникален и не routing token. |
| ProjectBinding | `bindingId`, serverProfileId, **projectId == v2 wire space == hello.space.id**, catalog-contract version, expected account, **storageEpoch == hello.space.storage_epoch**, legacy provenance. До подтверждения mapping legacy record не является writable binding. ID другой binding не меняется in place. |
| ActiveBinding | Immutable snapshot URL + credential revision + account + projectId + storageEpoch + selection/connection generation. Свои transport/repository owner/coordinator/channel. Нельзя подменить поля существующей сессии. |

**Логический проектный namespace**: `(canonicalServerUrl, projectId)`.
**Физический/private partition**: `(namespaceVersion, canonicalServerUrl, projectId, authenticatedUserId, storageEpoch)`.
**Документ**: partition + case-sensitive relative POSIX path.

Account partition остаётся даже без серверного RBAC: это защита от показа чужого локального кэша после замены ключа. Local profileId — ссылка UI/credential ownership, **не замена URL+ID identity**. Один URL/ID с разными accounts не образует общий readable bucket. Display name, имя Android-профиля, папка/название Studio и документный заголовок не участвуют в identity.

### 3.1 URL, ID, incarnation

- Сохранить текущую HTTPS/TLS/hostname/no-redirect политику. Каноникализацию вынести из объекта, требующего фиктивный space. Например, default HTTPS port/host canonicalization — по существующему OkHttp; reverse-proxy prefix и его регистр не отбрасывать. `https://host/a` и `https://host/b` — разные серверные namespace. Не делать DNS/redirect-based слияния.
- Версионировать canonicalizer. V1 адрес переносится exact persisted canonical value; изменение parser не должно незаметно переселить данные. Хешировать однозначную length-prefixed/tagged структуру, не concat URL+ID и не имя OS-папки. Новый storage key не подменять старым hash: v1 использует свои кодировки/ключи.
- Project ID берётся из выбранной записи каталога/результата explicit create. **Не вычислять slug из имени.** Предложенный VS-89 ID: exact 1–64 ASCII, regex `[a-z0-9][a-z0-9._-]{0,63}`, без trim/lower/Unicode normalization. Новый Create предлагает случайный lowercase UUID v4 с дефисами, редактируемый до отправки. Legacy spaceName — только selector/provenance; **не v2 projectId**.
- Изменение ID — **выбор другого пространства**, не rename и не перенос документов. Для настоящего переноса потребуется отдельный согласованный server workflow, вне Android-перехода.
- По предложению VS-89 **v2 catalog.id == query space == hello.space.id**; `storage_epoch` — отдельное поколение данных, не room.epoch. Для серверной миграции **v2 id = старый v1 hello.space.id**, initial storage_epoch = этот же прежний UUID, bytes/rev/seq сохраняются. Старое name — только exact legacy resolution mapping, не sync alias.
- Server replacement/recreate требует нового storage_epoch. Его несовпадение блокирует cursor/queue/rejoin до recovery и нового согласования. Даже при том же epoch **hello.seq < saved_cursor** означает rollback: блокировать старую базу и делать полный безопасный reconciliation. Откат backup с тем же epoch не всегда обнаружим; не обещать полное распознавание rollback.

### 3.2 Изменение настроек

| Изменение | Правило |
| --- | --- |
| Переименование server profile / displayName проекта | Не меняет namespace, credential или pending. |
| Новый URL, порт или proxy prefix | Новый server namespace; verification отзывается. Старый кэш/recovery остаются в архивной binding, не переносятся. |
| Замена personal key | Новый credential revision, HTTP-only reverify. Тот же user.id позволяет **явно** привязать прежний partition; другой user.id — новый partition и подтверждение. Старый account не показывать новому автоматически. |
| Project ID A→B | Барьер §6, новая binding и mirror. Pending/drafts A не становятся B. |
| Тот же URL+project ID, другой storage_epoch | Identity mismatch; сохранить A recovery, запрет replay, полный sync в отдельный partition только после явного принятия новой identity. Не считать обычным reconnect. |
| Удаление local server profile | Сначала барьер. Удаляется локальная ссылка, не Remote project и не офлайн-правки. Credential удаляется только явной отдельной операцией после проверки всех ссылок; recoveries не garbage-collect автоматически. |

## 4. Проверка сервера, каталог и совместимость API

### 4.1 Что работает сейчас

| Операция | Действующий wire |
| --- | --- |
| Health | `GET <base>/healthz`, без auth; service/version/protocol. Не подтверждает ключ/проект/schema editor. |
| Проверка ключа | `GET <base>/api/v1/me`, native `Authorization: Bearer <personal-key>`; user + protocol; invalid key → HTTP 401. |
| Sync выбранного space | WSS через `/api/v1/sync?space=<token>`, тот же header; hello/version/account/space checks **до sync/join/write**. |
| Чтение Documents | Sync/change/synced, не REST GET documents. |
| Каталог/explicit create проекта | **Клиентского HTTP API сейчас нет.** Не вызывать выдуманные `/projects`, `/spaces`, `/documents` или внутренний Store.list_spaces. |

Новый **ServerVerifier** должен выполнить только bounded HTTP me (при необходимости health как диагностику), без WS и без фиктивного space. Сохранить user из me, проверить protocol/schema ответа, cancellation и request generation. Перед project connection сравнить hello.user.id с verified account; mismatch останавливает binding. Health/version не заменяют редакторный gate. Bearer только native header, без query/cookie/JS; ошибки наружу — allowlisted категории, не response body/exception dump.

Сохранение server profile и проверка — разные действия. Проверка не создаёт проект, не синхронизирует Documents и не «включает запись».

### 4.2 Адаптер будущего VS-89

Native interface поверх предложенного wire (§4.2.1), не действующих endpoints:

- `verifyServer(address, credentialRevision)` → authenticated identity/protocol/support;
- `listProjects(verifiedServer)` → authoritative list of ID/displayName;
- `createProject(verifiedServer, id, displayName)` → confirmed ProjectSummary либо typed conflict/uncertain outcome;
- `resolveBinding(project)` → exact wire routing и expected identity по утверждённой версии.

Это семантика адаптера поверх **предложенных ниже v2 маршрутов**, не текущего Remote. Согласовать три документа до реализации. Для discovery использовать известный health/me без WS: protocol=1 означает upgrade-required; advertised v2 проверяется v2 me/capabilities. Будущий v1 me с protocol=2 не трактовать как v1 editor connection. Не перебирать URL и не откатываться на v1 при ошибке v2.

Обязательные совместные решения:

1. Catalog.id **равен v2 wire space/hello.space.id**, display_name только отображаемый; legacy ID = прежний UUID, incarnation = storage_epoch.
2. List/verify/select/refresh **не создают** проект. Create — отдельная подтверждённая мутация; WS missing ID не должен создавать опечатку на новом сервере.
3. Auth остаётся личным Bearer; не вводить Android admin/login/refresh token/RBAC. Текущий ключ имеет общий доступ к spaces; не обещать фильтрацию по правам, которой нет.
4. Create timeout — неопределённый исход, не автоматический повтор. По VS-89 GET **исходного ID** показывает результат и требует отдельного Select/подтверждения; запись-победитель гонки не становится «нашей». При 404 только пользователь может повторить Create того же ID. Не подставлять новый UUID и не искать по displayName.
5. Каталог может устареть между list и connect. Проверить выбранный ID/identity на connect; исчезнувший проект не пересоздавать. Ошибка не переводит клиента скрыто в legacy.
6. Серверное переименование displayName не меняет binding/cache. Серверная миграция legacy требует явного доказуемого mapping, не совпадения названий.

### 4.2.1 Точный предлагаемый wire VS-89 — ещё не действующие endpoints

После чтения [[remote-identity/server-design]] §§2–5 фиксируется контракт потребителя. На текущем сервере эти маршруты **не вызываются**.

| Только будущее v2 | Контракт Android |
| --- | --- |
| GET /healthz | Дополняется supported_protocols:[2], catalog_api:2; discovery, не key verification. |
| GET /api/v2/me | protocol:2, catalog_api:2, capabilities, user:{id,display_name,color}. Проверить project_catalog/explicit_project_create/strict_connect и native Bearer. |
| GET /api/v2/projects?limit=100&after=<ID> | projects:[Project], next_after; limit 1–200, keyset по ID, без snapshot-гарантии между страницами. Dedup по ID, refresh при гонке. |
| GET /api/v2/projects/{id} | Project либо 404 project_not_found; разрешение неопределённого исхода Create. |
| POST /api/v2/projects | Только {id,display_name}; 201 создан, 409 project_exists. **Нет operation_id/idempotency поля или server replay** в этом increment; повтор того же body при занятом ID даёт 409, не replay 201. |
| GET /api/v2/legacy-spaces/resolve?name=<exact-old-selector> | Только exact миграционное отображение old name→Project, не sync alias и не create. |
| WS /api/v2/sync?space=<ID> | Lookup-only; hello protocol:2, user.display_name, space:{id,display_name,storage_epoch}, seq. 4404 missing project, 4400 bad/protocol, 4401 auth прекращают retry. |
| GET /api/v2/projects/{id}/snapshot | Read-only preview при необходимости; exact pagination/expected_seq/expected_epoch и 409 snapshot_changed — по VS-89 §3.3. Не заменяет room sync/CAS и не даёт overwrite grant. |

Project = {id,display_name,storage_epoch,metadata_revision,created_at}. Подпись 1–120 Unicode code points/≤480 UTF-8 bytes, NFC+trim как явная нормализация, запрет управляющих/bidi. Строгие правила подписи применяются к новым/редактируемым значениям; исторические legacy display_name вне этих правил сохраняются буквально с пометкой Remote §5.1. Входной каталог из-за такой подписи целиком не отвергать и не нормализовать; отображать безопасно, не использовать текст как ID. **ID не нормализуется.** REST error envelope {error:{code,message,request_id}}; UI переводит stable code, не raw body/message. Document/room frames сохраняют прежнюю семантику, но версия/URL/hello/user/presence карточки меняются согласованно; room epoch не storage_epoch.

V2 mapping не вводится в v1 FrameCodec молча. Legacy fixture decoder остаётся для локального импорта; production connection новой модели принимает только v2. Неподдержанные версии/ID/epoch блокируются до sync/join/write.

### 4.3 Старый сервер и offline: fail-closed по VS-89

- Новый Android + старый protocol=1 сервер: server/key verification через действующий me остаётся возможной, но UI **«Сервер требует обновления — каталог недоступен»**; catalog/select/create/sync/write новой модели отключены. **Никакого legacy manual-space/WS fallback**, даже для импортированной binding.
- Старый Android + новый сервер (проект VS-89): v1 me сообщает protocol=2; v1 WS отказывает 4400 protocol_upgrade_required **до lookup/create**. Новый EXE/Android сам по себе не обновляет старый Remote; deployment требует согласованного окна и совместимых клиентов.
- Старый Android + старый сервер сохраняет историческое auto-create поведение; это не возможность нового Android. VS-90 ничего не отключает на действующей установке.
- 401/TLS/timeout/malformed/unknown version — отдельные ошибки, не «старый сервер» и не пустой каталог. Создание по опечатке на старом сервере нельзя исправить проверкой после hello, поэтому новый flow **вообще не открывает v1 WS**.
- Offline список — **ранее известные проекты**, с пометкой времени/устаревания, не актуальный каталог. Импортированные legacy записи доступны отдельным read-only cache/recovery списком с original selector и observed UUID. Без доказанного ID показывать unresolved, не генерировать v2 projectId.
- Offline создание и editing недоступны; нет offline CRDT editor или auto-publish. После restart/миграции нет automatic connect. Persisted «ключ принят раньше» не разрешает writable session.

## 5. Безопасная миграция локальных данных

**Цель: сохранить все уже durable офлайн-правки и их provenance, не объединяя проекты.** Это не обещание извлечь ещё не доставленный native IME/WebView ввод, восстановить отсутствующий Keystore или неисправный диск.

### 5.1 Профили и секреты

1. Миграция запускается **без сети**, до открытия writable repository/room; один ordered IO owner и process lock. Проверить известные versions, checksums/limits; corrupt/unknown journal — ошибка и read-only recovery, не «пустая установка».
2. Каждый legacy SavedProfile первоначально даёт отдельный ServerProfile с прежним localProfileId/name/URL/credentialId и **LegacyImportRecord**, не активную v2 binding. Сохранить profileId, credentialId, spaceName, last authenticated account и v1 hello.space.id. Известный UUID — candidate v2 projectId, ещё не подтверждённый каталогом. Если UUID нет — unresolved, не projectId=spaceName и не новый UUID.
3. **Не deduplicate по URL/названию/сходству ключа.** Даже два профиля одного URL могут принадлежать разным accounts. Последующее объединение — явная отдельная операция после reverify, с сохранением project bindings/recovery и без слияния pending.
4. Секрет переносится **ссылкой на существующий credentialId**. Сохранить `credentials.v1`, alias `com.voxarium.remote.credentials.v1`, package/applicationId и signing continuity для обычного APK upgrade. Ротация vault/alias не нужна этому переходу.
5. Missing alias + existing ciphertext → KEY_UNAVAILABLE, не генерация новой пустой базы. Corrupt vault не очищать. Предложить повторный ввод ключа для новой credential revision; durable Documents/recovery сохранять, но не выдавать новому account без явного сопоставления. JVM String guaranteed zeroization/StrongBox/hardware-backed не обещать.
6. Никаких токенов в manifest миграции, логах, shell args, saved state, screenshots, Markdown, URL или JS. Documents/recovery остаются app-private/noBackup, **не зашифрованы Documents-слоем**; миграция не меняет эту модель.

### 5.2 Зеркало, очередь, черновики, room journal

Предлагаются новые versioned metadata и `documents.v2` рядом с v1. Имена новых форматов уточняются реализацией, но инвариант copy-on-write обязателен.

1. Создать durable migration journal: version/phase, точные source identity и destination partition, source hashes/counts, migration record IDs. Без контента/секретов в диагностических логах.
2. Локальная фаза **без сети** собирает candidate mapping из authenticated bindings + name→space.id history и сохраняет legacy partitions. V1 journal общий на account и содержит несколько space.id: **не копировать его целиком в один проект**. После обновления сервера отдельная явная фаза reverify + read-only v2 legacy resolution/GET сверяет mapping: canonical ID = прежний UUID, storage_epoch = прежний UUID при штатной миграции. Показать old selector→ID/epoch и запросить принятие; при расхождении/отсутствии mapping только archive/full reconciliation, не импорт cursor.
3. Copy/readback переносит mirror (versions/rev/hash/tombstones/content/complete/cursor), drafts (base/content/generation/kind), immutable pending snapshots и unknown outcome, newer draft поверх pending, оба варианта conflict/recovery, reserved copy names и monotonic counters.
4. Отдельно перенести room recovery: source/last-valid snapshot, raw/rejected state/update, original namespace/path/epoch/generation/reason. Raw не декодировать/не replay-ить при миграции. Прошлые space.id должны остаться доступны как архив с provenance, включая raw-only records.
5. Если несколько names ведут к одному legacy space.id, либо соответствие name↔ID/account неоднозначно, **не размножать writable state**. Сохранить неизменённый legacy archive с исходным namespace и показать read/copy recovery. Выход в новый partition разрешается только после доказуемого mapping.
6. Подтверждённый mapping активирует v2 partition только по явному действию; offline/local-copy фаза не активирует сеть. Проверить точные bytes/hashes/counts и counters чтением новых blobs. Поскольку cache и drafts — разные транзакции, **сначала durable journal/recovery, потом replaceable mirror**; лишь затем атомарно переключить общий activation manifest. Нельзя считать несколько AtomicFile одной транзакцией.
7. States `prepared → copied/verified → activated` возобновляемы и идемпотентны. Crash после каждого шага не теряет источник/не удваивает generation/recovery. При disk-full/corrupt/readback failure старый source остаётся, новая binding не активируется; никакого silent cleanup/eviction.
8. V1 files/vault/alias и история **не удаляются в этом переходе**. Это только источник recovery, **не параллельное writable хранилище**. После activation v2 повтор migration не импортирует устаревший v1 поверх новых edits. Старый APK/старый server binary не понимает новые markers: запрет downgrade нельзя выдавать за уже технически обеспеченную защиту. Возврат старого APK/backup требует остановки и отдельного сохранения/export v2 изменений, не отката файлов поверх новых.
9. Offline binding в v2 хранит explicit URL+projectId+account+incarnation и credential association. Старую profile-binding metadata переносить через exact mapping; новый profile без доказанной identity не получает старый кэш по одному URL.

### 5.3 Мигрированный pending — не разрешение отправки

Pending сохраняется со **старым target** и состоянием uncertainty/recovery, но owner, connection generation, sid, epoch и room write token **не оживают** после restart/migration.

Перед любой новой отправкой нужны fresh verification/hello, exact target/account/storage_epoch, sync и reconciliation. При hello.seq < saved_cursor нельзя ни выпускать incremental sync/write, ни подтверждать pending по старому mirror/hash: сначала blocked rollback recovery и полный согласованный snapshot/reconciliation. Для прежней identity можно распознать уже committed exact hash/content без повторного PUT. Расхождение сохраняет обе версии, не подставляет новую base_rev к старому тексту. При другой identity/ID pending остаётся архивным и **никогда автоматически не получает новый target**.

Нельзя inject offline snapshot в новую room/Y.Doc или ставить `live` старого sid. Recovery UI даёт read/copy; auto restore/replay/overwrite оригинала не добавляется. Миграция сама порождает **0 WS/put/delete/update/create**.

## 6. Смена проекта/ID и барьеры

Обязательный переход A→B (включая URL/key/account/incarnation):

1. Зафиксировать switch intent с immutable A и выбранным B; отозвать новые edit/format intents. Старые callbacks продолжают работать только с A.
2. Завершить IME/composition и typed Flush. Штатно дождаться ACK **последнего snapshot без newer debt**; non-scribe ждёт materialized Markdown либо сохраняет durable recovery.
3. При timeout/renderer loss сохранить last-valid/source/rejected diagnostics в A и показать «закрыто с локальной копией», не CLOSED_CONFIRMED. При storage failure не завершать switch как успешный; остановить input/network effects.
4. После барьера retire A channel/coordinator, leave/disconnect, отозвать room grants, pending send effects и retry; immutable pending остаётся в A storage.
5. Новый selection/connection generation, новый owner/scope/coordinator, новый sid/Y.Doc для B; очистить reader/editor/recovery presentation A, confirmation и старые catalog/verification/create replies.
6. Fresh B me/hello identity checks и sync. Только затем room join. **Проверка target непосредственно перед send** на том же ordered worker, а не только при постановке в очередь.

Каждый durable send intent хранит versioned target tuple, original binding/partition, path, snapshot/hash/generation и correlation. Нельзя в старом callback читать «текущий выбранный проект» и отправлять туда intent. Late ACK A меняет только A и только подтверждённый snapshot; не очищает B draft, не подтверждает более новый A ввод и не переоткрывает blocked room.

Критический сценарий: A имеет in-flight PUT + newer draft; пользователь вводит ID B с тем же названием и path. После переключения **0 старых PUT/UPDATE/SEED в B**, обе версии A доступны recovery. Даже если B имеет те же rev/hash/name, target mismatch не разрешает replay.

## 7. Material3 UI EN/RU

Сохранить текущие Material3 theme, safeDrawing+IME, scroll/max width, системные EN/RU/light/dark. Новые строки в обеих resources одновременно, одинаковые placeholders; реальные server/project names — данные, не переводятся.

| Экран/действие | EN / RU и контракт |
| --- | --- |
| Servers | **Servers / Серверы**. Карточка: local name, exact canonical URL, last verification status/account. Не выводить personal key. |
| Server form | **Server name / Название сервера**, **Server URL (HTTPS) / Адрес сервера (HTTPS)**, **Personal access key / Личный ключ доступа**. **Без space**. Сохранить native password protections; token очищается после save/выхода/rotation, не rememberSaveable. |
| Save / verify | **Save server / Сохранить сервер** — local-only. **Verify server / Проверить сервер** — HTTP-only. **Not verified / Не проверен**, **Verifying… / Проверка…**, **Key accepted / Ключ принят**; отдельно auth/TLS/network/protocol/invalid-response. Не называть это «проект синхронизирован». |
| Projects | **Projects / Проекты**, выбранные server/URL/account. Состояния loading/empty/error/stale/offline/unsupported различаются. В карточке displayName **и Project ID / ID проекта**; одинаковые названия допустимы. |
| Select | **Select project / Выбрать проект**. Confirmation привязано к URL+credential revision+account+projectId+intentGeneration. Смена любого поля отзывает confirmation; stale click не переадресуется. |
| Create | **Create project / Создать проект**, display name и exact ID. По предложению VS-89 клиент предлагает UUID v4, пользователь может отредактировать его до explicit Create; показать подтверждённый сервером ID до connect. Explicit confirmation сервера/URL/ID; refresh/back/cancel не создают. Pending create без ответа → **Creation result unknown / Результат создания неизвестен**, не auto retry. |
| Legacy | **Server upgrade required / Требуется обновление сервера**, **Project catalog unavailable / Каталог проектов недоступен**. Create/select/sync/write disabled, без manual-space fallback. Импортированный кэш/recovery читается отдельно, без подключения. |
| Offline | **Known projects on this device / Известные проекты на устройстве**, **Open cached documents / Открыть кэш документов**. Не маскировать старый кэш под актуальный каталог. |
| Switch mismatch | **Project identity changed / Идентичность проекта изменилась**, исходные и новые URL/ID, предупреждение «старые правки не будут отправлены в новый проект». Без кнопки «перенести очередь». |
| Recovery | **Local recovery / Локальное восстановление**. Группы по исходным server URL/projectId/account/incarnation, path/generation/reason; read/select/copy exact Markdown. Не смешивать одинаковые пути разных namespaces. Raw-only — честный статус без обещания UI декодирования. |

Ошибки/статусы — доступные live regions и подписи, не только цвет/snackbar. Проверить 320×480, fontScale2, landscape, IME, keyboard navigation/TalkBack. Не помещать ключ в semantics/test evidence. «Ключ принят», «кэш синхронизирован», «только в комнате», «Remote подтвердил Markdown», «только локальная копия» — **разные статусы**.

## 8. Редактор и gates: сохранить без ослаблений

- `app/build.gradle.kts:12–38`: fingerprint покрывает app main/test (включая новые strings/UI/tests), web source/tests/scripts/config/lock и app Gradle. **Даже UI-only изменение отзывает VS-84 acceptance.**
- Report отсутствует → `EDITOR_WRITES_ENABLED=false`; stale/incomplete/неверный report или changed evidence → **ошибка сборки**. Не ручное обновление старого hash, не runtime checkbox и не `-PenableWrites`.
- Сохранить пять gates: schemaParity, roomInterop, noWriteOnOpen, scribeAckOrdering, recoveryConflict; exact schema/version/source/evidence path+hash checks. BuildConfig policy не подменять.
- Сохранить web typecheck → все tests → build → оба bundle smoke и зависимость packaging от полного native suite. Без `-x`, selective tests, hand-edited assets/DEX/BuildConfig.
- `editor-web/src/model.ts:58–67,130–218`, `validation.ts:141–225`, `color-safety.ts:17–43`: source guard до parsing; unknown schema/foreign winner/update preflight на detached clone **до live binding**; unsafe local/format/final IME блокируются до LocalUpdate/Changed/Flushed. Block permanent для incarnation, undo/Flush не обходят отказ.
- Сохранить typed bridge/generation/origin/main-frame/size checks, local assets/CSP/no network/no credentials; no-write-on-open, seed winner CAS, scribe/ACK ordering, recovery-before-dispose и newest-generation semantics.
- **INTEROP-01 остаётся FAIL_UPSTREAM**: Studio-only color round-trip теряет видимые пробелы; Android защищает от своей опасной публикации, не исправляет Studio и не возвращает утраченный им текст. Не объявлять «нормализацией»/PASS/skip. Текущая запись о 23 PASS / 1 FAIL_UPSTREAM / 0 SKIP, exit=1 — историческое evidence, не новый запуск VS-90.
- Offline только reader; Remote хранит **Markdown, не Y.Doc**, update ENQUEUED не durability ACK, protocol v1 не согласует editor schema. Last leave/crash/reset до materialization и окно до native snapshot/IME commit остаются рисками.
- Нет обещания произвольного Markdown, offline merge, полного OS kill/power-loss/hardware Keystore/OEM/API/provider matrix. Старые device probes — один API35/WebView124/IME, device transport controlled; **единого enabled APK + WebView + настоящий Remote/Studio E2E нет**. Identity UI не превращает прежние seams в такое доказательство.

## 9. Небольшие будущие задачи

Это **план, не созданные карточки и не разрешение менять файлы сейчас**. Все перечисленные write_paths — абсолютные exact files; фигурных glob/владения всем source tree нет. `/*` используется только для нового evidence/release каталога. Читаемые источники и Studio/Remote source не входят в Android write_paths.

### A0. Зафиксировать baseline и отозвать active acceptance перед source-изменениями

Зависимости: принят этот контракт.
Write_paths:
- `D:/VoxariumRemoteAndroid/verification/editor-write-gate.json`
- `D:/VoxariumRemoteAndroid/verification/identity-v1/prior-gate-vs84.json` (новый exact byte-copy)
- `D:/VoxariumRemoteAndroid/verification/identity-v1/baseline.json` (новый)

Приёмка: сохранены hashes источников/report/evidence/APK; прежний report архивирован byte-exact и удалён из active path **до** изменения covered source. VS-84 evidence/dist неизменны. Build без report штатно read-only; никаких новых true booleans. Это отдельное разрешённое действие, не обязанность implementation writers «чинить gate».

### A1. ServerProfile/ProjectBinding и local metadata migration

Зависимости: A0.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/security/ProfileStore.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/security/ServerProfileStore.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/security/IdentityModels.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/ProfileStoreTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/ServerProfileStoreTest.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/CredentialStoreTest.kt`

Приёмка: §3/§5.1, idempotent copy-on-write v1→v2, no URL/name dedupe, credentialId/alias unchanged, missing alias/corrupt vault отрицательные тесты, 0 network. Старый ProfileStore оставлен читаемым для migration; текущие callers не ломаются до A5.

### A2. URL-only verification без открытия space

Зависимости: A0; может выполняться параллельно A1.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/RemoteEndpoint.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/ServerVerifier.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/EndpointTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/ServerVerifierTest.kt` (новый)

Приёмка: prefix-preserving URL-only value, bounded me parser/user/protocol, TLS/no redirects, cancellation/stale revision; 0 WS/sync/create/write. Старый RemoteEndpoint.create остаётся совместимым до integration.

### A3. Project partitions и resumable migration всего durable state

Зависимости: A1, A2.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/documents/DocumentModels.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/documents/DocumentsRepository.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/documents/DocumentStateCodec.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/documents/DocumentStorage.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/documents/IdentityMigration.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/room/RoomRecoveryStore.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/documents/DocumentsRepositoryTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/documents/RepositorySafetyTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/documents/IdentityMigrationTest.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/room/RoomRecoveryStoreTest.kt`

Приёмка: §5.2–5.3, interruption после каждого commit, same path в разных URL/ID/accounts/incarnations, newer draft+pending+raw-only recovery сохранены byte-exact; ambiguous mapping только archive, 0 cross-target replay, corrupt/disk-full fail-closed. Legacy constructors/adapters сохранены до A5; нет автоматического удаления v1.

### A4. Native catalog adapter по принятому серверному контракту

Зависимости: A1/A2 и **утверждённые + реализованные catalog/capability/create/no-auto-create semantics из VS-89**. Документ VS-89 сам по себе не означает готовый сервер.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/ProjectCatalog.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/ProjectCatalogCodec.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/ProjectCatalogTest.kt` (новый)

Приёмка: exact согласованные endpoints/version/auth, ID не name; list/verify без мутаций, create explicit, uncertain outcome без blind retry, auth/TLS/invalid не legacy fallback; old server unsupported без догаданных запросов. Не менять file/room protocol по собственной инициативе.

### A5. Immutable server→project sessions и barrier/fencing

Зависимости: A1–A4.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/RemoteViewModel.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/connection/RemoteSession.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/RemoteConnection.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/data/transport/Frames.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/RemoteConnectionTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/FramesTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/transport/TransportSecurityTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ui/RemoteSessionTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/editor/EditorLifecycleTest.kt`

Приёмка: §6, v2 URL/hello/user.display_name/presence/close codes, me.user==hello.user, exact ID/storage_epoch checks, hello.seq rollback; v1 decoder только для локального импорта, **никакого v1 network fallback**; switch server/key/account/project/ID не меняет live binding; late replies/ACK/timeout/overflow/storage failure; **ни один старый queue effect не отправлен в новый space**. Если потребуется production-изменение RoomCoordinator/ScribeQueue — отдельная точечная корректирующая задача с exact расширением scope, не ослабление тестов.

### A6. Material3 серверы/проекты/recovery EN/RU

Зависимости: A5 (последовательно: общие ViewModel/session файлы).
Write_paths:
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/VoxariumRemoteApp.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/RemoteViewModel.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/connection/RemoteSession.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/connection/ProfileForm.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/connection/ProjectsScreen.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/main/java/com/voxarium/remote/ui/editor/RecoveryHub.kt`
- `D:/VoxariumRemoteAndroid/app/src/main/res/values/strings.xml`
- `D:/VoxariumRemoteAndroid/app/src/main/res/values-ru/strings.xml`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ui/ConnectionUiTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ui/RemoteSessionTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ui/ProjectsUiTest.kt` (новый)
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/ResourcesSmokeTest.kt`
- `D:/VoxariumRemoteAndroid/app/src/test/java/com/voxarium/remote/SmallScreenSmokeTest.kt`

Приёмка: §7, form без space, save≠verify≠sync≠saved; exact ID рядом с displayName; stale confirmation/replies fenced; offline/legacy/create states честны; recovery provenance разных проектов не скрыт; password safeguards/EN/RU/light/dark/font2/IME/TalkBack. Никакого auto-create от refresh/select.

### A6v. Зафиксировать version metadata нового APK

Зависимости: A6; до A7.
Write_paths:
- `D:/VoxariumRemoteAndroid/app/build.gradle.kts`

Приёмка: versionName/versionCode утверждены для нового upgrade artifact; applicationId и signing continuity сохранены, parser/gates/dependencies не изменены. Не выпускать параллельно A7 и не менять metadata после final fingerprint.

### A7. Независимая новая identity/editor/APK приёмка

Зависимости: A1–A6v, принятые серверные изменения и тестовый стенд; сначала closed-stage, затем решение о gate.
Write_paths:
- `D:/VoxariumRemoteAndroid/verification/identity-v1/*`
- `D:/VoxariumRemoteAndroid/verification/editor-write-gate.json`
- `D:/VoxariumRemoteAndroid/VERIFICATION.md`

Приёмка: вся §10, новое evidence и независимый fingerprint, существующие regressions без skip; report только после доказательства пяти gates на final source. Если source исправляется — отдельная корректирующая задача/повтор приёмки. Старые `verification/vs84/*`, исторические evidence и release helpers не переписывать.

### A8. Новый debug artifact и инструкция upgrade

Зависимости: A7 и enabled-APK проверка.
Write_paths:
- `D:/VoxariumRemoteAndroid/dist/identity-v1/*`
- `D:/VoxariumRemoteAndroid/README.md`
- `D:/VoxariumRemoteAndroid/RELEASE.md`

Приёмка: новые helpers/manifest/APK/size/SHA-256/signer/BuildConfig/assets/provenance; старый dist VS-79 не заменяется. Версия устанавливаемого upgrade утверждена в A6v до final fingerprint. Нельзя после acceptance тихо изменить Gradle ради номера релиза.

## 10. Новая проверка APK после реализации

Все пункты ниже — **будущие проверки**, в VS-90 не выполнялись. VS-79 и VS-87 не принимают новый source/UI/migration.

1. **Manifest/toolchain.** Новый final source manifest, независимый hash по фактическому gateInputs (sorted relative POSIX UTF-8 path + NUL + raw bytes + NUL), сравнение Gradle. Отдельно exact wrapper/JDK/node/npm/lock/deps/WebView. Текущий wrapper — **8.14.7-bin** (VS-87), исторический RELEASE — **8.14.3-all**; не откатывать пользовательский wrapper и не подменять историю. Fingerprint не покрывает всю toolchain/node_modules.
2. **Closed build.** Controlled task-private source-copy без active report; полный `generateEditorAssets --info --stacktrace`, затем forced `printEditorGateFingerprint assembleDebug testDebugUnitTest lintDebug` без `-x`/filters/cache-PASS. Все web tests, оба smoke, native suites, lint XML/warnings. Исторические **445 web / 362 native** — baseline, не неизменный будущий счётчик. Missing report false; stale source/changed evidence/invalid fields/path — negative controls с ошибкой.
3. **Настоящий upgrade.** Owned disposable установка прежнего APK с synthetic profiles/Keystore/mirror/queue/newer drafts/conflicts/raw-only journals; обновить **без uninstall/clear data**, с совместимой подписью/package. Проверить storage migration и restart offline до любого connect. Keystore failure/corrupt IO — controlled fault tests отдельно, не удаление личных alias. Crash injection каждого migration phase; exact recovered bytes и source provenance.
4. **Identity matrix.** Одинаковые labels/разные IDs; один ID на разных URL/prefix/accounts; rename display; ключ same account/new account; ID A→B; тот же ID после server replacement; unknown mapping; старый pending+новый draft; поздние ACK/catalog/create/verification callbacks. Wire/server-state assertion: **0 старых effects в B**; обе версии A читаются. Disk-full не выдаёт успешный switch.
5. **Согласованный API.** Реальный isolated Remote нового контракта: HTTP-only verify создаёт 0 spaces, list/refresh/select не создают, explicit create единственный источник creation, timeout/duplicate ID/missing/deleted ID и отсутствие server replay проверены по серверному контракту; GET исходного ID и отдельный Select, без автоматической привязки победителя гонки. Отдельный старый Remote: me работает, catalog disabled, upgrade-required без v1 WS/identity mismatch. Не использовать production данные/ключи.
6. **Editor regression final source.** Реальный native transport/repository/coordinator/Atomic storage + RoomRuntime + эталонный Studio editor: schema parity, 10 clean opens→0 writes, seed race/dirty-at-join, non-scribe/scribe handoff, ACK newest snapshot, lost ACK, reset/disconnect/rejoin, recovery и no replay. Повторить unsafe initial/winner/foreign/local/final-IME color guards и safe Unicode/color save→last leave→fresh room. Studio-only INTEROP-01 фиксировать отдельно как FAIL_UPSTREAM при воспроизведении, не скрывать exit=1.
7. **Новая acceptance.** Только после независимого решения записать новый evidence/report для **этого** fingerprint и выполнить полный enabled build. Проверить true и в generated Java, и в APK DEX; negative controls остаются. Версии/исходники после acceptance не меняются.
8. **Именно новый APK на device.** Указать exact installed artifact/hash/package/version/signer/API/provider/IME. EN/light, RU/dark/font2, small screen, keyboard/rotation/password clearing, server verify/picker/create/upgrade-required/offline/recovery. Реальный dirty EditorScreen: composing IME → Back/background/rotation/disconnect/project/server/key switch; Flush/ACK или durable recovery, без cross-space effects. TalkBack и OS kill/power-loss/hardware checks отмечать своим результатом, не выводить из unit suite.
9. Для заявления полного E2E нужен **единый enabled APK+WebView+настоящий Remote/Studio**. Если снова только native/network и controlled-device seams, явно сохранить это ограничение; не повышать его до PASS E2E по совпадению APK.
10. **Artifact audit.** aapt/apksigner/zipalign, package/version/signature continuity; APK assets = новые generated bytes, local CSP, no source maps/tests/verification/keys. Свои size/SHA-256, source/report/evidence hashes, команды/логи/warnings. Heuristic secret scan не выдавать за абсолютное доказательство.
11. **История и безопасность стенда.** Новый evidence namespace и temp будущей задачи; retained outputs скопировать из disposable temp до Done. Старые APK/reports/evidence неизменны. Только разрешённые owned test процессы/listeners, без личных устройств/shared adb/IDE/production Studio. Реальные server/device прогоны требуют отдельной разрешённой задачи; VS-90 их не разрешает.

Старые `dist/snapshot.py`, `dist/audit-apk.py`, `dist/reproduce.ps1` привязаны к VS-79/VS-84 bytes/evidence/toolchain. Новому APK нужны новые helpers в `dist/identity-v1/`, а **не удаление byte-equality assertions из исторического workflow**.

## 11. Итоговые условия допуска реализации

Согласовать с VS-88/VS-89 только межкомпонентные решения: public ID/query/hello/incarnation mapping, capability/version, catalog/create wire и uncertain-outcome, серверный запрет auto-create и legacy policy. До этого UI/model/миграцию можно проверять локально в read-only режиме, но нельзя объявлять catalog/write binding совместимыми с будущим сервером.

Непересматриваемые Android-инварианты: **URL+ID namespace с account/incarnation partition; никакого слияния по имени; durable source/recovery остаются; смена ID никогда не переназначает старую очередь; проверка сервера без WS; editor fail-closed и новая APK acceptance после covered изменений.**

Статическая проверка VS-90: результаты двух read-only субагентов прочитаны и интегрированы; отдельный review сопоставил migration/epoch/legacy policy с VS-89. Исправлены расхождения draft: legacy name не v2 ID, storage_epoch отделён от ID/room epoch, v1 fallback запрещён, rollback/downgrade явно ограничены. Документ прочитан обратно через Studio, проверены структура и write_paths; runtime-проверок это не заменяет.

## 12. Междокументное согласование VS-91

Единый wire/migration contract сопоставлен с [[remote-identity/server-design]] §§2–5 и [[remote-identity/studio-design]] §§6/9/13: POST только `{id,display_name}`, без server replay; operation_id Studio — лишь локальный журнал. Unknown outcome → GET исходного ID и отдельный Select, не автоматическая привязка победителя гонки. Canonical ID и initial storage_epoch мигрированного space оба равны прежнему UUID байт-в-байт; space_instance_id в Studio — только локальный alias storage_epoch, не дополнительное поле Remote.

Один профиль на URL в Studio и несколько профилей/account partitions Android — намеренное различие локального хранения, не конфликт wire или новый RBAC. Нормализация URL остаётся платформенной и не даёт права сливать существующие namespaces; exact ID/display validation, protocol/catalog v2, routes/errors/pagination/snapshot — §4.2.1 и Remote §3. При rollback сохраняются очереди/recovery (§5.3); editor gates, hash/fingerprint acceptance и ограничения INTEROP (§8) не пересматриваются. Таблица закрытых расхождений — Studio §13; новых runtime/E2E доказательств VS-91 не добавляет.
