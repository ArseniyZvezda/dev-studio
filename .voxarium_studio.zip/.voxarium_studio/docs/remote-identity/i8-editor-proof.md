# I8 — локальный proof materialized Markdown (VS-174)

Основа: [[remote-identity/runtime-integration-plan]] §3.3–3.4/I8, [[remote-identity/studio-design]] §5.2–5.3. Только synthetic/local backend; R3, новый Remote wire, Enable и переделка frontend VS-173 вне этой задачи.

## Контракт до реализации

Join правильно отзывает initial ordinary receipt: Markdown диска не доказывает RAM комнаты. `record_saved` правильно подтверждает только writer. Для clean collab и non-scribe нужен собственный receipt, а не копирование scribe receipt или heartbeat `dirty=false`.

Локальный API: `POST P/remote/editors/{editor_id}/materialization` выдаёт одноразовый RAM ticket для точных backend_epoch/G/document_path/client_instance_id/sid/version/revision. `POST .../materialization/confirm` принимает тот же tuple, ticket и **полный materialized Markdown текущего frozen editor**, возвращает новый собственный `last_saved_version`. `P` — неизменяемый project-scoped selector с runtime epoch; root берётся только из bound Ctx, никогда из JSON. Поле `revision` добавляется к lease DTO, это серверный CAS, не локальный version и не Remote document rev.

Frontend обязан заморозить input, дождаться своих queued saves/объявлений dirty и применённых room frames, захватить immutable lease/epoch/G/path/sid/version, получить ticket, материализовать собственный editor (не подменять экран текстом сервера), подтвердить ticket и проверить неизменность snapshot до ACK. 409 не разрешает overwrite/Keep mine. ACK остаётся отдельным существующим запросом; close/leave/Y.Doc destroy только после подтверждения. Cancel до fence сохраняет прежний editor; после fence требуется прежний paused/resume contract. Текущий frontend этот API ещё не вызывает.

## Серверное доказательство

Оба шага проверяют живой exact lease, отсутствие snapshot/fence, чужих/in-flight saves и admitted mutations. Ticket привязан к owner/root, session object, room epoch, локальной revision наблюдаемых room событий, generation, lease version/revision, exact agreed base rev/hash и fresh uncached Markdown bytes. Confirm повторяет все проверки синхронно, потребляет ticket и сравнивает materialized UTF-8 bytes с новым чтением файла. Никакой Markdown write, remote send, Yjs persistence или implicit join.

Разрешённые room anchors: (1) явный `joined` с `dirty=false`, точным base rev, room epoch и завершённой seed handshake; (2) exact ACK собственного live pending put этого Ctx, с тем же target/G/path/sid/room epoch и room revision, захваченными перед save, плюс завершённый однозначный writer save. Второй anchor служит room/save evidence, **не** чужим lease receipt: каждый peer подтверждает собственный materialized snapshot и получает новый receipt. Любой новый update/seed/rejoin/reset/disconnect инвалидирует tickets/room anchors и подтверждения затронутых leases. Подтверждение повторно проверяется перед ACK/close и drain, не только в момент выдачи.

Dirty/unknown/expired/divergent/in-flight/stale tuple остаются blocked. Dirty peer может быть подтверждён лишь после совпадения его свежего frozen Markdown с доказанным peer-final-save; dirty bool никогда не доказательство. Unversioned/reused-version dirty сохраняет minimum_save_version. Late callbacks не получают latest G.

## Ограничения evidence / отсутствующие seams

Remote не связывает Yjs state vector с Markdown revision и не проверяет materialization: existing live put принимает Markdown участника комнаты. Поэтому данный proof проверяет **переданный конкретным editor материализованный snapshot**, не является независимым серверным Yjs renderer или доказательством всех ещё не доставленных remote edits. Remote peer `change` не несёт sid/room epoch/vector; только disk/base/hash недостаточны для восстановления утраченного room anchor. Seed race `seeded.ok=false` не сообщает текущий dirty/revision. Такие неизвестные случаи fail-closed; нужны отдельные согласованные causal room-save/seed evidence seams, не выдуманный новый wire в VS-174.

## Реализованный API для frontend

Оба POST project-scoped, authenticated и `Cache-Control: no-store`. Первый запрос не принимает ни `dirty`, ни чужой receipt, ни content. Полный обязательный body:

```json
{
  "backend_epoch": "<captured backend epoch>",
  "expected_binding_generation": 0,
  "document_path": "guide/spec.md",
  "client_instance_id": "<original browser instance>",
  "sid": "<original live sid>",
  "version": 0,
  "revision": 1
}
```

Ответ первого POST — lease DTO (`editor_id/backend_epoch/binding_generation/document_path/client_instance_id/lease_expires_at/last_saved_version/version/revision/dirty/confirmed`) плюс `proof_id`. Confirm добавляет к **тому же** body `proof_id` и `content` — полную UTF-8 сериализацию собственного editor. Ответ confirm — lease DTO с новым положительным `last_saved_version`, `dirty=false`, `confirmed=true`; автоматического `editor-ack` нет. Ticket один на sid, замена отзывает прежний, попытка confirm с неверным token/content его потребляет. Отсутствующий/stale identity/version/revision нельзя заменить latest значениями в отложенном callback.

`revision` читается из registration/heartbeat DTO после применения room frames и заморозки snapshot, не вычисляется клиентом. Heartbeat с `dirty=false` не выдаёт evidence; новый dirty/version меняет CAS. До confirm нельзя послать новый dirty heartbeat или применить новый room update и продолжить старым snapshot. Для non-scribe сначала завершённый local peer-final-save + exact ACK, затем **собственный** proof/receipt и существующий editor-ack. Writer вправе использовать обычный successful save receipt либо reproof того же snapshot без ещё одной записи. Любое новое изменение требует нового snapshot/proof; это не разрешение разрушать DOM/Y.Doc.

422 `invalid_request` — strict schema/неизвестные поля; typed 409: `pending_edits`, `unknown_sid`, `unknown_editor`, `editor_mismatch`, `editor_lease_expired`, `stale_editor_version`, `stale_backend_epoch`, `stale_binding_generation`, `mutation_busy` по существующему gate. Эти отказы не disk conflict и не разрешение на overwrite. Byte-exact сравнение сохраняет CRLF/Unicode; разница сериализации/пробелов — divergence, не скрытая нормализация/запись.

## Владельцы и ограничения

- `sync/transitions.py`: exact lease CAS, initial untouched marker, собственный materialized receipt и сохранённый fresh validator; heartbeat/close/ACK/sealing не обходят его. Ordinary save/receipt и initial ordinary read не заменены.
- `sync/service.py`: ephemeral tickets/anchors на существующем RemoteSync; наблюдение существующих joined/seeded/update и local live pending/ACK. Incoming/outgoing update инвалидируется до send-lock ожидания; unknown/duplicate seed reply не оживляет anchor. Во время quiesce post-ACK update/expiry блокирует, сохраняя комнату и browser, без destructive close.
- Перед leave повторно проверяются все coordinator room ACK, в том числе после durable evidence callback. После intentional fence существующие I5 corpus/checkpoint fingerprints защищают leave/stop; disconnect не получает эту привилегию.
- `api/sync.py`: два узких local POST; новый Remote wire/runner/store не добавлен. Полный materialized Markdown/tickets/Yjs не попадают в durable journal.
- Conservative duplicate/no-op updates тоже отзывают anchor: relay не умеет независимо интерпретировать Yjs semantic state. Неизвестное состояние не чинится лишним Markdown save автоматически; точный отсутствующий seam — causal room/vector↔saved Markdown checkpoint. Production cross-Studio peer-final-save, frontend wiring и R3 этим не подтверждены.

## Проверка VS-174

Graphify использован до поиска/изменений; proof/API записан в этот документ **до реализации**. Исходные snapshots изменяемых owners сохранены только в task temp, посторонний dirty diff не откатывался; `test_remote_editor_leases.py` совпадает с исходным байт-в-байт.

Команда из корня (backend venv, `PYTHONDONTWRITEBYTECODE=1`):

```powershell
backend/.venv/Scripts/python.exe -m pytest -n0 -p no:cacheprovider --basetemp=.voxarium_studio/temp/TASK-174/final2 backend/tests/test_remote_editor_leases.py backend/tests/test_remote_transitions.py backend/tests/test_remote_binding_drain.py backend/tests/test_remote_mutation_gate.py backend/tests/test_remote_runtime_binding.py backend/tests/test_remote_profile_lifecycle.py -q
```

Итог: **616 passed, 0 skipped**, 88.74 s. Новый proof suite — 85 tests: positive clean/accepted seed/local peer-final-save (также во время quiesce), отдельный peer receipt, writer reproof, zero Markdown writes, exact tuple/token/revision, same-stat disk/base divergence, expired/in-flight/overlap, foreign root/capabilities, post-ACK/send-lock/evidence-sink races, generic change, unknown seed и cancel/late G. В первом общем прогоне было 614 passed + 1 fixture setup error (`teams/store.py:sync_to_db`, Windows `WinError 5` при replace default-team.yaml, вне proof); полный повтор выше прошёл без изменений этого owner. Осталось существующее предупреждение pytest-asyncio о default fixture loop scope; skips/errors в итоговом прогоне нет.

Независимый read-only evidence audit выявил отсутствующий cross-Studio causal seam, оставленный fail-closed. Независимые tests сначала воспроизвели post-ACK destructive close и late seed revival; обе regression-проверки исправлены без xfail. Финальный независимый delta review: **блокеров не обнаружено**, новый suite 84 passed/0 skipped (до добавленного отдельного cancel regression); итоговый parent run включает все 85. `git diff --check`, AST parsing и явная проверка whitespace для untracked owners пройдены.

Remote package установлен в том же backend venv (import path проверен), но `test_remote_sync.py`/реальный interop, frontend typecheck/jsdom и UI smoke **не запускались** в этой synthetic/local задаче и не выданы за passed. Production instance/ключи/серверы/Enable не трогались; R3 gate не закрыт.
