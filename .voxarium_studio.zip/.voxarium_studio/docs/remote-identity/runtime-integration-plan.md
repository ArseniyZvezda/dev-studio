# VS-164 — план подключения Remote runtime S4/S5

16.11.2026. **Исполнимый backlog интеграции, не объявление готовности Select/Enable.** Единственный результат VS-164 — этот документ. Основание: [[remote-identity/studio-design]] §4.1–4.3, §5.2–5.3, §6–9, S4–S7; [[remote-identity/catalog-api-activation-plan]] C5/C7 и R1–R3; [[remote-identity/delivery-authorization]].

Общее разрешение на доставку уже дано; повторное разрешение на рутинную интеграцию не требуется. Ограничение **этой** карточки — только документ: код, config, runtime, сеть, реальные home/ключи и данные не менялись и не читались. Android, Admin, AI, новые права доступа и переаудит foundations не входят в backlog ниже. Сохранность Markdown, изоляция root/Ctx и явное согласие не сокращаются ради скорости.

## 1. От чего продолжаем

Graphify query/explain по D:/VoxariumStudio/graphify-out/graph.json выполнены до чтения owners; широкие ответы усекались, поэтому факты ниже проверены по текущим исходникам. Строки — координаты снимка checkout, не контракт стабильных номеров. Старый activation plan описывает тогдашний остаток: выполненные C5/C7 и VS-159/160/162 не назначать повторно.

| Принятый компонент | Текущий owner / доказанное поведение | Остаток интеграции |
| --- | --- | --- |
| VS-159: private consent | [BindingSnapshot.require_confirmed](../../../backend/voxarium_studio/sync/bindings.py#L150), [RemoteBindings.read/save](../../../backend/voxarium_studio/sync/bindings.py#L187), строки 196–309: exact root/profile/URL/ID/identity revision/incarnation, selected не confirmed, whole-file fingerprint CAS, atomic replace | Не подключён к inventory/runner. Нет публичного CAS-remove для edit_id/unbind. Отсутствие файла — только отсутствие нового store. |
| VS-160: state v2 | [SyncNamespace](../../../backend/voxarium_studio/sync/state.py#L127), [SyncStateV2](../../../backend/voxarium_studio/sync/state.py#L205), validate_hello 314–333, save 335–371: root+URL+ID, полная проверка tuple, incarnation/cursor rollback блокируются, missing отдельно от ошибки | RemoteSync всё ещё импортирует SyncState v1. V2 не проверяет account/protocol/consent, не является concurrent-writer CAS; saves должен сериализовать runtime. |
| VS-162: reservation | [ReservationOwner.reserve/release](../../../backend/voxarium_studio/sync/reservations.py#L44), [initialise_workspace](../../../backend/voxarium_studio/core/workspace.py#L59), [shutdown_workspace](../../../backend/voxarium_studio/core/workspace.py#L113) | Один owner уже есть, но runner его не использует. Он создаётся при initialise_workspace, тогда как bootstrap sync.start уже выполнен: [lifespan 152–168](../../../backend/voxarium_studio/main.py#L152). Передать **тот же** owner до первого startup, не делать второй registry. |
| C5 / VS-141 | [ProfileLifecycle](../../../backend/voxarium_studio/sync/profile_lifecycle.py#L68): register_context, attach, operation, nonblocking guard, logical leases; [_ProfileRemoteSync](../../../backend/voxarium_studio/core/context.py#L56) держит lease через runner/reconnect lifetime | [RemoteCatalogRuntime.__init__ 191–194](../../../backend/voxarium_studio/sync/catalog_runtime.py#L191) не задаёт inventory callback. Authoritative inventory и положительного drain proof нет. Enabled resident/live lease делает local_active независимо от inventory.drained (233–252). |
| C7 / VS-142 | [_mutate_profile](../../../backend/voxarium_studio/sync/catalog_runtime.py#L371), [RemoteProfiles._consumers](../../../backend/voxarium_studio/sync/profiles.py#L129), credential/URL/delete 193–246: lifecycle → config → credentials, CAS/journal, typed отказ | HTTP уже подключён. Не переписывать его. Добавить только связь реального S5 proof/consent invalidation с существующим guard; URL/delete и после drain требуют unbound. |
| Каталог / Create | [RemoteCatalogReady](../../../backend/voxarium_studio/sync/catalog_runtime.py#L167), [providers_for/Verify](../../../backend/voxarium_studio/sync/catalog_runtime.py#L537), [CatalogReadService.snapshot/resolve_legacy](../../../backend/voxarium_studio/sync/catalog_read_service.py#L78), [CatalogCreateRuntime](../../../backend/voxarium_studio/sync/catalog_create_runtime.py#L139) | Verify работает через HTTP owner. Production list всё ещё _UnavailableOutbound (126–135), Create transport=None (catalog_runtime 632–639), snapshot/resolve не выставлены production-композицией. VS-152 подключил handlers, **не снял R3 gate**. |
| Identity/config | [ProjectIdentity](../../../backend/voxarium_studio/core/project_identity.py#L20), [identity_migration_plan](../../../backend/voxarium_studio/core/project_identity.py#L110), [SyncConfig/AppConfig](../../../backend/voxarium_studio/core/config.py#L443), [save_config](../../../backend/voxarium_studio/core/config.py#L631) | ID — пока metadata; legacy sync.space сохраняется. Diagnostic fingerprint не CAS. save_config atomic replace без guarded identity CAS/journal; обычные settings уже не принимают identity/target: [SettingsUpdate](../../../backend/voxarium_studio/api/project.py#L84). |
| Runtime sync | [RemoteSync._start_runner](../../../backend/voxarium_studio/sync/service.py#L211), [_converse](../../../backend/voxarium_studio/sync/service.py#L325), [_disconnected](../../../backend/voxarium_studio/sync/service.py#L359) | Запуск по legacy enabled/url/space + URL-key, hello v1 → SyncState.load. Disconnect очищает pending/live writes; stop/reconfigure cancel-ят задачи. Это не drain и не новый consent flow. |
| Save boundary | [api/docs.write_doc](../../../backend/voxarium_studio/api/docs.py#L304), [RemoteSync.note_live_write](../../../backend/voxarium_studio/sync/service.py#L691), [DocStore](../../../backend/voxarium_studio/teams/docs.py#L300) | Неизвестный sid сейчас игнорируется, затем Markdown всё равно записывается. Общего generation/mutation gate, editor lease и доказанного flush ACK нет. Проверка только в HTTP не защищает MCP/remote apply/folder move. |
| UI/immutable context | [sync store](../../../frontend/src/stores/sync.ts#L33), [project client](../../../frontend/src/api/client.ts#L776), [ProjectSession](../../../frontend/src/session/project-session.ts#L16) | Текущий sync.save вызывает старый PUT /sync; scope capture защищает runtime binding, но не смену remote generation. Global [remote.ts](../../../frontend/src/api/remote.ts#L235) и remote-servers store уже есть: не дублировать их. VS-163 — отдельная текущая карточка UI ключа, не зависимость save fencing. |

## 2. Границы и реальные незакрытые gates

### 2.1 Authoritative inventory — не список открытых вкладок

Будущий callback C5 объединяет **все** validated private rows, включая unopened roots, selected и confirmed, с starting/resident/failed-cleanup contexts и in-flight Verify/read/Create/runner leases. Сопоставление — profile_id **или exact normalized URL**; explicit recovery включает current/old/target URLs из существующего [_recovery_urls](../../../backend/voxarium_studio/sync/catalog_runtime.py#L292). Для этого нынешнего callback только с profile_id недостаточно: расширяется существующий seam, не создаётся второй inventory service.

Private store с fingerprint=None, корректный пустой JSON, отсутствие resident contexts, успешный Verify, отсутствие ключа и bounded recents **не доказывают отсутствие unopened legacy bindings**. [BindingInventory 24–36](../../../backend/voxarium_studio/sync/profile_lifecycle.py#L24) требует явной полноты. [load_recent 569–593](../../../backend/voxarium_studio/core/workspace.py#L569) проглатывает ошибки и ограничивает список: это discovery hint, не authoritative census. Не обходить диск, не автоматически открывать roots и не считать исчезнувший/недоступный root unbound.

**Gate L (положительная legacy completeness) сейчас не обеспечен owning source.** I1 подключает доказанные строки и сохраняет unknown/recovering для неполного legacy покрытия; не фабрикует known. До появления принятого доказательства полноты sensitive C7 mutations, включая **первичную запись ключа нового профиля**, остаются закрытыми даже при пустом новом store. Это не мешает read-only metadata и локальному edit_id. Проектный catalog/Select/Enable flow может продолжаться лишь с уже usable profile+credential либо явно привязанным ENV URL/key; собственный exact root consent не подменяет отсутствующий credential и не снимает L; не ослаблять C7 ради их выпуска. S9/I15 решает только явно предъявленные legacy roots и mapping, не доказывает отсутствие всех остальных проектов на диске. Полное снятие L — отдельный release check владельца, а не скрытый результат S4 storage или этого плана.

Отдельно учесть browser editing inventory. [Legacy collab](../../../backend/voxarium_studio/ws/routes.py#L321) захватывает Ctx, а [legacy /ws 338–378](../../../backend/voxarium_studio/ws/routes.py#L338) подписывается на переключаемый browser_bus: initial hello не привязывает его навсегда к одному root. I4 учитывает legacy capability/visibility при selection switch; unknown живой клиент блокирует затронутый cutover до close/reload, не трактуется как отсутствие editor.

### 2.2 Совместимый Remote

Текущие [Studio protocol](../../../backend/voxarium_studio/sync/protocol.py#L14) и [Remote protocol](../../../remote/voxarium_studio_remote/protocol.py#L1) — v1; [socket_url](../../../backend/voxarium_studio/sync/protocol.py#L61) строит /api/v1/sync. [Remote app](../../../remote/voxarium_studio_remote/app.py#L77), [Hub.connect](../../../remote/voxarium_studio_remote/hub.py#L134) и [Store.space](../../../remote/voxarium_studio_remote/store.py#L200) ещё используют name/autocreate. Не объявлять v2 существующим по готовому client adapter или Admin EXE.

Повторно использовать **R1 → R2 → R3** и exact write_paths из [[remote-identity/catalog-api-activation-plan]] §5, не создавать конкурирующую серверную цепочку. R3 принимается целиком: schema/catalog + HTTP v2 + strict-connect/unknown-ID/v1 rejection + snapshot pagination/epoch/seq + legacy resolution. Одного health capability недостаточно. В просмотренной текущей доске нет выпущенной серверной карточки этой цепочки; при назначении Producer связывает зависимости с реальными карточками, а не с выдуманными VS-номерами.

До R3 можно реализовать и принять локальное wiring и fake/in-process boundary tests; **реальные list/Create/Select/Preview/Enable/новый WS закрыты**. Никакого v1 fallback для активированной новой модели. Дополнительный security rollout gate — Remote credential-generation enforcement/отзыв уже открытых WS (server-design §6/S4); R3 сам его не доказывает.

### 2.3 Неизменяемые основы

Persistent ID не заменяет runtime project_id/backend epoch/root, ProjectSession, desktop registry/storage keys, MCP owner и пути AppContext. Разные copies того же ID остаются разными Ctx; reservation ограничивает лишь один backend, не другие процессы/машины. Pure rename профиля/проекта не меняет binding generation и не reconnect-ит.

Новая модель активируется только через barrier и обновлённые редакторы. I6 сохраняет durable **completed activation evidence exact canonical root** в том же transition journal без GC в этом increment; этот маркер имеет приоритет над восстановленным legacy config и наличием/отсутствием private binding row. Это не новый переносимый flag и не разрешение автоматически завершать pending phase. Само наличие project_identity, уже создаваемое S1, **не считается** активацией. Canonical project commit удаляет sync.space; normal settings save не должен восстановить legacy поле или сбросить revision/target. Определение активированного canonical формата и незавершённого journal проверяется strict чтением disk bytes; mismatch/ручной checkout не включает legacy reconfigure. Никаких новых переносимых profile/consent/secret полей или второго изменяемого space. До явной активации сохраняется прежний legacy режим; после неё downgrade config не оживляет старые callbacks.

## 3. Порядок интеграции и владения блокировками

Следующие сущности — **планируемое** wiring в предусмотренном studio-design sync/transitions.py и текущих owners, не названия уже реализованных API. Не вводить новый repository, transport, event bus, registry или универсальный transaction framework.

### 3.1 Attach/startup

1. Один app lifespan закрепляет personal home и создаёт существующие ProfileLifecycle и ReservationOwner до первого ctx.startup. Тот же reservation owner получают bootstrap и последующие resident contexts; selection/reinitialise его не заменяют.
2. Для активированной модели strict disk snapshot/journal → project revision/URL → private BindingSnapshot.require_confirmed → exact profile/credential binding → namespace SyncStateV2. Missing/selected/stale consent даёт binding_required **до key lookup/WS**. Corrupt/unknown-version store не становится fresh state.
3. До публикации runner получить C5 logical attach lease с profile_id и destination reservation для canonical root. Проверки snapshot/CAS повторить после любого await и перед публикацией. Если вторая reservation проиграла, снять только **свой** новый attach lease; alias должен переиспользовать consumer, а не запускать второй по тому же ReservationLease.
4. Захватить immutable transient binding: root descriptor, ID/URL/profile, identity revision, G, expected incarnation, profile/credential observation. Для runner pure metadata rename отличать от URL/credential drift: [profile_token_revision/source](../../../backend/voxarium_studio/sync/credentials.py#L337) и exact endpoint не меняются от имени. Rename может инвалидировать выполняющийся catalog/prepare CAS, но не вызывает stop/reconnect или новый G действующего consumer. Старт новой модели — только после отдельного Enable и compatible protocol. Реконнект удерживает своё владение и заново проверяет captured fences; он не берёт актуальную generation из mutable config.
5. Startup failure/stop сначала действительно закрывает и join-ит runner/tasks, затем release точных leases. Не release в начале cancel/shutdown; failed cleanup остаётся учтённым. При запрете admission не останавливать jobs другого Ctx.

### 3.2 Lock/CAS discipline

- Ctx identity asyncio-mutex выбирает change/phase. Во время сетевого/editor ожидания остаётся только логическое состояние quiescing; ACK/save/read-loop не должны ожидать mutex, удерживаемый командой, которая ждёт их.
- Короткая финальная секция: **Ctx transition ownership → общий DocStore mutation gate → C5 lifecycle admission → application_config_transaction → credential lock (если нужен)**. ReservationOwner lock — короткий leaf reserve/release, без callbacks/await и без обратного захвата этих locks. S2 mutation никогда не захватывает Ctx/DocStore после lifecycle.
- Thread lifecycle lock, OS/file-config lock, credential lock не держатся через await. Длительные HTTP, WS send, editor ACK и disk-preparation выполняются вне них; logical lease не равен thread lock. Нельзя вложить второй application_config_transaction с новым OS lock descriptor для «реентерабельности».
- Существующий S2 порядок lifecycle → config → credentials сохраняется. I1 добавляет **узкую финальную проверку inventory fingerprint/coverage под уже взятой config transaction** до journal/key/publication: нынешняя observation до неё не защищает от concurrent private writer. Production binding writers участвуют в том же lifecycle ordering и whole-file CAS. Изменился inventory — refusal/reprepare, не overwriting. Межпроцессное отсутствие active consumers не обещается.
- Для private publication внутри уже взятой S2 config transaction I6 добавляет узкий **внутренний transaction-aware seam в RemoteBindings** (планируемый, сейчас отсутствует): shared validation/CAS/atomic replace без повторного application_config_transaction. Public save/remove сами берут transaction ровно один раз; coordinator/S2 hook вызывает внутренний seam только под своим lifecycle→config владением. I14 использует его после profile CAS, durable journal и до credential/publication. Отказ оставляет recovery fence, не восстанавливает старый confirmed. Это расширение текущего owner, не новый store/framework; тест считает OS lock acquisition, не лишь отсутствие deadlock.
- SyncStateV2.save сериализуется одним namespace writer, не модифицируется параллельно ACK и reconciliation. Immutable checkpoint заменяется целиком с проверенной копией docs; формат VS-160 не переизобретается.
- Финальный CAS включает runtime selector/backend epoch, R/G, change_id/TTL, config **bytes fingerprint**, private whole-file fingerprint, profile/credential observation, local Markdown fingerprint и, для select/enable, exact catalog ID/incarnation/snapshot seq. Подтверждение — exact URL+ID из preview. Недостаточно проверить только R или hash имени файла.
- app.state.project_lock не используется как длительный drain lock. Существующие settings writers координируются лишь на коротком commit, повторно читают актуальный config; unrelated save не должен затереть identity. Send/state/DocStore locks отпускаются до ожидания remote ACK.

### 3.3 Общий mutation gate

Gate находится в **том же bound DocStore**, который используют browser, MCP/агенты и remote apply. Он охватывает write/create/exclusive create/delete/move/rename/folder rename/delete с затронутыми документами, а не только PUT body. Generation проверяется внутри gate **до** filesystem side effect и снова перед remote send/apply.

После активации любая HTTP mutation документов требует captured expected_binding_generation; browser editor ещё editor_id, collab ещё sid. Missing G → reload_required, stale G/unknown sid → 409 до Markdown write, без fallback в «обычный save». In-process MCP не подделывает HTTP payload: работает локально через свой DocStore и тот же barrier; на краткий final snapshot получает сериализацию/typed retryable отказ, не остановку агента. Внешний FS/VCS не перехватывается gate — его ловит повторный fingerprint/CAS. Events публикуются вне reentrant mutation-critical section.

Во время quiesce разрешаются только завершающие saves **ранее зарегистрированных** leases старого G, пока backend не подтвердил их last_saved_version. Новые joins/rejoins/editor leases/reconnect/target changes закрыты. Все browser instances и legacy project WS учитываются; истёкший heartbeat/молчание/закрытие socket не равны clean ACK. Legacy editor без editor-lease/flush capability требует reload/закрытия с доказанным сохранением, иначе blocked. Автоматически подставить latest G в старый callback запрещено.

### 3.4 Drain → fence → disabled commit

1. **Prepare** read-only: validate R/config fingerprint, old/new tuple, профиль/catalog/reservation collision; сохранить change_id/TTL и expected evidence в памяти. Не резервировать новое назначение побочным эффектом prepare, не писать config/base/Markdown. Offline edit_id без каталога допустим при отсутствии unresolved editors/saves.
2. **Quiesce** старого Ctx: freeze input, flush debounce/Markdown, backend сверяет завершённую save version по lease; scribe flush, дождаться exact pending ACK/nack reconciliation, только затем leave/закрытие rooms. [Нынешний _flush](../../../backend/voxarium_studio/sync/service.py#L667) — полезная отправная точка, но его timeout/empty _pending после disconnect не являются доказательством drain.
3. **Fence** старых sid/leases/retry/callbacks → close/join old runner. Сохранить старые namespace/checkpoint и target-bound unresolved evidence; не вызывать прежний cancel+clear как реализацию drain. Не держать send/DocStore lock в ожидании ACK.
4. **Commit point** — atomic replace project config с R+1, новым ID/URL и enabled=false. До него durable nonsecret change journal; после него private CAS: select/migrate → selected, disable → прежний выбор selected, edit_id/unbind → remove; unbind очищает URL, но не локальный ID. Старую reservation release только после доказанного runner stop. Config/revision — источник истины, private mismatch не разрешает старт.
5. Публикуется Ctx-only remote.binding_change, обновляется metadata без project.opened, rebind/remount или смены runtime handle. Успешный commit даёт новый random G; repeated change_id возвращает committed result, не повышает R ещё раз. Cancel/5 min expiry до fence возобновляют прежние leases; после fence старые leases **никогда** не оживляются — новый G/leases на прежний target, paused/resume required.
6. **Preview отдельно**, read-only snapshot/local tree; files/remote seq changed → repreview. **Enable отдельно**: recheck all evidence, reserve destination, journal, project enabled=true с R+1, затем confirmed private row того же R+1; новый G. До согласованности обеих записей нет runner. Затем hello protocol/ID/account/storage_epoch/cursor gate до sync/put/delete/join. Новые rooms только connected, новый Yjs/undo/awareness/sid.

Дополнительные текущие обходы, которые обязаны закрыть I3/I8: [rename_folder 1065–1114](../../../backend/voxarium_studio/teams/docs.py#L1065) возвращает ответ до завершения _mend, а [_mend 1151–1218](../../../backend/voxarium_studio/teams/docs.py#L1151) пишет через _mend_file мимо DocStore.write. Gate/учёт admitted mutation охватывает всю continuation; disconnect HTTP-stream не отменяет mending, final ready ждёт её окончания. Folder-only style не пересылается в Remote и не превращается в синхронизацию folder looks.

На frontend [save 791–818](../../../frontend/src/stores/docs.ts#L791) читает open/live внутри отложенной chain; требуется захват **до** постановки в очередь. [Любой 409 сейчас disk conflict](../../../frontend/src/stores/docs.ts#L840): stale_binding/reload_required/quiescing нельзя предложить обходить Keep mine/saveOverwriting. Переиспользовать существующий [close flush → settle → snapshot check](../../../frontend/src/views/DocsView.vue#L158), но отличать transition от [dropToSolo/adopt](../../../frontend/src/views/DocsView.vue#L216). [CollabSession.close](../../../frontend/src/lib/collab/session.ts#L195) разрушает Y.Doc: не вызывать до извлечения и подтверждения экранного Markdown.

### 3.5 Отказы и restart — обязательная матрица

| Точка | Что сохраняется / последующий исход |
| --- | --- |
| Prepare/cancel/expiry до fence | Disk config/base/Markdown не меняются; старое назначение остаётся своим. Create никогда не откатывает/удаляет серверную запись. |
| Dirty/unreachable/expired editor, failed save, offline с неподтверждённой live write, ACK timeout | blocked, no commit/no discard. Экранный текст остаётся доступным для сохранения в старую identity; Yjs не уничтожается ради выхода из барьера. |
| Disconnect/cancel во время drain | Не очищать unresolved pending/live evidence и не считать _settled успехом. Старый target/checkpoint сохраняются; explicit safe resume/reconcile, не replay в новый target. |
| Journal write/flush/replace failure до config commit | Нулевые target writes; старые Markdown/base/consent не теряются, phase blocked. Нельзя менять config, если recovery fence не опубликован. |
| Fence завершён, config replace не удался | Старые ID/URL/R на диске, sync paused/blocked. Старые editor leases отозваны; выдать новые только при безопасном resume, не возвращать G из запроса. |
| Config committed disabled, private CAS/remove/journal completion/response упал | Не rollback config поверх нового writer. Effective disabled/binding_required; journal связывает root/change_id/from/to/R/fingerprints, повтор идемпотентен, private repair только по совпавшему commit evidence. Несовпадение/битый journal сохраняется и блокирует, не defaults/auto-Enable. |
| Enable: crash между enabled=true и confirmed row | Намерение true недостаточно: journal/exact consent gate оставляет effective disabled/binding_required. Никаких token/WS/push до согласованного recovery и нового актуального preview. |
| Hello ID/account/epoch mismatch, seq ниже сохранённого cursor, terminal 4400/4401/4404 | Закрыть socket/rooms, запретить retry/push/rejoin; сохранить checkpoint/Markdown/очереди прежнего target. Не обнулять cursor, не генерировать epoch из ID, не fresh-load поверх corruption. |
| Ручная правка config/VCS checkout либо внешний FS write | Fingerprint mismatch → pause/review/reprepare; не reconfigure и не безусловный overwrite. Вернувшийся старый ID не разрешает blind resume. |
| Shutdown/restart | Admission закрывается до await; leases освобождаются после stop. Новая backend epoch отвергает старые requests. Отсутствующие/частичные/несогласованные записи не подтверждают consent; unopened private rows не исчезают из inventory. |

Journal/checkpoint implementation относится к I5/I6/I12, **сейчас её нет**. Предлагаемое расположение journal — `user_config_dir()/remote-changes/<root-hash>/<change_id>.json` (новая реализация **внутри transitions.py**, не новый сервис). Startup только читает/классифицирует journal, не auto-commit/repair/Enable; unsafe partial требует явного refresh/reprepare/reconfirmation через существующие §5.2 commands, не выдуманного recovery HTTP endpoint. Journal хранит nonsecret versioned phases, old/new tuples/revisions/fingerprints и target-bound unresolved path/hash/base evidence; не key/token/hash ключа, не Yjs, не private данные в managed config. Не переиспользовать для этого S2 remote-profile-change.json или Create intents SQLite: их recovery/ownership другие.

Для queue safety требуется не «перенести RAM pending после restart», а сохранить доказательства неоднозначных отправок старого target до остановки и reconciliation по exact saved version/hash. Текущий _Pending содержит лишь path/hash ([110–119](../../../backend/voxarium_studio/sync/service.py#L110)), очереди не durable. I5 фиксирует recovery evidence до destructive cleanup; после crash нельзя восстанавливать queue как fresh/empty или blind replay. Вне перехода восстановление идёт из сохранённых Markdown + старого checkpoint и read-only reconciliation; точное возрождение старых message IDs не обещается. Если для операции недостаёт доказательства, она остаётся blocked. Новый crash-draft/autosave или сохранение несброшенного RAM/Yjs после убийства процесса не входит в контракт.

## 4. Малые карточки реализации

I1–I16 — **ярлыки предлагаемых briefs, не созданные номера задач**. Все write_paths exact и относительно D:/VoxariumStudio, новый файл помечен. До назначения объявить полный список; reference-only файлы не брать в locks. Каждый результат — targeted tests + counts/skips и независимое scoped review, не повторная приёмка всех foundations. Общие owners сериализуются по §5.

### I1 — Подключить private inventory к C5

**Depends:** VS-141, VS-142, VS-159.
**Граница:** До R3; production completeness L не фабриковать.
**write_paths:**
- backend/voxarium_studio/sync/profile_lifecycle.py
- backend/voxarium_studio/sync/catalog_runtime.py
- backend/voxarium_studio/sync/profiles.py
- backend/tests/test_remote_profile_lifecycle.py
- backend/tests/test_remote_profile_mutation_api.py

Подключить RemoteBindings.read и текущие lifecycle evidence, включая unopened selected/confirmed и recovery URL union; completeness — отдельно от пустоты. Узкий final inventory recheck под существующей S2 config transaction, без nested OS transaction/нового store. **Acceptance:** hidden/legacy/two roots, missing/empty/corrupt/unknown version/recovering, binding publication race до S2 commit; unknown →503 без writes/keys/network, known in-use →409. Test-only completeness proof не выдаётся за production закрытие L. Existing C7 handlers и rename не переписывать.

### I2 — Подключить consent, v2 state и reservation к владельцу startup

**Depends:** I1, VS-159, VS-160, VS-162.
**Граница:** До R3, production outbound новой модели закрыт.
**write_paths:**
- backend/voxarium_studio/main.py
- backend/voxarium_studio/core/workspace.py
- backend/voxarium_studio/core/context.py
- backend/voxarium_studio/sync/service.py
- backend/tests/test_remote_runtime_binding.py — новый
- backend/tests/test_workspace.py

Передать существующие app-owned компоненты до bootstrap startup; внедрить exact read-only preflight активированной модели и per-namespace ownership, не второй runner. Missing consent/state-error/clone → no token/runner; fresh state лишь кандидат после будущего Preview/Enable. **Acceptance:** bootstrap/subsequent/alias/copy, failed startup/cleanup/shutdown/selection, reservation loser release только своего lease, retained lease до join; root A не останавливает jobs B. Legacy не мигрировать, v1 файлы не импортировать; wire пока прежний.

### I3 — Поставить generation gate на общий DocStore

**Depends:** I2.
**Граница:** До R3.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py — новый предусмотренный S5 owner
- backend/voxarium_studio/teams/docs.py
- backend/voxarium_studio/core/context.py
- backend/tests/test_remote_mutation_gate.py — новый
- backend/tests/test_docs.py
- backend/tests/test_doc_folders.py

Минимальное per-Ctx transition/generation состояние и gate в существующем DocStore; без пока prepare/commit endpoints. **Acceptance:** write/create/exclusive/delete/move/doc rename/folder rename/delete, remote apply и in-process MCP используют одну границу; stale G отвергается до bytes/event, final snapshot сериализует агентскую запись, external FS race обнаружим fingerprint; rename_folder/_mend/_mend_file остаются admitted до конца, включая streaming disconnect. Reentrant event publish не deadlock-ит; A/B одинаковые пути изолированы. Ничего не менять в pipeline/job admission.

### I4 — Подключить editor leases и HTTP fencing

**Depends:** I3.
**Граница:** До R3; старые клиенты не активируют новую модель.
**write_paths:**
- backend/voxarium_studio/api/sync.py
- backend/voxarium_studio/api/__init__.py
- backend/voxarium_studio/api/docs.py
- backend/voxarium_studio/sync/service.py
- backend/voxarium_studio/ws/routes.py
- backend/voxarium_studio/sync/transitions.py
- backend/tests/test_remote_editor_leases.py — новый
- backend/tests/test_project_scopes.py
- backend/tests/test_docs.py

Реализовать **новые** P/remote GET/editor register/heartbeat/delete по §5.2, captured backend epoch/G/editor_id/sid и server saved-version evidence. Project remote router из sync.py монтировать **только** под project selector отдельно от /sync prefix; не создавать глобальный /api/remote дубликат в обход profiles router. Все HTTP document mutations и legacy/scoped /sync compatibility проходят §5.3. **Acceptance:** missing/stale G, unknown sid, чужой editor/path/Ctx, expired dirty lease, legacy socket без capability; no-write rejection. После активации PUT /sync target/token/enable/disable не cancel-reconfigure, а use_remote_settings/guarded barrier; до активации legacy сохраняется. Auth/Host/Origin/no-store, invalid handle не открывает root.

### I5 — Реализовать bounded prepare/quiesce/drain

**Depends:** I4.
**Граница:** До R3 с fake transport/editor; настоящий drain проверяется после I10/I8.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/sync/service.py
- backend/voxarium_studio/ws/events.py
- backend/voxarium_studio/api/sync.py
- backend/tests/test_remote_transitions.py — новый
- backend/tests/test_remote_sync.py

Подключить prepare/quiesce/editor-ack/cancel к текущим flush/pending/room owners; quiesce state/event Ctx-only, immutable expected evidence, 5 min expiry. Не commit-ить identity в этой карточке. Убрать использование pending.clear/settled как успешного drain в new-model branch; сохранять target-bound unresolved evidence до cleanup. **Acceptance:** все editors, scribe/ordinary save, ACK/nack, timeout/offline/error/cancel/unknown client, no new join/reconnect; delayed ACK проходит при ожидании без lock deadlock. Не потерять экранный текст или очереди и не остановить agents B. Ready только после доказанного flush/ACK/leave/fence, не по bool клиента.

### I6 — Подключить disabled commit и crash-safe local recovery

**Depends:** I5.
**Граница:** До R3 с injected catalog observations; реальный Select ждёт I9/I8.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/sync/bindings.py
- backend/voxarium_studio/core/config.py
- backend/voxarium_studio/core/context.py
- backend/voxarium_studio/api/sync.py
- backend/tests/test_remote_transitions.py
- backend/tests/test_remote_bindings.py
- backend/tests/test_project_identity.py
- backend/tests/test_project.py

Подключить prepare-ready → journal/config commit → existing binding CAS; добавить CAS-remove private row и узкий transaction-aware внутренний publication seam по §3.2, не второй repository. edit_id/select/disable/unbind по §7, canonical config writer без sync.space после activation; migration operation пока typed blocked до I15. Shared settings save не теряет target и не восстанавливает legacy поле. **Acceptance:** R/G/config/private CAS races, exact confirmation, idempotent change_id, expiry/cancel before/after fence, faults/restart каждой строки §3.5; no automatic Enable/rollback/push. Смена ID сохраняет runtime descriptor/пути/jobs/MCP. Обязательный restart case: completed edit_id/unbind → binding row отсутствует → VCS восстановил legacy sync.space → 0 credential/WS calls, blocked, а не legacy runner. Completed activation evidence не удаляется при cleanup/expiry; corrupt/known-lost evidence блокирует. Истинно неактивированный legacy сохраняет прежний режим. Offline edit разрешён только без unresolved leases/rooms/saves.

### I7 — Расширить проектный клиент и sync store, не global catalog заново

**Depends:** I4.
**Граница:** До R3 на mock API; commit controls полностью принимаются после I6.
**write_paths:**
- frontend/src/api/types.ts
- frontend/src/api/client.ts
- frontend/src/api/client.spec.ts
- frontend/src/api/client.spec.ts
- frontend/src/api/project-scope.ts
- frontend/src/api/project-scope.spec.ts
- frontend/src/stores/sync.ts
- frontend/src/stores/sync.spec.ts — новый
- frontend/src/ws/events.ts

Добавить весь planned §5.2 project surface: GET remote, editor register/heartbeat/delete, prepare/quiesce/editor-ack/commit/cancel, reconcile-preview/enable, migration GET/profile/resolve. Методы будущего backend не объявлять уже доступными: I13/I15 потребляют их после своих release gates. Здесь же назначен **весь document-mutation wire contract**: save/create/delete/move/folder delete и streaming NDJSON renameDocFolder, expected_binding_generation/editor_id/sid как явно переданные captured arguments, не подстановка актуального G. Добавить typed fence error code/details с совместимостью прежнего ApiError, чтобы store отличал fencing от disk conflict. Сейчас [ApiError/readError 110–117/209–210](../../../frontend/src/api/client.ts#L110) хранит строковый detail, [renameDocFolder 371–387](../../../frontend/src/api/client.ts#L371) отправляет только path/name, [save/create/delete/move 787–819](../../../frontend/src/api/client.ts#L787) не принимают эти fences. G-aware tickets/phase events остаются в существующем sync store; global remote.ts/remote-servers уже реализованы и не копируются. **Acceptance:** captured runtime binding + remote G, late response/event old G отбрасывается, stale callback не получает latest G, /sync GET только compatibility, никакого ProjectSession rebind/renderer reload. Exact global allowlist не расширять до blanket remote prefix; EN/RU данные не подменять raw error. Targeted client.spec проверяет все mutation paths, streaming fences, typed409 против обычного disk conflict, no implicit generation upgrade и stale response. Secrets не добавляются в store. API specs проверяют body/query fences каждого mutation, NDJSON early refusal и typed 409 без unsafe overwrite; весь §5.2 surface типизирован до потребления I13/I15.

### I8 — Подключить настоящий editor flush/ACK handshake

**Depends:** I7, I4, I5, VS-163 (locale-lock).
**Граница:** До R3 локальные/component/jsdom; использует backend drain fixtures I5.
**write_paths:**
- frontend/src/components/docs/BlockEditor.vue
- frontend/src/views/DocsView.vue
- frontend/src/views/DocsView.spec.ts
- frontend/src/stores/docs.ts
- frontend/src/stores/docs.spec.ts
- frontend/src/lib/collab/session.ts
- frontend/src/lib/collab/session.spec.ts
- frontend/src/lib/collab/editor.spec.ts
- frontend/src/locales/en.json
- frontend/src/locales/ru.json

Обычный и collab editor регистрируются **до первого save**, heartbeat, flush debounce/local Markdown до backend ACK, freeze/cancel/resume; transport save несёт captured lease/G/sid, захваченные до queue/debounce, не из open/live после await. Typed fence 409 не становится disk-conflict/Keep mine; overwrite/adopt/create/delete/move/folder mutations также fenced. Переиспользовать close guard и сохранение DOM, не второй close framework. **Acceptance:** два реальных editors (jsdom), non-scribe → final scribe save, offline/error/unmount/transfer/legacy browser, delayed callbacks после fence/commit rejected, несохранённый текст не исчезает, нет auto-join нового target. Dirty expired lease блокирует, clean open и live transfer пишут 0. Никакого нового crash-draft механизма.

### I9 — Снять R3 gate у существующего catalog owner

**Depends:** I6, R3.
**Граница:** Только production compatible Remote после R3; подготовка fixtures/brief заранее не означает принятой активации.
**write_paths:**
- backend/voxarium_studio/sync/catalog_runtime.py
- backend/voxarium_studio/sync/catalog_create_runtime.py
- backend/voxarium_studio/main.py
- backend/voxarium_studio/api/sync.py
- backend/tests/test_remote_catalog_activation.py
- backend/tests/test_remote_catalog_create_runtime.py
- backend/tests/test_remote_catalog_read_service.py

В том же app owner заменить _UnavailableOutbound на существующие CatalogService/CatalogReadService и передать owned transport существующему CatalogCreateRuntime. Snapshot/resolve/exact project lookup — backend facades для project flow через существующий app.state.remote_catalog holder; расширить тот же holder, передать проектным handlers, не app.state.ctx и не новый singleton. Select handler из I6 получает реальный exact catalog observation, а не доверяет catalog_id/incarnation browser payload. Это не новые произвольные browser URL handlers. **Acceptance:** lifecycle read/Create leases покрывают каждый await/page/cleanup, before/after provider guards, strict v2/capabilities, no secret/redirect/partial result, shutdown join. V1 Verify остаётся diagnostic; v1 catalog/POST/WS=0. Create journal/operation continuity/cold refusal не переписывать; Create не делает Select.

### I10 — Подключить v2 runner к готовым consent/state/reservation

**Depends:** I6, I9, R3.
**Граница:** Compatible Remote для интеграционной приёмки; verified profile/account observation из I9.
**write_paths:**
- backend/voxarium_studio/sync/service.py
- backend/voxarium_studio/sync/protocol.py
- backend/voxarium_studio/core/context.py
- backend/tests/test_remote_runtime_binding.py
- backend/tests/test_remote_sync.py

Активированная модель использует captured binding, profile-bound credential provider и SyncStateV2; до любого sync/push/join строгие hello protocol=2, exact ID, account verified me, storage_epoch и cursor. Frame-константы согласовать с **уже принятой** Remote стороной; не импортировать её package. Legacy до activation — явно отдельная compatibility ветвь, не fallback из v2 при ошибке. **Acceptance:** 4400/4401/4404 terminal, malformed hello/ID/account/epoch/seq rollback, reconnect/manual config drift/late ACK/send; старые checkpoint/Markdown/queues остаются old-target, ни reset cursor, ни v1 fallback. Existing reconciliation/conflict-copy/clean-open инварианты сохраняются. V2 checkpoint updates сериализованы, immutable state не обновляется старым in-place кодом.

### I11 — Подключить read-only reconcile-preview

**Depends:** I6, I9.
**Граница:** R3 snapshot capability; mock tests заранее не включают production Preview.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/api/sync.py
- backend/voxarium_studio/sync/catalog_runtime.py
- backend/tests/test_remote_reconcile_preview.py — новый

P/remote/reconcile-preview использует **готовый** CatalogReadService.snapshot и локальный Markdown, old v2 bases, exact selected tuple. Preview связывает root/R/G/config/private/profile observations, incarnation/seq, local file fingerprint, TTL и counts/conflicts. **Acceptance:** pages epoch/seq drift/409, changed files, tombstones, same ID/different URL, copied roots; только GET, 0 DocStore/config/base/queue writes/rooms/WS. Snapshot не lock и не разрешение overwrite. Отказ уничтожает только временный preview.

### I12 — Подключить отдельный Enable/catch-up

**Depends:** I10, I11, I8.
**Граница:** Только compatible Remote и обновлённые editors.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/sync/service.py
- backend/voxarium_studio/api/sync.py
- backend/tests/test_remote_enable.py — новый
- backend/tests/test_remote_transitions.py
- backend/tests/test_remote_sync.py

P/remote/enable — отдельный command после актуального preview, точного confirmation и повторных CAS; reserve, journal → project R+1 enabled → private confirmed R+1 → только затем runner/hello/catch-up. **Acceptance:** crash/failure до/между/после обеих публикаций, concurrent copies один победитель, profile/credential/local/remote race, room только connected; mismatch сохраняет старый namespace/evidence и blocked, no fresh reset/automatic retry. Нельзя включать простым PUT /sync или 201 Create.

### I13 — Дать пользователю project Select / ID edit / Preview / Enable

**Depends:** I6, I7, I8.
**Граница:** UI на mocks / локальный ID edit после owning deps; реальные Select/Enable release только после I9/I11/I12.
**write_paths:**
- frontend/src/components/settings/SyncSettings.vue
- frontend/src/components/settings/SyncSettings.spec.ts — новый
- frontend/src/views/ProjectSettingsView.vue
- frontend/src/locales/en.json
- frontend/src/locales/ru.json

Заменить project URL/space/password flow существующими global profiles/catalog client + project API. Явные отдельные Create → Select → barrier → Preview → Enable; offline edit ID не создаёт Remote. **Acceptance:** EN/RU, ID/URL видимы при одинаковых display names, canonical ID до confirmation, disabled after commit, cancel/fail/409/repreview не включают sync; blockers/editor reload честно показаны. Create unknown/conflict/rejected не auto-select/retry, operation continuity существующего клиента сохранена. Не редактировать global Settings UI VS-163 и не хранить secret в project form.

### I14 — Подключить S5 drain proof/consent invalidation к C7

**Depends:** I6, I8, I9, I10, I11, I12.
**Граница:** После owning prerequisites; mock tests не заменяют настоящий positive drain с совместимым Remote и L.
**write_paths:**
- backend/voxarium_studio/sync/profile_lifecycle.py
- backend/voxarium_studio/sync/catalog_runtime.py
- backend/voxarium_studio/sync/profiles.py
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/sync/bindings.py
- backend/tests/test_remote_profile_lifecycle.py
- backend/tests/test_remote_profile_mutation_api.py

S5 выдаёт bounded evidence точного consumer/G после editor+pending ACK и stop; C5 проверяет/удерживает его, не выполняет async drain внутри guard. Credential mutation/recover не становится forced-stop API. Действующие/unopened confirmed consent affected roots безопасно demote/revoke через transaction-aware seam I6 под **одной уже взятой** config transaction, после profile CAS/durable fence и до допуска нового credential, без автоматического изменения чужих project files/Enable. Это необходимая связь, не готовое поведение C7 сегодня. CAS profile проверяется до дополнительных writes; unknown/corrupt inventory всё ещё closed, stale proof/reconnect/new read/Create инвалидируют разрешение. **Acceptance:** real compatible Remote/editor drain interop и отказ старой WS credential generation, drained не unbound; URL/delete отказывают при любом bound root; credential failure/restart не восстанавливает confirmed по старому proof, ENV не удаляется, rename не reconnect. Если L не закрыт, production positive mutation не выпускается; refusal — ожидаемый результат.

### I15 — Применить S9 только к явно выбранному legacy root

**Depends:** I6, I9, I12, I13, I14, I16.
**Граница:** Не входит в минимум нового проекта; compatible legacy_resolution, I16 раньше из-за общих UI specs.
**write_paths:**
- backend/voxarium_studio/sync/transitions.py
- backend/voxarium_studio/core/project_identity.py
- backend/voxarium_studio/api/sync.py
- backend/tests/test_remote_migration.py — новый
- frontend/src/components/settings/SyncSettings.vue
- frontend/src/components/settings/SyncSettings.spec.ts
- frontend/src/locales/en.json
- frontend/src/locales/ru.json

Подключить существующий diagnostic plan и S2 explicit profile/import к §5.2 migration/profile/resolve/apply, не выполнять миграцию на GET/startup. Exact legacy name → catalog ID=old UUID и epoch=old UUID байт-в-байт; base импорт только при полном доказательстве root/URL/mapping/incarnation, copy/check new checkpoint, old оставить. **Acceptance:** real in-process legacy fixture interop после R3, idempotent apply, malformed config/base без repair, collision/key conflict/нет mapping → no project/base writes, drain старого назначения, commit disabled, no WS existence probe. Ни одна предъявленная root не доказывает глобальную legacy completeness L. Production data — только целевой backup/rollback check; общего разрешения повторно не просить.

### I16 — Проверить fresh-project срез и restart

**Depends:** I13, I12.
**Граница:** Fresh-project release check без ожидания I14/I15; их used-profile/legacy interop проверяется в самих I14/I15.
**write_paths:**
- backend/tests/test_remote_sync.py
- backend/tests/test_remote_runtime_binding.py
- frontend/src/lib/collab/editor.spec.ts
- frontend/src/components/settings/SyncSettings.spec.ts
- .voxarium_studio/docs/remote-identity/runtime-integration-verification.md — новый

Синтетический уже usable profile+stored credential либо exact URL-bound ENV; I16 не выдаёт заблокированный L первичный ввод ключа за проверенный onboarding. Реальный in-process совместимый Remote в backend environment, test_remote_sync **не skipped**, два root, copies/alias/same path, normal+collab редакторы, agent B, Create/Select/Preview/Enable/ID change/disable/unbind/late callback/rollback hello/crash matrix. Проверить 0-write clean open, не persist Yjs, conflict copies, old namespace/ambiguous evidence. typecheck/build/targeted suites и независимый scoped review; HTML/manual smoke не заменяет editor+server interop. Запуск если безопасен: только штатный run.cmd/run.ps1, :8765, явный demo project; существующий remote_test.bat — только legacy launch/safety reference, **не v2 acceptance**: [remote_test.connect 211–223](../../../remote_test.py#L211) ещё делает PUT /api/sync, а [326–334](../../../remote_test.py#L326) создаёт sample без G. Обязателен v2 in-process interop. Если нужен отдельный ручной парный v2 smoke, сначала отдельная карточка адаптации remote_test.py с exact write_paths и task-temp, запуск всё равно только через штатный remote_test.bat с остановкой его PID. Не останавливать user jobs и не поднимать второй приватный backend. Все disposable артефакты будущей карточки — её task temp, generated static не редактировать.

## 5. Dependency/scope self-check и критический путь

### Что запускать параллельно

- **Сейчас:** I1; серверная цепочка R1→R2→R3 независимо. I2 затем I3→I4: сначала подключаются существующие storage/lifecycle/reservation, а не вводится ещё один фундамент.
- После I4: I5 backend параллельно I7 frontend; затем I6 параллельно I8 (I8 ждёт I5 и I7). До E2E нет activation старых клиентов.
- После I6 + R3: I9 backend параллельно независимым I7→I8 frontend. I9 меняет main/api/sync.py, поэтому **не** параллелен I2/I4/I5/I6. После I9: I10 и I11 могут идти параллельно — их write_paths disjoint; I12 ждёт оба и I8.
- I8/I13/I15 имеют общие locale files с текущей VS-163: перед их стартом дождаться её завершения. I13 после I6/I7/I8 можно реализовать на mock backend, но реальные Select/Enable не выпускать до их gates; I8→I13→I15 строго последовательно.
- I14 после I12 можно параллельно fresh-project I16 (их write_paths disjoint). I15 ждёт I14/I13/I16: shared SyncSettings.spec.ts не меняется во время I16. Used-profile и legacy interop принимаются в I14/I15 отдельно; I16 не объявляет их готовыми. При назначении зависимость-финиш карточки нельзя заменить «другая уже начала».
- Все пересечения main/workspace/context/service/transitions, api/sync.py, catalog_runtime.py, docs.ts, locale files учтены. Shared tests тоже write locks; не параллелить карточки только потому, что feature назван иначе. Backlog ярлыки не дают write permission вне будущей карточки.

### Минимальный путь до действий пользователя

Сетевой путь ниже предполагает уже пригодные profile+credential или принятую paired ENV URL/key. Для пользователя, которому ещё нужно впервые сохранить key, **L/I14 — дополнительный критический gate**, а не только «поздняя смена ключа». UI VS-163 и 201 Create profile его не снимают.

1. **Локальное редактирование ID без потери текста:** I1→I2→I3→I4, затем параллельно (I5→I6) и (I7→I8), затем соответствующая часть I13. R3 для чистого offline edit не нужен, но unresolved legacy/editor/room/save blocker обходить нельзя. Итог только disabled, no remote rename/create/перенос документов.
Пути 2–3 и I16 предполагают уже usable profile+credential либо exact URL-bound ENV. Для пользователя без ключа сначала первичный C7 credential onboarding, который также ждёт **L**; не изображать это как готовый fresh-install путь и не обходить guard. Offline ID/read-only metadata не ждут ключа.

2. **Select существующего серверного ID:** предыдущий barrier/editor путь + R1→R2→R3→I9 + Select часть I13. Результат select commit — disabled/selected, не connected. Для неподготовленного legacy target требуется I15; не маскировать migrate как select.
3. **Enable и совместное редактирование:** R3 + I9→(I10 и I11 параллельно)→I12 + I8/I13, затем fresh-project I16. До него открытая кнопка/успешный unit test не поставка. Create использует уже имеющиеся C8/C9/client после I9 и добавляет явное действие **перед** Select, не новую скрытую зависимость consent.
4. **Смена ключа используемого профиля/URL/Delete и существующие legacy roots:** отдельные I14/I15 и L; они не должны повторно блокировать уже безопасные независимые offline ID/read-only функции. URL/delete всё равно требуют явного unbind всех известных bindings; нет массового forced stop.

Остающиеся release gates: положительное legacy inventory L для sensitive profile mutations; принятый R3 и отдельный credential-generation security gate; совместимый v2 hello/account/state runner; все editor leases/legacy capability + реальный flush ACK; durable config/private journal recovery; snapshot/CAS preview и отдельный Enable; не-skipped interop/двуязычный UX. Ни один gate не считается закрытым этим документом или историческими PASS foundations.

### Как проверять будущие карточки

Из backend/: `python -m pytest tests/<target_module>.py` и адресные регрессии затронутых owners. Для I16 Remote сначала установлен в **той же** backend environment; skipped test_remote_sync — отсутствие проверки, не PASS. Frontend: npm test -- <target specs>, npm run typecheck, npm run build; реальные editor tests сохраняют jsdom. При faults считать side effects (config/base/Markdown/queue/network/runner/key lookup), а не только HTTP код. Каждый brief фиксирует exact command/count/skips, scope diff и независимый review; не гонять production migration и не читать секреты ради unit tests.

## 6. Проверка самого плана VS-164

Прочитаны текущие карточки VS-159/160/162, VS-141/142, VS-152 и параллельная VS-163; актуальные owners сверены после Graphify. Результаты двух независимых read-only исследований inventory/lifecycle и save/drain прочитаны через get_subagent и интегрированы по owning source. Независимый review плана и финальный delta-review — **PASS**, все указанные P1/P2 исправлены; это оценка исполнимости документа, не runtime readiness.

Статическая самопроверка: 16 briefs, dependency cycles 0, неупорядоченных пересечений write_paths 0; 58 source links, отсутствующих путей/выхода номера строки за файл 0. Проверены planned-new paths, EN/RU owner/VS-163 lock, I10∥I11 и независимый fresh-project I16 перед I15. Unmatched bold, U+FFFD, conflict markers и trailing whitespace — 0; git diff --no-index --check относительно пустого task-temp baseline без whitespace diagnostics (exit 1 означает наличие документа).

В VS-164 изменён только заявленный shared document; disposable checker/results находятся в D:/VoxariumStudio/.voxarium_studio/temp/TASK-164. Большой существующий чужой diff не включается в результат. Code/config/data edits, runtime imports/tests, build, listeners/restart и сеть не выполнялись; реальные personal config/keys не читались. Будущие команды §5 — acceptance реализации, не выполненные тесты; L/R3/security/editor/recovery gates остаются явно открытыми.
