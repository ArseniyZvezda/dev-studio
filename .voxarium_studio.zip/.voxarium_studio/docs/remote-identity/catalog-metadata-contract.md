# VS-121 — read-only metadata каталога: композиция и граница status

## 1. Решение и область

15.11.2026. Основание — [[remote-identity/studio-design]] §4.2, §5.1, §6 и [[remote-identity/catalog-offline-gaps]]. Это узкое продолжение принятого VS-119, не повторная приёмка A–D. Прочитаны карточки VS-117–119 и актуальные owners после Graphify; историческая карта gaps ещё говорит об отсутствии REST/Verify, но теперь их немонтируемые реализации существуют.

**Исторический вывод VS-121 до решения VS-123 (§§4–7 ниже): существующих S2 readers достаточно для дискретной secret-free проекции списка и наличия/источника effective credential. Они недостаточны для полного `ServerMetadataProvider`: достоверного владельца verification metadata сейчас нет.** Отсутствие такого владельца нельзя исправлять постоянным `unchecked`, фиктивным `error` или вызовом Verify из GET.

В VS-121 выбран следующий минимальный offline-срез **M: конкретная внутренняя list/source-проекция с явным unavailable status**, §7. Она не меняет утверждённый REST DTO и не выдаётся за завершение GET servers. Для непустого списка его полная успешная проекция в нынешний `ServerProfile` остаётся заблокирована отсутствием доказанного status; точная граница — §6. Новый общий аудит перед M не нужен.

**Обновление VS-123 (15.11.2026):** пользователь утвердил показ сохранённых серверов с неизвестным status без нового cache. Это снимает blocker только для unavailable verification у корректных rows; конкретный будущий DTO/adapter и неизменный отказ ENV-unbound — §§4–7. Исторические выводы/приёмка VS-119/121/122 не переобъявляются реализацией нового решения.

В VS-121 разрешены только статическое чтение и этот документ. Здесь не разрешаются код, runtime/lifecycle/API mounting, сеть/DNS/listeners, реальные config/keys/data, новые credential-continuity/wire semantics, миграции, deploy/build/restart. Все будущие write_paths ниже — предложение отдельной реализации, не расширение текущего scope.

## 2. Что дают актуальные owners

Пути относительно репозитория; номера строк — ориентиры прочитанного checkout, символы первичны.

| Owner | Доказанное поведение и ограничение |
| --- | --- |
| `backend/voxarium_studio/api/remote.py:66–109,237–270` | `ServerProfile` требует has_token/source/verification; source только stored/environment/none. `ServerMetadataProvider.list()` — обязательный trusted seam без production adapter. GET проверяет полный tuple/DTO/дубликаты, но не доказывает происхождение status. Unknown metadata должна вызвать отказ, не пустой список. |
| `sync/profiles.py:63–81` | `RemoteProfiles.list/get` читают через strict application reader; не создают lock и не проверяют pending сами. `list` даёт metadata, не credentials/status. |
| `core/application_config.py:160–184,219–237` | Strict reader отклоняет malformed metadata. Обычный `load_application_config` может вернуть defaults после ошибки — для этой композиции непригоден. Отсутствующий config даёт пустой реестр. `RemoteServerProfile` сохраняет историческое имя при stored-read, проверяет UUID/revision/URL; `ApplicationConfig` запрещает дубликаты ID/URL (`82–139`). |
| `sync/catalog_providers.py:34–92` | `S2CatalogReaders.check()` связывает live paths с одним явно заданным absolute home, проверяет home и глобальный journal через lstat. Любое присутствие journal, даже другого профиля, directory/dangling link, либо ошибка наблюдения блокирует чтение. Не читает содержимое journal. List/source reader в нынешнем контракте отсутствуют. |
| `sync/catalog_providers.py:96–170` | `PendingCatalogProviders` — неизменяемая привязка exact ID/URL/revision, проверки до/после get/credential read, включая ошибки и ENV. Нет общего mutable «последнего профиля». Это дискретные наблюдения, не межпроцессная транзакция. |
| `sync/credentials.py:316–353` | `profile_token_source` уже secret-free: stored/missing/environment/environment_unbound. `load_profile_token` использует exact profile+normalized URL, ENV имеет приоритет и при unbound не откатывается к stored. `profile_token_revision` — только stored revision/tombstone, не ENV revision. |
| `sync/catalog_service.py:31–40,127–191` | Живой `_Snapshot` хранит token приватно, `_check` сравнивает metadata и текущий token. Это fence текущей операции, не cache API, не историческое credential proof. |
| `sync/catalog_verification.py:29–43,145–222` | Verify получает guarded snapshot и реальное checked_at от injected clock, возвращает frozen secret-free `VerificationStatus`. Результат не содержит binding/revisions, не публикуется в cache; read-status API нет. Valid v1 не разрешает каталог. |

`RemoteProfiles.load_token` не использовать: он входит в `application_config_transaction`, создающий директорию/lock (`profiles.py:175–183`, `application_config.py:188–203`). Не использовать legacy URL lookup, migration/recover, writer, runtime-selected home или default production transport.

## 3. Минимальная композиция чтений

### 3.1 Зависимости и exact binding

Новый observer получает обязательные явно связанные readers одного synthetic home: существующие `RemoteProfiles.list/get`, `credentials.profile_token_source` и live location observers. Reuse `S2CatalogReaders.check`/`PendingCatalogProviders.get`, не новый parser или ослабленная копия fence. Callback должен описывать именно свой owner/path: совпадение произвольных возвращённых Path не доказывает честность Python closure. Реальная S2-связка проверяется synthetic real-storage fixtures; абстрактные callbacks остаются trusted dependency boundary, не sandbox.

Скопировать scalar metadata каждого профиля в immutable binding `(profile_id, exact normalized URL, profile revision)`; имя сохранять буквально. URL prefix, HTTP/HTTPS, ID и revision не заменять по имени, aliases, active project или новейшей версии профиля. Revalidation должна учитывать stored-name context и не нормализовать историческую подпись заново. Запрос к source выполняется только для original URL после повторной проверки binding, никогда для внезапно нового locator.

Presence и source выводятся **из одного** `profile_token_source` observation, без `load_profile_token` ради bool:

| S2 source | Внутренняя проекция / REST-совместимые поля |
| --- | --- |
| stored | `has_token=true, credential_source=stored` |
| environment | `true, environment`; это не проверка ключа и не доказательство здоровья stored файла |
| missing | `false, none`; exact entry отсутствует, tombstone либо доступен только legacy key |
| environment_unbound | Отдельный внутренний unusable outcome. ENV задан, но URL не совпал/некорректен, либо значение пустое. Не missing, не fallback. Для нынешнего полного DTO выбрать консервативный typed отказ `metadata_unavailable`, не добавлять enum и не маскировать причиной none. |

Has_token означает наблюдаемое наличие выбранного key, не его пригодность для HTTP, valid/account/catalog permission. S2 source не выполняет bearer-валидацию или Verify.

### 3.2 Порядок и all-or-nothing

1. Глобальный fence до list. Прочитать strict `L0 = list()`, затем fence **также при ошибке**. Валидировать tuple, полные записи и уникальность ID/normalized URL; ошибка не равна пустому реестру.
2. Для каждого элемента L0: immutable binding → fence/exact get → source → fence/exact get. Проверять также failed read и ENV early return. Смена ID/URL/revision отвергается до lookup нового locator.
3. До выдачи повторить source для каждого original binding и проверить неизменность наблюдаемого outcome; обрамить повторные чтения теми же fence/exact checks. Затем перечитать **весь** список L1 с fence и сравнить с L0 полные scalar записи, membership и порядок. Это замечает add/delete/rename/reorder, а не только изменение уже выбранного профиля.
4. Финальный глобальный fence обязателен даже при пустом списке. Только после всех проверок публикуется полный immutable результат. Никакого partial items, skip bad profile, silent retry/rebind или смешивания старых и новых строк.
5. Если когда-либо появится доказанный status owner, его bound-read должен войти внутрь этих проверок и быть повторно сверён перед публикацией; при решении VS-121 unknown/stale одного элемента запрещал полный REST-ответ. По новому VS-123 отсутствие применимого результата допускает только явный unavailable (§4), без переноса старого результата; ошибки наблюдений по-прежнему запрещают ответ. Список/source сами status не создают.

`create/rename` публикуют metadata без cross-file journal (`profiles.py:96–127`): один pending fence не замечает все гонки списка. Повторные get не замечают добавление другого профиля. Повторные source не замечают замену непустого ключа другим непустым того же source; это допустимый предел **presence observation**, но не основание переносить verification.

Нет общего linearization point: завершившаяся между наблюдениями транзакция, ABA, ручная правка/restore и изменение после финального fence могут остаться незамеченными. Контракт M — bounded observations с отказом при обнаруженной гонке, не непрерывная/multiprocess isolation, не credential-lease и не send-boundary atomicity. Новый lock для такого более сильного обещания здесь не вводится.

### 3.3 Missing, corruption, path uncertainty

- Missing обычного home/config: strict list может дать известный пустой реестр, после обоих fence вернуть пустую проекцию без создания dirs/lock/keys. Это ничего не утверждает о credentials несуществующих профилей.
- Для существующего профиля missing keys store/exact entry или tombstone — known absence, не corruption. Legacy-only key не импортировать.
- Malformed/unreadable config — fixed `application_store_unavailable`; malformed key store на stored branch — fixed `credential_store_unavailable`. Не возвращать defaults/none/unchecked. Raw exceptions/input/path/key и exception context не выводить в DTO/log/repr.
- При выбранном ENV существующий source reader **не читает stored файл**. Поэтому даже corrupt stored файл не обнаруживается на этой ветке; M не обещает обратного и не добавляет принудительный stored read. Когда ENV исчезнет, strict stored read обязан обнаружить corruption, без fallback.
- Текущий strict config reader использует `Path.exists()` для missing. Dangling config symlink может выглядеть отсутствующим; существующий fence проверяет home/journal, не тип всех stores. В новой композиции нужны read-only lstat observations config/keys до/после чтений: только ENOENT — отсутствие; symlink, не-regular entry или ошибка наблюдения — отказ. Это локальное усиление fail-closed observer, без переписывания S2/обещания filesystem sandbox. TOCTOU между lstat/read всё равно остаётся.

## 4. Verification: новое решение VS-123 и строгий DTO

15.11.2026 пользователь ответил «Да»: **сохранённые серверы без результата проверки показывать как «Статус подключения неизвестен», без дополнительного кэша**. Это новое решение, а не переоценка принятого VS-121. Для будущего локального `ServerProfile` добавить отдельный strict-вариант `UnavailableVerification = {state:"unavailable"}` к существующему union verification. Само поле `verification` обязательно; его отсутствие, null, неизвестный state или неверный тип остаются ошибкой. Все поля сверх `state` в unavailable запрещены (extra forbid), в том числе null-valued `checked_at/user/capabilities/wire_protocol/catalog_version/error_code`.

| Наблюдение | Допустимая выдача |
| --- | --- |
| Корректные metadata/presence наблюдены, но нет status owner или применимого результата | `verification={state:"unavailable"}`, без времени, user и capabilities |
| Авторитетный владелец доказал отсутствие проверки exact credential binding в определённой области истории | `{state:"unchecked"}`; отсутствие результата само по себе этого не доказывает |
| Владелец зарегистрировал незавершённую проверку binding | `{state:"checking"}`, не предположение GET |
| Владелец публикует реально выполненный Verify с доказанной применимостью к текущему binding | Только исходный sanitized checked status; valid не означает каталог/доступ сейчас |
| Старый/чужой binding, неизвестная история или cache miss | Не переносить результат и не превращать в unchecked/error; при корректных metadata допустим только unavailable |
| Ошибка stores/readers, pending, обнаруженная гонка или invalid row | Отказ всего ответа по прежнему typed contract, не unavailable verification |

Unavailable говорит только «результат проверки недоступен», а не «сервер offline», «ключ отсутствует/валиден», «сеть проверена» или «доступ разрешён». Missing key также не доказывает историю unchecked. Checked `error` утверждает выполненную проверку и требует настоящего checked_at; unavailable его не подменяет. GET не вызывает Verify/clock/transport, не создаёт и не хранит status. DTO-валидация доказывает форму, не историческую истинность.

## 5. Key/status invalidation и узкая граница без cache

Profile revision и stored credential revision различны; ENV может измениться без обеих. Same source/has_token при key A→B не доказывает credential continuity. VS-123 **не добавляет cache/status owner, token hash, ENV revision, durable proof или новый storage API**. Будущий adapter использует presence-only VS-122 rows и всегда выдаёт unavailable, не принимает caller-supplied checked result и не переиспользует последнее успешное me как permission.

Если позже отдельно разрешат публикацию checked/unchecked/checking из истории, по-прежнему нужен verifier-owned bound-publication/read API. Его invalidation должна учитывать profile revision (включая rename), URL, stored credential revision, effective ENV key/source/binding, удаление, pending и reader failure; поздний Verify не должен восстановить status старого binding. Эти требования не реализуются и не обходятся текущим решением. Ошибка локального fence не становится checked remote error.

Existing list/get/source достаточны для M и нового unavailable mapping; чтение token/revision ради bool не требуется. GET не вызывает Verify или clock и не сохраняет status ни в память для последующих GET, ни на диск. Unavailable — явная проекция отсутствия результата, не новый cache epoch.

## 6. Исторический blocker и будущий mapping rows → ServerProfile

**При приёмке VS-119/121/122** полного production metadata adapter не было: Verify не сохраняет bound-result, REST DTO не допускает unavailable, M даёт только внутренние rows. Поэтому прежний отказ полного GET был правильным. VS-119 остаётся принятой немонтируемой REST-оболочкой с trusted seam; VS-121 — контрактом M; VS-122 реализовал M, а не новый DTO. Их прежние выводы не означают, что новый adapter уже существует.

**Решение VS-123 снимает только необходимость status owner для успешной выдачи неизвестного status.** Разрешён будущий отдельный немонтируемый adapter с обязательным injected observer, без default home/production injection; ниже его контракт, не изменение кода в VS-123:

1. Один вызов `CatalogMetadataObserver.observe()` получает полный immutable tuple. Не повторять lookup по новому URL, не делать silent retry/rebind. Сохранить все fences, exact ID/URL/revision, lstat, L0/L1 и bounded-observation ограничения §3.
2. Скопировать `profile_id,name,url,revision` без нормализации исторического имени, подстановки active project или aliases.
3. Строго проверить строковый discriminant row `verification="unavailable"` и mapping ниже. Не передавать row напрямую как REST DTO; не использовать missing/default/null.
4. Построить и валидировать **весь** tuple ServerProfile до публикации `{items:[...]}`; empty допустим только после успешного полного observe. Любая ошибка — отказ без partial items и без пустого success вместо ошибки.

| VS-122 row: credential_source / has_token | Будущий ServerProfile |
| --- | --- |
| `stored / true` | `has_token:true, credential_source:"stored", verification:{state:"unavailable"}` |
| `environment / true` | `has_token:true, credential_source:"environment", verification:{state:"unavailable"}` |
| `none / false` (S2 missing, tombstone, legacy-only) | `has_token:false, credential_source:"none", verification:{state:"unavailable"}` |
| `environment_unbound / None` | Typed `metadata_unavailable` → 503 всего GET; не missing, не none, не stored fallback |
| Иная комбинация, отсутствующий verification/discriminant, unknown state | Invalid metadata: fixed sanitized отказ по существующей оболочке, не unavailable/default |

ENV-unbound означает unusable ENV (включая пустое значение или несовпавший/некорректный URL). Пользователь **не утвердил расширение credential DTO**: enum остаётся stored/environment/none. Даже один ENV-unbound запрещает весь ответ; skip bad row недопустим. Ошибки observer сохраняют существующий fixed sanitized code/status mapping оболочки, включая fail-closed для stores/pending/races; unavailable применяется только к отсутствию результата Verify у корректной строки.

## 7. Принятый M и следующий отдельный synthetic-срез

M, предложенный VS-121 и принятый VS-122: `CatalogMetadataObserver.observe()`, immutable внутренние rows с exact metadata, presence/source (включая environment_unbound) и строковым verification unavailable. Его файлы — `backend/voxarium_studio/sync/catalog_metadata.py` и `backend/tests/test_remote_catalog_metadata.py`. M не менял REST DTO, не имел cache/clock/Verify/transport или production factory; принятие M не являлось успешным GET ServerProfile.

После VS-123 реализация разделена на две последовательные задачи: VS-124 — strict unavailable-вариант локального DTO, write scope только `backend/voxarium_studio/api/remote.py` и `backend/tests/test_remote_api.py`; затем зависимая от VS-124 задача VS-125 — отдельный немонтируемый rows → ServerProfile adapter по §6, write scope только `backend/voxarium_studio/api/remote_metadata.py` и `backend/tests/test_remote_metadata_adapter.py`. DTO предшествует adapter; задача adapter не меняет observer/S2/REST, включая файлы и contracts. Это не разрешение писать код сейчас. Не менять service/protocol, POST Verify semantics, mounting, runtime/lifecycle, Remote wire, migration/deploy/build/restart; production injection не добавлять.

### Scoped synthetic acceptance будущего DTO/adapter

| Случай | Ожидаемое evidence |
| --- | --- |
| Строгий unavailable DTO | Только `{state:"unavailable"}` принят; missing verification, null, строка вместо объекта, неверный state/type и любое extra (включая null checked_at/user/capabilities) отвергнуты, не default |
| Stored/environment/missing; tombstone/legacy-only; два exact профиля с одинаковым или историческим именем | Полный mapping §6, имя/ID/URL/revision сохранены; unavailable без checked fields; не unchecked/error; строки не переданы напрямую |
| Empty result и несколько корректных rows | Один injected observe; полная валидация до публикации; empty только из успешного observer; no-store сохраняется на success/error |
| Один ENV-unbound среди корректных rows (empty/mismatched ENV) | `metadata_unavailable`/503, без partial items, none/stored fallback и расширения credential enum |
| Observer сообщает corrupt/unreadable/nonregular stores, pending, failed reader, list/source/locator drift | Прежний typed sanitized отказ, не unavailable/empty success; без retry/rebind/skip; fences M не обходятся |
| Key A→B с прежними source/has_token; неизвестный/stale status | Только presence + unavailable; не переносить checked result, не утверждать continuity/историю unchecked |
| Invalid row или missing row verification | Весь ответ отвергнут; ни default unavailable, ни partial items |
| Повторные GET, fake Verify/clock/token loader/transport и synthetic canary errors | Verify/clock/token lookup/transport/cache writes = 0; никакой status persistence; no-store/auth/validation и secret-free errors/repr/log/chains сохранены |

Только targeted socket-free endpoint-unit/adapter tests на synthetic home в task-private temp, с injected observer (при необходимости реальные S2 readers для узкой wiring-проверки). Не повторять общий аудит/A–D или полную приёмку M; существующие fences не переобъявлять непрерывной изоляцией. Фактическая будущая приёмка должна назвать command/count/skips и counters запрещённого I/O; таблица — план, не уже выполненные тесты. В VS-123 допустимы только документальные проверки и независимое статическое scoped review, без runtime imports, реальных configs/keys/data, сети/DNS/listeners.

**Проверка VS-123:** независимое scoped static review трёх согласованных разделов — PASS; DTO/mapping сверены с актуальными owners, блокеров нет. `git diff --check -- docs/voxarium-studio-dev-spec.md` пройден; U+FFFD в трёх документах — 0. Только документы: synthetic acceptance не запускалась; код, реальные configs/keys/data, сеть/DNS/listeners и runtime не затрагивались, чужой diff сохранён.

## 8. Проверка VS-121

Graphify query → актуальное статическое чтение пяти запрошенных owners, `catalog_service.py` и strict application reader; граф — навигация, не доказательство поведения. Два независимых Studio subagent проверили list/source и границу verification; результаты прочитаны через get_subagent. Их выводы согласованы консервативно: environment_unbound остаётся различим внутри, а не теряется в missing; unknown cache не превращается в unchecked.

Тесты/probes, импорты project runtime, сеть, реальные configs/keys/data, build/restart не выполнялись. Постоянная запись VS-121 — только этот документ через write_doc; код и чужой diff не редактировались и не откатывались. Synthetic acceptance выше — план, не заявление о пройденных тестах. Финальное независимое scoped review текста — PASS: проверены state semantics, точный blocker, scope M и synthetic acceptance; это не runtime/API readiness. Статическая проверка UTF-8: replacement characters — 0; документ содержит ровно два предложенных code write_paths для M.
