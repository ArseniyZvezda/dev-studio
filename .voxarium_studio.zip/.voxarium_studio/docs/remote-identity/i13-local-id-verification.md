# VS-176 — локальное редактирование ID: UI и проверка

16.11.2026. **Частичный I13; приёмка доставки заблокирована P1 контракта G.** Полный I13 и второй milestone не завершены. Основание: [[remote-identity/runtime-integration-plan]] I13/§5, [[remote-identity/studio-design]] §5.2–5.3, [[remote-identity/i8-editor-proof]] и [[remote-identity/i8-editor-verification]]. Graphify применён до поиска; текущие owners прочитаны отдельно, индекс не использовался как доказательство свежести diff.

## Реализованная дельта

- `frontend/src/components/settings/SyncSettings.vue`: вместо legacy URL/space/password/Save-and-connect — последний наблюдаемый persistent ID, read-only URL/статус и локальная смена ID. Строгая canonical validation `[a-z0-9][a-z0-9._-]{0,63}` без trim/lowercase, отдельный review и явное подтверждение точного ID/URL.
- После подтверждения: prepare `edit_id` → quiesce → commit только при ready. Настоящие freeze/flush/receipt/ACK выполняют существующие редакторы I8 через Ctx events; форма не фабрикует ACK, не закрывает dirty editor и не делает clean-save ради продолжения.
- R/fingerprint/backend epoch/runtime scope/old G и target захвачены до первого await. Commit request несёт известный fence oldG+1 по контракту I5, **не latest G**. Финальный committed G — отдельный непрозрачный результат I6, не oldG+1. Чужой phase/новое наблюдение отвергают позднее продолжение.
- Cancel во время prepare делает DELETE только точного позднего change_id; поздний ready не запускает commit. Ошибка отмены допускает явный повтор Cancel. Paused после fence не называется восстановлением. Во время commit отмена недоступна; потеря ответа даёт unknown outcome без автоматического повторения/DELETE.
- Полный receipt проверяется до success; противоречивый follow-up GET убирает saved notice. Ошибки локализованы EN/RU без вывода raw details. Старые наблюдения помечаются как «Последний известный ID».
- Ни Remote rename/Create, ни Select/Preview/Enable, ни migration/join не добавлены; ключа в форме нет. `ProjectSettingsView.vue` уже монтирует SyncSettings, поэтому дополнительная правка не нужна. Config/session stores, пути, MCP, jobs и foundations не переписывались.

## Проверки текущего checkout

Из `frontend/`:

```powershell
npm test -- src/components/settings/SyncSettings.spec.ts src/api/client.spec.ts src/api/project-scope.spec.ts src/stores/sync.spec.ts src/stores/docs.spec.ts src/views/DocsView.spec.ts src/lib/collab/session.spec.ts src/lib/collab/editor.spec.ts src/i18n/i18n.spec.ts
npm run typecheck
```

**563 passed, 9 файлов, 0 failed/skipped/todo; typecheck PASS.** Новый SyncSettings suite: **82 passed**, real Vue createApp + Pinia sync store + project API client + immutable rendererSession, synthetic HTTP boundary. Покрыты EN/RU success, invalid/boundary ID, явное подтверждение, cancel/late prepare/quiesce/unmount, dirty/room/legacy blockers, transport failure/409/stale G, uncertain commit, foreign late response, malformed receipt и противоречивый refresh. Все запросы ограничены project remote surface: **0 Markdown mutation calls**, нет `/sync` PUT, editor ACK из формы, Remote Create/Enable/socket и renderer rebind/invalidate.

Прежние I8 suites сохранены и повторно зелёные: docs-store 267, DocsView 60, collab session 20/editor 8. Их paired clean/non-scribe доказательства описаны в [[remote-identity/i8-editor-verification]]; это не подмена backend/Remote interop.

Из `backend/`, окружение с установленным `voxarium_studio_remote`:

```powershell
.venv\Scripts\python.exe -m pytest tests/test_remote_transitions.py tests/test_remote_binding_drain.py -q
```

**185 passed, 0 skipped/failed** (task-private basetemp/cache заданы явно). Это регрессии существующих drain/lease owners, не end-to-end смена ID из нового UI. Scoped `git diff --check` — PASS. Остались прежние предупреждения Vite native config и pytest asyncio fixture loop scope. Полный frontend suite/build не запускались; серверы, run.cmd и remote_test не запускались, production данные/ключи не читались.

## Независимый scoped review

Отдельный read-only worker проверил current source, Ctx/API/backend boundary и дополнительные race probes. Первичный verdict был **NOT PASS**: P1 ниже и P2 — неполный commit receipt/противоречивый refresh могли оставить ложный saved notice.

P2 исправлен; независимый delta-review подтвердил устранение, поздние callbacks, captured oldG/fence, Cancel/unmount и uncertainty без новых scoped P1/P2. На момент review component/store/i18n: **113 passed, 0 skipped**. Независимые probes: **20 passed, 2 failed, 0 skipped**; оба отказа воспроизводят P1. После review добавлены ещё 3 постоянные регрессии missing G/fingerprint и contradictory refresh; implementation не менялся, финальные 563 выше включают их. Это **не independent deployment PASS**.

## Открытый P1: несовместимость owning I6/I7 G

`backend/voxarium_studio/api/sync.py` формирует committed `binding_generation = secrets.randbits(63)+1`; `sync/transitions.py::complete_commit` устанавливает его. Однако `frontend/src/stores/sync.ts::loadRemote/subscribe` принимает только safe integer и неубывающий G. Поэтому G=`2**62` отвергается, а часть JSON чисел теряет точность ещё до проверки. Даже точный безопасный финальный G=2 после oldG=7 отвергается как устаревший. Последующий refresh оставляет прежние ID/G; обычный случайный 63-битный результат почти всегда выходит за safe range.

Новый UI честно fail-closed/unknown outcome и не снимает guards, но это **не исправляет реальную смену ID**: backend мог уже записать новый ID, а браузер не принимает новую generation. Success fixtures используют явно обозначенный безопасный возрастающий sample; отдельные постоянные тесты показывают отказ на реальном диапазоне I6 и меньшем opaque G, а не скрывают проблему зелёными mocks.

Нужна узкая согласованная коррекция owning I6/I7 с lossless G, порядком наблюдений и restart/late-callback regressions; просто убрать Number.isSafeInteger или взять latest G нельзя. Маршрутизация передана Producer в **VS-178** (Todo, ещё не выполнена). До неё текущая приёмка VS-176 незавершена; требуется решение reviewer о corrective owner и возврат к этой карточке после исправления. Реальный end-to-end smoke — отдельная задача, не выполнен здесь.

## Сохранность и артефакты

Большой исходный чужой diff, включая partial VS-173/175, сохранён; изменения этой карточки ограничены SyncSettings.vue/new spec, новым `sync.identity` EN/RU subtree и этим документом. Task-private baselines, JSON reports, independent probes и логи — только `.voxarium_studio/temp/TASK-176`; они disposable и не заменяют этот постоянный результат. Коммит общего shared worktree не выполнялся.
