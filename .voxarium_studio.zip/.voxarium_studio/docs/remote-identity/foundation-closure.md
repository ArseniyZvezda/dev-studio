# VS-112 — закрытие девяти ошибок E1/E2 foundations

15.11.2026. Узкая read-only приёмка после VS-106/VS-107, по [[remote-identity/foundation-final-validation]] и [[remote-identity/studio-design]] §3.1, §11/S1–S2. Прочитаны карточки VS-105–107 и актуальные исходники. Graphify выполнен первым; индекс использован для навигации, не вместо чтения владельцев.

## Вердикт и граница доказательства

**Восстановленные ожидания VS-105: E1 — 3/3 PASS, E2 — 6/6 PASS.** Адресные дополнительные/regression проверки — **515 PASS**; пять финальных запусков суммарно **524 PASS / 0 FAIL / 0 errors / 0 skipped**. Это case-executions, не 524 уникальных новых теста: 15 disposable cases и 509 existing cases; девять repro намеренно пересекаются с correction suites.

В проверенных границах E1/E2 закрыты, новых продуктовых дефектов не обнаружено. Это **не общая чистая приёмка S1/S2, не готовность UI/runtime и не разрешение production/cutover**. Завершённые F1–F4/A–C audit и workspace flake не повторялись. Результаты VS-105 (762 PASS / 9 FAIL, workspace 3/3) и заявленные в карточках VS-106 (562 PASS), VS-107 (460 PASS) — прежние данные, в текущие counters не включены. Историческая причина VS-100 по-прежнему не установлена.

## Восстановление именно исходных девяти ожиданий

Новые probes созданы с нуля по постоянному описанию VS-105, без чтения/копирования прежних TASK-105/106/107 temp-скриптов. Ожидания контракта не заменены ожиданием старого дефекта.

Общий E1 fixture — точные UTF-8 bytes:

```yaml
project_identity: {id: good-id, revision: 1}
unused: 2026-13-01
```

Файл — synthetic `<tmp>/project/.voxarium_studio/config.yaml`; отдельный synthetic Studio home. E2 использует `RemoteProfiles` и вымышленный URL `https://e2.fixture.invalid/team` только как metadata. Для rename сначала создаётся профиль `Original` с revision=1; затем передаётся его exact ID/current revision. Публичных mutation endpoints нет.

| Исходный дефект VS-105 | Новый тест (модуль относительно TASK-112) | Проверенное ожидание после исправления | Результат |
| --- | --- | --- | --- |
| E1-1: plan выбрасывал constructor ValueError | `test_e1_original.py::test_e1_plan` | `invalid_config`, ID/revision отсутствуют, SHA256 исходных bytes, повторный план идентичен; snapshot через finally | PASS |
| E1-2: load выбрасывал тот же ValueError | `test_e1_original.py::test_e1_load` | Полный прежний default fallback, warning args=(trusted path, yaml_error), без exc_info; snapshot через finally | PASS |
| E1-3: GET migration отдавал 500 | `test_e1_original.py::test_e1_get` | Diagnostic 200, no-store, invalid_config/no ID, fingerprint bytes; snapshot через finally | PASS |
| E2-1: create сохранял внешние пробелы | `e2/test_e2_original.py::test_e2_original[trim-create]` | `"  Team  "` → `"Team"`, сохранено и перечитано | PASS |
| E2-2: rename сохранял внешние пробелы | `e2/test_e2_original.py::test_e2_original[trim-rename]` | То же; ID/URL неизменны, revision+1 | PASS |
| E2-3: create принимал 121 ASCII | `e2/test_e2_original.py::test_e2_original[reject-121-ascii-create]` | `ProfileError("invalid_profile_metadata")`, bytes/mtime файлов home неизменны | PASS |
| E2-4: rename принимал 121 ASCII | `e2/test_e2_original.py::test_e2_original[reject-121-ascii-rename]` | То же, исходная metadata не заменена | PASS |
| E2-5: create принимал newline | `e2/test_e2_original.py::test_e2_original[reject-newline-create]` | `"Team\nInjected"` отклонено, files snapshot неизменен | PASS |
| E2-6: rename принимал newline | `e2/test_e2_original.py::test_e2_original[reject-newline-rename]` | То же | PASS |

В E1 GET оставлен настоящий production router, parsing и serialization; заменён только `get_ctx` на synthetic `SimpleNamespace(paths=...)`. `httpx.ASGITransport(raise_app_exceptions=False)` позволяет увидеть 500 при дефекте, не подменяет response. **Это endpoint-unit ASGI проверка без AppContext/lifespan, не full application/workspace integration.** Внешний URL не разрешается и не обслуживается сокетом.

У disposable модулей вне pytest root фактически collected nodeids имеют вид `::test_e1_plan` / `::test_e2_original[trim-create]`; таблица добавляет имя модуля для однозначности. Запуски передавали абсолютный путь соответствующего файла целиком.

## Адресные regressions и source review

### E1: границы parsing и B

`test_yaml_constructor_errors.py`: **147 PASS**. Настоящие invalid month/day/leap/hour/minute/second/timezone timestamps; read/load/load-with-migration, legacy/scoped diagnostic GET, с существующим/отсутствующим home config. Constructor canary не попадает в warning/LogRecord/exception fields; повторные планы стабильны, bytes/mtime/empty dirs/home сохранены. Valid dates сохраняют SafeLoader date/datetime types и identity; duplicate/merge policy не унифицирована незаметно.

Отдельные existing tests внутри этих 147: `test_model_validation_is_not_reclassified_as_yaml_fallback`, `test_value_error_from_disk_read_is_outside_yaml_boundary`, `test_value_error_after_yaml_parse_propagates`, `test_value_error_in_application_overlay_is_not_swallowed`. Проверено, что ошибки validation/scope/read ValueError/overlay не поглощаются новым constructor catch. Предусмотренные старым контрактом OSError/Unicode/YAML read fallbacks остаются fallbacks, а не превращаются в validation.

B — **22 PASS** direct init/ensure cases из `test_project_open_validation.py`: 16 комбинаций layouts × init/ensure × preferences плюс 6 invalid identity shapes. Валидно разобранная YAML с невалидной identity по-прежнему даёт ValidationError **до** init writes/preference migration; root/home snapshots и отсутствие генерации UUID проверяются исходными assertions. HTTP open, bootstrap и runtime registry здесь не запускались.

Актуальные owners: `core/config.py:_read_project_config` переводит ValueError только вокруг `yaml.safe_load`; чтение, `_project_fields`, model validation и overlay вне этой границы. `core/project_identity.py:identity_migration_plan` считает fingerprint до decoding/parsing и возвращает invalid diagnostic без ID. `core/project.py:init_project` сохраняет preflight до writes. **B не означает запрет открытия любого повреждённого файла:** если YAML вообще не разобрана, прежний runtime parse fallback намеренно сохраняется; это не новая гарантия validation такой identity.

### E2: fresh input, historical metadata и binding

`test_remote_profile_labels.py`: **329 PASS**, без API/runtime. Модель/repository: trim, 1–120 Unicode code points; 120 кириллических/astral и decomposed labels; отсутствие NFC и wire byte-limit; empty/121/type и все C0/DEL/C1 отвергаются. Invalid create/rename до disk transaction/read; whole-home snapshot (включая empty dirs/mtimes), revisions и keys сохранены.

Historical labels (внешние пробелы, пустые/overlength/decomposed/controls) читаются буквально и переживают preferences/create/rename-other/set/clear/URL fixture operations; opaque top-level/nested preference fields сохраняются, stale preference save не откатывает актуальную registry. Явный rename вновь применяет strict input. Stored metadata context не отключает валидацию ID/URL/revision/extra secret/type.

Независимо написанные `e2/test_e2_addressed.py`: **6 PASS** — три historical-label round-trips (untrimmed/121/newline), сохранение opaque fields и stale preferences; stale profile CAS сохраняет metadata/credential bytes+mtime; exact profile-ID+normalized-URL credential binding и credential CAS; ENV требует exact normalized URL. Дополнительно **11 existing PASS** (9 credential cases + 2 metadata/CAS/URL-change cases), перечисленных в командах ниже.

Source review: `application_config.py:validate_profile_name` запрещает Unicode Cc до trim; stored context сохраняет только label буквально. `profiles.py:create/rename` вызывает strict helper до transaction, CAS остаётся перед publication; rename сохраняет ID/URL и увеличивает revision. Metadata writer сохраняет raw opaque document и актуальную registry при preference save. Stored credentials связаны с exact profile ID **и** normalized URL; ENV override связан с URL, не с profile ID — это отдельная семантика, не равная stored binding. Synthetic lifecycle guard существующих storage tests не доказывает production drain/wiring.

## Команды и точные counters

CWD `D:\VoxariumStudio`; Python — существующий `backend/.venv`, CPython 3.12.13. Ничего не устанавливалось. Навигация:

```powershell
graphify query "remote identity foundation S1 S2 E1 E2 settings read project display name" --graph "D:\VoxariumStudio\graphify-out\graph.json"
```

Фактические финальные invocations (для каждого также stdout/stderr redirect `> "$t/<label>-console.txt" 2>&1`):

```powershell
$py = '.\backend\.venv\Scripts\python.exe'
$t = 'D:\VoxariumStudio\.voxarium_studio\temp\TASK-112'

& $py -B "$t/run.py" e1-original-final "$t/test_e1_original.py"
& $py -B "$t/run.py" e1-regressions backend/tests/test_yaml_constructor_errors.py backend/tests/test_project_open_validation.py::test_invalid_existing_identity_precedes_all_init_writes backend/tests/test_project_open_validation.py::test_other_invalid_identity_shapes_also_precede_init_writes
& $py -B "$t/run.py" e2-original "$t/e2/test_e2_original.py"
& $py -B "$t/run.py" e2-addressed "$t/e2/test_e2_addressed.py"
& $py -B "$t/run.py" e2-regressions backend/tests/test_remote_profile_labels.py backend/tests/test_remote_profiles.py::test_credentials_require_profile_and_normalized_url backend/tests/test_remote_profiles.py::test_credentials_cas_delete_and_aba_protection backend/tests/test_remote_profiles.py::test_credentials_never_transfer_live_key_to_new_url backend/tests/test_remote_profiles.py::test_credentials_env_unbound_never_falls_back backend/tests/test_remote_profiles.py::test_credentials_env_matching_is_volatile_and_url_bound backend/tests/test_application_settings.py::test_remote_profiles_metadata_cas_collision_and_preferences_preserved backend/tests/test_application_settings.py::test_remote_profiles_url_change_revokes_not_transfers_key_and_cas
```

Runner вызывает `pytest.main` в том же guarded процессе, без дочерних pytest workers:

```text
-c D:\VoxariumStudio\backend\pyproject.toml -o addopts=
-p no:cacheprovider -p pytest_asyncio.plugin
--basetemp <TASK-112>/<label>/pytest
--junitxml <TASK-112>/<label>/junit.xml
--log-file <TASK-112>/<label>/pytest.log -q <selected files/nodeids>
```

Plugin autoload выключен, xdist не загружается; никакого `-n auto`. Точные args, collected nodeids, setup/call/teardown outcomes и guard summary — в каждом `command.json`, `collected.json`, `results.jsonl`, `guard.json`.

| Финальный run | PASS | FAIL | Errors | Skipped | JUnit seconds |
| --- | --- | --- | --- | --- | --- |
| e1-original-final | 3 | 0 | 0 | 0 | 1.070 |
| e1-regressions | 169 | 0 | 0 | 0 | 3.158 |
| e2-original | 6 | 0 | 0 | 0 | 0.099 |
| e2-addressed | 6 | 0 | 0 | 0 | 0.269 |
| e2-regressions | 340 | 0 | 0 | 0 | 5.277 |
| **Итого финальные** | **524** | **0** | **0** | **0** | — |

В `e2-regressions`: 329 label + 9 credential + 2 application cases. Новых skip/xfail/assertion relaxation нет; process/HTTP-open/другие suites **не выбраны**, а не объявлены passed/skipped.

**Не скрытая предварительная ошибка harness:** первый `e1-original` завершился **2 PASS / 0 FAIL / 1 setup ERROR / 0 skipped**: stock Proactor constructor ожидал `_csock` для signal wakeup после отключения self-pipe. Это ошибка disposable NoSocketLoop до GET, не продуктовый FAIL. Исправлен только task-temp runner: BaseEventLoop/IOCP инициализируются без self-pipe/signal fd; все три неизменных E1 probes заново выполнены как `e1-original-final`. Ранний run хранится отдельно и не входит в финальные 524; включая его, все шесть invocations дали 526 passed и 1 harness setup error. Во всех invocations печатался pytest-asyncio warning о незаданном default fixture loop scope; это не skip/error теста.

## Изоляция и честные denied counters

До asyncio/pytest/product imports runner направляет HOME/USERPROFILE/APPDATA/LOCALAPPDATA/XDG/Studio/Codex/Claude homes и TEMP/TMP/TMPDIR под собственный `TASK-112/<label>`, удаляет Remote credential ENV, отключает bytecode/cache. Per-test fixtures дополнительно задают synthetic Studio home. Все project configs/credentials — fixtures; реальные config/keys/data не читались.

Python audit hook fail-closed запрещает все `socket.*` (включая hostname/DNS), перечисленные process-launch events, audited filesystem/SQLite writes вне TASK-112; дополнительно отвергает чтение настоящих managed-project data и config/key filenames вне isolated temp. HTTP-send guard разрешает только два diagnostic migration GET, любой sync HTTP send и прочие async sends запрещены. Серверов/listeners нет; public mutation endpoints, PUT sync, migration apply не вызывались.

| Run | Denied socket.gethostname | Denied launch | Denied writes/real-data reads/forbidden HTTP | Разрешённые diagnostic ASGI GET |
| --- | --- | --- | --- | --- |
| e1-original-final | 1 | 0 | 0 | 1 |
| e1-regressions | 1 | 0 | 0 | 72 |
| e2-original | 1 | 0 | 0 | 0 |
| e2-addressed | 1 | 0 | 0 | 0 |
| e2-regressions | 1 | 0 | 0 | 0 |
| **Финальные пять** | **5** | **0** | **0** | **73** |
| Предварительный e1-original (отдельно) | 1 | 0 | 0 | 0 |

Не «ноль сетевых попыток»: hostname attempts были и запрещены до выполнения. Во всех шести guard summaries других socket events (creation/bind/listen/connect/accept/getaddrinfo/gethostbyname) нет; успешных audited socket operations — 0.

NoSocketLoop использует настоящий IOCP, но **не штатный Windows scheduler**: self-pipe/self-read/socket wakeup/signal fd отсутствуют, native select capped polling quantum=0.001 s. Thread callbacks доставляются через polling, 1 ms не гарантирует latency. Это diagnostic no-socket harness, не доказательство штатной transport/process/thread-wakeup работы. Workspace/watcher не запускались.

Audit hook **не OS/native sandbox**: lexical abspath containment не защищает универсально от junction/symlink, integer descriptors разрешены; нет общего allowlist всех reads и native/ctypes перехвата. Counters отражают наблюдённые Python audit events/HTTP observer, не аттестацию отсутствия любого native IO. Проверенные storage operations включают штатный Windows ACL код на synthetic files, не полную сертификацию ACL/durability. Никаких install/build/restart/deploy/EXE/APK, runtime wiring или реальных Remote requests.

## Scoped source-integrity

HEAD до/после: `f84cf0d9838e46b7f58e357331dbc3ef38685f9b`. Сняты 17 конкретных sources/config/test files до первого probe и после всех runs: **0 изменений SHA256/length/mtime, 0 missing**. Это scoped snapshot, не полный checkout audit.

SHA256 **before = after** (повторный финальный snapshot также совпал):

| Path | SHA256 before = after |
| --- | --- |
| backend/voxarium_studio/core/config.py | `55cbbeefce5ca6c1e6bd3296627026579fc4f39509a7d9c5cbbec37d24fd472d` |
| backend/voxarium_studio/core/project_identity.py | `b6377fea0996164e9239eb28e38fe9774d5a0b972bfed4d02a67c46566905979` |
| backend/voxarium_studio/core/project.py | `1c913e02357899a8fddc409eaff56e2a880597ef6622018ff3c5a5cbdcc0a0ca` |
| backend/voxarium_studio/core/application_config.py | `36b6f8cffc57c09ff96e089e7928659cd42e128c4aa254439a6aff1355561022` |
| backend/voxarium_studio/core/paths.py | `98fd659c031b80d38630a85abe2d0a641421b99004c51e2dfc4e5aa12e086b07` |
| backend/voxarium_studio/api/project.py | `f50fc13905c1aba2a54cdf3354b09d4e22d8bf782a3fef9ff42e6f4c81ff6dc6` |
| backend/voxarium_studio/api/deps.py | `be4a977dce8c7f924378936ebf0161c681480a10268f9b0880ee7f270885fdb4` |
| backend/voxarium_studio/sync/profiles.py | `582be5e6864897842198c625d02fe5bac89f713a63e10d5255cb16fbf87ceea5` |
| backend/voxarium_studio/sync/credentials.py | `2269a4430e1e5a4ae03e160d5540c7aba2a6b6721f130f58691f7de3329e823d` |
| backend/tests/conftest.py | `b62529138a446f4cbd7479e1a3bfa44b61760a1e0fc7a2e20bb3d4d015132cf3` |
| backend/tests/test_yaml_constructor_errors.py | `f8984a78b4ee69282734dbce9da16c2a06e33e3e7ac35e2edf54f4ec561fd746` |
| backend/tests/test_remote_profile_labels.py | `c754d7faa3c9aefaefc10331bbfbcce9573083860ed5a68ecb042a7058f59ced` |
| backend/tests/test_project_open_validation.py | `286a1b4e1486e99889fadf0016106b379e0a9ed20393daa1889dc15c093333b0` |
| backend/tests/test_config_error_redaction.py | `e783495f995286a0ef359ddf246488b2822b6d838c8766ee7b81cbfa1728efa9` |
| backend/tests/test_remote_profiles.py | `384dae3bc60e362eeaa9007ace9c0e7e55f2258f9f7155bb08dd3bf51874de73` |
| backend/tests/test_application_settings.py | `a2dd16fb93cdf33fc48e97fda2df523d6eca4698259d0fee7130f1164748cdf4` |
| backend/pyproject.toml | `8707f6110693d2742c366e0daf9b24b2d58d2a7d68381ab68717667cb8c3be2f` |

`snapshot.ps1 before/after` сохранял список/hash/length/mtime, HEAD, `git status --porcelain=v1 --untracked-files=all` и `git -c core.safecrlf=false diff --binary --no-ext-diff`. Сохранённые UTF-8 PowerShell text snapshots diff до/после побайтно одинаковы, SHA256 `20036bcba9bbcccf7b39fa7c4d8735aeb34079ab0e0fca46cb330485cd407aba`; status snapshots — `6d59acca6d005b6bb56b0254740b416ce89d7626eceda377485684a0807d377b`. Это hash именно сериализованных text artifacts, не raw Git stdout binary hash. `git -c core.safecrlf=false diff --check` — без diagnostics, exit 0. Existing code/tests и чужой diff не редактировались, не откатывались, не stash/commit.

Единственный постоянный deliverable — этот документ; probes/harness/logs/snapshots только в `.voxarium_studio/temp/TASK-112`. Raw evidence disposable и удаляется при Done; его нужно просмотреть до утверждения. Таблица fixtures/ожиданий и команды выше оставлены постоянно, но исчезающие temp paths не являются гарантированно доступным будущим test package.

## Независимое review

Studio subagents, результаты прочитаны через `get_subagent`:
- `subagent_fcee4d1180d14b9b` независимо восстановил E2 six + six адресных probes и прочитал owners; тесты запускал parent.
- `subagent_caa328fcf619401f` независимо прочитал E1/E2 owners, existing tests, harness и E1 probes: блокеров в коррекциях не нашёл; потребовал отличать endpoint-unit от application integration, ограничить B успешно разобранной YAML и явно назвать audit/scheduler limitations. Эти ограничения включены выше.

Финальное независимое evidence/draft review выполнено `subagent_caa328fcf619401f`: **PASS в заявленных границах**. Сверены probes/harness, пять финальных комплектов JUnit/guard/collected/results (все 524 setup/call/teardown passed), отдельная предварительная ошибка harness и source-integrity artifacts; расхождений и блокеров не обнаружено. Reviewer тесты не запускал и файлы не изменял.

## Не проверено этой задачей

HTTP open/bootstrap/resident context integration, stock Windows scheduler, межпроцессный CAS/abrupt-exit/crash contention, real disk-full/power-loss durability; весь прежний audit и workspace/watcher flake; transport/remote sync/v2 catalog/UI/runtime wiring/installed Studio; реальные configs/keys/server data, сеть/DNS/listeners, production migration/cutover/deploy/build/EXE/APK. Никаких выводов об их готовности из 524 PASS не следует.
