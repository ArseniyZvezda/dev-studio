# VS-180 — Remote v2 и Admin: проверка server candidate

16.11.2026. **Серверная область VS-180 завершена; общий релиз НЕ объявляется.** Основа: dev spec §16.7–16.9, [[remote-identity/server-design]], [[remote-identity/delivery-authorization]], [[remote-identity/runtime-integration-verification]]. VS-54 bootstrap/discovery/TLS переиспользованы, а не переписаны; контракт VS-89 реализован с явно документированной staged-границей Studio.

## 1. Поставленный срез

- Remote package 0.2.0, wire/catalog v2, schema v2 через `PRAGMA user_version`, SSH admin RPC v1 — независимые версии. Fresh DB создаётся; существующая v1/неизвестная schema на startup не мигрируется и не открывается для обычных записей.
- Явные offline inspect/backup/dry-run/apply/rollback. Backup использует SQLite backup API с committed WAL; apply требует нового backup и утверждения offline, выполняет транзакционную миграцию и сравнение сохранённых данных. Rollback восстанавливает целый v1 backup, сначала сохраняя нынешнее состояние в отдельный recovery backup; требует offline и явного принятия потери последующих записей. Команды и эксплуатационные предупреждения — `remote/README.md`.
- Сохранены старые UUID пользователей/проектов, FK, Markdown/hash/rev/seq/tombstones, авторство и timestamps, пустые и tombstone-only проекты. ID и initial storage_epoch равны прежнему UUID байт-в-байт; old name сохранён как display label и exact legacy mapping, не sync alias.
- Exact ID==space, authenticated каталог/get/explicit Create/snapshot/legacy resolve. Duplicate labels разрешены. Unknown/v1 connect, GET, snapshot, resolve, комнаты и reconnect ничего не создают. V1 WS закрывается 4400 до Hub; unknown v2 ID — 4404. Нет публичного admin HTTP/RBAC.
- Credential binding `(UUID, credential_version)`: весь синхронный inbound handler и registration сериализованы транзакцией с отдельными SQLite connections; outgoing перепроверяется при dequeue. Rotate/revoke/delete и revoke→rotate не оживляют старый socket; очередь очищается, штатно удаляются presence/sessions и передаётся scribe. Watcher не может перенять новую credential generation. Уже авторизованные in-flight bytes не отзываются назад; DB lock не держится через сетевой await.
- UUID/CAS user CRUD, immutable legacy handles, duplicate display names, soft-delete и идемпотентный revoke/delete. Edit не меняет credential. Hash-only хранение; ключ выдаётся после commit, не восстанавливается через get/list.
- Расширено существующее EN/RU меню Users/Projects. Полные target UUID/server/container, default Cancel, typed UUID и второе подтверждение rotate/delete, отдельное восстановление revoked. Unknown outcome перечитывается по исходному UUID без replay mutation. Legacy fallback читает существующую v1/v2 DB read-only, не bootstrap/migration.
- SSH JSON RPC: одна allowlisted stdin-операция, request ≤16 KiB, response ≤256 KiB, stderr ≤16 KiB; фиксированная команда без payload/ключа в argv, без auto-retry. Предварительный Docker/sudo probe отдельно bounded: stdout 64 B, stderr 4096 B, 15 s, только точный `true`. Сырые stdout/stderr/timeout diagnostics не показываются.
- Одноразовая скрытая issue view с явными Reveal/Copy и TTL ≤60 s; секрет не идёт в generic result/profile/temp/DB. Windows clipboard — in-process ctypes, pointer-safe signatures и hidden owner HWND; очистка только собственной sequence. Сбой получения sequence после передачи очищает запись ещё под исходным clipboard lock. Реальная история/cloud clipboard и физическое стирание Python memory не обещаются.

## 2. Финальные команды и результаты

Рабочая директория `D:/VoxariumStudio`. Test interpreter: `backend/.venv/Scripts/python.exe`, Python 3.12.13 x64; Remote установлен editable из данного `remote/`, версия 0.2.0, pycrdt присутствует. Ни importorskip для отсутствующего v2 prerequisite, ни xfail/skip ради зелёного результата не добавлялись.

Disposable scripts/cache/logs/XML/build/downloads находятся в `.voxarium_studio/temp/TASK-180`. Ошибочно созданный worker-cache из `remote/.voxarium_studio/temp/TASK-180` перенесён в абсолютный task-temp. Артефакты temp будут удалены Studio после Done; существенные результаты зафиксированы здесь, постоянный EXE — в корне.

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
backend/.venv/Scripts/python.exe -m pytest -q -o addopts= -p no:cacheprovider remote/tests --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/remote-corrective-final --junitxml=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/remote-corrective-final.xml
backend/.venv/Scripts/python.exe -m pytest -n0 -q -p no:cacheprovider backend/tests/test_remote_protocol_v2_contract.py --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/protocol-corrective-final --junitxml=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/protocol-corrective-final.xml
backend/.venv/Scripts/python.exe -m pytest -q -o addopts= -p no:cacheprovider remote/tests/test_admin_bootstrap.py remote/tests/test_admin_bundle.py --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/bootstrap-bundle-corrective --junitxml=D:/VoxariumStudio/.voxarium_studio/temp/TASK-180/bootstrap-bundle-corrective.xml
```

| Финальный набор | Результат |
| --- | --- |
| Весь `remote/tests`, включая VS-54 bootstrap/transport/UI/bundle и новые миграции/catalog/lifecycle/RPC/secrets | **500 passed, 0 failed/errors/skipped**, 19.93 s |
| Backend v2 declarations + настоящий legacy-runner refusal / настоящий Remote hello | **38 passed, 0 failed/errors/skipped** |
| Отдельная bootstrap/bundle регрессия | **74 passed, 0 failed/errors/skipped** |
| Root corrective snapshot/catalog/bundle subset | **158 passed, 0 skipped** |
| Scoped `git diff --check`, AST decoding через `tokenize.open` | **PASS**; только предупреждения Git о CRLF→LF |

Эти наборы пересекаются; числа не суммируются. Pytest сообщает прежний unset asyncio fixture loop scope warning. Remote и backend suites запускаются отдельно: backend conftest создаёт дополнительные fixture-каталоги в tmp_path, поэтому совместная collection с одним Admin secret tree-assertion не является штатным harness.

Проверены concurrent Create (ровно один победитель), CAS/stale confirmation, snapshot keyset/cursors/tombstones/epoch+seq race, отдельные SQLite connections и настоящие handler/queued-send guards; комнаты не персистируют Yjs и чистое открытие не пишет Markdown. Проверки сохранности включают настоящую исходную v1 schema из `git show HEAD:remote/voxarium_studio_remote/store.py`, а не только migration-константу.

Snapshot budget соответствует фактическому compact UTF-8 JSONResponse. DEL×1,000,000 возвращается полностью HTTP 200; патологический legal content с обязательным JSON-экранированием, например NUL×1,000,000, даёт явный 413 payload_too_large без усечения/пропуска/изменения source. Это read-only preview limit, явно внесённый в dev spec §16.7 и README; он не разрешает overwrite или открытие Enable.

## 3. Независимые review и corrections

Два read-only Studio subagents независимо проверили сервер/data/security и Admin/RPC/secret UX. Первые review нашли **5 P2**, без P1: искусственное ASCII budget snapshot, неполная проверка embedded deployment context, clipboard sequence failure, unbounded Docker probe и writable/non-working legacy fallback. Все пять исправлены с постоянными regression tests; дефект-подтверждающие probes заменены acceptance expectations, не засчитаны повторно как успешное исправление.

- Server corrective review: **scoped PASS**, новых P1/P2 не найдено; **254 repository tests + 16 independent corrective tests**, без skips. Проверены WAL-safe backup, transactional rollback после полного DDL rebuild и отдельно whole-backup CLI restoration с сохранением post-backup writes в recovery backup. Проверены generation races/queued outgoing и completeness/hash всех 18 обязательных Remote-файлов + ssh.exe.
- Admin corrective review: **scoped PASS**, новых замечаний не найдено; итоговый объединённый прогон без `-k`/фильтрации — **473 passed, 0 failed/skipped**: 444 проектных теста + 29 independent probes. Включены canary diagnostics, UUID/CAS/default-cancel, lost-result GET, EN/RU, TTL/concurrency, fake WinAPI sequence/error cleanup, bounded probe и RPC rotate/revoke/delete через отдельную SQLite connection для всех 8 inbound frame kinds и queued outbound.

Независимые probes были в `TASK-180/review-server/` и `TASK-180/review-admin/`; reviewers проектные файлы не меняли. Выводы относятся к текущему server/Admin scope, не к общему клиентскому релизу.

## 4. Candidate EXE и clean-folder smoke

Сборка по существующему VS-54 процессу, без переделки bootstrap:

```powershell
$env:VOXARIUM_REMOTE_ADMIN_BUILD_DIR='D:\VoxariumStudio\.voxarium_studio\temp\TASK-180\build'
cmd /c 'build-remote-admin.bat --no-pause'
Get-FileHash D:/VoxariumStudio/voxarium-remote-admin.exe -Algorithm SHA256
```

Build Python **3.14.6 x64**, PyInstaller **6.22.3**. Успешный финальный build: `build-final.log`. Результат — **`D:\VoxariumStudio\voxarium-remote-admin.exe`**, unsigned candidate, **24,236,225 bytes**. Fallback `-updated.exe` не понадобился.

**SHA256:** `1f2b70e1deaf5247ac23420aa7de93fc510a469fc3c5b1eda00b938b31c4c0f9`.

Встроены полный deployment context Remote (18 обязательных файлов) и Windows OpenSSH с dependencies/notices; manifest покрывает 24 ресурса. Все embedded Remote hashes сопоставлены с окончательными исходниками после corrections, а не только с imported Admin runtime. Manifest SHA256: `8d0f8197c18b08539dbbf4289a42205af69a70d39521b5dbbeb1e308ea2d7635`. Embedded ssh.exe SHA256: `98d447730047f5df91373e852d057928a921c3d1e89938700ab656ba84b19dc8`.

Clean-folder: EXE скопирован в `TASK-180/smoke/clean`, PATH содержит только эту папку, без Python/OpenSSH; TEMP и config направлены в task-temp. Проверки:

```powershell
.\voxarium-remote-admin.exe --help
.\voxarium-remote-admin.exe --check-bundle
.\voxarium-remote-admin.exe --language en --config .\absent.json
.\voxarium-remote-admin.exe --language ru --config .\absent.json
```

- Help и check-bundle — exit 0. Запускается embedded ssh.exe `-V`; packaged in-memory fake SSH → настоящий RPC create/get + ephemeral Copy/close с fake clipboard проходит: **protocol=2, schema=2, admin_rpc=1**. Никакой реальный сервер/clipboard не используется.
- EN/RU меню проверены в **настоящем Windows ConPTY**: видны Users/Projects и соответствующие переводы, Esc завершает оба с exit 0. В clean-folder остаётся только EXE; профиль не записан, сетевых действий не выбирали.
- Первоначальная попытка интерактивного меню с redirected pipes без Windows console завершилась NoConsoleScreenBufferError. Это не засчитано как smoke PASS; повтор выполнен в ConPTY. Help/check-bundle пригодны для pipe automation, меню требует console.
- Отсутствие обязательного source-файла/manifest entry или несовпадение hash отклоняется. Manifest — проверка комплектности/целостности bundle, не цифровая подпись и не защита от намеренного переписывания всего EXE.

## 5. Staged-граница и остаток вне VS-180

Remote использует `PROTOCOL_VERSION=2`. В независимой Studio protocol-копии согласованы v2 ID/label/color правила, capabilities, catalog version и close codes через `WIRE_V2_VERSION=2`, но **используемый legacy runner остаётся `PROTOCOL_VERSION=LEGACY_RUNNER_PROTOCOL_VERSION=1`, socket URL — `/api/v1/sync`**. Настоящий `_converse` отвергает v2 hello до state load/send, а настоящий Remote отвергает v1 socket до Hub/записей. Одни декларации не включают I10.

Продолжение Studio I9–I16/L остаётся в VS-177 и связанных клиентских работах: production catalog/Select/Create/Preview/Enable adapters, runner ID/account/epoch/cursor checks, positive drain/L completeness и настоящий two-root/editor/restart v2 interop. Старый `backend/tests/test_remote_sync.py` — v1 integration harness; его прежние 21 PASS из VS-177 не переобозначены как v2 evidence и здесь не заявлены. V2 fixture установлен и новый refusal contract выполняется без skip; gate не обходился ради старого harness.

Android/editor interop, INTEROP-01 FAIL_UPSTREAM и AI-доступ не изменены и не принимаются этой поставкой. Нет общего enabled Studio+Android+Remote E2E, production cutover или общего релиза. Реальные SSH/install/TLS на новом сервере, production migration/deploy, личные ключи/профили/clipboard и рестарт Studio **не выполнялись**; clipboard подтверждён unit/fake WinAPI и packaged fake adapter, не ручной операцией над личным clipboard.

Чужой исходный diff сохранён; shared worktree не коммитился. Новых карточек не создано. Для VS-180 открытых P1/P2 по двум corrective review нет; перед production нужны отдельная клиентская приёмка, согласованное offline окно, backup/recovery и отдельное разрешение deploy/migration.
