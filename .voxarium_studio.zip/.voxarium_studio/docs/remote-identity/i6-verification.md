# VS-172 — I6: disabled commit и crash-safe fencing

16.11.2026. Основание: [[remote-identity/runtime-integration-plan]] §2.3, §3.2–3.5/I6; [[remote-identity/studio-design]] §5.2/7. Это локальная интеграция I6, не выпуск Select/Enable в production.

## Результат и границы

- Подключён ready → durable versioned journal → atomic project config commit (R+1, disabled, без sync.space) → whole-file private CAS → completed evidence. edit_id/unbind удаляют private row; unbind очищает URL, сохраняя ID; disable демотирует прежний выбор в selected; select сохраняет selected только на injected exact catalog observations.
- Public RemoteBindings.remove и внутренние transaction-aware save/remove используют существующий store. Финальный порядок: Ctx/DocStore → lifecycle → один application_config_transaction → credential lock. Тест считает реальный OS-lock acquisition: один. Thread/OS/credential locks не пересекают await.
- Exact confirmation URL+ID, R/G/backend scope, config/private/profile/credential/catalog observations и uncached Markdown/checkpoint повторно проверяются. После journal/config temp staging повторяются fences; после callback ещё раз проверяются config bytes непосредственно перед replace. Config — commit point; rollback поверх чужого writer отсутствует.
- Повтор change_id возвращает durable результат именно того изменения, включая после следующего изменения; одновременно ожидавшие settings lock запросы не повышают R повторно. Новое назначение получает случайный G.
- Startup только читает/блокирует. Completed evidence не удаляется при expiry/cancel/cleanup и при отсутствии private row имеет приоритет над VCS-restored legacy sync.space. Corrupt/duplicate/unknown-version/known-lost journal, canonical config без журнала и неопределённое чтение fail closed до credentials/WS. Metadata-only legacy с явным sync.space сохраняет прежний режим.
- Совпавший partial commit можно явно повторить в ещё живом подготовленном Ctx; fingerprint drift не разрешает private repair. После restart partial остаётся blocked: startup не завершает config/private публикацию, не включает sync и не replay-ит очереди. Автоматического recovery/repair endpoint нет.
- Обычный settings save перечитывает текущую identity/target/revision и не восстанавливает sync.space из stale draft. Изменение ID не заменяет paths/DocStore/jobs/teams/runtime descriptor/MCP и не меняет Markdown другого Ctx.
- Production Select остаётся catalog_unavailable до I9/R3/I8; migrate — migration_required до I15. Enable, новый transport/wire, frontend и настоящие пользовательские home/ключи не менялись. Сервер Studio не перезапускался: параллельная I8 и чужие resident jobs не затронуты.

## Матрица отказов

| Граница §3.5 | Проверка |
| --- | --- |
| Prepare/cancel/expiry до и после fence | Существующие I5 tests; новые commit-boundary TTL tests; completed history не истекает и DELETE возвращает already_committed. |
| Dirty/unreachable/expired editor, failed save, offline unresolved | Полный test_remote_transitions плюс test_remote_editor_leases/test_remote_mutation_gate: blocked, без discard/commit и без повышения generation из клиентского bool. |
| Disconnect/cancel во время drain | I5 tests сохраняют pending/live/rooms и old-target evidence; ACK/leave/join доказываются владельцем service. |
| Journal write/flush/fsync/replace | Реальные fault injections до config commit: config/private/Markdown неизменны; после fence старые leases не оживляются. |
| Config publication failure | Storage fault tests и coordinator restart test: прежний config, durable fence, blocked; не rollback. |
| Config committed, private/remove/journal/response failure | Disabled R+1 сохраняется, явный matching retry не повышает R снова; restart не repair-ит. |
| Config/VCS/private/profile/credential/catalog/Markdown drift | No-write CAS refusals, включая drift во время journal staging, config tempfile staging и внутри последнего callback. |
| Shutdown/restart | edit_id/unbind с отсутствующим binding + восстановленный legacy config; corrupt/lost evidence; счётчики credentials/WS равны нулю, config/docs неизменны. |
| Enable/hello | I6 не реализует Enable/новый WS; адресные I2/runtime-binding и реальные remote-sync regressions остаются включены. |

## Команды и результаты

Команды выполнялись из D:/VoxariumStudio через backend/.venv/Scripts/python.exe. Все basetemp, scripts и logs находятся только в D:/VoxariumStudio/.voxarium_studio/temp/TASK-172. Везде synthetic home/config; remote package установлен и импортируется из checkout, test_remote_sync не пропущен.

### Основная выборка

```powershell
backend/.venv/Scripts/python.exe -m pytest backend/tests/test_remote_transitions.py backend/tests/test_remote_bindings.py backend/tests/test_project_identity.py backend/tests/test_project.py -q -n 4 -p no:cacheprovider --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-172/pytest-targeted-complete
```

616 passed, 0 skipped; независимый reviewer повторил те же 616 serial с -n 0. Затем добавлен один concurrent-idempotency regression; окончательно весь test_remote_transitions.py: **92 passed, 0 skipped**, остальные три модуля ранее **525 passed, 0 skipped**. Итого основная выборка содержит 617 тестов; это не заявление о прогоне всего backend suite.

```powershell
backend/.venv/Scripts/python.exe -m pytest backend/tests/test_remote_transitions.py -q -n 4 -p no:cacheprovider --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-172/pytest-transition-final
```

### Адресные regressions

```powershell
backend/.venv/Scripts/python.exe -m pytest backend/tests/test_remote_runtime_binding.py backend/tests/test_remote_mutation_gate.py backend/tests/test_remote_editor_leases.py backend/tests/test_remote_profile_mutation_api.py backend/tests/test_remote_sync.py backend/tests/test_project_scopes.py backend/tests/test_application_settings.py backend/tests/test_config_error_redaction.py backend/tests/test_project_open_validation.py -q -n 4 -p no:cacheprovider -k 'not test_remote_profiles_application_get_and_all_existing_status_are_secret_free' --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-172/pytest-regressions-complete
```

**766 passed, 0 skipped; один тест явно исключён.** Его прежнее ожидание POST /api/remote/servers →404/405 уже противоречит имеющемуся Create →201; воспроизведено отдельно с pre-I6 save_config, без изменения исходного теста. Полный пробный прогон зафиксировал именно этот unrelated failure.

test_remote_api.py имеет жёсткую fixture-привязку к старому TASK-124: обычный пробный запуск дал 250 setup errors, не behavioral failures. Не меняя project source, выполнена task-temp копия с заменой только fixture anchor TASK-124 →TASK-172; --noconftest, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, -p pytest_asyncio.plugin -o addopts='' -o asyncio_mode=auto -p no:cacheprovider. Результат: **250 passed, 0 skipped**, один pytest-asyncio deprecation warning.

Storage worker дополнительно проверил YAML-constructor suite: **147 passed**, с task-local no-socket Windows runner. git diff --check — без whitespace errors; test_project.py byte-for-byte совпадает с исходным снимком этой задачи, его чужой diff сохранён.

## Независимое scoped review

Отдельный read-only subagent проверил I6. Найденные staging-окна TTL/Markdown/config CAS и historical-result replay исправлены с regressions; последний verdict: no unresolved findings within delegated I6 scope. Финальная ветка concurrent replay после settings lock также отдельно принята: 1 passed, no new scoped findings. Общие foundations и frontend повторно не переаудировались.

Временные подробные логи: targeted-complete.log, transitions-final.log, regressions-complete.log, remote-api-relocated.log и i6-*.log. Они disposable; приведённые здесь команды/результаты сохраняются после завершения задачи.
