# Аудит основы S1/S2 — VS-95

Контекст: [[remote-identity/studio-design]], только storage/diagnostic foundation VS-93 и VS-94. Не приёмка полного v2. Producer прочитал актуальные исходники, воспроизведения и логи TASK-95 перед их автоматической очисткой при Done.

## Результат проверки

Запуски из backend через `.venv/Scripts/python.exe -B -m pytest -n0 -p no:cacheprovider`: targeted test_project_identity/test_remote_profiles — 135 passed; regression test_project/test_project_scopes/test_application_settings/test_workspace/test_api — 223 passed; два legacy теста test_remote_sync — 2 passed. Итого по отчёту VS-95: 360 passed, 0 skipped. Девять дополнительных негативных проверок ожидаемого поведения падают: 5 confirmed, 2 open-errors, 2 plan-edges. Проходящие регрессии не отменяют эти дефекты.

## F1 — secret отражается в HTTP errors

Синтетический маркер, не реальный ключ: `VS95_SYNTHETIC_CREDENTIAL`.

В настоящем TestClient PUT возвращает 422, но содержит маркер из отвергнутого тела:

- `/api/settings`, тело `{token: marker}`.
- `/api/settings`, тело `{sync: {token: marker}}`.
- `/api/settings/application`, тело `{remote_servers: [{token: marker}]}`.
- `/api/projects/{runtime}/settings`, тело `{token: marker}`; runtime получен через fixture POST `/api/projects/open`.

Два дополнительных случая: config fixture содержит `project_identity: {id: good-id, revision: 1, token: VS95_STORED_SYNTHETIC_CREDENTIAL}`. POST `/api/projects/open` с create=false или POST `/api/settings/reload` возвращает 400, но отражает stored marker. Файл остаётся неизменным. Нужна redaction на границах request/config validation, без ослабления запрета неизвестных полей, без включения mutations и без утечки в logs.

Владельцы: `api/project.py` (SettingsUpdate, ApplicationSettingsUpdate, ProjectSettingsUpdate, open/reload errors), HTTP validation handler приложения. `hide_input_in_errors` сам по себе не доказывает безопасность FastAPI JSON errors.

## F2 — profile mutation теряет неизвестные global-поля

В изолированном home записать application config с `language: ru`, `future_section: {future_flag: 17}`. Вызвать `RemoteProfiles().create('Fixture', 'https://fixture.invalid/team')`. Профиль создан, language сохранён, но future_section исчезает. Расширенная fixture также показывает потерю `theme.future_theme_flag: 23`.

Владельцы: `core/application_config.py` и `sync/profiles.py`. Требование: profile metadata mutation сохраняет посторонние global данные и preferences, включая вложенные неизвестные поля, либо безопасно отказывает без записи при неоднозначности. Не переносить opaque данные/secret в effective/project config или GET. Сохранить CAS, duplicate detection, corrupt-store fail-closed и atomic publication.

Обычный project save с неизвестными полями также исследовался, но baseline-проблемы не являются разрешением на общий рефакторинг config. Исправление ограничено новым profile flow и непосредственно нужным сохранением global preferences.

## F3 — migration plan валидирует устаревшие global-поля

В isolated home сохранить ApplicationConfig(language='ru'). В project YAML записать `theme: {text_size: 99}` и `project_identity: {id: good-id, revision: 1}`. `load_config(paths).project_identity.id == 'good-id'`, но `identity_migration_plan(paths)` ошибочно возвращает invalid_config вместо identity_present/good-id. Причина: raw AppConfig validation без project-scope filtering.

Ожидание: diagnostic использует ту же семантику разделения scopes, что load_config, не подменяет ошибочные project-owned поля defaults. Чтение не пишет ни home, ни project, не генерирует ID и не обращается к сети. Fingerprint привязан к исходным bytes.

## F4 — неоднозначный YAML выбирает последнее identity

Fixture:

```yaml
project_identity:
  id: first
  revision: 1
project_identity:
  id: second
  revision: 2
```

`identity_migration_plan` использует yaml.safe_load и молча выбирает второе поле. Ожидается invalid_config без persistent_id из неоднозначного ввода, без изменения bytes. Проверить также вложенные дубликаты identity/sync и безопасное поведение YAML aliases/merge, не делать неявной нормализации ID. Владелец: `core/project_identity.py`.

## Границы

Аудит read-only, исправлений не делал. По отчёту VS-95 реальные ключи/данные, сеть и серверы не затронуты. Исправления — отдельные узкие задачи текущего этапа Studio; lifecycle, публичные mutation endpoints, новая sync-модель, production migration/deploy и EXE/APK остаются вне этого этапа. Чужие dirty изменения сохранять. После исправлений нужна отдельная read-only повторная проверка всех четырёх замечаний.
