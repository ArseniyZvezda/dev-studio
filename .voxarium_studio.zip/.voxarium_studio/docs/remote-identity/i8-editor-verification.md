# I8 — проверка редакторов Studio (VS-175)

Дата: 2026-11-16. Основа: [[remote-identity/runtime-integration-plan]] §3.3–3.4/I8 и принятый контракт VS-174 в [[remote-identity/i8-editor-proof]]. Здесь принимается только оставшийся frontend-срез I8, не R3 и не production editor gate.

## Что подключено

- В существующем DocsView close/transition owner используется один путь freeze → flush debounce/очередей и dirty heartbeat → собственный materialization proof/receipt → существующий editor-ack. Второго close framework нет.
- Typed project-scoped API содержит оба POST materialization/confirm и серверную lease revision. Нейтральный heartbeat после очередей получает текущую серверную CAS revision, но не объявляет dirty=false и не создаёт receipt.
- Clean collab получает собственное подтверждение без Markdown PUT. Non-scribe ждёт завершения final scribe save/серверного anchor и затем подтверждает собственную сериализацию. Writer вправе использовать собственный completed-save receipt; receipt другого editor не копируется.
- Epoch/G/editor/client/path/sid/version фиксируются до очереди/await. Следующие проверки только сравнивают исходный ticket, не заменяют его latest G. Deferred store actions держат owning sync-store, а не выбирают чужой active Pinia после await.
- Snapshot проверяет конкретный PM editor/document, готовность, uploads/drag/debounce и RAM revision наблюдаемых room frames. Даже duplicate/no-op update и same-Markdown Yjs update инвалидируют прежнюю проверку. RAM counter не добавляет frame или Remote wire.
- До положительного доказательства остаются прежние DOM, экранный текст и Y.Doc. Принятие proof не подменяет source/PM/Yjs серверным текстом. Desktop prepare может thaw после veto другого guard; окончательная validation всё равно отвергает новую правку.
- pending_edits/mutation_busy/stale_editor_version на proof остаются блокирующим, но повторяемым proof-ожиданием в пределах исходного change TTL. Expired/unknown editor/sid, stale epoch/G и ошибки допуска сохраняют paused editor; не создаются overwrite/Keep mine, новый lease или auto-join target.
- Cancel/expiry до fence снимает freeze с того же editor; cancel/late response не получает ACK. После fence сохраняется прежний paused/explicit-reopen contract, без автоматического перехода на новый target.
- Внешние doc/folder delete/rename и поздние чтения не закрывают и не заменяют scoped live/transitioning/fenced source. Выдаётся typed blocker. Legacy clean semantics отдельно сохранены.
- Готовая registration/heartbeat/fencing архитектура VS-173 сохранена; изменены её proof seam, owner capture и необходимые защитные callback-проверки. Добавлен синхронный EN/RU статус ожидания proof.

## Матрица local/component/jsdom

| Случай | Что проверено |
| --- | --- |
| Два clean collab editors | Два настоящих DocsView, отдельных Pinia/router/BlockEditor и Y.Doc; оба own proof/receipt/ACK, 0 PUT, прежние DOM/Y.Doc, ровно два первоначальных join |
| Non-scribe → final scribe save | Правка настоящего non-scribe проходит Yjs relay в scribe; final PUT удерживается незавершённым, до него нет ACK/receipt; после завершения оба настоящих view owner автоматически получают отдельные ACK, ровно 1 writer PUT |
| Ordinary save | Registration до первого write; debounce flush ждёт завершения save, ACK использует серверный sequence, не client version |
| Dirty/expired/offline/error | Отказ не очищает несохранённый текст, не уничтожает room, не превращается в disk conflict или Keep mine |
| Forced unmount | Dirty Y.Doc/lease остаётся blocker; ordinary экранный Markdown сохраняется в прежнем RAM model; pending confirm после unmount не выдаёт локальный receipt/ACK |
| Transfer/focus | Reparent того же live subtree/focus не remount, не flush и не write; это component-инвариант, не native Electron smoke |
| Legacy | Freeze без guessed G, новой registration или capable ACK; legacy blocker не обходится |
| Pathless page target | Freeze удерживается до lease DELETE и destructive select; повторная проверка после ответа сохраняет late command/отменённый target вместо удаления текста |
| Cancel/late callbacks | Cancel на neutral heartbeat, ticket и confirm; delayed save/join, fence/new G, same-Markdown и duplicate updates отвергаются; target не auto-join |
| External callbacks | Scoped live/paused/error source защищён на doc/folder событиях и после listing/read awaits; обычный legacy clean путь сохранён |
| API/store contracts | Exact scoped URL/runtime epoch, полный immutable tuple, CAS/token/content, чужие/просроченные ответы, typed errors, отсутствие save/overwrite/ACK в самом proof store method |

Новые paired проверки вызывают именно владельцев DocsView: тест не вызывает materialization/ACK вручную. При этом HTTP/relay остаются узкой локальной synthetic моделью: это frontend-интеграция компонентов с typed client, **не backend/Remote interop**. Прежние ручные API mocks сами по себе не считаются её заменой.

Реальные paired owners выявили дополнительный дефект: lazy useSyncStore() после await выбирал другой active Pinia и отвергал исходный writer ticket до PUT. Исправлено захватом owning dependency при создании docs-store; dirty paired regression после исправления проходит.

## Воспроизводимые проверки

Рабочий каталог команд — D:/VoxariumStudio/frontend. Все disposable логи/JSON и baselines находятся только в D:/VoxariumStudio/.voxarium_studio/temp/TASK-175; этот каталог не является постоянным deliverable.

```powershell
npm test -- src/api/client.spec.ts src/api/project-scope.spec.ts src/stores/docs.spec.ts src/stores/sync.spec.ts src/views/DocsView.spec.ts src/lib/collab/session.spec.ts src/lib/collab/editor.spec.ts src/desktop/close-barrier.spec.ts src/desktop/page-state.spec.ts src/i18n/i18n.spec.ts
npm test -- --reporter=default --reporter=json --outputFile=../.voxarium_studio/temp/TASK-175/frontend-final.json
npm run typecheck
npm run build
```

- Targeted regressions: **499 passed, 10 файлов, 0 skipped/failed**.
- Полный текущий frontend: **5410 passed, 108 файлов, 0 skipped/failed/todo**; JSON success=true, pending=0. Это число всего текущего checkout, включая прежние тесты, не число новых тестов VS-175.
- В полном прогоне: client 76, docs-store 267, DocsView 60, collab/session 20, collab/editor 8, i18n 8.
- typecheck и build — **PASS**. Generated static получен штатной сборкой, вручную не редактировался.
- Scoped git diff --check — **PASS**; предупреждения Git о будущей нормализации CRLF не являются whitespace errors.
- Остались предупреждения инструментов: Vite future native-config JSON import; build chunk-size/ineffective dynamic import; полный suite также печатает прежние Vue Router R0029 из plugin-runtime tests. Test failures/xfail/skips в итоговом полном прогоне нет.

Backend suite в VS-175 не запускался: принятый local proof VS-174 и его 616 passed описаны отдельно в [[remote-identity/i8-editor-proof]], не включены в числа выше. Серверы/run.cmd/remote_test не запускались, runtime не перезапускался, ключи и production data не читались.

## Независимый scoped review

Выполнены два независимых read-only scoped audit одним не участвовавшим в реализации worker: исходный race audit и итоговый review текущих owners/дельты, сверка с backend schema/confirm и отдельный запуск 5 suites: **428 passed, 0 skipped**. Graphify использован до поиска; новые изменения проверялись по актуальным файлам, поскольку индекс отражает baseline.

Первый audit выявил sticky pending proof, self-invalidating thaw validator и destructive live delete callback. Замечания исправлены с регрессиями; final review подтвердил их устранение и отдельно подтвердил строгий proof tuple, paired view-owner flow, captured G/owner, внешние callbacks и остальные I8 случаи.

Final review затем воспроизвёл ещё один **P1**: pathless desktop target thaw происходил перед awaited lease DELETE, после чего late input мог уничтожаться через select(null). Исходный независимый probe: **1 failed / 57 намеренно filtered**, то есть исходный final-review verdict был **NOT PASS**, не PASS по одному лишь зелёному suite.

После review родитель исправил этот P1 в том же существующем owner: freeze охватывает settle → release → destructive selection; release повторно проверяет исходный snapshot/version/owner после DELETE, current() вызывается до удаления, поздний edit/отмена сохраняет model/DOM и blocker. Добавлены 3 постоянные component-регрессии: clean held release, programmatic late edit и cancelled target; DocsView suite теперь **60 passed**. Неизменённый независимый probe после исправления: **1 passed / 60 намеренно filtered**; полный итоговый suite выше — без skips.

Повторного полного независимого delta-review после последней правки не было: исправление проверено родителем независимым reproducer и постоянными регрессиями, а не переименовано в independent PASS. При обычном manager review следует адресно проверить последнюю ветку pathless target/releaseRegistration; неустранённых воспроизводимых scoped дефектов после проверок нет.

## Границы результата

I8 frontend local/component/jsdom-приёмка завершена. **R3/production editor gate остаётся закрытым.** Не заявлены deployed/cross-Studio Remote interop, v2 runner/Enable, onboarding, credential-generation security или legacy completeness L. Unknown causal room/vector ↔ saved Markdown evidence остаётся fail-closed по контракту VS-174, а не чинится дополнительным clean save.

Settings UI/Enable/новый Remote wire/backend owners не изменялись. Большой исходный чужой diff сохранён; task baselines использованы для отделения нового proof delta. Сборка не означает, что установленный/работающий Studio уже использует эти изменения.
