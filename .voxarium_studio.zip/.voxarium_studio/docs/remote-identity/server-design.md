# Remote: каталог проектов по ID и управление пользователями — VS-89

Дата: 15.11.2026. Статус: **проект контракта для реализации**, не описание уже работающего API. VS-89 меняет только этот документ. Исследование: сначала Graphify, затем текущие исходники, dev spec §16, remote/README.md и карточка VS-54; независимые read-only проверки Remote и Admin. Graphify `merged-graph.json` отсутствовал; использован `graph.json`, ответы перепроверены по текущим файлам. Реальные серверы, production-БД, SSH, deploy, сборка EXE и миграции в этой задаче не запускались.

Связанные контракты: [[remote-identity/studio-design]] (VS-88), [[remote-identity/android-design]] (VS-90), исторический wire v1 — [[remote-android/protocol]]. Последний документ не является контрактом нового каталога. Перед реализацией согласовать эти три identity-документа и внести решения ниже в `docs/voxarium-studio-dev-spec.md` §16; здесь они **предлагаются**, существующая спецификация и код пока остаются v1.

## 1. Текущее состояние и границы изменения

| Основание | Что действительно есть |
| --- | --- |
| `docs/voxarium-studio-dev-spec.md:4118–4159`, §16.1–16.2 | Отдельный Remote без импортов Studio; HTTP health/me и sync WS; управление пользователями из серверной оболочки; любой действующий ключ имеет доступ ко всем spaces. Нет публичного admin API, ролей или ACL |
| `remote/voxarium_studio_remote/store.py:28–54,200–223` | `spaces(id UUID hex, name UNIQUE, seq, created_at)`; `docs.space_id` уже ссылается на UUID. `Store.space(name)` ищет по имени и **создаёт при отсутствии** |
| `remote/voxarium_studio_remote/hub.py:134–161`, `app.py:90–117` | WS принимает `space` как нормализуемое имя, хаб индексируется именем; hello содержит отдельные `space.id/name`. Ошибка в имени создаёт другой набор документов ещё до проверки версии клиентом |
| `remote/voxarium_studio_remote/protocol.py`, `backend/voxarium_studio/sync/protocol.py` | `PROTOCOL_VERSION = 1`; имя 1–64 ASCII, trim/lower; hello mismatch останавливает Studio, но не отменяет уже произошедшее создание space |
| `store.py:66–78,137–196`, `auth.py:53–73`, `cli.py:user_add/user_rotate/user_revoke` | UUID пользователя; уникальное `name`, цвет, SHA-256 ключа, revoked_at. Ключ `vxs_` + 32 случайных байта через token_urlsafe; add/rotate печатают его один раз. Нет CRUD display_name/delete |
| `app.py:157–163` | Раз в 30 секунд проверяется только active(user.id). Revoke закрывает соединение с задержкой; **rotate не инвалидирует уже открытые сессии**, а revoke→rotate до проверки способен оставить старую сессию живой |
| `backend/voxarium_studio/sync/state.py:38–104`, `service.py:325–345` | База ревизий локальна, ключуется URL + полученным `space.id`; этот UUID одновременно защищает от подмены БД. Изменение идентичности нельзя свести к новой подписи поля |
| VS-54 (done), `remote/README.md`, `admin*.py`, `build-remote-admin.bat` | Уже готовы меню RU/EN, SSH-профиль, проверка соединения, discovery Docker, телеметрия, список пользователей, bootstrap Ubuntu/Debian + Docker, опциональный Caddy/TLS и standalone EXE со встроенными Remote-исходниками/OpenSSH |

**Не повторять VS-54:** не создавать новый установщик, SSH-клиент, Docker discovery или мастер TLS. Добавляются каталог, user management и безопасная выдача ключа в существующее меню и transport; установленный старый контейнер сам по себе не получает новые команды от замены EXE.

Сохраняются dev spec §16.3–16.6: только тексты Documents, CAS/tombstones, эфемерные Yjs-комнаты, отсутствие записи при открытии, отсутствие истории/картинок/папочного оформления/приглашений. Идентичность проекта не решает известные ограничения editor-schema parity и сохранности нематериализованных room updates. Remote не получает агентов, checkout, файловую систему Studio или зависимости Studio.

## 2. Идентичность и каталог

### 2.1 Одно значение ID == space

- `project.id` — постоянный идентификатор проекта в пределах конкретного Remote; **это же значение** передаётся в sync как `space`, хранится в `spaces.id`, `docs.space_id` и используется ключом `Hub._spaces`.
- `display_name` — только подпись. Не ключ БД, не маршрут, не основа ID, не средство поиска подходящего проекта для автоматического подключения. Одинаковые подписи разрешены; в списках всегда показываются подпись **и полный ID**.
- URL сервера + project ID образуют клиентский namespace. Профиль подключения и локальный runtime/project binding Studio — другие сущности: server API не назначает и не меняет desktop registry/runtime адреса.
- Новый ID предлагает клиент (по умолчанию случайный lowercase UUID v4 с дефисами (36 символов; UUID hex также валиден)); пользователь может отредактировать его **до явного Create**. Сервер принимает валидный свободный ID, не генерирует его из имени/папки.
- Серверный ID неизменяем. Редактирование локального ID — отключение старой привязки и явный выбор либо создание другой, а не rename/merge серверных данных. Серверный rename ID, автоматическое перемещение документов и удаление проекта не входят в этот increment.
- `storage_epoch` — отдельный opaque UUID hex, обозначающий поколение данных данного ID. Нужен теперь, когда один пользовательский ID можно повторно использовать в другой БД. Namespace баз/очередей: canonical URL + ID + storage_epoch. Это **не** ID комнаты (`room.epoch`).
- При создании epoch генерирует Remote независимо от ID. При штатной миграции существующего space epoch = его прежний UUID id: никаких смен ID или ревизий. Пересоздание/разрушительное восстановление с тем же ID требует нового epoch и полного безопасного reconciliation, не повторного использования cursor.
- Обычный backup сохраняет epoch. Откат backup с тем же epoch не обнаруживается одной идентичностью: `hello.seq < saved_cursor` должен блокировать продолжение старой базы и вызывать recovery/full reconciliation. Оператор будущего restore обязан объявить новые epoch при намеренном rollback, а не обещать автоматическое обнаружение всех откатов.

### 2.2 Валидация и конфликты

| Поле/случай | Правило нового контракта |
| --- | --- |
| ID | JSON string, 1–64 ASCII, regex `[a-z0-9][a-z0-9._-]{0,63}`; полное совпадение, не substring |
| Недопустимые ID | Пробелы в начале/конце, uppercase, Unicode/confusables, slash/backslash, %, управляющие символы, пустая строка, >64: отказ. **Не** trim/lower/slugify; UI может предложить исправление, но не подключаться к изменённому ID молча |
| URL encoding | Один обычный decode транспортом; ID не файловый путь. Повторный decode запрещён; duplicate `space` query keys и неизвестные query-поля — bad request |
| display_name проекта/пользователя | Непустой string, 1–120 Unicode code points, ≤480 UTF-8 bytes; NFC, trim внешних пробелов как явная нормализация подписи. Запрет C0/C1/DEL, переводов строк и bidi override/isolate; безопасный terminal rendering. Внутренние пробелы и кириллица допустимы |
| Цвет курсора | `#[0-9a-fA-F]{6}`, сохранение lowercase; default — существующая серверная палитра |
| Занятый ID | 409 `project_exists`, даже если подписи совпали. Не объединять и не перезаписывать. Клиент перечитывает карточку и предлагает **отдельное** «Выбрать существующий» |
| Два Create одного ID | Одна SQLite-транзакция/PK гарантирует ровно один 201; второй — 409. Смена подписи не создаёт проект |
| Одинаковые display_name | Разрешены; не вызывают rename, suffix или dedup. Порядок выбора не зависит от подписи |
| Неизвестный ID при connect/get | Not found без записи в БД; не искать его как legacy name и не вызывать create |
| Неизвестные поля/неверные типы | 400 со стабильным кодом; boolean не принимается как integer; size limits до разбора больших payload. Ошибка не отражает весь входной объект |

Новые API обязаны использовать одну функцию проверки ID в Remote; Studio повторяет правила в собственном protocol-модуле без импорта Remote. Для миграционных данных не применять новую нормализацию. Повреждённые ID/FK/ревизии останавливают миграцию с отчётом; старые display names вне новых UI-правил сохраняются буквально с пометкой (§5.1), а не «чинятся» переименованием.

## 3. Версии и публичный API — предложение v2

Три независимые версии: schema БД (migration version), wire `PROTOCOL_VERSION = 2` в обеих Python-копиях и формат SSH admin RPC (`admin_rpc_version = 1`). Версия пакета/EXE не подменяет ни одну из них.

### 3.1 Auth и поверхность

Все `/api/v2/*` принимают **только** `Authorization: Bearer <personal key>`; нет query/body/cookie fallback для ключа. Auth выполняется до выдачи каталога/проверки существования ID. 401 + WWW-Authenticate для отсутствующего/неверного/revoked/deleted ключа; одинаковая безопасная диагностика. TLS либо loopback SSH tunnel сохраняются. Нет browser CORS/static/admin HTTP API.

**Любой** active пользователь может читать каталог, явно создавать проект и работать с любым проектом. Это доверенный командный Remote, **не RBAC**. Метаданные проекта меняет оператор по SSH; это существующая системная граница администрирования, не новая роль внутри ключей. Перечень пользователей, выдача/отзыв ключей, delete и миграция по публичному HTTP не доступны.

| Маршрут | Запрос и ответ |
| --- | --- |
| `GET /healthz` | Без auth: существующие service/version/protocol, дополнить `supported_protocols:[2]`, `catalog_api:2`. Ни каталога, ни пользователей, ни schema/секретов |
| `GET /api/v2/me` | `{protocol:2, catalog_api:2, capabilities:["project_catalog","explicit_project_create","strict_connect","project_snapshot","legacy_resolution"], user:{id,display_name,color}}`; только собственная публичная карточка |
| `GET /api/v2/projects?limit=100&after=<ID>` | `{protocol:2,projects:[Project],next_after: ID либо null}`. keyset по ASCII id, limit 1–200; after — валидный ID, не обязан существовать. Без cursor — первая страница. Нет гарантии snapshot между страницами; dedup по ID, refresh после гонки |
| `GET /api/v2/projects/{id}` | 200 `{protocol:2,project:Project}` или 404 `project_not_found` |
| `POST /api/v2/projects` | Только `{id,display_name}`; 201 `{protocol:2,project:Project}`, Location на GET; 409 при занятом ID. Пустой проект, seq=0. Операция вызывается только после явного подтверждения создания |
| `GET /api/v2/projects/{id}/snapshot` | Read-only страницы content/hash/rev/tombstones для preview по §3.3; не открывает room/WS и не создаёт project |
| `GET /api/v2/legacy-spaces/resolve?name=<exact-old-selector>` | Authenticated exact lookup сохранённого migration mapping, `{protocol:2,legacy_space_name,project:Project}` или 404 `legacy_space_not_found`; никакого trim/lower/fuzzy и создания |
| `WS /api/v2/sync?space=<ID>` | Аутентификация, exact ID validation, lookup-only; затем hello v2. Никакого создания при upgrade, GET, hello, sync, join, put/delete или reconnect |

`Project = {id,display_name,storage_epoch,metadata_revision,created_at}`. В каталоге нет текста документов, ключей/хешей, SSH-параметров и списков участников. Не задаются owner/roles. `metadata_revision` — целое ≥1 для optimistic concurrency подписи через Admin; docs seq — отдельный счётчик и в каталоге не нужен.

REST error: `{error:{code,message,request_id}}`, без сырых request/headers/exception locals. Используются 400 invalid_id/invalid_display_name/invalid_request, 401 unauthorised, 404 project_not_found, 409 project_exists/metadata_conflict, 413 payload_too_large, 503 temporarily_unavailable. `message` — безопасная диагностика, клиент локализует по code.

WS принимает handshake перед отказом, как сейчас, для различимого close-кода. До hello/регистрации в Hub: 4401 unauthorised; 4400 invalid_request/invalid_id; **4404 project_not_found**. Причины короткие фиксированные, без токена/полного ввода. 4408 overload сохраняется. Клиенты прекращают автоматический retry на 4400/4401/4404 и показывают исправление/повторный выбор, но не Create.

Пример hello (остальные put/delete/CAS/room frame semantics сохраняются):
```json
{"t":"hello","protocol":2,"user":{"id":"<user-id>","display_name":"Анна","color":"#3e63dd"},"space":{"id":"boloto-team","display_name":"Болото","storage_epoch":"<uuid-hex>"},"seq":42}
```

Клиент до отправки sync/write обязан сравнить protocol, **ожидаемый ID** с hello.space.id, epoch и cursor. Несовпадение ID — terminal protocol error, не разрешение привязаться к ответу. Epoch mismatch — остановка старой очереди/комнат, recovery, затем полный reconciliation; не очистка локальных Documents. При hello.seq < saved_cursor даже с совпавшей epoch также blocked rollback recovery: до sync/write остановить старые pending/комнаты, сохранить bases/cursor/drafts/очередь, затем согласованный read-only snapshot/full reconciliation и явное подтверждение; не reset cursor с auto-push и не перенос старой очереди в другую identity. Правила `user.display_name` применяются также к presence/room карточкам; автор записи хранится по user ID, не по отображаемому имени.

POST body ограничен 2 KiB; до успешного ответа не отдавать ни partial object, ни token-bearing диагностику. Поиск legacy selector — вспомогательная **явная миграционная** операция: результат нужно показать и подтвердить; не применять его как fallback connect. Старое имя, совпавшее с чужим canonical ID, не имеет приоритета над ID.

### 3.2 Неопределённый результат Create

Timeout/обрыв после POST не означает отсутствия проекта. Нет слепого повторного Create с новым ID. Клиент GET-ит **исходный ID**, показывает результат и требует отдельного выбора/подтверждения привязки; чужой победитель гонки с тем же ID не считается автоматически собственным проектом. Если 404 — можно повторить Create того же ID по действию пользователя. Новый endpoint не принимает initial documents: начальная синхронизация проходит существующее conflict-safe reconciliation, а не overwrite серверного проекта.

### 3.3 Snapshot для безопасного клиентского preview

Это добавление по требованию потребителя VS-88, а не новый mutable document API. Начальный GET `/api/v2/projects/{id}/snapshot?limit=20` читает в одной короткой SQLite read-транзакции epoch/seq и страницу **всех** документов, включая tombstones; порядок — binary path. Ответ: `{protocol:2,snapshot:{id,storage_epoch,seq},documents:[{path,content,hash,rev,deleted,updated_by,updated_at}],next_after:null|path}`. Limit 1–100; дополнительно сумма UTF-8 JSON ответа ≤4 MiB (документ уже ограничен 1 MB). Курсор указывает последний фактически возвращённый path; страницы никогда не пропускают документ из-за byte budget.

Продолжение обязано передать `after`, `expected_seq` и `expected_epoch` из первой страницы. Если epoch/seq уже изменились — 409 `snapshot_changed`, ни смешанной страницы, ни частичного success; клиент отбрасывает только временный preview, сохраняет drafts и начинает заново. Invalid cursor/параметры — 400. Первая страница может также принять expected_epoch для проверки выбора. Последняя страница завершает согласованный snapshot: если сервер менялся между страницами, продолжение не выдаст результат; изменение после окончания инвалидирует клиентский fingerprint/preview перед Enable. Не держать SQLite transaction через сетевые awaits и не хранить durable history/snapshot на Remote.

Snapshot сам по себе **не lock** на будущие изменения. Перед Enable/initial reconciliation клиент повторно проверяет epoch/seq и сохраняет CAS/conflict handling; никогда не превращает preview в разрешение безусловного overwrite. На постоянно меняющемся проекте после ограниченного числа повторов показать «проект изменяется, повторите», не отключать проверку. Mapping и snapshot требуют того же active key, как каталог; отсутствие capability блокирует зависящий от неё flow.

### 3.4 Имена адаптеров VS-88/VS-90

В потребительском Studio-контракте логическая incarnation названа `space_instance_id`; **на wire v2 здесь это `storage_epoch`**, adapter выполняет явное отображение 1:1. `space.id` на wire — canonical editable selector, не incarnation. Редактируемый локальный ID и runtime `project_id/epoch` Studio не смешиваются. UUID с дефисами, предложенный VS-88 для новых локальных проектов, проходит точный общий regex; миграционные UUID hex не форматировать заново.

`operation_id` потребительского локального API — только локальный журнал операции, **не** поле Remote POST; даже повтор того же body при занятом ID даёт 409 project_exists, не replay 201. Серверный POST этого increment не предоставляет server replay результата Create; потерянный исход разрешается §3.2. Adapter не должен объявлять чужой проект своим или молча bind-ить его по одному совпадению ID. Дальнейшее серверное idempotency extension требует отдельного контрактного изменения, не угадывания поля.

## 4. Старые клиенты и порядок перехода

**Решение: fail-closed, без режима совместимости, создающего по имени.**

| Сочетание | Поведение |
| --- | --- |
| Новый клиент + новый сервер | Catalog v2, явный Create/Select, WS v2, ID/epoch checks |
| Старый v1 клиент + новый сервер | `GET /api/v1/me` возвращает protocol=2 и безопасную собственную legacy-карточку; `WS /api/v1/sync` после auth закрывается 4400 с `protocol_upgrade_required` **до lookup/create/Hub**. Новый каталог через v1 не предоставляется |
| Новый клиент + старый сервер | Проверка health/me выявляет protocol=1/отсутствие catalog; «Сервер требует обновления», sync/write/create отключены. Не fallback на v1 и ручное имя |
| Старый клиент + старый сервер | Поведение v1 не меняется; риск создания по опечатке остаётся до обновления. Новый EXE не исправляет старый сервер сам по себе |
| Версия wire неизвестна | Terminal unsupported_protocol, без «попробовать всё равно»; локальные drafts/базы не стираются |

План перехода: подготовить совместимые версии всех клиентов и Admin, backup и контролируемое окно остановки Remote, выполнить миграцию и обновление, затем подключать обновлённые клиенты. Временная недоступность старым клиентам предпочтительнее тихого смешивания данных. Reconnect старого клиента не создаёт ни одного space; число spaces после серии таких попыток неизменно.

Исторический `remote-android/protocol.md` описывает v1 и допускавшееся там автосоздание по имени. Это **не** разрешение сохранять его в v2; Android-задачи VS-90 обязаны обновить handshake/URL/политику retries и сохранить editor fail-closed gates. Никакого смешанного v1/v2 редактирования одной комнаты.

## 5. Миграция существующего Remote без потери данных

Это проект будущей **offline-операции**, не инструкция выполнить её в VS-89. `Store.__init__` и admin discovery не должны незаметно мигрировать живую БД.

### 5.1 Схема и однозначное соответствие

- Зафиксировать текущую схему как v1 (сейчас CREATE IF NOT EXISTS без versioned migrations); ввести schema marker и проверку совместимости. Новое приложение отказывается открывать старую/неизвестную схему на запись до явной миграции. Старый binary после миграции запускать запрещено.
- Сохранить **каждый существующий `spaces.id` байт-в-байт**. Этот UUID уже реальный FK документов и станет canonical project ID/space. `spaces.name` → `display_name` с тем же исходным текстом, убрать UNIQUE с подписи.
- Отдельно сохранить `legacy_space_name` в migration mapping (old name → прежний id, UNIQUE для этой исторической пары). Это доказательство происхождения/помощь человеку, **не alias для sync**. Каталог v2 опирается только на canonical ID.
- Добавить **storage_epoch = прежний UUID spaces.id байт-в-байт** и metadata_revision по §2. Не менять seq, docs content/hash/rev/deleted/updated_by/updated_at, пути, created_at. Переносить tombstones и пустые spaces тоже.
- Пользователям сохранить id, hash, цвет, created_at/revoked_at; `display_name` заполнить прежним name. Сохранить уникальное `name` как **неизменяемый legacy CLI handle**, не использовать для auth/нового UI. Для новых пользователей handle = их сгенерированный UUID; пользователь задаёт только display_name.
- Добавить users.deleted_at, credential_version (начальное 1), metadata_revision (начальное 1). `token_hash` становится nullable, остаётся UNIQUE для non-null; revoke/delete могут уничтожить hash. В базе нет plaintext-колонки/зашифрованного «восстанавливаемого ключа». Новые display_name не уникальны.
- Если legacy текст не проходит новые правила подписи, сохранить его как историческое значение; Admin помечает «нужно исправить отображаемое имя». Не менять автоматически и не блокировать сохранённые документы. Новые/редактируемые значения проходят §2.2. Если повреждён сам id/FK/ревизии — fail и ручной разбор, не исправление по догадке.

### 5.2 Порядок и проверки будущей операции

1. По явному подтверждению оператора остановить Remote/запретить новые подключения; до остановки предупредить о незаписанных room updates. Штатно дать клиентам materialize/flush, сохранить recovery; нельзя считать ephemeral Yjs уже сохранённым Markdown.
2. Подтвердить целевой container/volume/data path и версию. Создать согласованный SQLite backup через backup API либо после полного остановленного checkpoint; **не копировать один remote.db при живом WAL**. Backup защищён как credential store, не попадает в исходный EXE.
3. Dry-run на копии: schema/integrity/FK checks, полный перечень spaces (old name, old id, new id=old id, epoch, seq, число активных/tombstone docs), users counts и безопасные контрольные суммы документов. Токены/хеши ключей не выводить.
4. Одна транзакция schema+data migration; при ошибке полный rollback. До commit проверить сохранность всех полей документов, уникальность id, соответствие FK/seq и пользователей. После commit повторные integrity/FK checks; повторный запуск — no-op при целевой версии.
5. Сохранить mapping/report без секретов. Отдельно подтвердить переключение клиентов: ни локальная папка, ни похожее имя не доказывают, к какому space относится checkout. Клиент с доказанным старым hello UUID может предложить именно его; без такой базы — ручной Select из каталога.
6. Только после verification открыть новый сервер для v2. Rollback binary требует остановки и восстановления **целого** backup v1, а не запуска старого кода на новой схеме. После новых записей rollback старого backup означает потерю этих записей, поэтому нужен отдельный recovery/export и подтверждение.

Нельзя заменить UUID старым name, выбрать «самый похожий» проект, слить одноимённые проекты с разных серверов, удалить пустые/tombstone-only spaces или перенумеровать rev. Имя `boloto` и UUID `abc…` могут обозначать один legacy space, но в новом контракте его ID — `abc…`, пока человек явно не создаст другой проект. Желание дать ему ID `boloto` — отдельная будущая операция переноса с отдельным согласованием, не часть миграции.

## 6. Пользователи, ключи, revoke/delete и сессии

### 6.1 Модель и операции

`UserAdmin = {id,display_name,color,created_at,status,revoked_at,deleted_at,credential_version,metadata_revision}`; status — active/revoked/deleted. В публичных user/presence карточках только id/display_name/color. Ни hash, ни credential_version не являются личным ключом. Любая реальная мутация карточки/статуса/credential увеличивает metadata_revision; credential_version растёт только при инвалидировании/замене credentials, а не при смене подписи. Повтор идемпотентного revoke/delete без изменения состояния не увеличивает версии.

| Операция Admin | Семантика |
| --- | --- |
| Добавить | display_name + необязательный цвет; назначается новый UUID (обычный CLI генерирует его на сервере; RPC принимает заранее сгенерированный Admin UUID по §7.1), сервер генерирует случайный ключ и сохраняет только SHA-256; возвращает карточку и **одноразовый** secret response после commit |
| Редактировать | По immutable user ID + expected metadata_revision: имя/цвет, не идентичность, не credential. 409 при stale edit; перечитать и подтвердить. Дубликаты display_name разрешены |
| Перевыпустить | Явное предупреждение: старый ключ больше не действует, **все его текущие сессии завершаются**. Новый random key, новая credential_version, новый hash. Для revoked — отдельное подтверждение восстановления доступа; deleted не восстанавливается |
| Отозвать доступ | Идемпотентно переводит в revoked, удаляет действующий hash, увеличивает credential_version при первом переходе. Нового ключа нет. Сохраняет пользователя, документы и авторство; позднее можно явно перевыпустить |
| Удалить пользователя | Логическое необратимое удаление: deleted_at + revoked_at, hash=NULL, credential_version++. Строка/tombstone с ID остаётся для авторства; hidden из обычного списка, доступна через «Показать удалённых». Нет физического удаления docs/spaces и автоматического перераспределения «владельца» |
| Повтор delete/revoke | Безопасный идемпотентный ответ с текущим статусом; rotate/edit deleted — ошибка user_deleted. Новый человек с той же подписью получает другой UUID и не наследует ключ/историю |

Исторический CLI `user add/list/rotate/revoke <name>` не ломать молча: документировать legacy handle, добавить by-ID команды/структурированный режим. Admin **никогда** не выбирает пользователя по подписи или номеру строки; UUID сохраняется при сортировке/refresh. Удаление последнего пользователя допустимо: SSH-оператор может создать нового без personal key; показать отдельное предупреждение, но не вводить «суперадмина».

### 6.2 Действующие соединения: усиление относительно v1

При auth создаётся credential binding `(user_id, credential_version)` без сохранения plaintext ключа в Connection. На каждый входящий sync/put/delete/join/seed/update/awareness/leave перед обработчиком проверяются active + соответствие credential_version в текущей SQLite. Это необходимо, поскольку CLI работает отдельным процессом: одного события в памяти Hub недостаточно.

**Гарантия:** после commit revoke/delete/rotate никакой frame старого binding, чья проверка началась после commit, не меняет документы/комнату и не авторизуется на получение новых данных. Уже атомарно обработанный до commit frame мог быть принят; его нельзя «отозвать назад». Между проверкой и mutation не должно быть await; проверка/операция сериализованы с credential mutation транзакцией/эквивалентной блокировкой между соединениями SQLite. Для read/outbound также нужен актуальный guard, чтобы отозванный socket не продолжал получать чужие изменения.

Idle-сокеты закрывает watcher не позднее 30 секунд; при обнаружении отзыва закрытие 4401 с безопасной причиной. До физического close новые чтения/записи и queued outgoing блокируются guard. Перепроверять перед каждым queued send; при отказе очистить очередь и выполнить штатный Hub.disconnect: уход awareness, удаление сессий, передача scribe, освобождение пустых комнат. Уже авторизованный до commit in-flight send/HTTP response и отправленные сетевые bytes вернуть невозможно; нельзя обещать мгновенный отзыв данных в сети. Не удерживать DB write-lock через websocket await.

Revoke→rotate между тиками watcher не оживляет старую сессию: credential_version монотонна. Rotate активного пользователя также разрывает старые сессии; новый ключ открывает только новые. Reconnect со старым ключом — terminal unauthorised без retry-цикла. Это security fix в реализации, не уже имеющаяся гарантия v1.

Редактирование имени/цвета не отзывает ключ и не меняет docs.updated_by. Watcher обновляет публичную карточку/presence активных соединений максимум за 30 секунд, новые подключения видят её сразу. Никаких обещаний переписать произвольный awareness payload клиента или прошлые записи.

Удаление/отзыв могут оборвать dirty room; предупреждать о возможных нематериализованных правках, но не откладывать security revoke ради согласия клиента. Если остаётся другой scribe — штатная передача; если последний клиент исчез, действуют пределы §16.4. Не добавлять durable Yjs-хранилище или тихий «финальный put» от имени отозванного ключа.

## 7. Admin: UX, SSH API и секреты

### 7.1 Расширение существующего меню

После выбора конкретного running container: «Пользователи» → список ID/подпись/цвет/active-revoked; «Добавить»; карточка → «Изменить имя/цвет», «Перевыпустить ключ», «Отозвать доступ», «Удалить». Действие «Копировать ключ» доступно **только в одноразовой карточке выдачи**, не в постоянном списке. Для старого пользователя: «Ключ не хранится на Remote. Можно явно перевыпустить»; кнопка не запускает rotate скрыто.

Перед mutation показать host/SSH user/container + **полный user ID**/подпись и последствия. Default — отмена; Esc/EOF/Ctrl+C до отправки ничего не меняют. Delete и rotate требуют ввода полного user ID и второго подтверждения; revoke — явное подтверждение; добавление/редактирование — просмотр итоговых полей и Apply. Удалённое/stale target перечитать, не заменять похожим именем. Не выполнять mutation при простом открытии меню, discovery или telemetry.

Если операция отправлена и ответ потерян, честно показать «Результат неизвестен»: прочитать статус по UUID перед повтором. **Не auto-retry add/rotate**: повтор может инвалидировать уже выданный ключ. Для add клиент заранее генерирует request_id и отдельный user_id=UUID v4 hex; RPC users.create принимает предложенный user_id, сервер проверяет UUID, атомарно отклоняет занятый ID и не использует его для импорта/перезаписи существующего пользователя. Обычный CLI без этого поля генерирует UUID на сервере. При неизвестном исходе можно найти пользователя по этому ID, но исходный secret не возвращается; при необходимости — новое явное rotate.

Все новые строки RU/EN в существующем `admin.MESSAGES` либо выделенном модуле, не frontend locale JSON. Обе локали проверяются на одинаковые ключи/плейсхолдеры. Terminal escape/control sanitization сохраняется; секретный ответ **не** отдавать универсальному `show_result`.

Каталог в Admin: read-only список ID/подпись/epoch/счётчик документов и отдельное редактирование подписи проекта по ID/revision. Create выполняется клиентами через явный POST; при желании оператор использует ту же доменную операцию через SSH. Delete/rename ID/move данных не добавлять.

### 7.2 Структурированный SSH-контракт (новый, не HTTP)

В существующий CLI добавить фиксированную команду `voxarium-studio-remote admin-rpc`: один ограниченный JSON request через stdin, один JSON response через stdout. Admin вызывает её через существующий OpenSSH `-T` и `docker exec -i <validated-container-id>`, без TTY/shell interpolation пользовательских полей. Существующее SSH quoting остаётся для фиксированных argv; stdin — данные, не исполняемый Python/shell. При sudo сохранить `sudo -n`; не открывать Docker socket. Режим Docker/sudo проверить read-only probe **до** mutation, затем выполнить mutation ровно один раз; существующий `_docker()` с read-only retry по stderr для неё не использовать.

Envelope request: `{admin_rpc_version:1,request_id,operation,payload}`; response: `{admin_rpc_version:1,request_id,result}` либо `{...,error:{code,message}}`. Один request ≤16 KiB; строгое множество полей, операции allowlist, bounded stdout/list pages. Команды: capabilities, users.list/get/create/update/rotate/revoke/delete, projects.list/update, migration.inspect (только read-only). Настоящая offline migration — отдельная команда и подтверждение, не RPC из меню по умолчанию.

Capabilities возвращает wire/schema/admin_rpc версии и точный список операций. Отсутствие RPC/unsupported schema → read-only старого списка + «обновите сервер»; **не** пробовать shell/SQL обход и не запускать install/update автоматически. Не парсить человекочитаемый `user list` для mutations.

create/rotate response содержит `issued_key` только после успешного commit, вместе с user ID и credential_version; list/get никогда его не содержат. Ошибки/validation не возвращают входной payload. Key response не кэшируется сервером для idempotency/replay; потеря ответа означает явный перевыпуск, не recovery секрета. Мутации несут expected metadata_revision/credential_version; stale confirmation не отзывает неожиданно более новый ключ.

### 7.3 Copy без plaintext-хранилища Remote

- Исходный ключ из текущего SHA-256 **невосстановим**. Нельзя добавить «показать старый» чтением БД, экспортом hash, расшифровкой или подбором. Криптографический алгоритм распознавания ключа менять для этой цели не требуется.
- Новый ключ проходит только по защищённому SSH stdout в память Admin и попадает в отдельную ephemeral issue view. По умолчанию скрыт; явные «Показать» и «Копировать». Повторное Copy возможно, пока view открыта; после выхода/истечения 60 секунд plaintext reference очищается best effort, секрет больше не доступен.
- Не сохранять его в connection.json, temp files, журнал, crash report, shell history, БД Remote, EXE assets, settings или общей persistent выдаче. Никакого encrypted-recoverable token vault на Remote. Python не гарантирует физическое стирание всех копий памяти — это честное ограничение, не обещание zeroization.
- Windows clipboard через OS API внутри процесса (например ctypes), **не** `powershell ... <token>`, `cmd echo`, `clip.exe` с токеном в argv и не внешнюю команду с secret. Для других OS отдельный безопасный adapter или понятное «копирование недоступно», без unsafe fallback.
- Clipboard — внешняя утечка по выбору оператора: предупреждение о clipboard history/cloud sync/чужих программах. Через 60 секунд очистить только если clipboard sequence не изменился после нашей записи; чужой clipboard не трогать. Не обещать удаление уже сохранённой истории.
- Если clipboard недоступен, не писать key в общий экран/логи автоматически; оставить явное Reveal в одноразовом view с предупреждением о screen/terminal recording. После закрытия — только rotate. Личный ключ следует передать человеку защищённым каналом, не через shared Documents.

### 7.4 Отсутствие секретов в диагностике

Ни personal key, ни Authorization, ни hash не должны попасть в local/remote argv, URL, env для SSH-команд, stderr, debug trace, telemetry или generic error. Key генерируется на Remote, не передаётся аргументом `user add --token`. SSH private-key contents никогда не читаются/не отправляются Admin; argv содержит только существующий путь к ключу.

Существующий `RemoteAdmin._run` включает remote stderr в AdminError, а `show_result` печатает результат. Для secret-bearing RPC нужен отдельный путь: pipe capture, строгий parser, redacted error mapping; не показывать raw stdout/stderr даже при malformed JSON/nonzero/timeout. `TimeoutExpired.stdout/stderr`, repr response и exception chaining не должны раскрыть выданный ключ. Логировать только operation/request_id/target ID/result code, без payload. Не включать frame/header debug logging у HTTP/WS/SSH.

Обычный серверный CLI add/rotate может сохранить явно запрошенный человеком one-time вывод в интерактивной оболочке (исторический интерфейс), но Admin его не вызывает как обычный printable result. Audit инфраструктуры с обязательной записью SSH stdout требует отдельной организационной политики; приложение не может защитить секрет от привилегированного администратора/компрометированного endpoint.

## 8. Небольшие задачи реализации и точные файлы

Ниже **предлагаемые этапы**, не созданные карточки и не разрешение менять перечисленные файлы в VS-89. Пути относительно D:\VoxariumStudio. Каждая будущая карточка объявляет полный write_paths; shared writers в одном файле запускаются последовательно. Имена новых файлов фиксируются при постановке. VS-88/VS-90 отвечают за собственную клиентскую декомпозицию.

| Этап / зависимость | Предлагаемые write_paths | Приёмка |
| --- | --- | --- |
| S0. Зафиксировать общий контракт | `docs/voxarium-studio-dev-spec.md`, `remote/README.md`; при согласовании — `.voxarium_studio/docs/remote-identity/server-design.md`, `.voxarium_studio/docs/remote-identity/studio-design.md`, `.voxarium_studio/docs/remote-identity/android-design.md` (с текущими владельцами) | §16.1/16.2/16.5 описывают v2, explicit Create/Select и hash-only UX; Studio/Android согласуют ID/epoch/error policy |
| S1. Версионировать схему и offline migration, после S0 | `remote/voxarium_studio_remote/store.py`, новый `remote/voxarium_studio_remote/migrations.py`, `remote/tests/test_store_migrations.py` | Копия настоящей v1 schema; backup/dry-run/rollback/idempotency, exact IDs/content/revs/tombstones/hash preservation; никакого live implicit migration |
| S2. Каталог store, после S1 | `remote/voxarium_studio_remote/store.py`, `remote/voxarium_studio_remote/protocol.py`, `remote/tests/test_project_catalog_store.py` | create/get/list/update label отдельны, lookup never creates; strict ID, duplicate labels, race/409, epochs |
| S3. Wire/API v2, после S2 | `remote/voxarium_studio_remote/app.py`, `remote/voxarium_studio_remote/hub.py`, `remote/voxarium_studio_remote/protocol.py`, `remote/tests/test_remote.py`, новый `remote/tests/test_catalog_api.py` | Auth до каталога, snapshot/legacy resolution/capabilities/pagination/errors, v1 reject до любых записей, WS unknown no-create, hello ID/epoch; CAS/room regression |
| S4. User domain/credential lifecycle, после S1; последовательно с S2/S3 по общим файлам | `remote/voxarium_studio_remote/store.py`, `remote/voxarium_studio_remote/auth.py`, `remote/voxarium_studio_remote/hub.py`, `remote/voxarium_studio_remote/app.py`, новый `remote/tests/test_user_lifecycle.py` | CRUD display_name по ID, tombstone delete, revoke/rotate generation checks на read/write/send, два SQLite connection, idle close/presence/scribe |
| S5. CLI + SSH RPC, после S2/S4 | `remote/voxarium_studio_remote/cli.py`, новый `remote/voxarium_studio_remote/admin_rpc.py`, новый `remote/tests/test_admin_rpc.py` | capabilities/version, bounded JSON stdin, by-ID CAS mutations, одноразовая выдача, unknown-result/no-replay, legacy handle compatibility |
| S6. Admin transport, после S5 | `remote/voxarium_studio_remote/admin_transport.py`, `remote/tests/test_admin_transport.py` | Mock SSH/Docker, fixed argv+stdin, container checks/sudo, no raw errors/token leakage, не auto-retry mutation; VS-54 discovery/install regression |
| S7. Ephemeral key view/clipboard, параллельно S6 | новый `remote/voxarium_studio_remote/admin_secrets.py`, новый `remote/tests/test_admin_secrets.py` | In-process clipboard, show/copy/TTL/close/cancel, sequence-safe clear, no file persistence; canary secret во всех error paths |
| S8. Меню пользователей/подписи, после S6/S7 | `remote/voxarium_studio_remote/admin.py`, `remote/voxarium_studio_remote/admin_ui.py`, `remote/tests/test_admin.py`, `remote/tests/test_admin_ui.py` | CRUD selection by full ID, stale confirmation, typed delete/rotate, EN/RU parity, Escape default cancel, secret не через show_result |
| S9. Studio interop, после S3/S4 и клиентской реализации VS-88 | `backend/voxarium_studio/sync/protocol.py`, `backend/tests/test_remote_sync.py`; остальные client files — отдельные write_paths из VS-88 | Константы обеих сторон v2, два Studio и реальный in-process Remote: create/select, mismatch/epoch/unknown-ID, rotation, no-write-on-open. Remote установлен в backend env, skipped ≠ pass |
| S10. Packaging/документация и standalone EXE, после S8/S9 и Android gate VS-90 | `remote/build_admin_bundle.py`, `remote/voxarium_studio_remote/admin_bundle.py`, `remote/tests/test_admin_bundle.py`, `build-remote-admin.bat`, `remote/pyproject.toml`, `remote/voxarium_studio_remote/__init__.py`, `remote/README.md`, `voxarium-remote-admin.exe`, `voxarium-remote-admin-updated.exe` | Полный Remote pytest, локальная сборка встроенного **нового** Remote payload + OpenSSH, provenance/hash и clean-folder smoke без Python/SSH PATH; никакого deploy |

S6/S7 — независимая параллельная работа; S1–S5 имеют shared store/protocol/app, их нельзя раздать одновременно без отдельного владения файлами. `admin_bootstrap.py` и `test_admin_bootstrap.py` в основном read-only регрессия VS-54; не менять bootstrap ради user CRUD. Если будущей реализации понадобятся другие файлы, расширить write_paths **до** записи.

Отдельный будущий эксплуатационный этап (вне кодовых S0–S10): обновление уже установленного Remote с сохранением volume и явной offline migration. У существующего Admin install найденная установка вызывает отказ; не обходить его ради CRUD. Проверку такого upgrade сначала делать на disposable local fixtures, production/deploy — только после отдельного разрешения.

S10 сохраняет существующий standalone-процесс, а не требует нового PyInstaller проекта. Встроить новые `admin_rpc.py/migrations.py` как Remote payload; server runtime не обязан исполняться локально в EXE. Проверить frozen imports нового clipboard adapter. Использовать `VOXARIUM_REMOTE_ADMIN_BUILD_DIR` для task-private build/temp/cache; постоянный EXE публиковать только в заявленный output. При занятом основном файле сохранить существующий fallback `-updated.exe`. Проверка EXE не равна обновлению контейнера/серверной миграции.

## 9. Матрица обязательной проверки реализации

| Группа | Минимальные сценарии и доказательство |
| --- | --- |
| ID/catalog | Границы длины, uppercase/Unicode/percent/double decode/duplicate query, equal labels/different IDs, exact IDs/different labels; list/get/me/snapshot/legacy resolve/failed WS не меняют space count; snapshot page race → 409 без смешивания; конкурентный Create ровно один 201 |
| Auth/security | Без ключа каталог не виден; invalid/revoked/deleted — 401/4401; public key не даёт user CRUD; нельзя передать key через query/body/cookie; no CORS/admin HTTP |
| Version | v1 WS→v2 сто попыток, включая опечатки: ноль созданных spaces; v2→v1 terminal upgrade_required, без writes; несовпавшие hello ID/epoch не выпускают старую очередь |
| Migration | Fixture v1 с несколькими users/spaces, empty/tombstone-only spaces, совпадением legacy name с чужим UUID-подобным именем; все ID/FK/content/hash/rev/seq/created/updated сохранены; corrupt schema/rollback/WAL backup; повтор no-op |
| User lifecycle | duplicate display names, edit без key change, stale revision, revoke идемпотентен, deleted не rotate; авторство и документы сохранены; последний user удалён → SSH create доступен |
| Active sessions | rotate active и revoked, revoke→rotate между watcher ticks; frame после commit не accepted, queued outgoing не выдаётся; separate CLI/Store process; close ≤30s; presence removal/scribe handoff/dirty last-scribe честно отражены |
| One-time secret | Copy только add/rotate view; closed/expired не «восстанавливается»; malformed JSON/nonzero/timeout/clipboard failure/interrupt не выводят canary secret; CLI/SSH/Docker argv, captured logs и temp tree не содержат key/hash |
| Admin UX | Не тот container/stale row/два одинаковых имени, confirmation full ID, Esc cancel, lost-response re-read и явное rotate; RU/EN labels/placeholders, terminal controls |
| Regression | Весь `remote/tests`, включая bootstrap/transport/bundle VS-54; backend sync integration без skip; CAS/conflict copies, room open 0 put, Yjs нигде не persisted |
| EXE | `--help`, `--check-bundle`, запуск из пустой папки вне repo с убранными Python/OpenSSH из PATH; packaged RPC capabilities и тестовый fake transport, clipboard canary; manifests без credentials/БД/профилей/кэшей; SHA-256 финального EXE и версия embedded payload в отчёте |

Будущие команды проверки: `python -m pytest remote/tests` из корня при установленном Remote; `python -m pytest backend/tests/test_remote_sync.py` в backend environment с Remote; `build-remote-admin.bat --no-pause` с task-private build dir. Сборка может скачивать build dependencies и не входит в VS-89. Реальный сервер/установка/TLS/deploy не требуются для unit/contract tests и не подтверждаются ими; любые последующие network/deploy/production migration — отдельная задача с явным разрешением.

## 10. Проверка самого VS-89

Документ прочитан обратно через Studio, проверены заголовки/структура и отсутствие conflict markers. Результаты двух независимых read-only review Remote/Admin получены через wait_subagents/get_subagent; исправлены двусмысленности legacy display-name validation, момента авторизации outgoing frame и генерации UUID для Admin create. Проверены чтение исходников и точность отличия «есть сейчас» от «предлагается», согласованность таблиц ID/API/версий/миграции, отсутствие plaintext recovery и неявного создания. Существующие чужие изменения рабочей копии не включаются в этот результат. Изменяемый deliverable — только `.voxarium_studio/docs/remote-identity/server-design.md`; тесты runtime/EXE и production-проверки здесь не заявляются как выполненные.

## 11. Междокументное согласование VS-91

Согласовано с [[remote-identity/studio-design]] §6/§13 и [[remote-identity/android-design]] §4/§5: Remote POST принимает только `{id,display_name}` без server replay; unknown outcome → GET исходного ID и отдельный Select, не автоматическая привязка победителя гонки. Штатная миграция: canonical ID = прежний UUID, storage_epoch = прежний UUID; space_instance_id только локальный alias epoch. Wire/catalog v2, no-auto-create, snapshot/CAS и terminal errors остаются этим контрактом, не заявлением реализации.

Различие локальных профилей намеренное: Studio — один профиль на normalized URL и drain при смене key; Android — несколько профилей одного URL с account-partition данных. Это не серверные identities/ACL; Remote остаётся командным без RBAC. Hash-only хранение ключей, одноразовая выдача/copy и явный reissue (§6–7) не меняются. Таблица закрытых расхождений — Studio §13; реализация, миграция production и deploy этим согласованием не разрешены.
