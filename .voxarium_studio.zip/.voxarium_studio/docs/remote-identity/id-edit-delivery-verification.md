# VS-177 — доставка локального ID edit и согласованный G

16.11.2026. Основание: [[remote-identity/studio-design]] §5.2–5.3/§7, [[remote-identity/runtime-integration-plan]] I6/I7/I8/I13, [[remote-identity/i8-editor-proof]]. Эта проверка исправляет открытый P1 из исторического [[remote-identity/i13-local-id-verification]]; не объявляет полный I13 или этап I9–I16 выпущенными. Общая матрица и команды — [[remote-identity/runtime-integration-verification]].

## Контракт G

- G — не секрет и не право записи, а числовой ordering/CAS fence внутри одного backend_epoch. Допустимы целые 0…9007199254740991, lossless для JSON/JavaScript.
- Drain расходует captured oldG+1, disabled commit — oldG+2. Все увеличения checked; нехватка двух значений блокирует quiesce до остановки runner/комнат и до durable publication. Оборачивание и случайный 63-bit committed G удалены.
- Новый backend lifetime получает другую backend_epoch и G=0. Старые journals не инициализируют RAM counter; исторический receipt не перематывает G и не переименовывается новой epoch. Partial retry допускается лишь для той же epoch и точного следующего G; durable-completed без RAM publication остаётся recovery_required.
- Frontend safe-integer/монотонные guards сохранены. Epoch mismatch необратимо отзывает старые tickets до reload; late reply не снимает этот latch. Prepare передаёт захваченную backend_epoch, дальнейшие запросы используют исходные oldG/fence, не latest G.

## Доставленный локальный путь

Project Settings показывает canonical ID/URL и отдельное подтверждение edit_id. Компонент использует prepare → существующий editor owner ACK → quiesce → CAS commit; сам не создаёт editor ACK/receipt, не пишет Markdown и не запускает Remote Create/Select/Enable. Success требует полного exact change receipt, disabled/R+1/fingerprint/G и согласованного наблюдения owning sync-store. Неполный/чужой receipt, 409, stale epoch/G, cancel, late callback и uncertain commit не превращаются в saved.

После restart canonical completed journal по-прежнему не является разрешением v2 runner. Новый renderer может явно попытаться изменить локальный ID при disabled/idle blocked observation без reasons, rooms, pending writes и binding change; это не Select/Enable и не обход backend recovery/CAS. Старый renderer не вправе получить тот же допуск через refresh после epoch mismatch. Реальные backend отказы остаются видимыми.

## Проверка сохранности

Новый backend suite test_remote_id_edit_delivery.py использует настоящие AppContext, DocStore, lifecycle/config transactions, journal, HTTP и Markdown. Offline sync/drain не заменены Remote mocks; подавлены только периферийные watcher/plugin processes.

Проверены byte/mtime неизменность не-ASCII/CRLF Markdown при clean read, untouched lease/ACK и commit; paths, runtime descriptor/epoch, DocStore/jobs/team objects и MCP остаются прежними. Cancel до fence не меняет identity; после fence не обещает rollback. Confirmation/CAS/disk failure сохраняют corpus. Старые captured G и epoch не могут сохранить текст под новым назначением; исторические/частичные receipts и safe-integer boundary покрыты отдельными регрессиями.

Frontend paired evidence выполняет настоящие DocsView/BlockEditor/Y.Doc: clean peers дают 0 PUT, non-scribe ждёт final scribe save, pathless release удерживает freeze через lease DELETE и повторно проверяет snapshot. Этот relay/HTTP слой синтетический, не v2 Remote interop; исходный proof подробно описан в [[remote-identity/i8-editor-verification]].

## Результаты

- Backend ID/barrier/lease/runtime/bindings/real legacy interop: **743 passed, 0 skipped**; новый delivery suite — 15 tests.
- Отдельные paired editor suites: **355 passed, 0 skipped**.
- Финальный весь frontend: **5557 passed, 109 файлов, 0 failed/skipped/pending**; SyncSettings — 139 tests.
- Независимый scoped review подтвердил G, сохранность, I8 pathless release и закрытие restart-UX finding; full release остаётся NO-GO. Проверки финальной дельты и build фиксируются в общем verification document.

Реальный установленный Remote пока protocol v1. Результат не доказывает v2 hello/account/storage_epoch/cursor, positive online editor drain, Preview/Enable, legacy apply или credential-generation security. Production keys/data не читались и не менялись; Studio/jobs не перезапускались.