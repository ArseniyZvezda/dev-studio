# VS-100 — independent S1/S2 correction re-audit

Отчёт VS-100 сохранён Producer из disposable TASK-100 для последующих корректирующих задач. Это завершённый аудит S1/S2, не чистая приёмка foundations и не приёмка v2. См. [[remote-identity/foundation-audit]] и [[remote-identity/studio-design]]. Остальной текст — результаты исполнителя; Producer сверил исходники владельцев, regression log и integrity report.
No implementation or existing test was edited; no corrective work was performed.

## Verdict

Original VS-95 defects: **F1 PASS (six HTTP repros), F2 PASS, F3 PASS, F4 PASS; 9/9 original cases now meet their expectations.**
The stronger additional assertions are **not all green**: 8 failures expose three baseline conditions, documented below.
These are not proven regressions introduced by VS-96–VS-99; they must not be hidden behind the passing original matrix.

## Final counters (not counting aborted/harness-debug runs)

| Command group | Passed | Failed | Skipped |
|---|---:|---:|---:|
| Broad 7-file regression run, regressions-verified.log | 560 | 1 | 0 |
| Unchanged broad repeat, regressions-repeat.log | 560 | 1 | 0 |
| Existing settings_error_redaction, existing-tests7.log | 80 | 0 | 0 |
| Independent F1, independent-tests4.log | 14 | 7 | 0 |
| Independent F2, f2/final.log | 55 | 0 | 0 |
| Independent F3/F4, f34/pytest.log | 62 | 0 | 0 |
| Parent surfaces + selected legacy sync (3 + 2) | 5 | 0 | 0 |
| Explicit baseline YAML log-security expectation | 0 | 1 | 0 |
| Single workspace-event repeats #1/#2/#3 | 1 | 2 | 0 |

The selected existing regressions therefore contain 642 passing cases plus the workspace-event failure on each broad run
(560 broad + 80 redaction + 2 legacy). New probes: **134 passed / 8 failed** (14+55+62+3 passed; 7+1 failed).
Original 9-case correction matrix is entirely green, but neither the additional strictness checks nor the whole regression run is clean.
Broad durations: 123.31s and 124.50s; network/listener/DNS guard attempts in both completed parent broad runs: **0**.
No task-owned test process remained after completion.

| Original case | Observed |
|---|---|
| PUT /api/settings `{token: marker}` | 422, fixed safe envelope, no marker/input/ctx, no writes/reconfigure |
| PUT /api/settings `{sync: {token: marker}}` | Same |
| PUT /api/settings/application `{remote_servers: [{token: marker}]}` | Same |
| PUT /api/projects/{runtime}/settings `{token: marker}` | Same, fixture runtime obtained through real in-process open |
| Stored extra project_identity.token, POST /api/projects/open create=false | 400, fixed safe message, config/runtime unchanged, no sync; fully populated fixture |
| Same stored extra, POST /api/settings/reload | Same |
| F2 future_section.future_flag + theme.future_theme_flag + language ru | Preserved after profile create |
| F3 obsolete project theme.text_size=99 with existing isolated global config | identity_present/good-id; original-byte fingerprint; no writes |
| F4 repeated project_identity first/second | invalid_config, no persistent_id, original bytes unchanged |

## Additional failures: exact conditions and owners

### Regression repeat caveat — workspace watcher event ordering

The first completed 561-test broad run was **560 passed / 1 failed / 0 skipped**.
`backend/tests/test_workspace.py:404`, `test_background_events_stay_local_and_browser_replay_changes_projects`,
expected test.background but received explorer.file_changed from the live synthetic filesystem watcher.
Three unchanged single-test repeats returned **PASS, FAIL, FAIL** (same unsolicited-event family).
This is a real non-green regression result; no event filtering, assertion relaxation or disabling the watcher was applied.
It is outside the corrected identity/profile storage owners and cannot be attributed to VS-96–VS-99 from this run.
The no-socket polling scheduler is an additional timing boundary; the normal Windows socketpair scheduler was not allowed by this task.
See regressions-verified.log, regressions-repeat.log and workspace-event-repeat-{1,2,3}.log;
the second full run reproduced the same failure (560 passed / 1 failed).

### A. Nested unknown acceptance: six failures, no secret reflection

`backend/voxarium_studio/api/project.py:63–67,79–80,111–117` reuses permissive nested models from
`backend/voxarium_studio/core/config.py:109–129,147,383–387,415`.
Send unknown `token: {nest: [synthetic_marker]}` together with a valid sibling:

| PUT | Unknown under | Valid sibling that is applied |
|---|---|---|
| /api/settings | theme | project_name: must-not-save |
| /api/settings | teams | project_name: must-not-save |
| /api/settings | concurrency | project_name: must-not-save |
| /api/settings | docs | project_name: must-not-save |
| /api/settings/application | updates | language: ru |
| /api/projects/{runtime}/settings | docs | project_name: must-not-save |

Actual: HTTP 200 and corresponding config file changes; expected stronger contract: 422 and no sibling mutation.
Unknown marker is discarded, not reflected or persisted; sync remains disabled.
The same model permissiveness exists in HEAD; redaction did not newly loosen it.
Application theme, scoped theme, forbidden top-level project_identity and dynamic unknown keys do reject safely.

### B. Rejected open without samples writes two files: one failure

Fixture: init_project(root, with_samples=False), then valid YAML containing rejected project_identity.token.
POST /api/projects/open create=false returns correct secret-free 400, but creates
`.voxarium_studio/pipelines/prompt-to-voxel-asset.yaml` and `.voxarium_studio/teams/default-team.yaml`.
Config bytes, selected context/registry and sync are unchanged.
Owners: `backend/voxarium_studio/core/project.py:181–195` initializes samples before load_config;
caller `backend/voxarium_studio/core/context.py:169`, workspace `core/workspace.py:128`.
Expected stronger no-write refusal: validate before these writes.
This is pre-existing ensure/init ordering, not a new identity/profile public mutation.

### C. Malformed project YAML leaks a source excerpt into warning: one failure

Fixture bytes: `project_identity: [VS100_BASELINE_MALFORMED_CANARY\n`.
`load_config` calls `_read_project_config`; `backend/voxarium_studio/core/config.py:590–593`
logs the YAML exception with its source excerpt at line 592, exposing the synthetic marker.
Expected: fixed/redacted diagnostic, no raw source in logs.
Original bytes remain unchanged; identity_migration_plan returns redacted invalid_config/no ID.
The logging line is unchanged relative to HEAD and was outside VS-96's stated malformed-YAML boundary.
An explicit security expectation was executed and left failing, not xfailed or weakened:
`test_baseline_log_security.py::test_malformed_project_yaml_must_not_log_raw_source`.

## Passed extended checks

- F1: exact statuses/envelopes; nested/type/list/malformed JSON errors; hostile dynamic error locations and contexts;
  unchanged unrelated FastAPI errors; application DEBUG records checked through teardown; real in-process TestClient.
- F2: semantic preservation through create/rename/credential set/clear/URL/delete/import/recovery and later stale preference save;
  nested unknown fields remain private; corrupt/duplicate/alias/merge/omap/pairs/UTF-8/empty stores fail closed with bytes preserved;
  strict CAS typing, lifecycle guards, fsync/replace fault injection, cleanup and recovery fences.
- Existing credential suite also covers process contention, abrupt process exit at replace boundaries and Windows fixture ACLs.
- F3/F4: nested identity/sync duplicates, unknown identity fields, malformed YAML, aliases/non-overlapping and overlapping merges,
  cyclic aliases, invalid project-owned data, unchanged original-byte fingerprints and read-only IO/UUID/credential guards.
- Global GET/effective/scoped/project-save isolation: actual synthetic private credential and opaque canaries absent from public/config/log surfaces.
- OpenAPI catalog: only new `/api/remote/migration` and scoped counterpart, both GET; no public identity/profile mutation endpoints.
  Legacy `/api/sync` remains; service still uses settings.space and credentials.load_token, not new profile/identity adapters.
  sync/service.py, sync/protocol.py and api/sync.py have no diff against HEAD.

## Commands, isolation and evidence

Navigation first: `graphify query "remote identity foundation settings profiles scopes validation audit" --graph "D:\VoxariumStudio\graphify-out\graph.json"`;
read VS-95–VS-100 cards, foundation-audit.md and studio-design.md; inspect current owning files and actual dirty diff.
Graph answers were navigational only; current sources were authoritative.

Parent wrapper, cwd D:\VoxariumStudio:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:VS100_RUN_LABEL='regressions-verified'
.\backend\.venv\Scripts\python.exe -B .\.voxarium_studio\temp\TASK-100\run_regressions.py
```

The wrapper runs `pytest -n0 -p no:cacheprovider --basetemp <TASK-100>/regressions-verified/pytest --junitxml <same>/junit.xml -q`
against `tests/test_project_identity.py tests/test_remote_profiles.py tests/test_application_settings.py tests/test_project.py tests/test_project_scopes.py tests/test_workspace.py tests/test_api.py`.
Exact argument list is `regressions-verified/command.json`; stdout/stderr is `regressions-verified.log`.
Surfaces and two selected non-network legacy sync tests use the same wrapper with explicit test arguments (`surfaces-verified.log`).
Separate failing log-security expectation: label baseline-log-security, argument test_baseline_log_security.py.

Worker exact commands/results are in `f1/report.md`, `f2/REPORT.md`, `f34/report.md`;
independent F1 failures are retained in `f1/independent-tests4.log` and structured `f1/independent-results.json`.
Existing F1 final result is `f1/existing-tests7.log`; F2 final result `f2/final.log`; F3/F4 `f34/pytest.log`.

All homes, temp dirs, stdout/stderr logs, pytest bases, scripts and probes are under TASK-100.
Bytecode/cache disabled; no real project/home/credential fixtures used.
Socket/DNS/listener operations fail closed; Windows asyncio's TCP socketpair is replaced only in disposable scheduling harness
by no-socket IOCP polling (no application validation/storage assertions replaced).
Initial strict guard run failed on Python's internal socketpair before socket bind; an inefficient polling run was interrupted;
OpenAPI probe was corrected for lazy router expansion and unrelated legacy remote-control routes.
These harness runs are kept, not counted as final product regressions or silently erased.

`baseline.diff`, `after.diff`, source-hashes-before.json and source-integrity.txt separate the pre-existing dirty checkout from this audit.
Tracked diff was byte-identical and 830 tracked/untracked source file hashes unchanged at the integrity checkpoint;
final verification is in final-source-integrity.txt: **830 files / zero changes, identical tracked binary diff**.
`git -c core.safecrlf=false diff --check` exit 0.

## Limits

This is not blanket strictness/security acceptance: A–C remain baseline defects/boundaries.
General load_config still uses last-wins YAML; only diagnostic F4 loader rejects ambiguous maps.
Legacy SyncConfig/AppConfig still permit some extras/coercions; no new v2 sync contract is claimed.
No real network/servers/restarts/deploy/install/build/production migration/EXE/APK were performed.
Full v2 S3–S10, live sync transport/cutover/drain/late-save, installed Studio and real power-loss/disk-full/hardware durability were not accepted.
Controlled failure injection and synthetic process crashes are not proof of physical disk durability.

