# VS-181 — Android foundation A1–A4: проверка

16.11.2026. **Foundation A1–A4 завершён; UI/session integration и выпуск APK не принимаются этим отчётом.** Основа: VS-90, [[remote-identity/android-design]], dev spec §16.7–16.9, [[remote-identity/delivery-authorization]], принятый [[remote-identity/server-admin-verification]] и фактический Remote v2 VS-180.

## 1. Границы и исходное состояние

Работа выполнена в отдельном `D:/VoxariumRemoteAndroid`, без Git-метаданных. Проверены отсутствие `D:/AGENTS.md`, корневого и вложенных Android AGENTS.md; прочитаны DATA.md, EDITOR.md, VERIFICATION.md и актуальные transport/storage источники. Graphify запрошен первым: Studio/Remote связи доступны, Android-specific индекс отсутствует, поэтому Android проверен по фактическим файлам.

Изменены только объявленные native source/test файлы и этот документ. Studio/Remote source, личные/production данные, устройства, старые APK, dist, evidence и active gate report не изменялись. Новых карточек нет; внутри VS-181 было три непересекающихся implementation workers и два независимых read-only reviewers, затем corrective turns.

Исходный closed-copy baseline: fingerprint `784840a151a5dbc35c68695ba856b586e039a17dc87d9dcf6a90c0b093b2f0f2`, 362 native tests / 25 suites и 445 web tests / 7 suites, без test skips. Это baseline, не доказательство изменённого source.

## 2. Поставленные API

### A1: metadata и credentials

- `ServerProfile` без project/space, исторический `ServerVerification`, immutable `ProjectBinding` и `LegacyImportRecord`; валидируются exact canonical HTTPS URL, account, ID, credential revision и 32 lowercase hex storage_epoch.
- `ServerProfileStore.open(context)` хранит `noBackupFilesDir/identity.v2`. `migrateLegacy(ProfileStore, observations)` — single-blob copy-on-write, checksum, checked fsync/readback, source hash/count и marker против повторного старого импорта.
- Каждый v1 профиль сохраняет свой localProfileId, label, canonical URL, credentialId и selector. Никакого dedupe по URL/имени/ключу, генерации projectId из имени или автоматической binding activation.
- `addBinding` регистрирует только inactive metadata и не позволяет переназначить прежний bindingId. Binding сохраняет исходные URL/credential revision/account/ID/epoch даже после редактирования профиля.
- `credentials.v1`, credentialId и Keystore alias `com.voxarium.remote.credentials.v1` не меняются. Missing alias при ciphertext и corrupt vault остаются ошибками, не пустой базой. Замена содержимого ключа под прежним credentialId требует повышения revision интеграционным owner; vault сам не может вывести это из metadata.

### A2/A4: native HTTP, не editor/session

- `RemoteEndpoint.create(url)` — URL-only value с сохранением reverse-proxy prefix. Старый `create(url, space)` совместим; URL-only value не может открыть dummy legacy space.
- `ServerVerifier`: bounded HTTP health → соответствующий me; native Bearer, стандартные TLS/hostname checks, без WS, redirects, retries, sync, create и fallback после ошибки. Protocol 1 проверяет ключ, но каталог недоступен.
- `ServerRequestIdentity` фиксирует profile/URL/credentialId/revision/selectionGeneration. Verify reply и `CatalogScope` ограждают cancellation и поздние ответы. При смене любого компонента owner инвалидирует адаптеры; consumer повторно проверяет scope перед применением queued reply.
- `ProjectCatalog`: page/list-all/get/exact legacy resolve/explicit Create по действующим v2 routes. ID не нормализуется; duplicate labels не объединяются. Legacy labels сохраняются буквально; новые labels нормализуются и валидируются отдельно.
- POST содержит только `{id,display_name}`, one-shot body запрещает HTTP machinery replay. Unknown outcome сохраняет исходный ID: повтор закрыт до GET исходного ID; найденная запись остаётся информацией, а не автоматическим Select. Есть `restoreUncertainCreate` для восстановления заранее сохранённого intent.
- Перед POST будущий A5 owner обязан durable сохранить original Create ID; adapter не является process-persistent UI intent store. Refresh/select/list/GET не вызывают Create. Старый server unsupported, auth/TLS/invalid response не становятся legacy fallback.

### A3: durable partitions и миграция

- `DocumentPartition` = exact canonical URL + project ID + account + storage_epoch; versioned length-tagged keys, отдельный `documents.v2` через `AtomicDocumentStorage.openV2`. Legacy constructors и v1 keys сохранены.
- `IdentityMigration.resume/status/activate`: prepared → copied → verified, затем отдельный атомарный activation manifest. Миграция без сети; caller сначала quiesce/retire legacy writers. Root-shared process locks; разные OS processes не поддерживаются.
- Сначала durable archive/journal/room recovery, затем replaceable mirror; каждый commit/readback возобновляем. Проверяются hashes, lengths, counts и **явное отсутствие** всех зарезервированных target slots, в том числе missing-source mirror и fresh live-room recovery.
- Перенесены exact Markdown/newlines/Unicode, versions/rev/hash/tombstones/cursor, pending immutable snapshot и newer draft, bases, generations/counters, обе conflict/recovery версии и reserved copy names. Live/sid/connection authority не оживает; исходный журнал сохранён byte-exact отдельно.
- Raw room recovery переносится только в provenance archive: namespace/path/context/generation/reason, source/last-valid и opaque raw/rejected bytes. Yjs не replay-ится и не восстанавливается автоматически в новой комнате.
- Atomic source inventory автоматически обнаруживает orphan/raw-only room namespaces без hints, проверяет payload и hash-directory provenance. Пределы — 4096 каталогов / 256 MiB aggregate; unknown schema, corruption, IO и превышение лимитов fail-closed. Virtual storage adapters должны реализовать собственный полный inventory contract.
- Strict migration-only reads различают missing и физическую corruption, читают committed backup/base **без recovery rename/delete/repair**. Обычное runtime refetch-поведение corrupt cache не ослаблено и не смешано с миграцией.
- Ambiguous name/account mapping, slug/dashed/invalid legacy IDs — archive-only. Нормальный импорт cursor/base возможен лишь для прежнего 32hex UUID с тем же initial epoch и отдельно принятым exact mapping.
- Activation только явная; после неё повтор миграции не накладывает v1 на новые v2 edits. V1 источники не удаляются. `selectPartitionOffline` — activation-gated reader/recovery adapter; ни один импортированный pending не может породить старый network effect.

## 3. Финальная полная проверка

Toolchain: Windows, Microsoft OpenJDK **21.0.8**, Gradle wrapper **8.14.7-bin**, Kotlin **2.3.21**, Node **v24.18.1**, npm **11.16.0**. Wrapper/dependencies/build parser не менялись. Существующий toolchain/cache переиспользован; для финального прогона Gradle user home, project cache, build/web outputs и temp направлены в TASK-181.

Controlled source copy: `D:/VoxariumStudio/.voxarium_studio/temp/TASK-181/closed-copy`. В ней нет active report. Исходные app/src, web inputs и app Gradle побайтно совпадают с финальным оригиналом; dependencies установлены в private copy через `npm.cmd ci --ignore-scripts` (203 packages, audit 0 vulnerabilities). Оригинальный node_modules не исправлялся.

Выполненная команда из closed-copy:

```powershell
$env:JAVA_HOME='C:\Program Files\Android\openjdk\jdk-21.0.8'
$env:GRADLE_USER_HOME='D:\VoxariumStudio\.voxarium_studio\temp\TASK-181\gradle-home'
$env:TEMP='D:\VoxariumStudio\.voxarium_studio\temp\TASK-181'
$env:TMP=$env:TEMP
$env:VOXARIUM_DOCUMENTS_TEST_TEMP=$env:TEMP
.\gradlew.bat --no-daemon --no-build-cache --rerun-tasks `
  --project-cache-dir "$env:TEMP\final-gradle-cache" `
  -I "$env:TEMP\final-corrective.init.gradle" `
  -PeditorBuildTemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-181/final-corrective-web `
  printEditorGateFingerprint assembleDebug testDebugUnitTest lintDebug
```

Init script меняет только output paths, не tests/gates/BuildConfig:

```groovy
allprojects {
    layout.buildDirectory.set(file('D:/VoxariumStudio/.voxarium_studio/temp/TASK-181/final-corrective-build/' + project.name))
}
```

| Финальный набор | Результат |
| --- | --- |
| Полный Gradle, включая packaging dependencies | **BUILD SUCCESSFUL, 1m34s, 60/60 actionable tasks executed** |
| Все native unit suites | **449 tests / 30 suites, 0 failures/errors/skipped** |
| Web typecheck + все web suites | **445 tests / 7 suites, 0 failed/skipped** |
| Web production bundle + оба smoke | **PASS**: ESM/DOM и APK page/bridge/theme/RU/format/flush |
| assembleDebug / lintDebug | **PASS**, lint **0 errors/fatal / 9 warnings** |
| Missing-report generated BuildConfig | **EDITOR_WRITES_ENABLED=false** |
| Независимый fingerprint по sorted POSIX path + NUL + raw bytes + NUL | Совпал с Gradle, **120 inputs** |
| Copy/original drift после финального прогона | **0** |

**Финальный sourceSha256:** `db6da4817b37dba48dc5dbe0abd6b23b4fb4c7cde8b249164f717260af685dce`.

JUnit skips равны нулю; обычные Gradle lifecycle NO-SOURCE/SKIPPED не являются исключением tests. Не применялись `-x`, test filters, cached PASS, подмена assets/DEX/BuildConfig или изменение пяти gates. Lint warnings — существующие dependency/SDK/network-security категории; compiler сообщает deprecated clipboard в tests, лишний cast и Gradle deprecated features.

Промежуточный полный build тоже прошёл, но snapshot отставал от последних правок: он **не принят вместо финального повторного прогона**. Первые harness attempts: UTF-8 BOM в init script и неполный скопированный node_modules; исправлены только temp harness/provisioning. Вспомогательный whitespace check отметил шесть новых пустых EOF строк в transport source/tests; функциональные проверки ими не подменялись.

## 4. Fault/identity matrix

Постоянные tests и независимые probes проверяют:

- interruption после каждого migration commit/phase и activation publication; reconstruction/resume без дублей и потери generation;
- disk-full, dropped write, readback mismatch, corrupt/unknown journal, malformed UTF-8, duplicate JSON/entries, numeric coercion, физически повреждённые Atomic cache envelopes;
- destination occupied/corrupt до prepare и после verified, включая missing-source mirror и чужой fresh live-room slot;
- byte-identical source base/.bak/.new до/после copy и activation; orphan/raw-only discovery без supplied hints, wrong-hash/unknown inventory refusal;
- same document path в разных URL/prefix/IDs/accounts/epochs, duplicate labels, ambiguous mappings archive-only;
- pending generation N плюс newer N+1, tombstones/conflicts/counters/provenance и отсутствие cross-target replay;
- stale verify/catalog/create replies, cancellation и same credentialId/new revision;
- TLS/hostname/auth failures, bounded UTF-8/gzip body, strict Android/libcore JSON preflight;
- redirect 301/302/303/307/308 и POST 408/503/421/401/407: **0 automatic POST replay**;
- old protocol unsupported без guessed catalog/WS fallback, unknown Create → original-ID GET → отдельный Select.

## 5. Настоящий Remote v2 + native TLS

Дополнительный root probe использует неизменённые production `create_app/Store/auth` Remote из VS-180, private synthetic SQLite, owned ephemeral loopback TLS listener под proxy prefix и настоящие native verifier/catalog. Test-only trust добавлен только для собственного CA; default production trust отдельно отвергает self-signed TLS.

```powershell
# Из D:/VoxariumStudio, после компиляции актуальных native HTTP sources:
$env:PYTHONDONTWRITEBYTECODE='1'
backend/.venv/Scripts/python.exe -B .voxarium_studio/temp/TASK-181/real-remote/run.py
```

Финальный повтор после UTF-8 correction: **1 JUnit PASS**, auth 401/default TLS refusal, verify/list/get/legacy resolve не создают проекты, explicit Create работает. Три одинаковые labels сохранили три разных ID/epoch. Всего **3 explicit POST**: успешный Create, Create с искусственным **503 после настоящего commit**, explicit conflict; повтор unknown не отправлен, GET original ID нашёл результат без Select. **0 WS, 0 document writes, 0 replay**; owned listener/thread закрыты.

Первый probe ошибочно сопоставлял mounted path без удаления proxy prefix и не включал post-commit fault; assertion честно упала. Исправлен только temp observer, не product semantics; финальный прогон проверяет действительное post-commit 503.

## 6. Независимые review и закрытые findings

**Storage/metadata review:** первый review нашёл 2 P1 (adoption чужого target cache при missing source mirror; corrupt cache как missing) и 2 P2 (неверный epoch validator; orphan inventory только по hints). Исправлены все четыре с постоянными regressions. Финальный независимый corrective review — **PASS, открытых конкретных дефектов нет**, source drift 0.

Независимо выполнены **189 permanent regressions** (A1 32 + A3 157, включая 54 Robolectric executions API23/35) и **16 acceptance probes**, из них 12 Robolectric API23/35: **205 executions, 0 failures/errors/ignored**. Новые probes требуют безопасного результата; зелёные первоначальные defect-canaries не засчитаны как acceptance.

**HTTP review:** P0–P2 не найдено. P3 неверной классификации malformed UTF-8 исправлен: CharacterCodingException → INVALID_RESPONSE до IOException; добавлен permanent regression. Corrective review — **PASS**, независимо **39/39 на JVM и 39/39 с настоящим Android/libcore JSON** из SDK sources (annotation stubs, без изменения JSON implementation), source drift 0. Проверены также настоящие Remote ASGI responses.

Команды независимых прогонов:

```powershell
backend/.venv/Scripts/python.exe -B .voxarium_studio/temp/TASK-181/review-storage/corrective/check.py
powershell -NoProfile -ExecutionPolicy Bypass -File .voxarium_studio/temp/TASK-181/review-http/probes.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .voxarium_studio/temp/TASK-181/review-http/android-probes.ps1
```

Counts разных наборов пересекаются и **не суммируются** с 449 native как уникальные tests. Direct reviewer compilation использует unchanged helper class dependencies; её дополняет полный чистый forced Gradle-прогон выше. Robolectric исполняет реальный AtomicFile/envelope code с Windows-host errno/lstat/rename shadows, не доказывает устройство/power-loss.

## 7. Gate, сохранность и остаток

Active `verification/editor-write-gate.json` оставлен byte-exact по требованию задачи. Старый report **не относится к новому fingerprint**. Negative control в disposable copy с копией старого report: `gradlew --no-daemon printEditorGateFingerprint` → **ожидаемый exit=1, acceptance stale/incomplete**. После проверки report убран только из copy. Обычную сборку исходного каталога нельзя объявлять принятой или обходить её отказ: отдельный A0/gate owner должен архивировать/отозвать прежнюю acceptance в своём scope, затем новая A7 приёмка.

Финальный hash audit: **646 protected original files unchanged**, включая все прежние verification/dist файлы, active report/evidence/APK и build/dependency inputs; новых файлов в старых verification/dist namespaces нет. Код Studio/Remote не редактировался. Новый verification APK существует только в disposable TASK-181, не публиковался и не устанавливался.

Raw logs/scripts/manifests/class directories/DB/certificates/source copies находятся в `D:/VoxariumStudio/.voxarium_studio/temp/TASK-181` и будут удалены Studio после Done. Существенные commands/counts/findings/fingerprint сохранены здесь; temp paths не являются постоянными release evidence. Исторические reports/APK не переписывались.

Остаётся **вне VS-181**:

1. A5: immutable live sessions, v2 frame/hello/presence integration, me.user==hello.user, epoch/seq rollback reconciliation, durable Create intent, retirement/Flush barriers и consumer-side fences. Текущие legacy callers совместимы, но это не готовый v2 UI/connect.
2. A6–A8: server/project/recovery UI EN/RU, version metadata, отдельная новая APK/device/upgrade acceptance и release artifact. Карточки для них этим запуском не создавались.
3. Настоящий upgrade без uninstall/clear data, OS process kill/power-loss, hardware Keystore/alias loss на устройстве, IME/TalkBack/OEM/provider matrix не запускались. JVM fault tests не повышены до этих гарантий.
4. Нет единого enabled APK + WebView + настоящий Remote/Studio E2E. Исторический Studio-only **INTEROP-01 остаётся FAIL_UPSTREAM**; он не исправлялся, не переименован в PASS/skip и не перезапускался этим foundation scope.
5. Virtual storage adapters обязаны предоставить полный inventory; Atomic app backend обнаруживает orphan rooms сам. Переход требует quiescence legacy writers и явного verified mapping; автоматический startup migration/connect не добавлен. V1 downgrade не гарантируется техническим marker: сначала отдельное сохранение v2 edits.

**Вывод:** A1–A4 готовы к последующей интеграции; это не общий Android/Remote rollout и не разрешение записи новым APK.
