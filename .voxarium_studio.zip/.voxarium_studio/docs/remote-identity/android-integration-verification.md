# Android integration A5+A6+A6v — проверка VS-182

## 1. Вердикт и границы

**17.11.2026: A5+A6+A6v завершены; независимый corrective review — PASS.** Основания: [[remote-identity/android-design]] (VS-90), принятый [[remote-identity/android-foundation-verification]] (VS-181), фактический Remote v2 VS-180 / [[remote-identity/server-admin-verification]]. Репозиторий: `D:/VoxariumRemoteAndroid`.

Это интеграция исходного кода и закрытая verification-сборка, **не A7/device acceptance, не публикация A8 и не разрешение записи новым APK**. `EDITOR_WRITES_ENABLED=false`; новый active report не создавался. Код Studio/Remote этой работой не изменялся, production и личные данные не затрагивались, Studio не запускался и не перезапускался. Новых карточек нет.

Локальные DATA/EDITOR/VERIFICATION, README/RELEASE и профильные исходники прочитаны. Локального/вложенного Android AGENTS.md и `D:/AGENTS.md` нет. Graphify был запрошен до поиска файлов; Android-specific индекс отсутствует, поэтому проверялся фактический отдельный репозиторий. Исторические README/RELEASE/VERIFICATION не переписаны: они описывают прежнюю поставку, а не этот кандидат.

## 2. A0 и сохранность

**До изменения covered source** сохранён `verification/identity-v1/baseline.json`: 747 исходных файлов с размером/SHA-256, включая app source, web source, build/dependency inputs, report/evidence/APK. Активный `verification/editor-write-gate.json` побайтно скопирован в `verification/identity-v1/prior-gate-vs84.json`, равенство проверено, затем удалён **только active path**.

SHA-256 прежнего report и его архива:
`f55f0f80cf6a5b05cc26844b1404abd88e59da88d0bb56aa2c87786146d54d06`.

Финальный аудит: **674 защищённых исходных файла без изменений**, в том числе **642 исторических verification/dist файла**; в старых evidence/dist пространствах новых файлов нет. Единственный отсутствующий baseline-файл — отозванный active report. Все изменённые/созданные project files входят в write scope; для адаптации реального Activity smoke явно добавлен `MainActivitySmokeTest.kt`. Password rotation/Back assertions сохранены.

Старый report проверен отрицательным контролем только в disposable copy: обычный `gradlew --no-daemon printEditorGateFingerprint` штатно отказал с **exit 1, acceptance stale/incomplete**. После проверки копия report удалена из temp, не возвращена в исходный active path. Parser, пять gates и зависимости не ослаблялись.

## 3. Что поставлено

### A5: identity, transport, partitions

- Production-соединение использует v2 me/sync, immutable URL + credential revision + account + project ID + storage_epoch. Exact `me.user.id == hello.user.id == expectedAccount`, ID и epoch проверяются до READY/Sync. Повторное подключение сохраняет исходную identity; 4400/4401/4404 и mismatch терминальны. Prefix, TLS/hostname, запрет redirects и bounded parsing сохранены.
- Legacy decoder оставлен для локальных fixtures/import. Двухаргументный legacy Connect отказывает без сети; **v1 WS/sync/create fallback отсутствует**. Foundation HTTP-only обнаружение старого protocol=1 остаётся лишь проверкой сервера с unsupported-каталогом, не способом подключить legacy space.
- Repository выбирает точную URL/ID/account/epoch partition. Effects содержат owner/generation и target namespace; старые callbacks и sends не переадресуются. Ошибочный select полностью закрывает event route.
- Rollback определяется не только по cursor, но и по максимальной durable cached revision: ACK/Change выше cursor не оставляют бесконечно сломанное зеркало. Сначала durable recovery pending/newer/подтверждённых высоких revisions, затем сброс mirror и Sync(0); validator rev>synced.seq сохранён. Старые hashes не дают преждевременного ACK/replay.
- Подготовленная migration reservation блокирует чтение staged journal даже при crash **до metadata**. Quiescence/Flush/ACK либо durable recovery предшествуют retirement. Activation — отдельное явное действие по проверенному mapping; после неё Select и Connect всё ещё отдельны. V1 источники не меняются.
- Metadata-профили импортируются без startup-сети. Offline archive доступен по точной исходной profile/account association без vault/network: mirror, pending N, newer draft N+1, recovery и raw-only room diagnostics с исходным provenance. Это read/copy, не восстановление Yjs и не активация.
- Durable Create intent с original ID сохраняется с fsync/readback **до POST**. Unknown переживает реконструкцию; разрешается GET исходного ID, без POST replay или auto-select. GET не разрешён во время ещё активного POST; после подтверждённого отсутствия возможен только новый явно подтверждённый Create. Найденный проект не объявляется доказанным результатом именно нашей попытки.
- Credential revision, captured UI generation и повторные worker-проверки ограждают Verify/catalog/key/migration/Select/Create/Connect. Последняя authenticated account association сохраняется: verified B не получает известный cache A через reselect/restart. Одинаковая immutable binding переиспользуется даже у лимита 1000 записей, но live owner всегда новый.

### A6 и A6v

- Material3 server/project/recovery screens EN/RU; **174 совпадающих resource keys**, одинаковые placeholders. Server form без space. Save local-only, Verify HTTP-only, Select, Create и Connect раздельны; exact ID/URL/account/epoch видны в подтверждениях. Duplicate labels не объединяются.
- Known/offline/unsupported/stale/unknown-create и identity/rollback состояния различаются. Исходный server/account/ID/epoch/path/generation/reason не подменяется текущим selection; все шесть recovery reasons сохранены. Raw-only честно отмечен, Copy недоступен без Markdown.
- Native masked key input не saveable/autofill, очищается до submission и при disposal/rotation/Back. Нет Bearer в JS, UI state, URL или диагностике.
- В `app/build.gradle.kts` изменены **только** `versionName=0.2.0`, `versionCode=2`. Обратная подстановка этих двух значений побайтно восстанавливает baseline hash. Package `com.voxarium.remote`, SDK и signing continuity сохранены.

## 4. Финальный полный прогон

Toolchain: Microsoft OpenJDK **21.0.8**, Gradle wrapper **8.14.7**, Kotlin **2.3.21**, Node **24.18.1**, npm **11.16.0**. Inputs/dependencies не обновлялись. Pinned npm dependencies установлены через `npm.cmd ci --ignore-scripts` только в task-private copy: 203 packages, audit 0 vulnerabilities.

Controlled source copy: `D:/VoxariumStudio/.voxarium_studio/temp/TASK-182/closed-copy`; без active report. Все 124 fingerprint inputs совпали с финальным оригиналом: **source-copy drift 0**. Gradle user home, project cache, outputs, web outputs, logs и temp находятся в TASK-182; существующий dependency cache использован read-only.

Фактически выполненная полная команда из closed-copy:

```powershell
$t='D:/VoxariumStudio/.voxarium_studio/temp/TASK-182'
$env:JAVA_HOME='C:/Program Files/Android/openjdk/jdk-21.0.8'
$env:GRADLE_USER_HOME="$t/gradle-home"
$env:GRADLE_RO_DEP_CACHE='C:/Users/AkaSd/.gradle/caches'
$env:TEMP=$t; $env:TMP=$t; $env:VOXARIUM_DOCUMENTS_TEST_TEMP=$t
./gradlew.bat --no-daemon --no-build-cache --rerun-tasks `
  --project-cache-dir "$t/project-cache" -I "$t/outputs.init.gradle" `
  "-PeditorBuildTemp=$t/web-build" `
  printEditorGateFingerprint assembleDebug testDebugUnitTest lintDebug
```

Init script меняет **только пути outputs**, не tests/gates/BuildConfig:

```groovy
allprojects {
    layout.buildDirectory.set(file('D:/VoxariumStudio/.voxarium_studio/temp/TASK-182/build/' + project.name))
}
```

| Набор | Финальный результат |
| --- | --- |
| Полный Gradle и packaging dependencies | **BUILD SUCCESSFUL, 1m46s, 60/60 actionable tasks executed** |
| Все native suites, включая Compose/Robolectric | **531 tests / 33 suites, 0 failures/errors/skipped** |
| Web typecheck и все web suites | **445 tests / 7 suites, 0 failed/skipped** |
| Web production build и оба bundle smoke | **PASS**, ESM/DOM и APK page/bridge/theme/RU/format/flush |
| assembleDebug / lintDebug | **PASS**, lint **0 errors/fatal, 9 warnings** |
| Generated BuildConfig | **EDITOR_WRITES_ENABLED=false** |
| Независимый fingerprint / Gradle fingerprint | Совпали, **124 inputs** |

Не применялись `-x`, selective tests, cached PASS или подмена assets/DEX/BuildConfig для этого полного прогона. Gradle lifecycle NO-SOURCE/SKIPPED не является пропуском JUnit. Девять lint warnings — прежние SDK/network-security/dependency категории; отдельное новое ModifierParameter warning исправлено. Deprecated clipboard/Gradle и unnecessary cast warnings не скрывались.

Финальный sourceSha256:
`41302de9d79f6a93b3b1800a5505d8e87a345d7375ffb1f31c42967cbc9b7bcc`.

Промежуточные сборки не приняты вместо финальной. Исправлены R-import ambiguity, тестовые ожидания async startup/lazy scroll/dialog Cancel и некорректная пустая legacy-journal fixture; безопасные assertions сохранены. Неполный logging native stderr в первом PowerShell harness также исправлен только в temp.

## 5. Fault/regression matrix и настоящий Remote v2

Постоянные tests покрывают exact account/ID/epoch/prefix, duplicate labels, stale me/hello/catalog/Create/key callbacks; same-counter effects разных repositories; pending N + newer N+1; late ACK/Disposed после switch; Flush/newest ACK и checkpoint failure; unknown Create reconstruction и in-flight GET race; migration interruption/readback/corruption/reservations; cached ACK/Change rollback с повторными storage faults/restart; отсутствие effects после отказавшего select; persistent different-account fence и binding reuse при 1000 metadata records.

UI/regression tests проверяют separate Save/Verify/Select/Create/Connect, отмену устаревших подтверждений, exact recovery copy/provenance/reasons/raw-only, EN/RU, small-screen 320×480/fontScale2, landscape и password rotation/Back. Это **Robolectric/Compose**, не физическое устройство/TalkBack/реальная IME-матрица.

Дополнительный финальный parent probe использует **неизменённый настоящий Remote v2**, synthetic SQLite, собственный ephemeral loopback TLS listener и prefix `/proxy`; test-only trust ограничен его сертификатом. Текущие production RemoteConnection/DocumentsRepository подключаются по очереди к двум одинаково названным проектам с одинаковым document path и разным exact content/epoch. Account mismatch, epoch mismatch, missing project и legacy connect завершаются без принятия чужого target.

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
./backend/.venv/Scripts/python.exe -B .voxarium_studio/temp/TASK-182/real-v2/run.py
```

**Финальный повтор: 1 JUnit PASS, exit 0**; исходящие client frames — ровно **2 Sync**, **0 PUT/DELETE/UPDATE/SEED/Create, 0 v1 routes**. Fixture setup выполнялся отдельно до наблюдения. Owned listener/thread закрыты, port-closed check PASS. Это отдельный filtered supplemental probe с собственным output directory и повторными web gates, **не замена полного 531-test packaging run и не APK/WebView E2E**. Ранее transport worker отдельно проверил настоящий v2 PUT/ACK и TLS refusal на synthetic fixture; эти counts не суммируются с финальным полным набором.

## 6. Независимые reviews и исправления

Первичные независимые reviews нашли **7 конкретных дефектов**; все закрыты с постоянными regressions:

| Finding | Исправление |
| --- | --- |
| F1, P2: staged journal до metadata обходил activation | Проверка строгой migration reservation до чтения partition |
| F2, P2: ACK revision выше cursor зацикливал rollback | High-watermark по durable revisions, recovery-before-reset, полный sync |
| F3, P3: callbacks после неудачного select давали synced | Публикация selection только после полного успешного load, закрытие route при отказе |
| RS-1, P1: verified B видел known cache A | Persisted и live account fences в native и UI, в том числе restart/reselect |
| RS-2, P2: старый key-form отменял выбор нового сервера | Captured generation, atomic request fences, повторная проверка до vault/после Flush |
| RS-3, P2: repeated Select исчерпывал 1000 bindings | Atomic reuse полного immutable tuple при сохранении нового live owner |
| RS-4, P3: legacy reason превращался в restart | Exact reason DTO и исчерпывающая EN/RU presentation mapping |

**Объединённый независимый corrective review: PASS, открытых конкретных P0–P3 blockers не найдено.** Reviewer заново скомпилировал текущие data/session источники, перечитал owning storage/migration/UI code и исполнил **253 tests: 237 permanent + 11 исходных reviewer probes + 5 новых adversarial probes; 0 failures/skips**. Исходный transport probe не изменён; session probe получил только передачу захваченного старого generation, без ослабления safe assertions. Дополнительно проверены malformed migration-record matrices, callbacks после отказов и повторные rollback storage faults. **Source drift 0/78**, EN/RU 174/174.

```powershell
./backend/.venv/Scripts/python.exe -B .voxarium_studio/temp/TASK-182/review-corrective/verify.py
# 248/248 PASS — permanent + исходные probes
./backend/.venv/Scripts/python.exe -B .voxarium_studio/temp/TASK-182/review-corrective/final-verify.py
# 253/253 PASS — расширенный независимый набор
```

Counts review пересекаются с 531 native и **не складываются как уникальные tests**. Review использовал Android compile stubs/неизменённые bridge type dependencies, поэтому не заменяет полный Gradle/Compose run родителя. MockWebServer teardown SocketException и uvicorn deprecation warnings сохранены; failures/skips и утечек owned listeners нет.

## 7. Verification APK, не релиз

Финальный APK существует только в TASK-182, не опубликован в dist и не установлен:

- Размер **12 940 008 bytes**, SHA-256 `986896898d70ce9ac9fc3e765d80b8594e1e713cea63cc783d9a1b2508f4ebe1`.
- `aapt dump badging`: package `com.voxarium.remote`, versionName **0.2.0**, versionCode **2**, min/target **23/36**.
- `apksigner verify --print-certs` PASS; certificate SHA-256 **`16528b9858590deb3bd458367cb2d62b85d59515801e95a6652200c0240c72eb`**, совпадает с прежним `dist/VoxariumRemoteAndroid-0.1.0-debug.apk`.
- Generated policy **false**, прежний accepted report не перенесён в active path. Signing continuity не выдана за выполненный upgrade на устройстве.

## 8. Остаток — не PASS и не часть завершённой VS-182

1. **A7–A8, новая device/upgrade acceptance, публикация artifact и write-enable отложены.** Для них нужен отдельный принятый source/evidence fingerprint и решение по gate; этот документ его не заменяет.
2. Нет единого enabled APK + WebView + настоящий Remote/Studio E2E. Hardware Keystore/alias loss, OS force-stop/power-loss, upgrade без uninstall/clear data, OEM/API/provider matrix, реальная IME и TalkBack этим этапом не проверены. Object reconstruction/fault injection не повышены до этих гарантий.
3. Исторический **INTEROP-01 остаётся FAIL_UPSTREAM**; Studio-only loss of spaces не исправлялся, не перезапускался и не переименован в PASS/skip. A5 identity changes не расширяют Markdown/editor acceptance.
4. Multi-process writers и safe downgrade старого APK не гарантируются. V1 источники сохранены; rollback/downgrade требует отдельного сохранения v2 edits. Recovery read/copy не является auto-merge/replay/overwrite, raw Yjs не восстанавливается автоматически.
5. Raw scripts/logs/copies/certificates/DB/builds/reviewer reports находятся в `D:/VoxariumStudio/.voxarium_studio/temp/TASK-182` и удаляются Studio после Done. Постоянные результаты — код/регрессионные tests, baseline/архив прежнего report и этот документ; disposable artifacts не объявлены release evidence.

**Итог: VS-182 готова к review/приёмке в своём scope; новая Android-поставка остаётся закрытой на запись до отдельного A7 решения.**
