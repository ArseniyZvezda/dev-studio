# VS-104 — диагностика workspace event-ordering

## Вывод и уровень доказательств

**Подтверждён механизм:** настоящий watcher первого проекта может поставить законный `explorer.file_changed` в его локальную FIFO-очередь во время `await open_project()`. Следующее строгое чтение тогда закономерно падает на `backend/tests/test_workspace.py:404`, не демонстрируя межпроектной утечки bus.

**Не установлен исторический файловый триггер VS-100.** `.voxarium_studio/temp/TASK-100`, wrapper и исходные logs уже отсутствуют. Доступен сохранённый shared document `remote-identity/foundation-reaudit.md`, но в нём нет `root`/`changes` падения. Нельзя доказать, что это именно readiness/fixture race, исключительно scheduler artifact или новая product regression. Нельзя приписывать FAIL исправлениям VS-96–VS-99.

Новая оболочка здесь — **diagnostic-only no-socket polling**, не восстановленный wrapper VS-100 и не обычный regression scheduler. Suite зелёным не объявляется.

## Текущий код и причинная цепочка

1. `backend/tests/conftest.py:235–240,267–274`: synthetic project — `tmp_path/game`; `ctx` полностью запускает настоящий `AppContext`. `studio_home:42–64` и agent home `:28–39` — соседние isolated каталоги, не реальные settings.
2. `backend/voxarium_studio/core/context.py:61–71`: каждому контексту принадлежат свой `EventBus` и watcher на этом же bus. `:193–201` запускает watcher до конца startup и фоновых plugin hooks. `explorer/watcher.py:97–101` только планирует задачу; readiness/quiescence handshake отсутствует. Это реальная структурная граница, **не доказательство**, что именно она сработала в VS-100.
3. `backend/tests/test_workspace.py:390–398`: подписки созданы до открытия второго проекта; `test.first` прочитан точно. `:399` ожидает создание/startup другого контекста, не останавливая первого watcher.
4. `core/workspace.py:128–139,171–176`: сначала `AppContext.create()`/`await startup()`, затем detach старого forwarding, очистка replay, attach нового. Весь этот await — окно для локальных файловых событий первого проекта.
5. `explorer/watcher.py:36–55,60–91`: разрешённые изменения превращаются в `explorer.file_changed` с `root` и `changes`. Публикует настоящий task `explorer-watcher`. `debounce=300`, `step=100` не менялись. Вложенный проект физически находится внутри watched tree родителя: его изменения видны родителю независимо от изоляции шин. Специсключения runtime применяются лишь при `parts[0] == .voxarium_studio` (`:47–51`), не к `event-isolation/.voxarium_studio/...`.
6. `ws/bus.py:129–139,64–76`: event предлагается всем локальным очередям FIFO; forwarding — отдельная последующая публикация. Очередь старой подписки не очищается переключением проекта. Поэтому `test.background`, опубликованный позже (`test_workspace.py:402`), стоит после уже поступившего watcher event и assertion `:404` падает.
7. `workspace.py:174` → `bus.py:142–144` очищает только replay history, не уже доставленную browser subscription queue. Если старый watcher успел до detach, строгие browser-assertions `test_workspace.py:406–410` тоже потенциально уязвимы. Это не означает, что background event был forwarded после detach.

## Controlled evidence и счётчики

Все вызовы сохраняют **исходное тело теста и все assertions**, настоящий watcher, его фильтр и настройки. Никаких xfail/skip, drain/filter очередей, отключения watcher или fake bus events нет. Observer wrappers только записывают publish/get и снимки очередей; вызывают исходные методы без изменения результата. Наблюдение добавляет timing overhead.

| Группа | Условия | Результат |
|---|---|---|
| `original-2`, `original-3`, `original-batch-10`, `original-repeat-8` | Исходный nodeid, стандартные fixtures; quantum 1 ms, 1 ms, 0.1 ms, 1 ms | **4 passed**, без watcher batches старого local bus |
| `current-original` | Исходный nodeid на финальных актуальных owners; quantum 10 ms; per-run source hashes | **1 passed**, без watcher batches старого local bus |
| `topology-control-2` | Неизменённая test function вызывается из disposable parametrized test; 2 обычных sibling targets, 2 намеренно nested targets | **2 passed / 2 failed**, оба FAIL точно `test_workspace.py:404`, `explorer.file_changed` вместо `test.background` |
| `topology-poll10` | Тот же controlled sibling/nested contrast, quantum 10 ms | **1 passed / 1 failed**, тот же assertion; watcher batches старого bus: **0 / 14** |
| `latency-0.001`, `latency-0.05` | 12 межпоточных callback samples на каждый quantum, без product scenario | **24 samples**; mean dispatch lag **12.07 / 58.65 ms**, ranges **11.29–12.57 / 55.74–60.21 ms** |

Всего завершённых вызовов исходного строгого сценария: **8 passed / 3 deliberately induced failed / 0 skipped**. Это диагностическая матрица, **не** 11 regression tests и не reproduction исторического payload VS-100. Имена `original-batch-10`/`original-repeat-8` не означают 10/8 executions: pytest дедуплицировал повторные nodeid даже с `--keep-duplicates`; JUnit подтверждает по одному case, они учтены только по одному.

### Точная controlled timeline (monotonic seconds)

`topology-poll10`, `nested0`:

- `197943.765`: исходный `other.mkdir()` создаёт `.../game/event-isolation`; точный `test.first` прочитан тестом из local bus **2566285475664** и browser bus **2566291435696**.
- `197944.109`: настоящий старый watcher публикует первый batch с `root=.../game`; пути включают `event-isolation`, `event-isolation/ignore.conf`, `event-isolation/.voxarium_studio/teams`. Далее — записи init/config/sample team/agent definitions внутри nested tree.
- `197952.390`: startup второго контекста завершён, browser получает `project.opened`; публикуются `test.background` (старый local bus) и `test.foreground` (новый local bus **2566291219248**).
- Снимок **до** публикации `test.background`: подписка **2566291436944** содержит **14** `explorer.file_changed`, `dropped=0`. Все остальные наблюдаемые local subscriber queues пусты, также `dropped=0`.
- В том же task **Task-76** и той же подписке исходный следующий `get()` возвращает `explorer.file_changed`, assertion `:404` падает. Publisher — старый настоящий watcher, root старого проекта: **не доставка с нового bus в старый**.

В `topology-control-2` nested0/nested1 получены соответственно **15/16** old-local watcher batches; в обоих sibling controls — **0**. В controlled probe изменена только переданная temporary topology: `tmp_path=ctx.paths.root` вместо обычного `tmp_path`. Это **намеренный дополнительный FS input**, которого нет в стандартном fixture (`other` там сосед `game`). Не переносить этот триггер на VS-100 без его payload.

Полные payload/stack/timestamps/очереди: `*/trace.json`; outcomes: `*/junit.xml`; аргументы: `*/command.json`; сводка: `results.json`, `results.log`.

## Отделение трёх гипотез

### Product regression / foundations

Исследуемое тело теста и watcher уже присутствуют в commit `fec1e648060af651fd69a53966faf5e31fe8beef` от **2026-11-04** (HEAD test lines 316–353, сейчас 386–423). Watcher, `context.py` и `tests/conftest.py` не имеют diff к HEAD. Текущий bus diff не меняет `publish`/FIFO/forwarding. Текущий workspace diff добавляет registry/descriptors/desktop observers и дополнительные задачи/DB reads; это может изменить interleavings, но не является доказательством неправильной доставки.

Foundation identity creation выполняется до подписок для первого fixture и в отдельном sibling tree для второго. VS-96 redaction, VS-97 global-profile preservation, VS-98/99 read-only migration diagnostics не объясняют сами по себе запись в watched root первого проекта. **Прямой причинной связи нет; изменение timing не исключено.** История показывает предсуществующую уязвимость test assumption, но не доказывает воспроизводившийся baseline FAIL.

### Watcher / fixture race

Строгое ожидание только synthetic event на шине с независимым настоящим producer требует доказанного отсутствия его FS input. Такого контракта/barrier в тесте нет. Controlled trace доказал весь механизм при реальном разрешённом FS input. Стандартные fixtures в новой оболочке **не воспроизвели** историческое падение; неизвестно, какие raw paths стояли за ним. Существующая readiness-граница и потенциально фоновые fixture/plugin writers — кандидаты, не установленный исторический триггер.

### No-socket scheduler artifact

Базовый stdlib: `C:\Users\AkaSd\AppData\Roaming\uv\python\cpython-3.12-windows-x86_64-none\Lib`, Python **3.12.13**.

- `asyncio/windows_events.py:893–901,313–321` выбирает/создаёт Proactor loop.
- `asyncio/proactor_events.py:632–643,785–790` безусловно создаёт `socket.socketpair()`; `:792–831` использует socket wakeup. Штатный Selector loop тоже делает socketpair (`selector_events.py:59–66,118–124`). Windows fallback `socket.py:611–627` использует TCP listener/bind/listen/connect/accept. **Обычный scheduler нельзя запустить в рамках запрета; он не запускался.** Никаких loopback exceptions или замены запрета private server нет.
- `watchfiles/main.py:257–266` возвращает native watch result через AnyIO worker; `anyio/_backends/_asyncio.py:1100–1109` ставит callback через `call_soon_threadsafe`; `asyncio/base_events.py:842–850` обычно будит loop socket self-pipe.
- Здесь disposable `NoSocketLoop` вообще не создаёт self-pipe sockets, signal fd остаётся -1; self-reading/wakeup не делает IO. IOCP select имеет конечный quantum. Иначе callback мог бы ждать постороннего таймера бесконечно. Не менялись watchfiles backend, debounce/step, product event handling или validation.
- Callback measurement показывает реальную scheduler-dependent задержку; nominal quantum не является реальным upper bound Windows latency. Это меняет продолжительность `open_project()` и шанс доставки watcher event до assertion. Но scheduler **не создаёт FS input**. В двух quantum nested probes подтверждены реальные watched writes; следовательно, controlled failure — не просто выдуманное scheduler событие. Какую долю исторического flake дал прежний scheduler, неизвестно.

## Минимальная рекомендация для отдельной задачи

Не менять product forwarding и не ослаблять тест по одному `:404` FAIL. Первым шагом сохранить пассивный диагностический payload `root`, `changes`, local/browser bus identities, subscription seq/backlog и запись/готовность watcher вокруг `await open_project()`; воспроизвести исходные fixtures, а при отдельно разрешённом socketpair — сравнить normal scheduler. Текущий запрет здесь не обходить.

Если payload подтвердит fixture/startup writes, минимальное исправление — **явная граница завершения известных fixture writers и наблюдаемого watcher/startup barrier перед созданием tested subscriptions**, плюс гарантированно неперекрывающиеся synthetic project/home/temp roots. Сам watcher оставить живым. Все точные локальные/browser/replay assertions сохранить; никаких фильтров/дренирования/произвольного sleep вместо handshake. Контракт такого barrier надо определить по фактическому writer, а не вводить глобальный «файлов больше не будет». Если payload окажется от другого bus/root, расследовать product scope bug отдельно.

## Изоляция, сторонние изменения и границы

- `probe.py`, `test_control.py`, `scheduler_latency.py`, `summarize.py` и все outputs находятся только в **TASK-104**. `HOME`, `USERPROFILE`, APPDATA/LOCALAPPDATA, TEMP/TMP, Studio/agent/XDG homes перенаправлены под каждый run. Bytecode/cache выключены; никакого сервера/TestClient/network transport сценарий не требует. Реальные настройки/ключи/данные не использовались; restart/deploy/install/build/EXE/APK и новый sync не выполнялись.
- До импорта test modules и создания loops установлен fail-closed Python audit guard: запрещены все `socket.*` audit operations и subprocess launch; записи разрешены только внутри TASK-104. По каждому завершённому scenario run: **0 socket creation/bind/connect/listener/DNS attempts**, но guard **запретил** один import-time `socket.gethostname` и один git metadata `subprocess.Popen`. В latency runs — один запрещённый import-time gethostname на процесс; успешных операций нет. Не скрывать эти denied attempts под формулировкой «0 сетевых попыток».
- Python audit не является OS/native sandbox; Rust watcher используется только для локального filesystem, тестовые external launch points штатно заглушены existing autouse fixtures, process launch fail-closed. Нативная реализация `.pyd` не переписана и не аттестована как sandbox.
- Начальный integrity snapshot: **262 backend Python files**. В ходе работы внешняя параллельная задача изменила `core/project.py`, `tests/test_api.py`, `tests/test_project_open_validation.py`; наши guards не допускают запись туда. Текущий `core/project.py:139–143` теперь добавляет read-only validation перед init writes. Остальные **259** первоначально снятых файлов совпали; шесть непосредственных owners (test_workspace/conftest/context/workspace/watcher/bus) имеют **побайтно идентичный binary diff до/после** (`owners-before.diff`, `owners-after.diff`, SHA256 `C944A4DB6BE5F9E35073A52863343A397D1328F53E731EC488FD5DD07F20350C`). Чужие изменения не откатывались. `current-original/owners-{before,after}.json` отдельно фиксируют финальный запуск на актуальном коде.
- Отладочные runs сохранены, но не включены в product counters: `original-1` остановлен write guard на pytest log target `\\.\nul` (затем лог перенаправлен в temp); `topology-control` — **4 setup errors**, поскольку внешний temporary test не подобрал backend asyncio auto config (затем явно задан `-c backend/pyproject.toml`). Они не переименованы в product FAIL и не удалены.
- Независимо прочитаны оба Studio subagent results: source/history audit и scheduler boundary review. Они ничего не запускали и не меняли. Полный suite и обычный Windows scheduler не проверены; исходный historical trigger остаётся неопределённым.

## Воспроизведение новых probes

Из `D:\VoxariumStudio`, только disposable outputs:

```powershell
$env:VS104_LABEL='new-original'
$env:VS104_POLL='0.01'
Remove-Item Env:\VS104_CONTROL -ErrorAction SilentlyContinue
.\backend\.venv\Scripts\python.exe -B .\.voxarium_studio\temp\TASK-104\probe.py

$env:VS104_LABEL='new-control'
$env:VS104_CONTROL='1'
.\backend\.venv\Scripts\python.exe -B .\.voxarium_studio\temp\TASK-104\probe.py `
  'D:\VoxariumStudio\.voxarium_studio\temp\TASK-104\test_control.py'
```

Использовать новые labels: pytest basetemp очищается runner'ом. Существующие evidence не перезаписывать. Отчёт disposable: если нужен после Done, reviewer должен перенести его разрешённым отдельным действием; эта задача не пишет shared docs.



## Приёмка Producer

Принято как завершённая read-only диагностика VS-104, не как исправление workspace или чистая приёмка S1/S2. Producer сверил текущие assertions, watcher/FIFO implementation, controlled topology, recorded traces и одинаковые SHA256 owners-before/after. Исторический trigger VS-100 не установлен; normal scheduler не проверен. Связанные документы: [[remote-identity/foundation-reaudit]], [[remote-identity/studio-design]].
