# VS-177 — проверка runtime integration

16.11.2026. **Частичный результат; этап «Разделить серверы и проекты в Studio» НЕ завершён.** P1 G и локальный ID edit исправлены; сетевые I9–I16 не выпущены. Основание: [[remote-identity/studio-design]], [[remote-identity/runtime-integration-plan]], [[remote-identity/delivery-authorization]], [[remote-identity/i8-editor-proof]]. Исторический открытый P1 из [[remote-identity/i13-local-id-verification]] заменён результатом [[remote-identity/id-edit-delivery-verification]].

## 1. Что изменено и что сохранено

- Backend G теперь неслучайный safe integer 0…2^53−1, монотонный внутри backend_epoch. Drain = captured oldG+1, commit = oldG+2; overflow отказывает до quiesce/drain. Старый journal/receipt не seed/relabel нового lifetime и не перематывает RAM G.
- Frontend сохраняет safe-integer/монотонные/epoch guards; Prepare отправляет captured backend_epoch. Success требует полного exact committed receipt и согласованного store refresh. Нет latest-G repair, автоматического retry, перепривязки renderer или editor ACK из формы.
- Partial VS-176 переиспользован. Локальный ID edit EN/RU проходит prepare/barrier/ACK/commit disabled, с честными cancel/409/blockers/unknown outcome. После restart новый renderer может явно попытаться выполнить offline ID edit только при disabled/idle blocked observation без room/pending/change/reason; старый renderer с epoch latch требует reload. Это не разрешение Select/Enable и не обход backend recovery/CAS.
- Подготовлен project UI явных catalog/Create/Select/read-only Preview на существующих typed clients. Create сохраняет operation continuity и не Select/Enable; отсутствующий production API даёт честный unavailable. Enable остаётся явно disabled. В проектной форме нет URL-bound key/password; глобальная форма поясняет L-gate.
- Bounded I14: после profile CAS/recheck и durable journal, до credential publication affected exact profile+URL confirmed rows демотируются в selected через существующий transaction-aware binding writer. Root/ID/revision/incarnation и чужие строки сохраняются; project files не редактируются. Partial failure/recovery никогда не восстанавливает confirmed. ENV не удаляется, binding не становится unbound.
- Runtime release guards не сняты: main/service/protocol/context не переведены на v2. L остаётся unknown; новая demotion не разрешает sensitive mutations и не является positive drain.
- Исправлены устаревшие test harness expectations после C9: POST Create/observe — реальные маршруты, не 405; startup stub учитывает failed-context inventory. Два standalone harness принимают test-only VOXARIUM_STUDIO_TEST_TASK_TEMP с сохранённым containment guard. Это не подмена capability/security evidence.

Большой исходный чужой diff сохранён. Изменения в уже модифицированном test_application_settings.py ограничены assertion нового global metadata POST и его secret-free response. Коммит shared worktree не выполнялся.

## 2. Сохранность документов и namespaces

Новый test_remote_id_edit_delivery.py использует реальные AppContext/DocStore/lifecycle/config/journal/HTTP; offline drain не заменён Remote mocks. Проверены Markdown bytes/mtime, включая не-ASCII/CRLF; clean open/lease/ACK без writes; неизменные paths, descriptor/runtime epoch, MCP и jobs/services objects. Cancel/errors сохраняют corpus, late captured G/epoch не сохраняют под новым target. Old checkpoint не превращается в базу нового ID.

Повторены paired настоящие DocsView/BlockEditor/Y.Doc из I8: clean peers — 0 PUT; non-scribe ждёт final scribe save; dirty/cancel/late callbacks и pathless lease DELETE сохраняют source/DOM. Их HTTP/Yjs relay синтетический; это frontend owner evidence, не настоящий v2 interop. Независимый reviewer отдельно проверил последнее I8 pathless исправление из [[remote-identity/i8-editor-verification]].

## 3. Среда и воспроизводимые команды

Все команды выполнялись в checkout D:/VoxariumStudio. Backend interpreter — backend/.venv/Scripts/python.exe; установлен editable voxarium_studio_remote 0.1.0 из D:/VoxariumStudio/remote, pycrdt доступен в той же environment. Никакой importorskip вместо отсутствующего v2 fixture не добавлен. Числа ниже пересекаются; их нельзя суммировать как количество уникальных тестов.

Disposable baselines/scripts/probes/logs/XML/JSON/cache — только .voxarium_studio/temp/TASK-177. PYTHONDONTWRITEBYTECODE либо task-private pycache заданы тестовым командам. Каждому pytest прогону выделен отдельный basetemp. Standalone блок запускается отдельным процессом с отключённым autoload, не вместо нормальных suites.

### Backend G / ID / barrier / реальный legacy interop

Из корня:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
backend/.venv/Scripts/python.exe -m pytest -n0 -p no:cacheprovider --basetemp=.voxarium_studio/temp/TASK-177/id-edit-backend/pytest-final3 backend/tests/test_remote_id_edit_delivery.py backend/tests/test_remote_transitions.py backend/tests/test_remote_binding_drain.py backend/tests/test_remote_editor_leases.py backend/tests/test_remote_mutation_gate.py backend/tests/test_remote_runtime_binding.py backend/tests/test_remote_bindings.py backend/tests/test_remote_sync.py -q
```

**743 passed, 0 skipped/errors/failed.** В новом delivery module 15 tests; отдельно добавлены generation/overflow regressions. test_remote_sync.py также отдельно: **21 passed, 0 skipped**, настоящий v1 Remote и два legacy Studios в одном event loop. Это test-owned ephemeral loopback Remote, не второй backend Studio и не v2 acceptance.

### Catalog/runtime/security regressions

Из backend/:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$tests = @(Get-ChildItem tests/test_remote_catalog*.py | Where-Object { $_.Name -notin @('test_remote_catalog_metadata.py','test_remote_catalog_runtime.py') } | ForEach-Object { $_.FullName })
.venv/Scripts/python.exe -m pytest @tests -q -n2 -p no:cacheprovider --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/pcf --junitxml=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/catalog-final.xml
```

**2875 passed, 0 skipped/errors/failed.** Включён новый test_installed_remote_v1_verifies_but_cannot_release_r3: реальный установленный Remote ASGI app/store/auth, настоящий Studio profile provider/HTTP parser/lifecycle, заменён только сетевой hop. Verify достоверно возвращает protocol=1/catalog_unavailable; последующие production catalog/Create отказали до дополнительного key lookup, journal/remote requests. Remote space не создан.

Отдельные standalone harness (каждый отдельной командой из backend/):

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
$env:VOXARIUM_STUDIO_TEST_TASK_TEMP='D:/VoxariumStudio/.voxarium_studio/temp/TASK-177'
.venv/Scripts/python.exe -m pytest --noconftest -o addopts= -p no:cacheprovider tests/test_remote_catalog_metadata.py -q --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/pmd
.venv/Scripts/python.exe -m pytest --noconftest -o addopts= -p no:cacheprovider tests/test_remote_catalog_runtime.py -q --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/prt
```

**167 passed** и **52 passed**, 0 skipped/failed/errors. Их original synthetic import/I/O guards сохранены.

### Consent и глобальная metadata

Из backend/, нормальный plugin autoload:

```powershell
.venv/Scripts/python.exe -B -m pytest tests/test_remote_profile_lifecycle.py tests/test_remote_profile_mutation_api.py tests/test_remote_bindings.py tests/test_remote_profile_labels.py -q -n0 -p no:cacheprovider --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/i14-consent/pytest-verified
.venv/Scripts/python.exe -B -m pytest tests/test_application_settings.py -q -n0 -p no:cacheprovider --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/pas
```

**955 passed** и **84 passed**, 0 skipped/failed/errors. I14 subset: **25 passed, 373 intentionally deselected**. Положительные mutation fixtures явно synthetic: проверяют порядок durable fence/demotion/key, fault/restart/ENV, retained bindings и один config OS lock; не доказывают L или online drain.

### Frontend / paired editors / build

Из frontend/:

```powershell
npm test -- src/views/DocsView.spec.ts src/lib/collab/editor.spec.ts src/lib/collab/session.spec.ts src/stores/docs.spec.ts --reporter=default --reporter=json --outputFile=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/paired-editors.json
npm test -- --reporter=default --reporter=json --outputFile=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/frontend-final.json
npm run typecheck
npm run build
```

Paired/editor set — **355 passed, 0 skipped**. Финальный весь frontend — **5557 passed, 109 файлов, 0 failed/skipped/pending**. Typecheck/build — **PASS**. Generated static получен штатным build, вручную не редактировался; это не доказательство обновления установленной/работающей Studio.

Остались предупреждения pytest asyncio loop scope/deprecated fixture; standalone без asyncio plugin предупреждает о неиспользуемом asyncio_mode. Vite предупреждает о native config JSON import, chunk size и ineffective dynamic import; полный frontend печатает прежние Vue Router warnings. Итоговых test failures в перечисленных финальных прогонах нет.

## 4. Независимый review и неудачные промежуточные прогоны

Независимый read-only worker проверил G/ID/receipt/store, consent ordering, I8 pathless release и реальные v1 gates. Backend повторный набор — **597 passed, 0 skipped**; frontend owner set — **336 passed, 6 файлов, 0 skipped**; отдельные backend restart ASGI и fresh-renderer UI probes — по **1 passed**. Scoped code verdict — **PASS**, full release — **NO-GO**. Финальная независимая delta-проверка captured epoch, offline-ID/Select separation и test harness — **PASS**; новых P1/P2 после corrective проверки не найдено. Scoped git diff --check и AST parsing 12 Python files — PASS.

Первый широкий catalog прогон: 2867 passed, 8 failed, 219 setup errors. Причины: запущенные вместе standalone harness требовали чужие TASK-122/140 temp, obsolete mount expectations и failed-context stub; после точечных corrections и раздельного standalone запуска финальные 2875+167+52 выше зелёные. Один первоначальный profile/application прогон: 703 passed/1 obsolete POST assertion; исправлен, application suite84 зелёный. При добавлении captured epoch две exact frontend mock-body expectations потребовали обновления; полный повтор5557 зелёный. G-test teardown после намеренной journal corruption исправлен до финального743.

В первом independent combined наборе был единичный отказ test_i14_synthetic_http_private_failure_is_redacted_and_precedes_key; отдельно, mutation module230, lifecycle+test169 и полный повтор597 зелёные. Причина пока не установлена; не выдаём повторный PASS за объяснение flake.

### Финальная corrective delta

Reviewer воспроизвёл отдельный P2 harness order-risk: mount real-project-selection → два application-settings tests давали 1 passed/2 failed с mcp.types import-state error; широкий I14-single+mount+application набор давал 410 passed/2 failed. Исправление ограничено одним mount test: vocabulary config.permission_modes явно использует существующий offline fallback до init_project, чтобы unrelated SDK discovery не выполнялся под blanket socket/process guards. Snapshot sys.modules до/после утверждает отсутствие SDK/MCP import pollution; реальные config validation/AppContext/workspace/catalog/auth и запреты I/O сохранены.

Независимый повтор минимального reproducer — **3 passed, 0 skipped**; итоговый corrective code/harness verdict — **PASS**, release — **NO-GO**. Родитель повторил тот же порядок и финальный полный affected harness:

```powershell
# backend/
.venv/Scripts/python.exe -B -m pytest -n0 -q tests/test_remote_profile_mutation_api.py::test_i14_synthetic_http_private_failure_is_redacted_and_precedes_key tests/test_remote_catalog_mount.py tests/test_application_settings.py --basetemp=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/pcombined -p no:cacheprovider --junitxml=D:/VoxariumStudio/.voxarium_studio/temp/TASK-177/combined.xml
```

**412 passed, 0 skipped/failed/errors.** Исходный I14 transient дополнительно прошёл в трёх независимых isolated процессах (1 passed × 3) и combined; его первоначальная причина остаётся неизвестной. MCP corrective fix не объявляется объяснением этого отдельного transient. Ни skip/xfail, ни runtime gate bypass для зелёного результата не добавлены.

## 5. Незакрытые prerequisites и остаток этой же карточки

| Срез | Текущее положение |
| --- | --- |
| I6/I7 G, локальный ID edit I13 | Исправлены и проверены в указанном local scope |
| I8 | Готовый owner переиспользован/повторно проверен; production online gate не снят |
| I9 catalog/exact Select | Production _UnavailableOutbound и absent Create transport сохранены до принятого R3; holder snapshot/resolve/exact facades ещё не подключены |
| I10 runner | protocol1 и legacy SyncState сохранены; v2 hello/account/ID/storage_epoch/cursor/reconnect runner ещё не подключён |
| I11/I12 Preview/Enable | Production handlers и CAS/crash matrix ещё не реализованы; UI не объявляет их доступными |
| I13 network UX | Подготовлен component/client flow с честными refusals; не поставка production Select/Create/Preview/Enable |
| I14 | Только consent demotion/fault/recovery добавлены; bounded exact-consumer/G proof→C5, positive drain и L не закрыты |
| I15 | Существующий strict read-only diagnostic сохранён; explicit profile/resolve/apply и checkpoint migration не подключены |
| I16 | Local/paired/real v1 legacy checks выполнены; свежий v2 two-root/editor/restart slice отсутствует |

Конкретные внешние blockers проверены после Graphify по текущим owning sources, а не по старым PASS:
- Remote app/protocol/store/hub всё ещё v1: только health, v1 me и v1 sync. Hub.connect → Store.space автоматически создаёт неизвестный space. Нет R1–R3 migrations/exact catalog, explicit Create, strict-connect, snapshot epoch/seq pagination и exact legacy resolution. Установленный package не решает это.
- Отдельный server credential-generation gate не реализован: store не хранит credential_version, watcher проверяет только is_active; rotate не гарантирует отзыв старого WS. Catalog health/мocks не являются заменой входящему и исходящему frame guard.
- Production ProfileLifecycle не имеет положительного legacy completeness owner L. Empty private store/recents/закрытые tabs/одна предъявленная root не дают такого доказательства; это блокирует и первый ввод ключа нового профиля. Нельзя подставить known/drained=True.
- Нужны принятые R1→R2→R3 и security, положительное owning L evidence, затем завершение Studio I9–I16 и настоящий не-skipped v2 interop. Remote/Admin/Android/AI в этой карточке не редактировались. Новых карточек не создано: продолжение остаётся в VS-177.

Реальные personal config/ключи и production roots не читались/не изменялись. User Studio/jobs не прерывались; run.cmd/remote_test не запускались. Browser/native smoke и production backup/rollback migration не выполнены: нет готового v2 prerequisite и нельзя подменять его старым launcher. Reviewer требуется принять внешние prerequisites/маршрут их поставки и вернуть эту же карточку для оставшейся интеграции; общее рутинное разрешение повторно не требуется.
