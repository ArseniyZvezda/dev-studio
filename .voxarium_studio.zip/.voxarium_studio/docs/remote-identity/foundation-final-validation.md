# VS-105 — итоговая read-only проверка foundations S1/S2

15.11.2026. Checkout `f84cf0d9838e46b7f58e357331dbc3ef38685f9b`, существующий общий dirty diff. Основания: [[remote-identity/studio-design]] §3–4, §11/S1–S2; [[remote-identity/foundation-reaudit]]; [[remote-identity/workspace-diagnosis]]; текущие владельцы и regression tests после VS-101–103. Graphify выполнен первым; индекс использован для навигации, не вместо актуальных исходников. Карточки VS-101–104 прочитаны.

## Вердикт

**Исходные F1–F4: 9/9 PASS. Исходные A–C: PASS в указанных ниже границах. Это не чистая приёмка всех S1/S2:** дополнительные строгие ожидания выявили **два дефекта (E1/E2), девять FAIL**. Они не исправлялись, assertions не ослаблялись. Не установлено, что эти дополнительные условия внесены VS-101–103.

Неизменный workspace-сценарий: **3/3 PASS** с настоящим watcher, без новых filter/drain/skip/xfail/sleep. Это результат диагностического no-socket scheduler, **не исправление исторического flake** и не проверка штатного Windows scheduler. Историческая причина VS-100 остаётся неизвестной.

## Матрица исходных девяти repro

Отдельный disposable `test_original_matrix.py`, группа `original-nine`: **9 passed / 0 failed / 0 skipped**. Все данные synthetic; фиксация HTTP и сохранности config/home/live state выполняется настоящим in-process приложением, не сервером.

| Случай | Результат | Проверено сверх статуса |
| --- | --- | --- |
| F1-1 PUT `/api/settings`, `{token: marker}` | PASS, 422 | Фиксированный safe envelope, без marker; config/home/live state без изменений, sync off |
| F1-2 тот же PUT, `{sync:{token:marker}}` | PASS, 422 | То же |
| F1-3 PUT `/api/settings/application`, `{remote_servers:[{token:marker}]}` | PASS, 422 | То же |
| F1-4 PUT `/api/projects/{runtime}/settings`, `{token:marker}` | PASS, 422 | Runtime descriptor получен реальным in-process open; то же |
| F1-5 stored `project_identity.token`, POST `/api/projects/open`, `create=false` | PASS, safe 400 | Target создан с `with_samples=False`; дерево/mtime, home, incumbent/registry без изменений; startup не вызван |
| F1-6 тот же stored extra, POST `/api/settings/reload` | PASS, safe 400 | Конфиг и live state прежние; sync.reconfigure не вызван |
| F2 `future_section.future_flag`, `theme.future_theme_flag`, `language:ru` + profile create | PASS | Все исходные значения сохранены, profile metadata добавлена отдельно |
| F3 `theme.text_size=99`, существующий isolated global config, валидная identity | PASS | `identity_present/good-id`, SHA256 исходных bytes, никаких записей |
| F4 два `project_identity` first/second | PASS | `invalid_config`, ID отсутствует, fingerprint исходных bytes, никаких записей |

Safe 422: `{"detail":[{"type":"value_error","loc":["body"],"msg":"Invalid settings request."}]}`. Safe 400: `{"detail":"Invalid project configuration."}`.

## A–C и совместимость поверхностей

| Граница | Статус | Основание и предел |
| --- | --- | --- |
| A: шесть nested unknown + valid sibling | PASS | Отдельная шестёрка внутри `test_settings_nested_validation.py`; 422 до persistence/reconfiguration, sibling не применяется |
| Все разрешённые nested DTO, включая `teams.prompts` | PASS | Extra forbid на API-моделях; hostile names, bounds/types/validators; valid partial updates и arbitrary keys в `custom_tokens` сохранены |
| B: invalid identity до init/open/bootstrap записей | PASS | 52 regression cases: no-samples/config-only/old-ignore/legacy, с/без preferences, оба open; snapshots empty dirs/bytes/mtime, incumbent/registry/sync |
| B: прямой invalid `init_project(...,with_samples=False)` и HTTP `create=true` | PASS | Два дополнительных independent probes; все snapshots прежние |
| C: проверенные YAML/Unicode/read-error families (без E1) | PASS | 49 cases: 48 сочетаний entry/read failure/home + повторный plan; LogRecord.msg/args/dict/exception fields и caplog без input; фиксированная категория, bytes/home неизменны |
| Identity/profiles/application/project/scoped isolation | PASS | Targeted existing suites + combined probe: synthetic credential и opaque canary отсутствуют в legacy/scoped project/settings/status/migration, application GET не раскрывает secret/opaque; project save не меняет home и не переносит profile_id/globals |
| Новый remote catalog | PASS, read-only inspection | OpenAPI содержит только два новых GET migration, оба `no-store`; mutation endpoints не вызывались |
| E1: YAML constructor error как безопасный diagnostic/fallback | FAIL | Три неослабленных ожидания, подробности ниже |
| E2: локальные profile labels по design §3.1 | FAIL | Create/rename: trim, 121 chars, newline — шесть FAIL; 120 Unicode chars — два PASS |
| Stock Windows scheduler, xdist, весь продукт, live sync/v2/UI/cutover | Не проверено | Не входит в эту проверку; штатный scheduler требует запрещённого socketpair |

Текущие owners: `api/project.py:52–146` — strict request DTO, `:389–460` — valid partial merges/save; `main.py:114–125` — fixed settings error handler. Disk-модели намеренно permissive, не заменены API-классами. `core/project.py:139–148` валидирует inspection config до rename/mkdir/ignore/sample writes; `core/config.py:561–580` проверяет identity до возможной preference migration. Resident reopen (`workspace.py:124–126`) переиспользует контекст и не перечитывает диск: B не означает повторную disk validation любого reopen; для ручной правки есть reload.

`core/application_config.py:61–68,202–218,252–289` разделяет opaque raw document/public DTO и profile/preference writers; `sync/profiles.py:19–22,81–116` использует именно profile writer. F2 покрывается также lifecycle/recovery/stale saves в `test_application_settings.py:803–967`. `core/project_identity.py:120–158` сохраняет raw-byte fingerprint до scope filtering; `_PlanConfigLoader:67–106` отвергает duplicate/overlapping merges/cycles. Общий `load_config` остаётся last-wins YAML: это не тотальная приёмка YAML parser. `core/config.py:591–599` логирует только trusted path и fixed error category, без exception input/traceback.

## E1 — дополнительный неперехваченный YAML constructor ValueError

Synthetic config:

```yaml
project_identity: {id: good-id, revision: 1}
unused: 2026-13-01
```

PyYAML распознаёт timestamp и вызывает `datetime.date`, выбрасывая `ValueError: month must be in 1..12` (`yaml/constructor.py:322–330`). `core/project_identity.py:130–135` ловит Unicode/YAML/Recursion, но не этот constructor ValueError; `core/config.py:590–591` также его пропускает.

`test_constructor_edge.py`, **0 passed / 3 failed / 0 skipped**:

- `plan`: вместо `invalid_config/no ID` выходит ValueError.
- `load`: вместо read fallback выходит тот же ValueError.
- GET `/api/remote/migration`: **500 Internal Server Error**, а не diagnostic 200/invalid_config. `raise_server_exceptions=False` только даёт наблюдать реальный HTTP 500, не подменяет приложение.

Config/home non-runtime files и их mtime сохранены через finally-snapshots; runtime SQLite-файлы отдельно не входят в этот read-diagnostic snapshot. Это не установленная утечка canary и не повтор исходных F3/F4/C. Для отдельной коррекции: охватить constructor errors узко на YAML parse-boundary; не поглощать Pydantic identity validation широким fallback вокруг всего `load_config`, иначе можно вернуть B. Общую YAML семантику без отдельного решения не менять.

## E2 — локальные имена профилей не соответствуют согласованному design

`studio-design.md:60` требует trim, 1–120 Unicode-символов и отсутствие controls для **локального** profile label; это не серверные NFC/480-byte правила. `core/application_config.py:76,91–96` допускает 200, проверяет `.strip()` лишь на непустоту и возвращает исходное имя; `sync/profiles.py:88–116` передаёт его напрямую в create/rename. Staged-исключение для этой модели не задокументировано: dev spec §5.2.1 ссылается на design, но не разрешает ослабленную validation.

`test_profile_labels.py`, **2 passed / 6 failed / 0 skipped**: отдельно create и rename сохраняют `"  Team  "` вместо `"Team"`, принимают 121 ASCII-символ и `"Team\nInjected"`. Оба positive controls с 120 кириллическими символами PASS. Это внутренний S2 contract/validation defect, не public mutation bypass и не доказательство утечки ключа. Проверены только isolated repository methods; никаких публичных profile mutation routes. Для отдельной коррекции нужны model/repository tests и явное решение о совместимости уже записанных metadata; исправление здесь не выполнялось.

## Targeted runs и точные счётчики

| Run | Passed | Failed | Errors | Skipped | JUnit seconds |
| --- | --- | --- | --- | --- | --- |
| `corrections-final` | 497 | 0 | 0 | 0 | 1692.663 |
| `storage-scopes` | 247 | 0 | 0 | 0 | 1031.313 |
| `original-nine` | 9 | 0 | 0 | 0 | 57.167 |
| `supplemental` | 4 | 0 | 0 | 0 | 31.069 |
| `workspace-2` | 1 | 0 | 0 | 0 | 18.661 |
| `workspace-3` | 1 | 0 | 0 | 0 | 18.692 |
| `workspace-4` | 1 | 0 | 0 | 0 | 18.721 |
| `constructor-edge` | 0 | 3 | 0 | 0 | 10.872 |
| `profile-labels` | 2 | 6 | 0 | 0 | 1.234 |
| **Итого завершённые исполнения** | **762** | **9** | **0** | **0** | — |

Это 771 case-execution, не 771 уникальный новый regression test; original repro и дополнительные проверки намеренно пересекаются с существующими suites. Existing selected corrections/storage: 744 PASS; исходный existing workspace дополнительно 3 PASS. Новые parent probes: 15 PASS / 9 FAIL.

`corrections-final`: `test_settings_error_redaction` 80; `test_settings_nested_validation` 85; `test_project_open_validation` 52; `test_config_error_redaction` 49; `test_project_identity` 231 selected. `storage-scopes`: `test_remote_profiles` 76; `test_application_settings` 83; `test_project` 24; `test_project_scopes` 49; только settings/theme/concurrency/teams/docs-reading/project-metadata API tests — 15.

Ни одного нового skip/xfail, никакого assertion relaxation. Не запускались четыре parametrized cases трёх subprocess-функций (credential process CAS, abrupt exit before/after replace, profile process URL collision) и один `test_new_mutations_are_not_exposed` с POST на remote mutation paths даже для проверки 404. Они **не проверено**, а не passed/skipped. Точные selected nodeids: `corrections-selected.json`, `storage-selected.json`, каждый `collected.json`; исключения заданы до запуска, не после FAIL. Полные unrelated API/workspace/picker и transport suites не запускались.

Сохранены отладочные/незавершённые запуски, не включённые в product counters: `workspace-1` — CLI exit 4 из-за явно не подключённого xdist plugin при `-n0`, до тестов; исправлен только disposable runner. `corrections` — родитель остановил незавершённый run до достижения identity tests, чтобы убрать из будущей selection запрещённый remote mutation endpoint test. Финальный `corrections-final` заново выполняет остальные исходные nodeids; ни FAIL не удалён. У прерванного run нет итогового JUnit/guard summary, поэтому его неполные dots и неизвестные финальные counters нигде не объявлены passing suite.

## Workspace: неизменный сценарий и evidence

Nodeid: `tests/test_workspace.py::test_background_events_stay_local_and_browser_replay_changes_projects`, исходные строки 386–423. Стандартные fixtures: `tmp_path/game` и соседний `tmp_path/event-isolation`. Не применялась nested topology VS-104; её deliberately induced FAIL не смешаны с текущими regression counters.

`workspace-2` (quantum 10 ms), `workspace-3` (0.1 ms), `workspace-4` (10 ms): **по одному PASS**, без pytest deduplication. Все точные local/browser/replay assertions сохранены, штатный FileWatcher/awatch и настройки debounce=300/step=100 не менялись. Observer вызывает оригинальные `EventBus.publish` и `Subscription.get`, записывая payload/type/seq, task, bus/forward identities, subscription/backlog/dropped **без извлечения/очистки событий**; snapshots пассивно читают очереди. При каждом watcher publish предусмотрено немедленное снятие шести source hashes в памяти; trace сохраняется в finally; before/after hashes есть у каждого run.

| Run | Trace records | Local A / browser / local B bus IDs | Unexpected watcher batches |
| --- | --- | --- | --- |
| `workspace-2` | 104 | `1869110889888` / `1869126502976` / `1869127262640` | 0 |
| `workspace-3` | 104 | `2577459586128` / `2577466278880` / `2577467282336` | 0 |
| `workspace-4` | 104 | `2386006298256` / `2386016699696` / `2386016703440` | 0 |

Каждый trace содержит 13 publish-before, 13 publish-after, 43 get-before, 35 get-after; все owners before/after равны. Get ordering исходного task: browser/test.first → local A/test.first → local A/test.background → local B/test.foreground → browser/project.opened → browser/test.foreground → browser/project.opened → browser/test.returned. Queue snapshots включают seq/backlog/dropped; наблюдение не извлекает и не дренирует события.

В этих runs watcher не публиковал неожиданного события, поэтому нет нового unexpected root/changes payload и его нельзя выдумывать. Трассировка готова сохранить его при появлении; уже документированный VS-104 механизм watcher → старая local FIFO не доказывает исторический trigger VS-100. Настоящий watcher работал, но отсутствие delivered batches не доказывает readiness/quiescence и не делает вероятностную проверку гарантией отсутствия flake.

## Команды и воспроизведение

Навигационная команда: `graphify query "remote identity S1 S2 foundation validation workspace profiles application scopes API" --graph "D:\VoxariumStudio\graphify-out\graph.json"`.

CWD `D:\VoxariumStudio`. Каждый label новый: basetemp pytest disposable; исходные logs не перезаписывать.

```powershell
$py = '.\backend\.venv\Scripts\python.exe'
$t = '.\.voxarium_studio\temp\TASK-105'
& $py -B "$t\launch_corrections.py"  # 497 selected cases; quantum 0.0001
$env:VS105_QUANTUM='0.01'
& $py -B "$t\launch_storage.py"      # 247 selected cases
& $py -B "$t\run.py" workspace-2 tests/test_workspace.py::test_background_events_stay_local_and_browser_replay_changes_projects
$env:VS105_QUANTUM='0.0001'
& $py -B "$t\run.py" workspace-3 tests/test_workspace.py::test_background_events_stay_local_and_browser_replay_changes_projects
$env:VS105_QUANTUM='0.01'
& $py -B "$t\run.py" workspace-4 tests/test_workspace.py::test_background_events_stay_local_and_browser_replay_changes_projects
$env:VS105_QUANTUM='0.0001'
& $py -B "$t\run.py" original-nine (Resolve-Path "$t\test_original_matrix.py")
& $py -B "$t\run.py" supplemental (Resolve-Path "$t\test_additional_integration.py")
& $py -B "$t\run.py" constructor-edge (Resolve-Path "$t\test_constructor_edge.py")
& $py -B "$t\run.py" profile-labels (Resolve-Path "$t\test_profile_labels.py")
```

Последние два вызова намеренно сохраняют непройденные **ожидания контракта**, а не превращают обнаруженную ошибку в passed test. Для повторения launchers также менять зашитые labels в disposable копии; приведены фактически использованные commands, не команда перезаписи evidence.

Общие аргументы pytest.main внутри runner (отдельный subprocess создаёт внешний launcher) (фактические expansion/paths — `<label>/command.json`):

```text
pytest -c D:\VoxariumStudio\backend\pyproject.toml -n0
 -p no:cacheprovider -p pytest_asyncio.plugin -p xdist.plugin
 --basetemp <TASK-105>/<label>/pytest
 --junitxml <TASK-105>/<label>/junit.xml
 --log-file <TASK-105>/<label>/pytest-internal.log -q <selected nodeids>
```

## Изоляция, scheduler и denied attempts

Все homes (HOME/USERPROFILE/APPDATA/LOCALAPPDATA/XDG/Studio/Codex/Claude), TEMP/TMP/TMPDIR и pytest bases направлены под TASK-105; remote-token environment удалён, bytecode/cache выключены. Данные, ключи и URL вымышленные, никакого DNS/transport для них. Synthetic settings PUT/open/reload, нужные для repro, идут только через in-process ASGI/TestClient; отдельного listener/server нет. Публичные remote/profile/identity mutations и PUT `/sync` не вызывались, migration apply/production operations не выполнялись. Чтение GET migration — только диагностический план, не migration execution.

До asyncio/pytest/product imports установлен fail-closed Python audit hook: запрещены все audited `socket.*` и перечисленные launch events (`subprocess.Popen`, `os.system/posix_spawn/spawn/startfile`); audited Python writes и SQLite — только внутри TASK-105. Последующие runner versions дополнительно fail-closed отвергают remote mutation HTTP send. Guard не выдаёт loopback exceptions даже там, где существующий F1 fixture допускает stdlib socketpair: внешний hook имеет приоритет.

| Run | Denied socket.gethostname | Denied subprocess.Popen |
| --- | --- | --- |
| `corrections-final` | 1 | 1 |
| `storage-scopes` | 1 | 3 |
| `original-nine` | 1 | 1 |
| `supplemental` | 1 | 1 |
| `workspace-2` | 1 | 1 |
| `workspace-3` | 1 | 1 |
| `workspace-4` | 1 | 1 |
| `constructor-edge` | 1 | 1 |
| `profile-labels` | 1 | 0 |
| **Итого 9 завершённых процессов** | **9** | **10** |

Это **denied attempts**, не «ноль сетевых/socket попыток»: gethostname запрещён до выполнения. В storage-scopes три denied launch: git build metadata, `cm getworkspacefrompath` synthetic project, `git rev-parse --is-inside-work-tree`; в остальных app runs — только git metadata, в profile-labels — ни одного launch. Recorded socket creation/bind/listen/connect/accept/getaddrinfo/gethostbyname attempts — 0; successful audited socket operations — 0. Denied writes вне temp и forbidden remote mutation sends в завершённых guarded runs — 0; ранние runner versions не имели HTTP-send observer, их selection проверена по источникам. Дополнительно workspace-1 до тестов: 1 denied gethostname, 0 launch. Для остановленного corrections нет завершённого counter summary; не складывается с этой таблицей.

Windows CPython 3.12.13 штатно создаёт socketpair для Proactor/Selector self-wakeup; fallback использует TCP bind/listen/connect/accept. Он не запускался. Disposable `NoSocketLoop` использует настоящий IOCP, но без self-pipe/self-read/socket wakeup/signal fd; native select ограничен quantum. Worker-thread callbacks AnyIO/watchfiles/aiosqlite поступают через прежний `call_soon_threadsafe`, а доставка зависит от polling. Quantum — не гарантированная верхняя граница Windows latency; это иной scheduler, не штатная regression сертификация. Observer snapshots/hashes также добавляют timing overhead. Никаких settle sleeps или product event substitutes нет.

Python audit **не OS/native sandbox**: Rust watcher и Windows ACL работают с локальными synthetic fixtures, но отсутствие native IO не аттестуется Python hook. Write guard проверяет lexical containment и допускает integer descriptors; не является общей защитой от junction/symlink bypass. Тестовый symlink указывает только на synthetic root. Изоляция дополнительно подтверждается source-integrity, но не выдаётся за security proof всего runtime.

## Source-integrity и независимое review

После завершения всех pytest процессов повторно проверены **17191 ранее снятых source-like файлов, включая 269 backend**: 0 изменённых, 0 missing. Набор включает generated desktop dependencies, не выдаётся за полный audit всего checkout и сам по себе не обнаруживает добавленные файлы. `git status --porcelain=v1 --untracked-files=all` до/после побайтно одинаков; дополнительных nonignored project source paths не появилось.

Tracked binary diff до/после побайтно одинаков, SHA256 **`c076697874d254c7187bbb5a8a040c1f4f0ea932709f1309b42a23641f171c9c`**; HEAD остался тем же. `git -c core.safecrlf=false diff --check` — exit 0. Шесть непосредственных workspace owners совпали во всех девяти завершённых runs:

| Owner | SHA256 before = after |
| --- | --- |
| `backend/tests/test_workspace.py` | `717329e8eb3d16897de4d05df8a83b36e9b5d225c67fb03aa456a3c598833ead` |
| `backend/tests/conftest.py` | `b62529138a446f4cbd7479e1a3bfa44b61760a1e0fc7a2e20bb3d4d015132cf3` |
| `backend/voxarium_studio/core/context.py` | `b7dca61e5c500c7607d57a54df33b5af032fc1ae46e11a213904fbc47edba2c8` |
| `backend/voxarium_studio/core/workspace.py` | `f58ec9dff8c936e5b568e046b6ed0568c8c16f6017ef163437d8a88514aa2eb5` |
| `backend/voxarium_studio/explorer/watcher.py` | `6453637bc6d18b4493ff046648c653e1681657dd0e99b29a08d7ed6b8c1d5afe` |
| `backend/voxarium_studio/ws/bus.py` | `e46021661122ddf51a76a8fc71ae29dd3bbf91587b9c79ed0a2de3f987786b31` |

Никаких code/test edits, откатов, stash/commit, install/build/restart; чужой diff сохранён. Проверка task-owned `run.py` процессов после тестов — пусто. Единственный постоянный deliverable — этот документ; все probes/logs/драфты/снимки лежат только под `.voxarium_studio/temp/TASK-105`. Evidence disposable и удаляется после Done; reviewer должен просмотреть его до утверждения либо отдельно разрешённо сохранить нужные raw artifacts, не рассчитывать на их постоянную доступность.

Три независимых Studio source reviews прочитаны через get_subagent:

- `subagent_011177d305a04de9`: strict DTO/F1/A/B и compatibility — PASS в исходных условиях; пробелы create=true/direct init/privacy дополнительно закрыты четырьмя parent probes.
- `subagent_b54a4e290a084005`: F2–F4/C, storage/privacy; обнаружен E1, повторный source-review подтвердил E2. Runtime-пробы обоих дефектов выполнил parent отдельно, без исправлений.
- `subagent_d035b1ee9e56442b`: harness/workspace — исходные assertions/fixtures/настоящий watcher сохранены, отмечены polling/native/isolation limitations и необходимость считать denied hostname/git attempts.

Независимый review draft/evidence подтвердил E1/E2 и девять FAIL, исходные repro, storage и три workspace PASS. По замечаниям уточнены passive queue reads, снятие hashes в памяти/finally flush, pytest.main вместо «subprocess внутри harness», ограниченность audit events и snapshot coverage. `corrections-final` на момент draft review ещё выполнялся; итоговые 497 PASS/счётчики и финальный integrity после его завершения проверены parent напрямую по JUnit/guard/source hashes, не приписаны раннему reviewer. Финальное независимое review после завершения run также подтвердило 497 PASS, общие 762 PASS / 9 FAIL / 0 skipped, guards 9/10 и integrity. Единственное оставшееся замечание о пассивном чтении очередей для snapshots исправлено в этом документе; parent проверил точную формулировку.

## Что не принято этим отчётом

Нельзя объявлять весь продукт или S1/S2 безусловно зелёными из-за E1/E2. Отдельных коррекций требуют именно два описанных дефекта; код/существующие tests в VS-105 не исправлялись. Process contention/crash tests четырёх случаев, normal scheduler, весь transport/remote suite, real power-loss/disk-full durability, установленный Studio, v2/catalog/UI/cutover/production migration/deploy/build/EXE/APK не проверены. `sync/service.py`, `sync/protocol.py`, `api/sync.py` не имеют diff к HEAD; новый profile/identity storage ими не потребляется. Исторический VS-100 payload не восстановлен и его причина не объявляется установленной.

