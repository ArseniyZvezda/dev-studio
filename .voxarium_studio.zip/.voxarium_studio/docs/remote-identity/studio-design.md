# Studio: ID проекта и Remote-серверы

## 1. Статус и границы

VS-88; согласование трёх контрактов VS-91, 15.11.2026. Контракт будущей реализации. Пользовательское решение: у управляемого проекта есть **редактируемый локальный persistent ID, равный Remote space**; название проекта и имя папки — только подписи/locator. Settings → Remote-серверы управляет глобальными персональными профилями, Project Settings → Remote явно создаёт серверный проект или выбирает его из каталога.

Это **только документ**, не миграция и не разрешение мигрировать production. Код, конфиги, базы, runtime, чужие изменения и серверы в рамках VS-88 не изменяются; подключение к настоящему Remote не требуется. Реализация, установка, deploy, перенос данных и проверка APK — отдельные задания.

Основание: актуальные исходники, `docs/voxarium-studio-dev-spec.md` §5.1–5.3 и §16; смежные контракты — VS-89 ([[remote-identity/server-design]]) и VS-90 ([[remote-identity/android-design]]). Эти ссылки задают границы ответственности, а не утверждают, что их API уже реализован. [[desktop-tabs/project-isolation]] — дополнительный контекст; актуальные исходники и §5.3 важнее его исторической карты будущих файлов.

Этот контракт намеренно меняет прежнее решение §5.3.2 «не нужен постоянный UUID» **только в части переносимой бизнес-идентичности**. Runtime registry, immutable bindings, root-based изоляция рабочих копий и desktop restore сохраняются. Перед реализацией один владелец должен внести согласованную поправку в dev spec (§11 ниже); в VS-88 сам spec не редактируется.

## 2. Что существует сейчас

Сначала выполнены Graphify query/explain по `D:\VoxariumStudio\graphify-out\graph.json`, затем прочитаны актуальные владельцы символов. Граф использован для навигации, не как доказательство актуальности checkout; номера строк ниже — ориентиры текущего снимка.

| Область | Текущий путь/символ и поведение |
| --- | --- |
| Project config/init | `backend/voxarium_studio/core/config.py:442–475`: `SyncConfig(enabled=False, url="", space="")`; `AppConfig.project_name`, `project_code`. Общего persistent ID ещё нет. Explicit init: `core/project.py:init_project` (126–173) сохраняет AppConfig; `ensure_project` затем загружает его. Ни model, ни `SyncSettings.vue` не подставляют имя папки в пустой space. `project_code` — префикс отображаемых task IDs, не project identity. |
| Глобальные настройки | `core/application_config.py`: `ApplicationConfig`, `application_config_file`, `load_application_config`, `save_application_config`, `apply_application_config`. Пользовательский `config.yaml` отдельно от проекта; `core/config.py:_project_fields/load_config/save_config` сохраняют этот split. |
| Локальный API | `backend/voxarium_studio/api/sync.py:24–78`: `SyncUpdate`, `get_sync`, `update_sync`; GET/PUT `/api/sync`, patch enabled/url/space/token. URL/space записываются в проект, token — отдельно; затем немедленный `reconfigure()`. Scoped вариант `/api/projects/{project_id}/sync` реально смонтирован в `api/__init__.py:49–64`. |
| Sync lifecycle | `backend/voxarium_studio/sync/service.py:136–371`: `RemoteSync`, `reconfigure`, `_stop_runner`, `_disconnected`, `status`; свой экземпляр в каждом `core/context.py:AppContext`. Stop/start отменяет pending и закрывает комнаты, но не является prepare/drain транзакцией изменения идентичности. |
| Комнаты и late save | `sync/service.py:667–789`: `_flush`, `note_live_write`, `serve_collab`, `_join`. Save перед leave штатного room lifecycle уже есть. Но `api/docs.py:write_doc` (около 304–315) пишет Markdown и при старом/неизвестном collab sid: `note_live_write` просто возвращается. Закрыть WS недостаточно, чтобы запретить late save в другое назначение sync. |
| Base/cursor | `sync/state.py:SyncState.file_for/load/save`: машинный файл `user_config_dir()/sync/<16 hex SHA-1 строки root>.json`, проверяются URL и `space_id` из hello. Хеш пути — **не** runtime ID. `hello.space.id` сейчас — opaque UUID incarnation серверного пространства, не строка space selector. |
| URL и wire | `sync/protocol.py:normalise_url/check_space_name/socket_url`: protocol v1, имя space 1–64 ASCII, первый символ alnum, далее alnum/`._-`, trim/lower; URL без userinfo/query/fragment, ws/wss → http/https, сохраняется prefix. |
| Ключи | `sync/credentials.py:keys_file/load_token/save_token`: `user_config_dir()/remote-keys.json`, по нормализованному URL; атомарная запись, chmod 0600 best-effort. Это plaintext в личном файле, **не** шифрованное vault. `VOXARIUM_STUDIO_REMOTE_TOKEN` сейчас перекрывает ключ **для любого URL**; переносить это поведение в multi-server flow нельзя. Значения личного файла для исследования не нужны. |
| UI | `frontend/src/views/SettingsView.vue:SECTIONS` — глобальные Settings. `views/ProjectSettingsView.vue:SECTIONS` и строки 408–410 подключают `components/settings/SyncSettings.vue` с enabled/url/space/password. `stores/sync.ts` получает status/events, `api/client.ts:776–777` — sync/updateSync, `api/types.ts:1290–1356` — SyncConfig/SyncStatus/SyncUpdate. |
| Runtime backend | `core/project_scope.py:ProjectDescriptor/canonical_root/resolve_project`; `core/workspace.py:initialise_workspace/_register_project/_ensure_project_locked` (58–139): frozen descriptor `{project_id,epoch,root,ctx}`; project_id = новый `uuid4().hex`, epoch = другой UUID. Канонический root определяет resident context, неизвестный handle не открывает другой проект. |
| Runtime frontend | `frontend/src/session/project-session.ts:ProjectSession` (16–64): bind immutable; capture защищает поздние ответы. `api/project-scope.ts:scopedApiUrl/scopedWsUrl` и `api/deps.py:get_ctx` адресуют захваченный runtime context, не space. `frontend/src/desktop/project-storage.ts:projectStorageKey` — namespace по root. |
| Desktop | `desktop/tabs.cjs:canonicalProjectRoot/bindingFrom/DesktopTabs.openProject/#open` (13–29, 287–335): main дедуплицирует root, а не metadata/DB IDs. `desktop/session-state.cjs` (132–149, 210–234) хранит root + relative page, restore делает ensure/create=false. Не сохраняет runtime handle/epoch/секреты. |
| Scoped rooms | `backend/voxarium_studio/ws/routes.py:project_collab_endpoint` (209–217) и legacy `collab_endpoint` (321–335), `frontend/src/lib/collab/session.ts:CollabSession/openSession`. Уже есть комнаты нескольких scoped проектов. Фраза §16.5 «только у выбранного» отстаёт от этой реализации; переносить её в новый контракт нельзя. |
| Remote сегодня | `remote/voxarium_studio_remote/app.py:create_app` (77–110): только GET `/healthz`, GET `/api/v1/me`, WS `/api/v1/sync?space=...`. `hub.py:Hub.connect` → `store.py:Store.space` (200–218) ищет по name и **автосоздаёт**. `Store.list_spaces` и CLI `space list` существуют, публичного HTTP-каталога/явного create нет. SSH Admin не является клиентским каталогом. |

§16.3–16.4 остаются обязательными: persist только Markdown, Yjs room никогда не записывается; открытие чистого документа ничего не пишет. Все прежние ограничения §16.6 сохраняются, кроме явно заменяемого выбора назначения: не добавляются картинки, история, RBAC, per-space ACL, plugin sandbox или синхронизация задач.

## 3. Термины и инварианты новой модели

| Имя в этом контракте | Назначение/namespace | Можно ли менять |
| --- | --- | --- |
| `persistent_id` | Переносимая идентичность управляемого проекта; точная строка **Remote space selector**. Хранится в проекте. | Да, явно, по барьеру §7; не rename серверной записи. |
| `display_name` | Локальное `project_name` либо серверная подпись записи каталога. Не обязаны совпадать. | Да; не влияет на ID, connection и каталожный lookup. |
| `url` | Нормализованный server endpoint, включая deployment prefix. | Это locator сервера, не ID проекта. Смена требует явной перепривязки. |
| `profile_id` | Локальный UUID персонального профиля сервера, отсутствует в переносимом project config. | Создаётся локально; имя профиля редактируемо, идентификатор неизменяем. |
| `runtime project_id + backend epoch` | Существующий opaque адрес resident AppContext, REST/WS/`/p/…`. В JSON сохраняется прежнее имя `project_id`. | Не менять при смене persistent_id. Новая epoch только после нового backend lifetime. |
| `canonical_root` | Локатор рабочей копии, registry/UI namespace. | Не live-rebind; move/rename отдельно, §8. |
| `space_instance_id` | Только локальный adapter alias для wire v2 `storage_epoch`, отображение 1:1. В v1 incarnation передавалась в `hello.space.id`; в v2 это поле уже canonical ID/selector. | Новая epoch создаётся Remote независимо от ID; при штатной миграции ID и epoch оба сохраняют прежний UUID байт-в-байт. Не вычислять epoch из произвольного нового persistent_id. |
| `binding_generation` | Fence назначения sync внутри одного runtime context. | Растёт при cutover, отдельно от backend epoch и room_epoch. |
| `room_epoch / collab_session` | Короткоживущая сессия редактора/комнаты внутри конкретного binding_generation. | Не переносится между назначениями. |

Полная идентичность remote данных: **(normalized URL, persistent_id)**; incarnation дополняет проверку базы ревизий. Строка ID глобально не уникальна между серверами. URL aliases не объединяются «похожестью», redirect или именем профиля. HTTP и HTTPS, разные path prefixes — разные назначения; нормализация должна одинаково выполняться в модели, API, credentials и клиенте.

Ни UI, ни миграция не выполняют lookup/merge по project_name, названию папки, имени профиля или display_name сервера. Скопированная папка с тем же persistent_id — ещё одна **рабочая копия**, но не тот же runtime context/tab. И наоборот, редактирование ID на прежнем root не создаёт новую вкладку/контекст.

В новых API поле `persistent_id` обязательно отличать от runtime `project_id`. Не переименовывать массово существующий wire/runtime project_id и не подставлять persistent_id в URL builders, plugin bindings, MCP owner keys, WS replay scope, desktop manifest либо storage key.

### 3.1 Валидация

- Новый/редактируемый ID: canonical lower-case ASCII, регулярное выражение `^[a-z0-9][a-z0-9._-]{0,63}$`. Не путь, не название. UI показывает canonical вариант до подтверждения; API отклоняет неcanonical ввод, а не незаметно меняет его. Общее правило должно совпасть с VS-89/VS-90.
- Для **нового локального** проекта предлагается случайный UUID v4 в lowercase с дефисами (36 символов); его можно заменить валидным ID. Никогда не slug от названия/пути. Диагностическое чтение UUID не генерирует и не сохраняет.
- Серверный display_name проекта/пользователя: NFC + trim внешних пробелов как явная нормализация подписи; после неё 1–120 Unicode code points и ≤480 UTF-8 bytes. Запрещены C0/C1/DEL, переводы строк и bidi override/isolate (Remote §2.2). Исторические подписи миграции сохраняются буквально с пометкой, не исправляются автоматически. Локальное имя проекта/профиля не является wire display_name: для профиля остаются trim, 1–120 Unicode-символов, без управляющих символов. Совпадающие подписи разрешены; локальное project_name не меняется при Select.
- URL использует нынешний `normalise_url`; не вводить новую неявную эквивалентность портов, путей или доменов при миграции. Дополнительно запретить path traversal/encoded separators в endpoint prefix. Отклонённый raw URL с userinfo нельзя отражать целиком в error/log.
- Один профиль на точный normalized URL в личном Studio home; второй с тем же URL возвращает 409 с profile_id существующего, не перезаписывает ключ. Два разных URL не доказывают два разных физических сервера; это не повод автоматически объединять их.

## 4. Точная модель хранения (предлагаемая, не текущая)

### 4.1 Переносимый project config

```yaml
# <managed-project>/.voxarium_studio/config.yaml — новый формат
project_identity:
  id: "d9099d14-d8e8-46d1-aa34-bd4359f770e3"
  revision: 1
project_name: "Boloto"       # подпись; независима от ID
project_code: "BT"          # task display prefix, не ID
sync:
  enabled: false
  url: "https://remote.example/team"
```

- `project_identity.id` — единственный источник persistent_id; `sync.space` после подтверждённой миграции не сохраняется. Runtime adapter вычисляет space = project_identity.id; двух редактируемых источников быть не должно.
- `revision` — целое >=1, версия изменения identity/target (ID, URL, enabled); увеличивается guarded API. Не является security token или переносимой runtime generation. Дополнительно CAS проверяет fingerprint реально прочитанного config, чтобы ручная правка/VCS checkout не затерялись.
- URL остаётся переносимым **несекретным locator**: коллега видит, к какому endpoint относится ID, но выбирает свой глобальный профиль и вводит свой ключ. profile_id, username, key, verification и local confirmation в проект не попадают.
- `enabled: true` — намерение проекта, но недостаточно для старта новой рабочей копии: необходима локальная подтверждённая привязка ниже. Новый/мигрированный/перепривязанный проект сначала сохраняется disabled.
- Общий PUT settings не принимает project_identity, sync target, ключи или профили; изменения этих полей — только специализированная транзакция. Save остальных настроек не сбрасывает их. Не копировать global fields в проект при save.

### 4.2 Глобальные профили и секреты

В `user_config_dir()/config.yaml`, `ApplicationConfig.remote_servers`:

```yaml
remote_servers:
  - profile_id: "c503da2b-f8fe-4fb0-b945-86bc119495b3"
    name: "Team Remote"
    url: "https://remote.example/team"
    revision: 1
```

Только metadata. В эффективном config допускается metadata/has_token, **никогда token**. Status проверки — volatile cache по `(profile_id, profile revision, credential revision)`, не доказательство текущего доступа и не permission на push.

Секреты: versioned `user_config_dir()/remote-keys.json`, новый формат `{version:2, profiles:{profile_id:{url, token, revision}}}`. Lookup требует точного profile_id **и** URL. Не использовать только имя/ID проекта. Поиск по URL legacy разрешён исключительно в явной миграции §9. Права owner-only/best-effort Windows ACL, атомарная запись, без секретных backup в проекте; plaintext личного файла честно обозначается в документации. OS vault — возможная отдельная работа, не условие каталога и не обещание существующего шифрования.

Сохраняемый ключ вводится только в Settings → Remote-серверы. GET, WS, logs, exception repr, application config, docs, project export, desktop manifest, analytics его не возвращают. Парольное поле пусто после save/cancel; в store/localStorage/sessionStorage/Pinia key не удерживается. Удаление ключа — явная операция, не неоднозначная пустая строка.

### 4.3 Машинная привязка и базы

Новый `user_config_dir()/remote-bindings.json`:

```json
{
  "version": 1,
  "roots": {
    "<sha256 canonical root>": {
      "canonical_root": "D:\\Games\\Boloto",
      "profile_id": "c503da2b-f8fe-4fb0-b945-86bc119495b3",
      "url": "https://remote.example/team",
      "persistent_id": "d9099d14-d8e8-46d1-aa34-bd4359f770e3",
      "identity_revision": 1,
      "selection_state": "confirmed",
      "space_instance_id": "<opaque value from confirmed server>"
    }
  }
}
```

selection_state = selected означает только сохранённый выбор профиля для Preview; confirmed означает завершённое Enable. Автостарт требует confirmed и exact tuple/revision. Это consent/выбор персонального профиля одной рабочей копии; не identity сервера, не переносимый config. Если файла/записи нет, selection_state != confirmed либо tuple/revision не совпали с проектом — `binding_required`, sync/rooms не стартуют. Ни совпавший URL профиля, ни скопированный config не дают consent автоматически. Runtime generation создаётся отдельно в памяти; после restart старые requests не проходят backend epoch fence.

Новый формат sync state: файл namespace `sync/v2/<sha256(canonical_root, url, persistent_id)>/state.json`, внутри version, полный namespace tuple, space_instance_id, cursor, docs bases. Код сравнивает tuple, а не доверяет одному hash. Новое назначение не наследует cursor/base/pending/live writes; старое состояние сохраняется отдельно, не перезаписывается новым. Ни state, ни локальные bindings не коммитятся в managed project. При несовпадении incarnation либо hello.seq < saved_cursor — **blocked/mismatch до sync/push**, а не автоматический «fresh full sync». Повторное согласование требует preview и нового подтверждения.

Runtime transient `RemoteBinding`: root descriptor + persistent_id + url + profile_id + identity revision + random binding_generation + expected incarnation. Pending requests, delayed debounce, collab sids, reconnect retries и callbacks захватывают этот binding; перед побочным действием проверяют generation.

## 5. Локальный API Studio (всё ниже — новый контракт)

Глобальные маршруты не scoped на активную вкладку; добавить их в `isGlobalApiPath`. Проектные обслуживаются только захваченным Ctx из runtime selector, с прежними auth/Host/Origin проверками. Ни один endpoint не принимает произвольный URL для «проверки с сохранённым ключом»: только profile_id из личного реестра.

Общие правила: `extra=forbid`, no-store для ответов, отражающих credentials/status/bindings; ошибки `{code, details}` без токена и сырых ответов Remote. Данные приходят как данные, тексты действий/ошибок UI — EN/RU. Ревизии/CAS обязательны при mutation; stale = 409, validation = 422, auth Studio = 401/403, Remote auth = typed `remote_unauthorised`, сеть = 502/504 без fallback на другой сервер.

### 5.1 Глобальные профили

Локальные additions C0/C9 и исправление пропуска rejected: [[remote-identity/catalog-api-activation-plan]]; каноническое соответствие — [dev spec §5.2.1](../../../docs/voxarium-studio-dev-spec.md), Remote wire остаётся §6.

**Локальное уточнение VS-134 (C0; нормативно для будущих C6/C7/C9).** Только глобальный API Studio; это не изменение Remote wire и не утверждение о mounting. `B=/api/remote/servers`, `S=B/{profile_id}`; profile_id — canonical UUID, expected_revision — strict integer ≥1 (не bool), неизвестные поля/лишний body/query отклоняются до dispatch. Все ответы, включая auth/validation/errors, — `Cache-Control:no-store`; credential/URL из browser payload не подменяют сохранённый exact binding.

| Метод / локальный путь | Строгий вход | Успешный HTTP / ответ и эффект |
| --- | --- | --- |
| GET `B` | Без body/query | 200 `{items:ServerProfile[]}`; metadata-only, verification ровно `{state:"unavailable"}` при отсутствии применимого результата, без Verify/clock/сети/записей. |
| POST `B` | `{name,url}` | 201 secret-free ServerProfile; keyless, уникальный normalized URL, без подключения проекта. |
| PATCH `S` | **Один вид**: `{expected_revision,name}` **либо** `{expected_revision,url,clear_credential:true}` | 200 secret-free ServerProfile с новой revision. Name-only без reconnect; URL-only только при допустимых consumers, с revoke binding/journal/очисткой stored key. Name+URL, пустой patch и clear_credential вне URL-варианта — 422 до любых writes. UI не делает hidden split одного Apply; два изменения — отдельные явные действия/подтверждения со свежим CAS. Composite atomic PATCH вне increment. |
| PUT `S/credential` | `{expected_revision,token}`, непустой secret | 200 metadata результата S2 (has_token/revision), без token; drain/CAS обязательны. |
| DELETE `S/credential` | `{expected_revision}` | 200 secret-free metadata; удаляет только stored key, не ENV/Remote user/project. ENV остаётся effective source либо environment_unbound даёт typed отказ, не ложный source none. |
| POST `S/recover` | `{expected_revision,confirmation:{profile_id,action:"discard_uncertain_credential"}}` | 200 `{profile:ServerProfile\|null}`; подтверждённое удаление uncertain stored credential через S2 recover, не восстановление/повтор старого key. null только при доказанном отсутствии metadata. |
| POST `S/verify` | `{expected_revision}` | 200 VerificationResult `{state,checked_at,user,wire_protocol,catalog_version?,error_code?}` при возврате facade; только HTTP health/me, не Create/WS. Typed exceptions не становятся успешной verification. |
| DELETE `S` | `{expected_revision}` | 204 без body, только без bindings/active consumers; не изменяет project configs. |
| GET `S/projects` | Только query `cursor?` (canonical after ID), без body | 200 `{items:CatalogProject[],next_cursor:ID\|null}`; revision захватывает backend, не browser CAS. Не вызывает явную команду Verify/Select/Create; собственный health/me/version/binding preflight каталога сохраняется. |
| POST `S/projects` | `{id,display_name,operation_id,expected_revision}` | 201/200 **только** result envelope по таблице ниже; C8 owner и durable reservation. Remote body только `{id,display_name}`. |
| POST `S/projects/operations/{operation_id}/observe` | `{expected_revision}`; без id/url/key | 200 result envelope found/absent при успешном observation; отдельная явная команда `CatalogCreateService.recover_create`, не GET handler и не повтор Create. Remote traffic только health/me + GET **исходного** ID из reservation, без POST/WS/writes проекта. |

Operation_id — локальный exact `[A-Za-z0-9._-]{1,128}`, не Remote field. ID/display_name валидируются по Studio design §6 / dev spec §16.7; name/url — существующими S2 validators. Невалидная форма confirmation — 422; структурно валидные, но несовпавшие profile_id/action — typed 409 до S2 recovery. Recovery требует предупреждения и отдельного подтверждения очистки uncertain key, того же CAS/drain/authoritative guard. Startup/GET не recover-ят, malformed journal сохраняется с отказом; ENV не меняется. Это **не** cold Create recovery.

**Result envelope фиксирован:** всегда ровно `{state,project,error_code}`, все три поля обязательны, включая null; без selection/ownership/retry booleans, raw message/body/request_id. Строка code — только fixed sanitized vocabulary, не произвольная серверная строка. Это mapping **возвращённого CreateResult**, не перехват исключений.

| CreateResult.state | Локальный HTTP | project | error_code / смысл |
| --- | --- | --- | --- |
| `created` | 201 | Exact validated CatalogProject исходного ID | null; даже 201 не Select/Enable. |
| `conflict` | 200 | null | `project_exists`; никакого auto GET/POST/Select победителя гонки. |
| `unknown` | 200 | null | Fixed sanitized code: `create_unknown`, `transport_unavailable`, `invalid_response`, `version_mismatch`, `redirect_refused`, `temporarily_unavailable` либо `remote_error`; неоднозначность не разрешает повтор. |
| `rejected` | 200 | **null** | Только `invalid_id`, `invalid_display_name`, `invalid_request`, `unauthorised`, `project_not_found`, `metadata_conflict`, `snapshot_changed`, `payload_too_large` либо fallback `remote_error`; без retry, Select или освобождения operation. |
| `found` | 200 | Exact validated CatalogProject исходного ID | null; только observation, не авторство/привязка; Select — отдельное будущее действие. |
| `absent` | 200 | null | `project_not_found`; не освобождает operation, не разрешает auto POST. |

Первичный Create возвращает первые четыре исхода; found/absent возникают после отдельного явного observe. Повтор того же Create с тем же exact input и живым неизменившимся binding возвращает последний сохранённый result (включая rejected и found/absent после явного observe), без нового transport send; другой profile/revision/body под тем же operation_id — typed 409 operation_conflict, не новый intent. Guards/journal failures могут вместо result дать typed exception. Ни rejected, ни остальные outcomes не освобождают reservation; исправленный Create требует нового явного действия и нового operation_id, не автоматического retry. Observe никогда не запускается автоматически после rejected/conflict/unknown; явно вызванный observe заново проверяет **живой** binding и читает исходный ID, может вернуть found/absent, но не делает Select. После restart/loss live proof любая durable запись, включая created/rejected/found, даёт `credential_binding_unproven` до credential/transport calls; revision/source/has_token не доказывают continuity.

**Boundary exceptions отдельно:** локальный envelope `{code,details}` (fixed codes, sanitized details), не `{state,project,error_code}`. Вход/валидация — 422; profile/operation not found — 404; CAS/collision/in-use/not-drained/recovery-required/conflicting confirmation/operation_conflict/operation_in_progress/credential_binding_unproven — typed 409; unavailable lifecycle/store/journal/admission capacity — typed 503. Malformed recovery journal — typed 503 profile_recovery_unavailable, без удаления/repair. Remote/transport/version/capability/response exceptions — существующий typed 502 mapping (unauthorised → remote_unauthorised); auth Studio — 401/403, unsupported method — 405. Не превращать эти исключения в rejected/unknown/absent, не заворачивать ошибки в HTTP200. Cancellation сохраняет cancellation и reservation, не синтетический success.

**Server status matrix — только обработанный ответ целевого Remote POST, после успешных guards/health/me:** не переопределяет Remote errors/wire. Если facade бросил исключение до возврата CreateResult (включая post-await guard/secret/journal failure), применяется boundary mapping выше, а не эта таблица.

| Ответ Remote POST / отдельного observation GET | Возвращённый локальный result |
| --- | --- |
| POST 201 + валидный project исходного ID | created →201. Невалидный 201 →unknown/200 с fixed invalid_response (protocol mismatch →version_mismatch), если facade вернул result, а не exception. |
| POST 400 invalid_id/invalid_display_name/invalid_request | rejected →200, project=null, только соответствующий fixed code. |
| POST 401 unauthorised | rejected →200 с unauthorised; не локальная Studio 401 и не отказ health/me. |
| POST 404 project_not_found | rejected →200; **не absent**. |
| POST 409 project_exists | conflict →200. |
| POST 409 metadata_conflict/snapshot_changed | rejected →200, не conflict и не Select. |
| POST 413 payload_too_large | rejected →200. |
| POST 503 temporarily_unavailable | unknown →200, не доказанный отказ/разрешение retry. |
| POST неожиданный status (включая 200/204/500) | unknown →200 с remote_error; redirects/transport failure — fixed code только если возвращён CreateResult, иначе typed boundary exception. |
| POST 400/401/404/409/413 с malformed envelope/неизвестным или несовпавшим code | rejected →200 с **remote_error**, не raw code; malformed 409 не project_exists/conflict. |
| Observe GET исходного ID 200 + валидный project / 404 project_not_found | found/absent →200; только exact project GET 404 означает absent. |
| Health/me error (включая 401/404/503), observation GET иной error/невалидный ответ | Typed boundary failure, не rejected/absent/unknown outcome; никакого implicit POST. |

**Targeted acceptance будущей реализации (не выполненные проверки VS-134):**
- Table-driven C9: все шесть states, обязательные три поля/null, 201 только created; перечисленные POST 400/401/404/409 (все три codes)/413/503, unexpected 200/204/500, malformed error envelopes и invalid 201. Проверить phase distinction: health/me 401/404/503 и GET error — typed failures; GET exact 404 — absent, POST 404 — rejected.
- Rejected и повтор: одинаковый operation/input → тот же rejected/200, project=null, fixed code, POST counter=1, новые GET/Verify/Select/retry/release counters=0; другой body/profile/revision →409 до credential lookup. Проверить durable reservation осталась и после rejected, response failure/cancel/restart; cold repeat/observe →409 credential_binding_unproven, credential/transport counters=0.
- Отдельный explicit observe — только health/me + GET reservation ID; found/absent не bind/enable/release. Raw canary в server message/code/request_id/exception не выходит в DTO/logs/repr/chains; unknown code →remote_error. Все boundary 404/409/422/502/503 и Studio 401/403/405 остаются typed no-store, не HTTP200 outcome.
- C7: missing/mismatched confirmation, stale CAS, in-use/not-drained/unknown consumers, partial writes, corrupt journal, absent metadata, ENV-bound/unbound; recovery не возвращает key и не делает network. C6/C7: name+URL/лишние поля/empty patch/неверный clear_credential →422 с **нулём writes**; UI не подменяет Apply двумя hidden requests.

`ServerProfile = {profile_id,name,url,revision,has_token,credential_source:"stored"|"environment"|"none",verification}`. Verification states: `unavailable|unchecked|checking|valid|unauthorised|offline|incompatible|insecure_blocked|error`; valid не означает наличие каталога. Неподдерживаемый каталог показывается отдельно. References/roots доступны локальному UI по typed 409, не отправляются на Remote.

**Решение VS-123 (15.11.2026), отдельное от принятых VS-119/121/122:** при отсутствии применимого результата сохранённый сервер показывается как «Статус подключения неизвестен». Обязательное поле `verification` содержит ровно `{state:"unavailable"}`: без `checked_at`, `user`, capabilities и других полей результата (включая `wire_protocol`, `catalog_version`, `error_code`), даже со значением null. Это не `unchecked` (доказанная история отсутствия проверки), не checked `error`, не свидетельство сети, доступности ключа, аккаунта или доступа к каталогу. Отсутствующее поле verification, null или некорректная форма остаются ошибкой, не default unavailable.

Новый контракт разрешает **будущий отдельный** adapter внутренних VS-122 rows → `ServerProfile`: exact metadata/историческое имя копируются; stored → true/stored, environment → true/environment, missing → false/none; строковый внутренний `verification="unavailable"` преобразуется в объект выше. ENV-unbound остаётся unusable outcome с typed отказом `metadata_unavailable` (503), не missing и не none; расширение credential DTO не утверждено. Повреждение stores, pending, обнаруженные races и invalid rows по-прежнему отклоняют весь ответ без partial items/defaults. GET не вызывает Verify/clock/transport, не хранит status и не добавляет cache. Неизвестность только verification больше не блокирует корректные metadata; иные ошибки не маскируются unavailable. Подробный mapping и synthetic acceptance — [[remote-identity/catalog-metadata-contract]] §§4–7.

Это поправка intent/локального DTO, не изменение Remote wire или существующего POST Verify; код DTO/adapter, production injection, mounting и runtime остаются отдельной реализацией. Принятый VS-119 — оболочка с trusted seam, VS-121 — контракт M, VS-122 — внутренний observer, а не реализация этого нового решения.

Настройка имени профиля не reconnect. Ротация личного ключа на сервере через Studio не производится: сюда вводят уже выданный key. Если Remote его отклонил/revoked — остановка без retry storm; другой профиль/ключ не подставлять.

### 5.2 Проектное назначение и редактирование ID

Префикс `P=/api/projects/{runtime_project_id}`, runtime epoch проверяется прежним способом.

| Метод/путь | Вход/выход |
| --- | --- |
| GET `P/remote` | `{persistent_id,identity_revision,config_fingerprint,url,enabled,profile_id?,binding_generation,space_instance_id?,state,reason?,active_rooms,pending_writes}`. Credentials — только has_token; поля runtime project_id/epoch выдаются существующим envelope, не заменяются persistent_id. |
| POST `P/remote/editors` | `{document_path,client_instance_id}` → `{editor_id,binding_generation,lease_expires_at}`; регистрирует обычный либо collab редактор до начала HTTP save. Heartbeat `POST P/remote/editors/{editor_id}/heartbeat`, закрытие `DELETE P/remote/editors/{editor_id}` только после последнего подтверждённого save. Истечение heartbeat при dirty/неподтверждённом состоянии блокирует cutover, не доказывает сохранение. |
| POST `P/remote/prepare` | `{expected_revision,config_fingerprint,profile_id?,persistent_id,url?,operation:"edit_id"\|"select"\|"disable"\|"unbind"\|"migrate",catalog_id?,catalog_instance_id?,migration_plan_id?}`. Проверяет намерение, возвращает `{change_id,expires_at,from,to,required_editor_acks,plan,conflicts}`; plan read-only. Server URL берётся из профиля, переданный url — только expected match. |
| POST `P/remote/changes/{change_id}/quiesce` | `{expected_generation}`. Запускает §7; ответ `{state:"draining"\|"ready"\|"blocked",missing_acks,reason?}`. Не меняет ID/URL. |
| POST `P/remote/changes/{change_id}/editor-ack` | `{editor_id,old_generation,last_saved_version}`. Только зарегистрированный editor lease, backend сверяет уже завершённый local save; клиентский bool «saved» сам по себе не доказательство. |
| POST `P/remote/changes/{change_id}/commit` | `{expected_revision,expected_generation,config_fingerprint,confirmation}`; confirmation = точные `{url,persistent_id}` из preview. Только ready. Атомарно меняет identity/target, сохраняет disabled; select/migrate сохраняют private selection_state=selected, edit_id/unbind очищают local selection, disable сохраняет выбор как selected; возвращает новый P/remote. Повтор change_id идемпотентен. |
| DELETE `P/remote/changes/{change_id}` | Отмена до commit снимает quiesce; после commit 409 already_committed. Expiry 5 минут = отмена, не auto-commit. |
| POST `P/remote/reconcile-preview` | Проверяет каталог/incarnation, читает remote snapshot по будущему read-only adapter, сравнивает с локальным Markdown без записи; `{preview_id,fingerprint,counts,conflicts,expires_at}`. Безопасного read-only snapshot ещё нет — реализация зависит от VS-89, нельзя эмулировать его подключением с автосозданием. |
| POST `P/remote/enable` | `{expected_revision,expected_generation,preview_id,confirmation:{url,persistent_id,action:"reconcile"}}`. Повторная проверка fingerprints/snapshot; только тогда enabled=true и catch-up. Устаревший preview = 409/repreview. Rooms — после connected. |

Миграционные маршруты (тоже новые): GET `P/remote/migration` строит локальный read-only план `{migration_plan_id,legacy_url,legacy_selector,config_fingerprint,has_legacy_key,state}` без сети. POST `P/remote/migration/{migration_plan_id}/profile` с `{config_fingerprint,profile_id?,name?,import_legacy_credential,confirmation:{url}}` — **отдельная явная** команда пользователя: создаёт/выбирает global profile по exact legacy URL, импортирует legacy key только если пусто и разрешено, не меняет project config/base и не соединяется с Remote. Нельзя передать другой URL/произвольный root; URL берётся из bound legacy config. POST `P/remote/migration/{migration_plan_id}/resolve` с `{profile_id,expected_profile_revision,config_fingerprint}` выполняет read-only catalog resolution и возвращает `{migration_plan_id,legacy_selector,catalog_id,space_instance_id,changes,conflicts}`. Только после этого prepare(operation=migrate, migration_plan_id) → quiesce → commit применяет §9: удаляет только локальное legacy-поле sync.space (не серверный space), записывает identity и импортирует доказанную base. В plan bound root/fingerprints/profile revision/selector/instance; изменение любого поля требует нового plan. Повтор profile/import/apply идемпотентен; clear_credential и credential conflicts не обходятся миграцией.

Prepare для простого offline edit_id допускает отсутствие profile/catalog: меняет локальный ID, **не** создаёт/ищет серверный проект, clears local consent, оставляет sync disabled. Для select обязательна точная запись каталога и явное принятие её ID как локального ID. Для create сначала отдельная явная POST projects, затем select; нельзя замаскировать bind под side effect create.

`state` сохраняет старые disabled/unconfigured/connecting/syncing/connected/offline/unauthorised/error и добавляет `binding_required|migration_required|quiescing|blocked` с typed reason: `catalog_unavailable|instance_mismatch|duplicate_local_binding|pending_edits|stale_binding|…`. Пока state != connected, новые rooms не предлагаются.

### 5.3 Совместимость старых локальных API и документа-save

- GET legacy/scoped `/sync` остаётся read-only compatibility status; `space` в ответе — вычисленный alias persistent_id после миграции, до неё — сохранённый legacy selector с migration_required. Это не второй источник.
- PUT `/sync` после включения новой модели **не** может обходить prepare/drain: url/space/token/enable отклоняются 409 `use_remote_settings`; запрос отключения тоже проходит guarded barrier, а не прежний cancel. Отказ лучше несовместимого silent switch.
- До явной активации новой identity модели старый формат работает в прежнем режиме; activation выполняется только после drain/обновления редакторов. После активации старые HTTP mutations без generation отвергаются, даже если target ещё не менялся. Read-only status остаётся совместимым. Не обещать old wire mutation compatibility новой модели и не подставлять актуальную generation в старый callback.
- Расширить document save contract: editor получает backend lease `editor_id + binding_generation`, а collab save ещё и sid. При принятом lease old generation/unknown sid = 409 **до DocStore.write**, не downgrade к обычному save. Stale callback не изменяет даже локальный файл.
- Все HTTP mutations документов (PUT/create/delete/move/rename, включая folder mutations с документами) после активации новой identity модели обязаны передавать `expected_binding_generation`; browser editor дополнительно передаёт editor_id, collab — sid. Отсутствующая generation у старого HTTP-клиента = 409 `reload_required`, не обход как «agent write». REST-интеграции получают актуальную generation через P/remote и обновляют контракт явно. Встроенный MCP write_doc/agent работает через bound backend DocStore, а не через старый browser HTTP payload: остаётся локальной операцией своего Ctx; барьер сериализует такие записи. После commit они не публикуются автоматически: новый destination disabled до следующего preview. Активный legacy project WS без capability editor-lease/flush требует закрытия/reload перед cutover; молчание клиента не доказывает отсутствие dirty текста.
- Project event `remote.binding_change` несёт phase/change_id/from/to/generation без secrets, строго внутри Ctx. Frontend reload metadata — не `project.opened`, не invalidate/rebind ProjectSession и не reload renderer.

## 6. Взаимодействие с новым серверным каталогом

**В текущем Remote этих маршрутов каталога нет.** Ниже согласованный будущий wire VS-89/VS-90, не утверждение реализации. Remote — отдельный пакет; Studio повторяет protocol-константы, не импортирует Remote. Локальные API §5 — адаптеры, не wire Remote.

| Wire Remote v2 | Контракт Studio adapter |
| --- | --- |
| GET `/healthz` | Без auth: service/version/protocol + supported_protocols:[2], catalog_api:2. Discovery, не проверка ключа. |
| GET `/api/v2/me` | Bearer; `{protocol:2,catalog_api:2,capabilities,user:{id,display_name,color}}`. Нужны project_catalog, explicit_project_create, strict_connect; для Preview/миграции также project_snapshot/legacy_resolution. Проверка не открывает WS и не создаёт space. |
| GET `/api/v2/projects?limit=100&after=<ID>` | `{protocol:2,projects:[Project],next_after:ID\|null}`. Limit 1–200, keyset ASCII ID; after — валидный ID, не обязательно существующий. Между страницами нет snapshot-гарантии: dedup по ID, refresh при гонке. Локальный cursor/next_cursor §5.1 — только alias after/next_after, не иная серверная pagination. |
| GET `/api/v2/projects/{id}` | `{protocol:2,project:Project}` или 404 project_not_found. Только exact ID. |
| POST `/api/v2/projects` | **Только `{id,display_name}`**; 201 `{protocol:2,project:Project}`, Location на GET, пустой проект seq=0; занятый ID всегда 409 project_exists, даже с той же подписью. |
| GET `/api/v2/projects/{id}/snapshot` | Read-only content/hash/rev/tombstones для preview, правила ниже. Без room/WS/create/put. |
| GET `/api/v2/legacy-spaces/resolve?name=<exact-old-selector>` | `{protocol:2,legacy_space_name,project:Project}` либо 404 legacy_space_not_found. Exact сохранённый mapping, не fuzzy lookup и не connect fallback. |
| WS `/api/v2/sync?space=<ID>` | Только существующий ID, hello protocol:2, user:{id,display_name,color}, space:{id,display_name,storage_epoch}, seq. Lookup-only на upgrade/hello/sync/join/put/delete/reconnect. |

`Project = {id,display_name,storage_epoch,metadata_revision,created_at}`. Локальный `CatalogProject` сохраняет эти поля и может называть storage_epoch `space_instance_id` только как явный alias 1:1. `catalog_instance_id` в prepare и incarnation в preview — alias storage_epoch. Preview fingerprint — отдельная локальная проверка актуальности назначения, конфигурации, локальных файлов и серверного snapshot; он не равен epoch и не является дополнительным wire-полем Remote. Каталожный id = persistent_id = query space = hello.space.id; room_epoch и backend epoch — другие сущности.

Все `/api/v2/*` используют только `Authorization: Bearer <personal key>`, без query/body/cookie fallback; ключ не отправляется на redirect/другой URL. REST error — `{error:{code,message,request_id}}`: 400 invalid_id/invalid_display_name/invalid_request, 401 unauthorised, 404 project_not_found (resolve: legacy_space_not_found), 409 project_exists/metadata_conflict/snapshot_changed, 413 payload_too_large, 503 temporarily_unavailable. Studio переводит их в локальные typed errors §5 и EN/RU, **кроме** возвращённых CreateResult: целевой POST mapping шести outcomes — §5.1; локальные 422/CAS 409 не являются статусами Remote. Не показывать raw body/message/секреты.

Create вызывается только явной командой. Локальный operation_id §5.1 **не передаётся Remote**, не даёт replay и не доказывает авторство записи. После timeout/обрыва нельзя автоматически повторять POST, менять ID или привязывать найденный проект: GET **исходного ID**, показать результат и отдельный Select/подтверждение. При Remote 409 project_exists — conflict и тот же отдельный Select существующего после явного observation, не автоматическая привязка победителя гонки. POST 400/401/404/409 metadata_conflict или snapshot_changed/413 возвращает rejected по §5.1: project=null, только fixed sanitized code, без retry/Select/освобождения operation. POST 503 остаётся unknown; boundary exceptions — typed failures, не outcomes. При 404 повтор Create того же ID допустим только по новому действию пользователя. Даже 201 не заменяет Select → barrier → Preview → Enable; Create не принимает initial documents.

Snapshot: первый GET `?limit=20` возвращает `{protocol:2,snapshot:{id,storage_epoch,seq},documents:[{path,content,hash,rev,deleted,updated_by,updated_at}],next_after:null|path}`. Порядок binary path, все документы с tombstones; limit 1–100 и ≤4 MiB UTF-8 JSON, курсор последнего реально возвращённого path. Продолжение передаёт after + expected_seq + expected_epoch первой страницы; изменение epoch/seq = 409 snapshot_changed, неверные параметры = 400. Первая страница может принять expected_epoch. При изменении отбрасывается **только временный preview**, не drafts/base/очередь, и запускается новый preview. Snapshot не lock: перед Enable повторно сверить epoch/seq/fingerprints, сохранить CAS/conflict handling; безусловный overwrite запрещён. Нет snapshot capability — Enable недоступен.

До **любого sync/put/delete/join** проверяются protocol=2, exact hello.space.id, storage_epoch (локальный space_instance_id), account hello.user.id против текущего verified me.user.id и cursor. ID/account mismatch — остановка без перепривязки к ответу; epoch mismatch или **hello.seq < saved_cursor даже при той же epoch** — blocked rollback/identity recovery. Закрыть socket/комнаты, не выпускать старые pending/live writes и не подтверждать их по старой base; сохранить старые bases/cursor/очередь и локальные Markdown отдельно. Затем read-only согласованный snapshot/full reconciliation и отдельный Preview/Enable; не обнулять cursor с автоматическим initial push и не переназначать старую очередь новому target. Уже принятые exact версии выясняются reconciliation, не blind replay. Пустой/битый hello не означает «новый сервер». Backup rollback с той же epoch не всегда обнаружим: одного сравнения seq недостаточно для обещания полного обнаружения; намеренный destructive restore требует новой epoch (Remote §2.1).

WS terminal close codes: 4400 invalid_request/invalid_id/protocol_upgrade_required, 4401 unauthorised, 4404 project_not_found — прекратить auto retry, показать исправление/Select, не Create. 4408 overload сохраняется. Остальные document/CAS/room semantics прежние; v2 user.display_name также в presence. Yjs не персистируется, чистое открытие не пишет.

Совместимость fail-closed: wire PROTOCOL_VERSION=2, catalog_api=2; schema migration version и admin_rpc_version=1 независимы от них и от package version. Старый сервер protocol=1 допускает HTTP-only Verify, но catalog/create/select/enable новой модели выключены, **никакого v1 WS fallback**. Новый сервер сообщает protocol=2 через legacy v1 me, а v1 WS после auth закрывает 4400 protocol_upgrade_required до lookup/create/Hub. Не угадывать capabilities из marketing version, 404 guessed route либо одного успешного me. Каталог и запрет auto-create — одна серверная приёмочная граница; старый deployment сам по себе не исправляется новым клиентом.

Это не RBAC: валидный личный ключ даёт командный доступ ко всем projects. Studio не посылает admin SSH credentials и не управляет пользователями. **Различие локальных клиентов намеренное**: Studio допускает один профиль на normalized URL в личном home и смену credential только через drain; Android допускает несколько профилей одного URL и account-partition кэша/recovery. profile_id нигде не wire ID/права. Android account partition не переносится как новая модель хранения Studio; verified account/hello и барьеры credentials всё равно обязательны.

## 7. Безопасная смена ID, сервера или режима sync

**Редактирование ID — смена назначения, не перенос/rename Remote-проекта.** Старые server documents и другие участники остаются там. Нельзя автоматически отправить все текущие файлы в новый ID. Даже после успешной смены проект локально работает, но новый destination остаётся disabled до отдельного preview + Enable.

Алгоритм одинаков для смены ID/URL/profile, disable/unbind и credential rotation потребителей:

1. **Prepare без побочных эффектов.** CAS config/revision, проверка profile, точной записи каталога и локальной duplicate reservation; preview `old URL+ID → new URL+ID`, список affected editors. При create server record может уже существовать, но это не разрешает sync. Cancel не удаляет созданный серверный проект.
2. **Quiesce.** На Ctx identity mutex установить смену; запретить новые joins, auto-rejoin, reconnect в новое назначение, новые browser editor leases и конфликтующие target changes. Приостанавливается только sync/room boundary, **не** job engine/агенты/другие проекты. Обычные DocStore writes кратко сериализуются/возвращают retryable 409 на время final snapshot; external filesystem writes ловятся повторной проверкой fingerprints.
3. **Drain старого назначения.** Все зарегистрированные редакторы этого Ctx (desktop и legacy, не только активная вкладка) временно прекращают ввод, сбрасывают debounce и сохраняют Markdown в старый generation; scribe отправляет финальную запись, backend ждёт ACK pending, затем leave/закрытие rooms. Не разрушать Yjs до успешного извлечения экранного текста. Unreachable/старый editor, dirty room, timeout, save error, offline при неподтверждённом live write — `blocked`, без commit и без discard. Не использовать `_stop_runner` как drain. Не держать send/DocStore locks, пока read-loop должен принять ACK.
4. **Fence.** После ACK/leave запретить все старые sid/leases/continuations; generation проверяется и до записи Markdown, и до отправки в Remote. Закрыть прежний sync socket, дождаться задач старого runner. Никакой pending/old debounce в новый binding. Ошибка на этой стадии оставляет старую identity и явный paused/blocked state; resume старого назначения — отдельное безопасное действие.
5. **Commit одного источника истины.** Повторный CAS и подтверждение пользователя, atomic replace project config: ID/URL/revision и enabled=false. Обновить metadata resident Ctx, снять confirmed consent: select/migrate сохраняют выбранный profile_id/tuple как selected, disable сохраняет прежний выбор как selected, edit_id/unbind очищают private selection. Unbind дополнительно очищает sync.url, но сохраняет локальный ID; disable не меняет ID/URL. Освободить старую destination reservation после закрытия runner; не трогать AppContext paths, frozen descriptor, epoch, main registry, renderer, MCP sessions/agents. Несогласованные multi-file записи не считаются транзакцией: project config — commit point, private binding journal/change_id позволяет recovery; после crash несоответствие revision/tuple всегда disabled/binding_required. Не откатывать remote уже принятые записи.
6. **Отдельное согласование нового назначения.** Preview сравнивает текущий локальный Markdown и выбранный remote; пользователь видит uploads/downloads/deletes/conflict copies. Конфликтная политика остаётся §16.3; не считать её разрешением переносить старые файлы без этой явной команды. Files changed после preview → пересчитать; remote moved → CAS/nack/repreview, не безусловная запись.
7. **Enable/catch-up.** После подтверждения повторно зарезервировать destination и вычислить следующую identity revision R+1. Под journal/change_id атомарно записать project enabled=true с R+1, затем private confirmed binding того же R+1; пока обе записи не совпали, runner не стартует. После crash между ними — disabled/binding_required в effective runtime до recovery. Затем проверить hello (ID/account/storage_epoch и hello.seq < saved_cursor по §6) до sync/отправки; mismatch/rollback блокирует старую очередь и требует recovery, а не cursor reset. Новое назначение использует отдельный namespace базы. Новые rooms создаются только после connected. Не переносить старые Yjs doc, undo, awareness/sid/room_epoch; чистое открытие снова ничего не пишет. Обычная навигация/transfer прежнего runtime остаётся без remount.

Generation: успешный target commit заменяет G на новый random G2 и повышает R на 1; Enable также создаёт G3 и повышает R на 1. Например disable (R1,G1) → (R2,G2,disabled,selected), edit_id → (R3,G3,disabled,no selection), select → (R4,G4,disabled,selected), enable → (R5,G5,enabled,confirmed). Pure profile rename не меняет R/G. После cancel до fence старые leases продолжаются; после fence, даже при отмене/ошибке до commit, старые leases не оживляются: выдать новые leases/generation к тому же старому target и сообщить paused/resume required. Ожидаемые R/G из прежней фазы никогда не подставлять автоматически.

Offline ID edit разрешён, только если нет нерешённых leases/rooms/saves: можно сохранить локальный новый ID без сервера, но нельзя погасить dirty-room blocker кнопкой «продолжить всё равно». Нет принудительного discard в MVP. Несохранённый текст должен оставаться видимым/сохраняемым в старой identity; отдельный crash-draft механизм не добавляется.

Ручной edit config или VCS checkout, изменивший ID/URL при работающем сервисе, не запускает reconfigure. При обнаружении mismatch — fail closed, pause sync, request drain/review; не перечитывать файл как разрешение отправить старую очередь. Возврат старого ID тоже требует нового preview, а не «совпало имя — возобновить cursor».

## 8. Коллизии, копии, имена и перемещение

| Ситуация | Требуемое поведение |
| --- | --- |
| Два проекта с одинаковым display_name, разные ID | Разные записи каталога; UI обязательно показывает ID. Ни merge, ни авто-выбор первой строки. |
| Create с уже занятым ID | 409 conflict. Предложить refresh и явный Select existing либо изменить локальный ID; не заменить подпись/документы и не генерировать тайный суффикс. |
| Один ID на разных normalized URL | Разные назначения, отдельные secrets/bases/confirmations. Переключение URL — §7. |
| Два локальных root с одним ID | Два runtime context/tab и разные UI/draft namespaces. Разрешено открыть оба локально. По умолчанию только **один активный sync consumer на (URL, ID) в одном backend**: атомарная reservation registry, второй получает duplicate_local_binding с root первого. Можно отключить первый через drain либо явно сделать fork с новым ID. Не останавливать чужой job/контекст. |
| Копия папки/clone с enabled=true | Нет private root-binding — sync заблокирован до выбора профиля и preview. «Та же удалённая рабочая копия» = явный select того же ID; «Независимый проект» = edit ID + явный create. Копирование DB IDs не дедуплицирует desktop. |
| Две машины/разные backend процессы | Общая серверная работа нормальна, reconciliation/rooms §16 сохраняются. Локальный reservation не обещает межпроцессный/межмашинный lease. Не вводить глобальную эксклюзивность проекта. |
| Rename local project_name / task project_code | Меняет подпись/префикс, не ID и не sync. Rename display_name на сервере — отдельный explicit API VS-89, не edit локального ID. |
| Rename/move папки | Persistent ID и remote data сохраняются. **Не делать live move**: при resident jobs/paths закрыть вкладку недостаточно — context живёт до shutdown. Пользователь отдельно завершает работу/Studio и переносит папку; это инструкция будущего UX, не действие VS-88. Новый root открывается явно, old restore entry показывает missing root, без поиска по ID и без миграции paths в памяти. |
| Повторное открытие alias root | Тот же canonical root → та же runtime вкладка, независимо от подписи и ID. |
| Папка переехала, private state осталось под старым hash | Не переносить bases автоматически по persistent ID. Новый root требует binding/preview; старое состояние сохранено отдельно. Автоматический поиск moved roots не входит в scope §5.3.6. |
| Server project удалён/recreated с тем же ID | Incarnation mismatch блокирует push/rejoin; никакого восстановления старых документов на новом сервере без подтверждённого preview. |
| Profile URL изменили или key удалили | Нельзя подменить endpoint/credential работающим consumers без drain; нельзя переносить key на новый URL или удалять remote project как побочный эффект. |

Root-based desktop registry остаётся **registry рабочих копий**, а persistent_id — бизнес-идентичность удалённого проекта. «Один проект — одна вкладка» §5.3 здесь означает одну вкладку одной canonical рабочей копии, не слияние всех clone одного Remote space. Restore, notifications и transfer не становятся механизмами угадывания root по ID.

## 9. Явная миграция старых настроек

Миграцию сначала реализовать/проверить на fixtures; выполнение на production требует отдельного разрешения и резервирования данных. Никакая операция этого исследования не переносит действующие настройки.

### 9.1 Read-only план

1. GET migration читает старый project sync config, legacy credential metadata и private base **без подключения sync**, без записи/создания профиля. Diagnostic info/list/recent/GET не должны мигрировать. Не выводить token в план. Если профиль ещё не существует, план останавливается на needs_profile: пользователь отдельной POST migration/profile подтверждает создание/выбор персонального профиля и возможный import ключа. Это отдельное изменение только личных настроек, не часть read-only плана; до него запросы каталога не делаются.
2. Вычислить прежний **эффективный selector** ровно по старому правилу check_space_name, а не из project_name/folder. Пустой space остаётся «не был задан»; никогда не приписывать `default` или slug.
3. После наличия явно выбранного/импортированного profile_id для непустого legacy selector запросить read-only exact legacy resolution у нового каталога (VS-89). Каталог возвращает canonical ID и прежнюю incarnation. Если canonical ID отличается от прежней строки — показать mapping и запросить явное принятие; не принять display_name как ID. Принят единственный migration contract VS-89/VS-90: **canonical ID = прежний UUID spaces.id / v1 hello.space.id, storage_epoch = этот же прежний UUID байт-в-байт**; локальный space_instance_id только alias storage_epoch. Старое имя сохраняется как display_name и exact legacy mapping, никогда как v2 sync alias. Клиент не выбирает альтернативную схему «старое name становится ID».
4. Если catalog ещё нет/сеть offline/ID отсутствует/lookup неоднозначен — migration_required, старые config/base нетронуты. Не открывать v1 WS для выяснения existence: он автосоздаёт.
5. Если sync никогда не был настроен, предложить новый случайный ID либо ручной ввод. Одинаковые названия/папки получают независимые ID. Существующий валидный persistent_id не генерировать заново.

### 9.2 Применение после подтверждения

Apply выполняется только prepare(operation=migrate, migration_plan_id) → quiesce → commit (§5.2), не через GET или старый PUT sync. Все локальные импорты имеют checkpoint/journal; ключ уже перенесён отдельной подтверждённой командой профиля и повторно не копируется при project commit.

- Старый scalar `sync.space` удаляется **только** вместе с успешной записью project_identity.id. До этого legacy data сохраняются как есть. Если оба поля присутствуют и различаются — migration_conflict/disabled, не «побеждает последнее». Невалидный/битый config не заменять defaults.
- Legacy URL нормализуется прежним правилом; глобальный профиль создать/переиспользовать только по точному URL после отдельного POST migration/profile (§5.2), ещё до сетевого resolve. Имя нового профиля пользовательское; совпавшее имя не даёт merge. Существующий профиль/ключ никогда не перезаписывать импортом.
- Старый URL-key импортировать в secret store под выбранный profile_id только когда URL совпадает и там нет другого key. Разные ключи/legacy normalized URL collision → показать credential_conflict без значений; пользователь явно вводит/выбирает ключ. Hash/suffix секрета в UI не нужен.
- Переход secret store атомарный, с проверкой чтения новой записи до удаления старой; journal/checkpoint только в user_config_dir, не в проекте, без копии ключа в отчёте. Невосстановимый malformed secret file не перезаписывать пустым словарём. Backup секрета, если нужен upgrade recovery, с теми же owner-only правами и явной политикой удаления.
- Старую base можно импортировать в новый namespace **только** при совпадении canonical working root, exact URL, подтверждённого legacy mapping и incarnation (canonical ID = old UUID, storage_epoch = old UUID); скопировать/проверить новый state до отказа от старого. Нет доказательства соответствия — оставить старую base и требовать preview; не интерпретировать старый cursor как cursor нового ID.
- Enabled legacy sync сначала проходит §7 drain; применение миграции оставляет disabled до проверки каталога/preview. Идемпотентный повтор не создаёт второй профиль/ID и не включает sync.
- Local binding создаётся отдельным подтверждением на каждой машине/root. В VCS попадает только project identity + URL, без персональной profile/key information.

### 9.3 ENV и старые клиенты

Новый flow принимает `VOXARIUM_STUDIO_REMOTE_TOKEN` только вместе с новым явным `VOXARIUM_STUDIO_REMOTE_URL`, нормализованным и совпавшим с выбранным профилем. Нет пары/несовпадение — environment_unbound, ключ никуда не отправляется; не выбирать «первый» из нескольких серверов. Environment key не сохраняется, UI показывает source=environment, забыть его через UI нельзя — изменить окружение. Не проверять скопированный проект автоматически даже при совпавшем ENV URL.

На старом сервере Settings умеет Verify по текущим health/me, но Project Remote показывает «Каталог недоступен — обновите Remote»; create/select/enable новой модели закрыты. Никакой скрытой legacy fallback записи. Политика обновления уже работающего legacy connection/старых Android клиентов согласуется в VS-89/VS-90 до переключения deployment; исследование не отключает действующих пользователей.

## 10. UI EN/RU

Settings остаётся глобальной страницей, не project store оболочки. В desktop shell не добавляется sync client/Pinia проекта. Глобальный компонент Settings → Remote servers доступен из обычного project renderer через global API; изменение metadata не меняет active root.

### 10.1 Глобальные профили

Карточки показывают name, URL, key stored/missing/environment и результат **последней** проверки со временем/пользователем, а не вечный зелёный «подключено». Add/Edit form: имя, URL, пустое password поле, Save, Verify, Forget key, Delete profile. Password не возвращается после сохранения; verify использует уже сохранённый key. Пустое поле = keep, удаление отдельной кнопкой. Busy consumers отображаются с root и предложением открыть их Remote settings, без их silent disable.

HTTP вне loopback требует отдельного явного предупреждения о передаче личного ключа открытым текстом перед Verify/Enable; default fail closed. Redirect с Authorization к другому URL/origin запрещён; не following redirect в верификации. Loopback exception не отменяет валидацию URL.

### 10.2 Project Settings → Remote

1. Всегда виден локальный Project ID, отдельные Name/Folder read-only labels для различения. Поле ID редактируемо с явным Apply и confirmation; подсказка «не переименование на сервере».
2. Server picker показывает имя + URL из **глобального** списка; здесь нет password/URL editor. «Manage servers» открывает Settings → Remote servers.
3. Кнопки «Choose existing project» и «Create server project». Каталог — ID крупно/mono, display name вторым полем; search фильтрует, но выбор всегда по ID. Название папки может быть предложено только для display_name формы create, не для ID.
4. Create form показывает текущий локальный ID, display_name и точный URL. Если пользователь изменил ID, сначала guarded local edit; затем явный create. Успех не включает sync, не загружает docs, не выбирает другую запись по совпавшему имени.
5. Select существующего с другим ID показывает old→new ID и target URL. Подтверждение меняет локальный ID через §7; не перемещает файлы/remote data.
6. После bind — Preview, список счётчиков/конфликтов, отдельная «Enable and reconcile». В процессе quiesce ввод/повторный submit заблокированы, видны неответившие редакторы. Cancel/save failure возвращает старое назначение или явный paused state, без discard.
7. При коллизии root, migration_required, unknown project, mismatch и catalog unavailable — понятный blocking state, не список пустых «успешных» проектов.

### 10.3 Ключи строк для реализации

Все новые строки одновременно в `frontend/src/locales/en.json` и `ru.json`, через t()/I18nT; backend отдаёт typed codes. Существующие общие Save/Cancel/Retry переиспользовать, не hardcode.

| Key | EN | RU |
| --- | --- | --- |
| remoteServers.title | Remote servers | Remote-серверы |
| remoteServers.add | Add server | Добавить сервер |
| remoteServers.name | Profile name | Имя профиля |
| remoteServers.url | Server URL | URL сервера |
| remoteServers.key | Personal key | Личный ключ |
| remoteServers.keyStored | Key stored; leave blank to keep it | Ключ сохранён; оставьте поле пустым, чтобы не менять его |
| remoteServers.keyMissing | No key stored | Ключ не сохранён |
| remoteServers.environment | Key supplied by environment | Ключ задан окружением |
| remoteServers.verify | Verify connection | Проверить подключение |
| remoteServers.verified | Verified as {name} at {time} | Проверено: {name}, {time} |
| remoteServers.forget | Forget key | Забыть ключ |
| remoteServers.delete | Delete local profile | Удалить локальный профиль |
| remoteServers.inUse | This profile is used by {roots}. Disconnect them safely first. | Профиль используется: {roots}. Сначала безопасно отключите эти проекты. |
| remoteServers.insecure | Your personal key will be sent without encryption to {url}. | Ваш личный ключ будет передан без шифрования на {url}. |
| remoteServers.duplicate | A profile for this URL already exists. | Профиль с таким URL уже существует. |
| projectRemote.title | Remote | Remote |
| projectRemote.id | Project ID | ID проекта |
| projectRemote.idHint | This ID is the Remote space, not the project name or folder. | Этот ID — пространство Remote, а не название проекта или папки. |
| projectRemote.applyId | Apply ID change | Применить смену ID |
| projectRemote.manage | Manage servers | Управление серверами |
| projectRemote.choose | Choose existing project | Выбрать существующий проект |
| projectRemote.create | Create server project | Создать проект на сервере |
| projectRemote.displayName | Display name | Отображаемое имя |
| projectRemote.preview | Preview reconciliation | Проверить согласование |
| projectRemote.enable | Enable and reconcile | Включить и согласовать |
| projectRemote.changeWarning | Change {oldId} to {newId} on {url}? This does not rename or move server documents. Sync will stay disabled until you review reconciliation. | Сменить {oldId} на {newId} на {url}? Документы на сервере не переименуются и не переместятся. Синхронизация останется выключенной до проверки согласования. |
| projectRemote.draining | Saving edits and leaving old rooms… | Сохраняем правки и выходим из прежних комнат… |
| projectRemote.pending | Could not confirm saved edits in {editors}. No ID change was applied. | Не удалось подтвердить сохранение в {editors}. ID не изменён. |
| projectRemote.catalogUnavailable | Project catalog is unavailable. Update Remote; no project was created. | Каталог проектов недоступен. Обновите Remote; проект не создан. |
| projectRemote.exists | This ID already exists. Choose it explicitly or use another ID. | Такой ID уже существует. Выберите его явно или используйте другой ID. |
| projectRemote.migration | Review legacy Remote settings before enabling sync. | Проверьте прежние настройки Remote перед включением синхронизации. |
| projectRemote.bindingRequired | Select your server profile and review this working copy. | Выберите свой профиль сервера и проверьте эту рабочую копию. |
| projectRemote.duplicate | Another working copy at {root} is already syncing to this URL and ID. | Другая рабочая копия {root} уже синхронизируется с этим URL и ID. |
| projectRemote.instanceMismatch | The server project changed. Review it before sending any documents. | Серверный проект изменился. Проверьте его перед отправкой документов. |
| projectRemote.idInvalid | Use 1–64 lowercase ASCII letters, digits, dots, underscores or hyphens; start with a letter or digit. | Используйте 1–64 строчных ASCII-буквы, цифры, точки, подчёркивания или дефисы; начните с буквы или цифры. |

Error code → UI message mapping также локализовать (unauthorised/offline/incompatible/stale/blocked). Для новых недостающих ключей повторно расширить точный write scope будущей UI-задачи; перечисленные строки — обязательный минимум, не разрешение показывать остальные ошибки raw traceback.

## 11. Маленькие задачи реализации

Ниже **предложения**, не созданные/запущенные карточки. Пути относительно `D:\VoxariumStudio`; каждый список — полный предлагаемый write_paths без globs. Новые файлы отмечены «новый». Общие файлы повторяются между последовательными задачами намеренно: не выпускать их параллельно без serial dependency/locks. Read-only references в locks не включать.

### S0 — Свести wire-контракт и обновить spec

Зависимости: одобрены VS-88/VS-89/VS-90; принят серверный catalog/strict-connect/snapshot контракт. Не ждать их реализации ради документа, но не выпускать интеграцию без неё.

`write_paths`:
- `docs/voxarium-studio-dev-spec.md`

Приёмка: §5.2/§5.3.2/§16.1–16.5 различают persistent selector, opaque incarnation и runtime handle; name не lookup key; profiles global, ключи отдельно; root registry/restore неизменны. Конкретные Remote routes/version берутся из VS-89, не из догадок. Review трёх клиент/сервер контрактов и Markdown diff check.

### S1 — Добавить persistent ID и read-only migration plan

Зависимость S0.

`write_paths`:
- `backend/voxarium_studio/core/config.py`
- `backend/voxarium_studio/core/project_identity.py` — новый
- `backend/voxarium_studio/core/project.py`
- `backend/voxarium_studio/api/project.py`
- `backend/tests/test_project_identity.py` — новый
- `backend/tests/test_project_scopes.py`

Приёмка: модель §4.1, metadata с отдельным persistent_id; UUID только при explicit init/migration apply, не GET/info/recent. Старые space пустой/валидный/битый и conflicting fields дают план без записи/сети; имя и папка никогда не генерируют общий ID. Смена metadata не меняет descriptor/epoch/ctx. На этом этапе mutation публично выключена до S5.

### S2 — Глобальные профили и безопасное хранение личных ключей

Зависимости S1 (пересечение core/config), S0.

`write_paths`:
- `backend/voxarium_studio/core/application_config.py`
- `backend/voxarium_studio/core/config.py`
- `backend/voxarium_studio/sync/profiles.py` — новый
- `backend/voxarium_studio/sync/credentials.py`
- `backend/tests/test_remote_profiles.py` — новый
- `backend/tests/test_application_settings.py`

Приёмка: metadata отдельно от secret; URL collision/CAS/atomic writes; malformed secret file не затирается; legacy import идемпотентен, existing key не перезаписывается. ENV только с exact URL. Project save не пишет globals, application GET никогда не возвращает key. Временные fixtures только task temp будущего исполнителя.

### S3 — Глобальный REST и каталог-адаптер

Зависимости S2; для реальных requests — готовая реализация server catalog/strict-connect/snapshot по VS-89. Пока её нет, contract tests с fake adapter, production capability disabled.

`write_paths`:
- `backend/voxarium_studio/api/remote.py` — новый
- `backend/voxarium_studio/api/__init__.py`
- `backend/voxarium_studio/sync/catalog.py` — новый
- `backend/voxarium_studio/sync/protocol.py`
- `backend/tests/test_remote_api.py` — новый
- `backend/tests/test_remote_catalog.py` — новый

Приёмка: §5.1/§6, authenticated no-store, verify не создаёт space; list/create только через agreed adapter; неизвестная версия блокирует flow. Redirect/credentials in URL/ошибки не раскрывают key. Conflict/unknown Create outcome разрешаются GET исходного ID + отдельным Select без автоматического POST/rebind; operation_id только локальный журнал, не server replay. Одинаковые display_name различимы. Публичные wire константы меняются согласованно с Remote владельцем; не импортировать remote пакет в production Studio.

### S4 — Namespace баз, private binding и локальная reservation

Зависимости S3.

`write_paths`:
- `backend/voxarium_studio/sync/state.py`
- `backend/voxarium_studio/sync/bindings.py` — новый
- `backend/voxarium_studio/core/workspace.py`
- `backend/tests/test_remote_bindings.py` — новый
- `backend/tests/test_workspace.py`

Приёмка: §4.3/§8; root+URL+ID+incarnation checks, отдельные namespaces, clone без consent не стартует; atomic reserve/release для одного destination; aliases root не дают второй reservation. Incarnation mismatch и hello.seq < saved_cursor блокируют sync/push до безопасного recovery §6. Legacy base импортируется только по доказанному mapping, без удаления старого.

### S5 — Backend cutover и save fencing

Зависимости S4, S1; S3 с совместимым сервером для интеграции.

`write_paths`:
- `backend/voxarium_studio/api/sync.py`
- `backend/voxarium_studio/api/docs.py`
- `backend/voxarium_studio/teams/docs.py`
- `backend/voxarium_studio/core/context.py`
- `backend/tests/test_docs.py`
- `backend/voxarium_studio/sync/service.py`
- `backend/voxarium_studio/sync/transitions.py` — новый
- `backend/voxarium_studio/ws/routes.py`
- `backend/voxarium_studio/ws/events.py`
- `backend/tests/test_remote_transitions.py` — новый
- `backend/tests/test_remote_sync.py`

Приёмка: §5.2–5.3/§6–7, rollback hello.seq < saved_cursor с сохранением базы/очереди до recovery, регистрация/heartbeat editor leases, ACK/generation до DocStore.write и remote send, drains перед leave, общий DocStore mutation gate для write/delete/move/folder rename (не только HTTP), offline/timeout blocked, stale sid не становится обычным write. Commit оставляет disabled; failure/restart в каждой фазе не активирует новый target. Old PUT /sync не обходит barrier. Тест A/B, identical doc path/copied IDs, активный агент B и открытая legacy сессия — B не затрагивается.

### S6 — Frontend API и состояния без runtime rebind

Зависимость S5.

`write_paths`:
- `frontend/src/api/types.ts`
- `frontend/src/api/client.ts`
- `frontend/src/api/project-scope.ts`
- `frontend/src/api/project-scope.spec.ts`
- `frontend/src/stores/remote-servers.ts` — новый
- `frontend/src/stores/remote-servers.spec.ts` — новый
- `frontend/src/stores/sync.ts`
- `frontend/src/stores/sync.spec.ts` — новый
- `frontend/src/ws/events.ts`

Приёмка: global paths не получают active project selector, project requests захватывают runtime binding; late responses old target/generation игнорируются; secret не хранится в Pinia. GET /sync compatibility не становится mutation API. Renderer ProjectSession не bind-ится заново при metadata change.

### S7 — Editor quiesce handshake

Зависимость S6.

`write_paths`:
- `frontend/src/components/docs/BlockEditor.vue`
- `frontend/src/views/DocsView.vue`
- `frontend/src/views/DocsView.spec.ts`
- `frontend/src/stores/docs.ts`
- `frontend/src/stores/docs.spec.ts`
- `frontend/src/lib/collab/session.ts`
- `frontend/src/lib/collab/session.spec.ts`
- `frontend/src/lib/collab/editor.spec.ts`

Приёмка: flush debounce/Markdown до ACK, input freeze/cancel/resume без потери экранного текста; generation на обычном и collab save; old callback не пишет после commit, не auto-join нового target. Offline/неответивший editor блокирует, чистое open и live transfer не пишут. jsdom test двух реальных редакторов обязателен, не только mock store.

### S8 — Двуязычный UI серверов и проекта

Зависимость S7 (общие frontend файлы теперь стабильны).

`write_paths`:
- `frontend/src/views/SettingsView.vue`
- `frontend/src/views/ProjectSettingsView.vue`
- `frontend/src/components/settings/RemoteServersSettings.vue` — новый
- `frontend/src/components/settings/RemoteServersSettings.spec.ts` — новый
- `frontend/src/components/settings/SyncSettings.vue`
- `frontend/src/components/settings/SyncSettings.spec.ts` — новый
- `frontend/src/locales/en.json`
- `frontend/src/locales/ru.json`

Приёмка: §10, explicit Apply/Create/Select/Preview/Enable, одинаковые имена различимы по ID/URL. Cancel/credential failure/conflict не включают sync; password очищается; in-use profiles не изменяются скрыто; EN/RU keys/placeholders в parity. npm typecheck/test/build в выделенной проверке; generated static не редактировать вручную.

### S9 — Применение миграции и crash recovery

Зависимости S8, S5; готовый server legacy-resolution contract.

`write_paths`:
- `backend/voxarium_studio/api/sync.py`
- `backend/voxarium_studio/core/project_identity.py`
- `backend/voxarium_studio/sync/profiles.py`
- `backend/voxarium_studio/sync/bindings.py`
- `backend/voxarium_studio/sync/state.py`
- `backend/voxarium_studio/sync/transitions.py`
- `backend/tests/test_remote_identity_migration.py` — новый

Приёмка: §9 fixtures (empty space, two same names, normalized URL collision, conflicting keys, missing catalog, corrupt config/state, renamed/copied root, changed incarnation, disk-full/replace failure). Повтор/процессный crash между каждой записью не смешивают namespace и не теряют старый key/base. Только fixture migration — production запрещён без отдельного задания.

### S10 — Runtime/desktop регрессии и итоговая fixture-проверка

Зависимость S9.

`write_paths`:
- `backend/tests/test_project_scopes.py`
- `backend/tests/test_desktop_project_isolation.py`
- `backend/tests/test_remote_sync.py`
- `desktop/test/tabs.test.cjs`
- `desktop/test/session-state.test.cjs`
- `frontend/src/desktop/project-storage.spec.ts`

Приёмка: разные roots/одинаковый persistent ID — два descriptors/tab; ID edit не вызывает ensure/loadURL/remount/backend restart; same-root aliases — одна вкладка. Restore свежей epoch по root, missing moved root без fallback по ID; storage/drafts/plugin bindings/notifications не переключаются. Изменение production desktop registry для этого контракта не требуется.

## 12. Матрица приёмки и фактическая проверка VS-88

| Приёмочный сценарий будущей реализации | Проверить не только HTTP-ответ |
| --- | --- |
| Verify/list/create в global Settings при активном B | Config/docs/WS A и B не изменились; space не создан verify/list; не ушли ключи другого URL. |
| Select существующего проекта с другим ID при dirty room | Сначала финальный Markdown в старом binding + ACK; при timeout ни ID, ни новый remote docs не изменены. |
| Late collab/обычный editor save после commit | 409 до локальной записи; ни старое, ни новое remote назначение не получило callback. |
| Commit succeeded, Enable ещё не нажат | Local ID новый, runtime descriptor прежний, sync disabled, old docs не отправлены новому space. |
| Same ID/display names/copy/VCS checkout | Нет merge по имени/папке; root storage раздельны; second local consumer blocked; agents продолжаются. |
| Server DB replacement, ID reused; rollback с hello.seq < saved_cursor при той же epoch | До sync/put/delete/join blocked; старые bases/cursor/pending сохранены, отдельный согласованный recovery/preview, без cursor reset + auto-push. |
| Старый сервер/старый клиент | Нет probe sync с автосозданием; capabilities/version явны; unsupported flow disabled, не silent legacy fallback. |
| Malformed config/secrets, crash/disk errors на миграции | Нет default overwrite; old data сохранены; несовпадение private/project revisions не активирует sync. |
| Secrets canary в ответах/логах/manifest/config/exception | Canary отсутствует везде, кроме личного secret store и Authorization transport exact URL; no redirect leakage. |
| Open clean editor/transfer/reconnect без правок | Markdown byte-equivalent, Yjs не персистируется; immutable runtime bindings и WS scope сохраняются. |

Будущие проверки: targeted backend suites из S1–S10, existing `test_workspace.py`, `test_application_settings.py`, `test_project_scopes.py`, `test_remote_sync.py`; frontend Vitest + `npm run typecheck` + `npm run build`; desktop node tests. Для backend интеграции Remote должен быть установлен в тестовом окружении: `importorskip` в test_remote_sync означает, что **skipped не считается passed**. Проверки выполняются на изолированных fixtures/task temp, без обращения к production; сетевой GUI smoke — отдельная согласованная задача по штатному launcher, не запуск второго backend.

В VS-88 выполнена статическая сверка: Graphify → текущие владельцы конфигурации/API/sync/rooms/runtime/desktop, dev spec §5/§16; две независимые read-only проверки runtime и sync интегрированы. Обнаружены важные разрывы: нет public catalog/create, нет persistent ID, немедленный reconfigure не drain, stale sid сейчас не запрещает DocStore.write, ENV-key имеет слишком широкую URL область. **Тесты и серверы не запускались**; документ не утверждает готовность будущего API, установленного приложения или production миграции. Документ прошёл независимый read-only review runtime/cutover и profiles/migration; найденные противоречия схем/порядка commit и write scope устранены. Проверены парность Markdown fences и отсутствие trailing whitespace; git diff --check не сообщил ошибок (есть существующие CRLF notices). Чужой dirty checkout сохранён; единственный deliverable VS-88 — этот документ.

## 13. Закрытые междокументные расхождения — VS-91

Сверены результаты VS-88/VS-89/VS-90; это корректировка документации первого этапа, не реализация и не разрешение миграции/deploy. Таблица отделяет реальные исправления от намеренных различий адаптеров.

| Расхождение / проверка | Согласованное решение и места |
| --- | --- |
| Studio §5.1/§6/S3 обещали идемпотентный Create/operation_id на Remote | Исправлено: Remote POST только {id,display_name}, без server replay. operation_id — локальный журнал, не гарантия повтора; timeout → GET исходного ID и отдельный Select, 404 → Create того же ID лишь по команде пользователя, никакого auto-bind победителя гонки. Studio §5.1/§6/S3; Remote §3.1–3.4; Android §4.2/§4.2.1. |
| Studio §9.1 допускал canonical ID = прежнее name | Удалена альтернатива: canonical ID = прежний UUID spaces.id/v1 hello.space.id, storage_epoch = тот же UUID байт-в-байт; old name — подпись/exact mapping, не sync alias. Studio §9.1–9.2; Remote §2.1/§5.1; Android §3.1/§5.2. |
| Studio incarnation могла читаться как отдельное wire-поле | space_instance_id — только локальный alias storage_epoch 1:1; v2 hello.space.id — canonical ID, не epoch. Studio §3/§4.3/§6; Remote §3.4; Android §12. |
| Studio не проверял hello.seq < saved_cursor при той же epoch | До sync/write/join blocked recovery, сохранение bases/cursor/pending/Markdown; read-only snapshot/full reconciliation и отдельное подтверждение, не reset+auto-push. Studio §4.3/§6/§7/S4/S5/§12; Remote §2.1/§3.1; Android §3.1/§5.3. Не обещано обнаружение всех backup rollback. |
| Display validation Studio была слабее wire | Серверные новые/редактируемые подписи: NFC+trim, 1–120 code points/≤480 bytes, запрет C0/C1/DEL/line breaks/bidi override/isolate. Legacy подписи сохраняются буквально, безопасное отображение; локальные labels отделены. Studio §3.1; Remote §2.2/§5.1; Android §4.2.1. |
| Versions/routes/errors/pagination/snapshot — разные имена локального API и Remote | Не конфликт: wire v2/catalog_api=2, exact routes/envelopes/after/next_after и snapshot expected_seq/expected_epoch/409 snapshot_changed зафиксированы в Studio §6 по Remote §3 и Android §4.2.1. Локальные cursor/items/422 остаются адаптером, не альтернативным wire. |
| Один профиль/URL Studio против нескольких Android и account partitions | Намеренное локальное различие, не серверные права: Studio drain credential changes, Android account partitions; не навязывается новая storage модель Studio. Studio §6; Remote §11; Android §12. |
| No-auto-create, сохранность очередей и внешние ограничения | Согласованы, не расширены: lookup-only v2, v1 WS отказ до Hub, никаких fallback/переназначений старых pending; runtime/root bindings, hash-only Remote keys, Android gates/INTEROP остаются прежними. Studio §6–9; Remote §4–7; Android §5/§6/§8. |

Проверка VS-91: Graphify использован для навигации (ответ общий по исходникам, актуальные три документа прочитаны напрямую через Studio). Первичный независимый read-only review выявил Create/migration/rollback/display/alias расхождения; правки внесены только в три объявленных документа. Финальное независимое read-only review и статические проверки фиксируются ниже; сборки, runtime-тесты, серверы и deploy не выполняются.

Финальный независимый read-only review VS-91: **PASS** после отделения preview fingerprint от storage_epoch; повторно проверены Studio §6 и Android §5.3. Прочитаны все результаты субагента; readback трёх документов совпал с сохранёнными версиями, Markdown fences парны, таблицы имеют согласованное число колонок, trailing whitespace отсутствует. Общий git checkout содержит чужие изменения; они не редактировались. Проверка git diff --check не дала ошибок, но эти shared docs не отображаются в git diff, поэтому их содержимое дополнительно проверено напрямую, не выдано за покрытое git-проверкой.
